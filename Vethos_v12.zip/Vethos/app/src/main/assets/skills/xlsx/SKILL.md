---
name: Spreadsheets
description: Use when the user wants a spreadsheet, table, budget, tracker or list of records to calculate with.
---

1. Make the table as CSV text: first row = column names, comma separated, quotes around text with commas.
2. Save it with file_create using a name ending in .csv (for example budget.csv). It opens in any spreadsheet app.
3. Use the resource file example.csv (read_skill_file) as a model of the layout.
4. For totals, calculate with the calc tool and write the results in the table.
