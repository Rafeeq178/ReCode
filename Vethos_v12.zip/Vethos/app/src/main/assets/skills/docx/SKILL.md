---
name: Word documents
description: Use when the user wants a Word document (.docx) or asks to write a letter, report, memo or essay to keep.
---

1. On this phone there is no Word writer. Write the full document as clean Markdown (headings, short paragraphs, lists).
2. Save it with the tool file_create, name ending in .md (for example report.md). Tell the user it can be opened and copied into Word or Google Docs.
3. If the user needs a real .docx file, say so plainly and suggest writing it on a computer.
4. For edits to an existing document, use file_read, then file_edit for each change.
