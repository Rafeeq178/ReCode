---
name: About Vethos
description: Use when the user asks what Vethos can do, how to add a tool, a skill or a model, or why something does not work.
---

1. Vethos runs AI models on the phone. Nothing is sent to the internet unless the user switches on the web tools (Phone tools → Web search / Read web page).
2. Models: Library → download one or pick a file. Liquid AI (LFM) models are the fastest on phones. The model stays in memory after it loads, so new chats open at once.
3. Tools: Phone tools. A tool of your own: Phone tools → "+ Add my own tool".
4. Skills: Skills screen. A skill is a folder with SKILL.md and optional resources.
5. Files and designs: Phone tools → My files & designs.
6. If the model says it can not load: the model type is not supported by this engine. Pick another model, or update Vethos.
