---
name: Email writer
description: Use when the user wants an email or formal message written.
---

1. Use what the user gave. Write a subject line, a greeting, a short body (3-5 sentences) and a polite closing.
2. Keep the tone the user asked for (formal by default).
3. Output only the email.
