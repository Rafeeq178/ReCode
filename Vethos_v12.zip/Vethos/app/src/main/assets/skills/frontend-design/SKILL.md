---
name: Web page design
description: Use when the user asks for a web page, a landing page, a poster-like page, an app screen or a visual design.
---

1. Decide the look first: one main colour, one accent colour, one font family, clear spacing (16px gutters).
2. Write ONE complete HTML file with CSS inside a style tag. It must work on a phone (viewport meta, no fixed widths).
3. Use the tool design with a title and the full html. The page opens only when the user taps it in My files & designs.
4. Follow the checklist in checklist.md (read_skill_file) before you answer.
