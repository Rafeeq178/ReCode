# Design checklist
- Phone width first (16px side space, no horizontal scroll)
- One accent colour, used sparingly
- Headline larger than body text, body at least 16px
- Buttons at least 44px high
- Works without internet (no external fonts or scripts)
- Light and dark: use one background colour and one text colour
