---
name: Morning brief
description: Use when the user asks for a morning brief, a daily plan or today's to-do summary.
---

1. Use user_time to get today's date. Use calendar_add only if the user asks to add something.
2. Write a short brief: date, 3 priorities (ask for them if the user gave none), and one tip for the day.
3. Keep it under 120 words.
