---
name: Reading PDF text
description: Use when the user attached a PDF and asks what it says, for a summary or a specific fact.
---

1. Use read_file to get the text of the PDF (the phone extracts it).
2. If the text is empty, the PDF is a scanned image. Say that the text can not be read, and ask for a text copy.
3. Answer from the text only. Quote the exact line when a number or date matters. Keep the summary to 5 bullet points unless asked.
