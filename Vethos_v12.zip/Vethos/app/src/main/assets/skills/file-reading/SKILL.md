---
name: Reading files
description: Use when the user attached or mentions a file and needs its content read: text, code, Word, PDF, CSV.
---

1. Use read_file to pick the file. It returns the text (up to a few thousand characters).
2. For CSV or tables, read the header first, then name the columns in your answer.
3. For code, say the language and what the file does in one line before the details.
4. If the text was cut, say so and ask which part the user needs.
