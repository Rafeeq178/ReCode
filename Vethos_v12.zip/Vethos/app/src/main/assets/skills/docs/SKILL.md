---
name: Documents and notes
description: Use when the user asks for notes, a plan, a letter or a document to keep or share.
---

1. Write the document in Markdown with a title, short sections and bullet points where they help.
2. Save it with file_create (name ending in .md). Tell the user where it is: Vethos → My files & designs.
3. Keep the wording simple. Use the language the user writes in.
