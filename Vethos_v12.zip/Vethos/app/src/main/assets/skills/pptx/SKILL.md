---
name: Presentations
description: Use when the user wants a slide deck or presentation (PowerPoint, slides, talk outline).
---

1. A .pptx file cannot be made on this phone. Make the content instead: a slide-by-slide outline.
2. For each slide write: Title, 3 short bullet points, and one line of speaker notes.
3. Save the outline with file_create as slides.md. If the user wants a visual deck, use the tool design to save an HTML slideshow page (one slide per screen, arrows with buttons).
