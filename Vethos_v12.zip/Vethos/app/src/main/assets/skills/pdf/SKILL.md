---
name: PDF files
description: Use when the user asks about a PDF: making one, merging, splitting, forms or reading its text.
---

1. Creating or changing a PDF file is not possible on this phone. Say so in one line.
2. Offer the closest useful result: a clean Markdown or text version saved with file_create, which can be printed to PDF from any app.
3. For reading a PDF the user attached, use the tool read_file (it extracts the text).
