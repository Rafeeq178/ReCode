---
name: Explain simply
description: Use when the user says explain, samjhao, or asks how something works.
---

1. Start with a one-sentence answer.
2. Then explain in 3-5 short steps with a simple everyday example.
3. Avoid jargon; if you must use a term, define it in a few words.
