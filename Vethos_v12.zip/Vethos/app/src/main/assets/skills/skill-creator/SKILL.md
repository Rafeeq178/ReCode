---
name: Making skills
description: Use when the user wants to create, edit or improve a skill (saved instructions for a special task).
---

1. Ask for the task in one sentence, and the answer format the user wants.
2. Write the skill as: a short name, a one-line description that says WHEN to use it, then numbered steps.
3. Keep it under 30 lines. Put long examples or templates in the skill's resources folder.
4. Give the user the finished text and tell them to paste it in Skills → New skill.
