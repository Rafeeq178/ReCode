package com.vethos.app.tools

import android.content.Context
import androidx.activity.ComponentActivity
import com.vethos.app.R
import com.vethos.app.data.Store
import org.json.JSONObject

/** text = what the user sees. data = optional content that is also given back to the model (file text, clipboard...). */
class ToolResult(val ok: Boolean, val text: String, val data: String? = null)

/** key = JSON argument name the model uses; label/hint = what the manual "Try" form shows. */
class ToolParam(val key: String, val label: String, val hint: String = "", val optional: Boolean = false)

/** Everything a tool needs to touch the phone. */
class ToolCtx(
    private val a: ComponentActivity?,
    /** works with or without a screen */
    val ctx: Context,
    private val p: PermHelper?,
    private val l: Launchers?,
) {
    /** normal use: a screen (activity) is open */
    constructor(act: ComponentActivity, perms: PermHelper, launch: Launchers) : this(act, act.applicationContext, perms, launch)

    val hasScreen: Boolean get() = a != null
    val act: ComponentActivity get() = a ?: throw IllegalStateException(NEEDS_SCREEN)
    val perms: PermHelper get() = p ?: throw IllegalStateException(NEEDS_SCREEN)
    val launch: Launchers get() = l ?: throw IllegalStateException(NEEDS_SCREEN)

    companion object {
        const val NEEDS_SCREEN = "This step needs the screen. Open Vethos and run it again."
    }
}

class ToolDef(
    val id: String,
    val title: String,
    val desc: String,
    val icon: Int,
    /** sensitive tools always ask "Allow?" before they run from a chat */
    val sensitive: Boolean,
    val params: List<ToolParam>,
    /** one compact line for the model's system prompt */
    val usage: String,
    val run: (ToolCtx, JSONObject, (ToolResult) -> Unit) -> Unit,
    /** if set, decides per call whether "Allow?" is asked (overrides [sensitive]) */
    val askWhen: ((JSONObject) -> Boolean)? = null,
    /** true = works in the background with no screen (automations that run by themselves) */
    val headless: Boolean = false,
)

class ToolCall(val name: String, val args: JSONObject, val before: String, val after: String)

/**
 * Tool registry. The model asks for a tool with
 *   <tool>{"name":"flashlight","args":{"on":true}}</tool>
 * The app finds that block, runs the tool and shows the result in the chat.
 */
object Tools {
    private val builtIn: List<ToolDef> by lazy {
        PhoneTools.build() + MoreTools.build() + SkillTools.build() + ExtraTools.build()
    }

    /** built-in tools + the tools the user added (re-read every time, so a new tool shows up at once) */
    val all: List<ToolDef> get() = builtIn + CustomTools.defs()

    fun get(id: String): ToolDef? = all.firstOrNull { it.id == id }

    /** ids of the tools that come with the app (a tool of yours can not use these names) */
    fun builtInIds(): Set<String> = builtIn.map { it.id }.toSet()

    private val prefs get() = Store.app.getSharedPreferences("vethos", 0)

    /** Global switch (Phone tools screen). A tool that is switched off is never offered to the model. */
    /** Web tools go to the internet, so they start switched OFF (turn them on in Phone tools). */
    val DEFAULT_OFF = setOf("web_search", "web_fetch")

    fun enabled(id: String): Boolean = !prefs.getBoolean("tool_off_$id", id in DEFAULT_OFF)
    fun setEnabled(id: String, on: Boolean) = prefs.edit().putBoolean("tool_off_$id", !on).apply()

    /** The short instruction block added to the system prompt. Empty when no tool is allowed. */
    fun prompt(allowed: Set<String>): String {
        val list = all.filter { it.id in allowed }
        if (list.isEmpty()) return ""
        val sb = StringBuilder()
        sb.append("You can control the phone. If the user asks for a phone action, reply with ONLY this one line and nothing else: ")
        sb.append("<tool>{\"name\":\"TOOL\",\"args\":{...}}</tool>\nTools:\n")
        list.forEach { sb.append(it.id).append(' ').append(it.usage).append('\n') }
        sb.append("For normal questions answer normally and do not use a tool.")
        return sb.toString()
    }

    /** While an answer is still typing, hide the raw tool JSON. */
    fun hideLive(s: String): String {
        val i = s.indexOf("<tool>")
        return if (i >= 0) s.substring(0, i) + "⚙ Using a tool…" else s
    }

    /** Finds a tool request inside the model's answer. Returns null if there is none (or it is not allowed). */
    fun parse(text: String, allowed: Set<String>): ToolCall? {
        if (allowed.isEmpty()) return null
        var start = text.indexOf("<tool>")
        val from: Int
        if (start >= 0) {
            from = start + 6
        } else {
            val k = Regex("""\{\s*["']name["']""").find(text) ?: return null
            start = k.range.first
            from = start
        }
        val open = text.indexOf('{', from)
        if (open < 0) return null
        val close = matchBrace(text, open)
        if (close < 0) return null
        val obj = try { JSONObject(text.substring(open, close + 1)) } catch (_: Exception) { return null }
        val name = obj.optString("name").ifBlank { obj.optString("tool") }.trim().lowercase()
        if (name !in allowed) return null
        val args = obj.optJSONObject("args") ?: obj.optJSONObject("arguments") ?: obj.optJSONObject("parameters")
            ?: JSONObject().also { o ->
                obj.keys().forEach { k -> if (k != "name" && k != "tool") o.put(k, obj.get(k)) }
            }
        var end = close + 1
        val endTag = text.indexOf("</tool>", end)
        if (endTag >= 0 && text.substring(end, endTag).isBlank()) end = endTag + 7
        return ToolCall(name, args, text.substring(0, start).trim(), text.substring(end).trim())
    }

    private fun matchBrace(s: String, open: Int): Int {
        var depth = 0
        var inStr = false
        var q = ' '
        var esc = false
        for (i in open until s.length) {
            val c = s[i]
            if (inStr) {
                if (esc) esc = false
                else if (c == '\\') esc = true
                else if (c == q) inStr = false
                continue
            }
            when (c) {
                '"', '\'' -> { inStr = true; q = c }
                '{' -> depth++
                '}' -> { depth--; if (depth == 0) return i }
            }
        }
        return -1
    }
}
