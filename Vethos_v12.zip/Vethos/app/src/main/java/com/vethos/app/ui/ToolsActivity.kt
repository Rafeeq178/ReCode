package com.vethos.app.ui

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.vethos.app.R
import com.vethos.app.databinding.ActivityToolsBinding
import com.vethos.app.databinding.ItemToolBinding
import com.vethos.app.tools.CustomTools
import com.vethos.app.tools.Launchers
import com.vethos.app.tools.PermHelper
import com.vethos.app.tools.ToolCtx
import com.vethos.app.tools.ToolDef
import com.vethos.app.tools.ToolRunner
import com.vethos.app.tools.Tools
import org.json.JSONObject

/**
 * Lists every phone tool. Tap one to try it by hand; the switch turns it off for all personalities.
 * v12: "+ Add my own tool", "My files & designs", and long-press a tool of yours to delete it.
 */
class ToolsActivity : AppCompatActivity() {
    private lateinit var b: ActivityToolsBinding
    private val perms = PermHelper(this)
    private val launchers = Launchers(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityToolsBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnBack.setOnClickListener { finish() }

        b.list.addView(actionRow("+ Add my own tool") { addTool() })
        b.list.addView(actionRow("My files & designs") { startActivity(Intent(this, FilesActivity::class.java)) })

        Tools.all.forEach { d ->
            val r = ItemToolBinding.inflate(layoutInflater, b.list, false)
            r.icon.setImageResource(d.icon)
            r.title.text = d.title + if (d.sensitive) "  (asks first)" else ""
            r.sub.text = d.desc
            r.sw.isChecked = Tools.enabled(d.id)
            r.sw.setOnCheckedChangeListener { _, on -> Tools.setEnabled(d.id, on) }
            r.root.setOnClickListener { tryTool(d) }
            if (CustomTools.isCustom(d.id)) {
                r.root.setOnLongClickListener {
                    MaterialAlertDialogBuilder(this).setTitle("Delete “${d.title}”?")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Delete") { _, _ -> CustomTools.remove(d.id); recreate() }
                        .show()
                    true
                }
            }
            b.list.addView(r.root)
        }
    }

    private fun actionRow(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 15.5f
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setTextColor(ContextCompat.getColor(this@ToolsActivity, R.color.v_blue))
        setBackgroundResource(R.drawable.bg_row)
        setPadding(dp(14), dp(14), dp(14), dp(14))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    private fun field(box: LinearLayout, h: String): EditText = EditText(this).apply {
        hint = h
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
    }.also { box.addView(it, LinearLayout.LayoutParams(-1, -2)) }

    /** A tool of your own: a fixed reply, or a web link with your inputs filled in. */
    private fun addTool() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), 0)
        }
        val fTitle = field(box, "Name, e.g. Shop hours")
        val fDesc = field(box, "What it does (the assistant reads this)")
        val fParams = field(box, "Inputs, comma separated, e.g. phone, message (or empty)")
        val fKind = field(box, "Type: reply  OR  url")
        val fTpl = field(box, "Reply text, or a https link with {input} in it")
        MaterialAlertDialogBuilder(this).setTitle("Add my own tool").setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val kind = if (fKind.text.toString().trim().lowercase() == "url") "url" else "reply"
                val id = CustomTools.add(
                    fTitle.text.toString(), fDesc.text.toString(),
                    fParams.text.toString().split(','), kind, fTpl.text.toString()
                )
                if (id == null) toast("Needs a name, a text, and a https:// link for type url")
                else { toast("Tool added"); recreate() }
            }
            .show()
    }

    private fun tryTool(d: ToolDef) {
        val ctx = ToolCtx(this, perms, launchers)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), 0)
        }
        val fields = d.params.map { p ->
            EditText(this).apply {
                hint = p.label + if (p.optional) " (optional)" else ""
                if (p.hint.isNotEmpty()) hint = hint.toString() + " – " + p.hint
                inputType = InputType.TYPE_CLASS_TEXT
            }.also { box.addView(it, LinearLayout.LayoutParams(-1, -2)) }
        }
        fun go() {
            val args = JSONObject()
            d.params.forEachIndexed { i, p ->
                val v = fields[i].text.toString().trim()
                if (v.isNotEmpty()) args.put(p.key, v)
            }
            ToolRunner.run(ctx, d, args, true) { r ->
                if (r.text.length > 70 || r.text.contains('\n'))
                    MaterialAlertDialogBuilder(this).setTitle(d.title).setMessage(r.text).setPositiveButton("OK", null).show()
                else toast(r.text)
            }
        }
        if (d.params.isEmpty()) { go(); return }
        MaterialAlertDialogBuilder(this).setTitle(d.title).setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Run") { _, _ -> go() }
            .show()
    }
}
