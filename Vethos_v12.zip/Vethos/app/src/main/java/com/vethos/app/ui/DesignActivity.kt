package com.vethos.app.ui

import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.vethos.app.tools.ExtraTools
import java.io.File

/**
 * Shows one saved design. It is created only when the user taps it (never automatically).
 * The page runs offline: network loads are blocked and it cannot read the phone's files.
 */
class DesignActivity : AppCompatActivity() {
    @Suppress("DEPRECATION") // blockNetworkLoads is deprecated on new Androids; still works and is what we want
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val f = File(intent.getStringExtra("path") ?: "")
        val inside = ExtraTools.workDir.canonicalPath
        if (!f.isFile || !f.canonicalPath.startsWith(inside)) {
            finish()
            return
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        top.addView(Button(this).apply {
            text = "Close"
            setOnClickListener { finish() }
        })
        val web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = false
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.blockNetworkLoads = true
            webViewClient = WebViewClient()
        }
        top.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(top)
        web.loadDataWithBaseURL(null, f.readText(), "text/html", "utf-8", null)
    }
}
