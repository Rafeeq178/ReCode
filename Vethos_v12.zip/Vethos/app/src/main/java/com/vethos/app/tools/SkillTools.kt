package com.vethos.app.tools

import com.vethos.app.R
import com.vethos.app.data.Skills

/** Skill tools: read_skill loads the instructions, read_skill_file loads one of the skill's resource files. */
object SkillTools {
    fun build(): List<ToolDef> = listOf(
        ToolDef(
            id = "read_skill", title = "Read skill", icon = R.drawable.ic_book, sensitive = false,
            desc = "Loads the instructions of a saved skill so the assistant can follow them",
            params = listOf(ToolParam("name", "Skill name")),
            usage = "{\"name\":\"skill name\"} loads the full instructions of a skill",
            run = { _, a, done ->
                val q = a.optString("name")
                val s = Skills.find(q)
                if (s == null) {
                    val names = Skills.all().filter { it.enabled }.joinToString(", ") { it.name }
                    done(ToolResult(false, "No skill called \"" + q + "\". Available: " + names))
                } else {
                    val res = Skills.resources(s.id)
                    val extra = if (res.isEmpty()) "" else
                        "\n\nThis skill has resource files you can open with read_skill_file: " + res.joinToString(", ")
                    done(ToolResult(true, "Skill: " + s.name,
                        "Follow these instructions (skill \"" + s.name + "\"):\n" + s.body.take(3000) + extra))
                }
            },
            headless = true,
        ),
        ToolDef(
            id = "read_skill_file", title = "Read skill file", icon = R.drawable.ic_clip, sensitive = false,
            desc = "Opens one resource file (template, example, reference) of a skill",
            params = listOf(ToolParam("skill", "Skill name"), ToolParam("file", "File name")),
            usage = "{\"skill\":\"skill name\",\"file\":\"file name\"}",
            run = { _, a, done ->
                val s = Skills.find(a.optString("skill"))
                val text = if (s == null) null else Skills.resource(s.id, a.optString("file"))
                if (text == null) done(ToolResult(false, "No such skill file."))
                else done(ToolResult(true, "Opened " + a.optString("file"), text))
            },
            headless = true,
        ),
    )
}
