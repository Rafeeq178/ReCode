package com.vethos.app.tools

import android.content.Intent
import android.net.Uri
import com.vethos.app.R
import com.vethos.app.data.Store
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder

/**
 * A tool the user made in Phone tools → "+ Add my own tool".
 *  kind "reply": gives back a fixed text, with {param} filled in (office hours, a template, a note).
 *  kind "url":   opens a web link (https only), e.g. https://wa.me/{phone}?text={message}
 */
class CustomTool(
    val id: String,
    val title: String,
    val desc: String,
    val params: List<String>,
    val kind: String,
    val template: String,
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("title", title)
        .put("desc", desc)
        .put("params", JSONArray(params))
        .put("kind", kind)
        .put("template", template)
}

object CustomTools {
    const val PREFIX = "x_"

    private val file: File get() = File(Store.app.filesDir, "custom_tools.json")

    fun all(): List<CustomTool> = try {
        val arr = JSONArray(file.readText())
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val ps = o.optJSONArray("params") ?: JSONArray()
            CustomTool(
                id = o.getString("id"),
                title = o.optString("title"),
                desc = o.optString("desc"),
                params = (0 until ps.length()).map { ps.getString(it) },
                kind = o.optString("kind", "reply"),
                template = o.optString("template"),
            )
        }
    } catch (_: Exception) {
        emptyList()
    }

    private fun store(list: List<CustomTool>) {
        file.writeText(JSONArray(list.map { it.toJson() }).toString())
    }

    fun isCustom(id: String) = id.startsWith(PREFIX)

    /** Adds a tool. Returns its id, or null when the input is not usable. */
    fun add(title: String, desc: String, params: List<String>, kind: String, template: String): String? {
        val t = title.trim()
        val tpl = template.trim()
        if (t.isEmpty() || tpl.isEmpty()) return null
        val isUrl = kind == "url"
        if (isUrl && !tpl.startsWith("https://") && !tpl.startsWith("http://")) return null
        val slug = t.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_').take(30).ifEmpty { "tool" }
        val taken = all().map { it.id }.toSet() + Tools.builtInIds()
        var id = PREFIX + slug
        var i = 2
        while (id in taken) { id = PREFIX + slug + "_" + i; i++ }
        val names = params
            .map { it.trim().lowercase().replace(Regex("[^a-z0-9_]+"), "_").trim('_') }
            .filter { it.isNotEmpty() }
            .distinct()
        store(all() + CustomTool(id, t, desc.trim(), names, if (isUrl) "url" else "reply", tpl))
        return id
    }

    fun remove(id: String) = store(all().filter { it.id != id })

    fun defs(): List<ToolDef> = all().map { t ->
        ToolDef(
            id = t.id,
            title = t.title,
            icon = R.drawable.ic_code,
            sensitive = t.kind == "url",
            desc = (if (t.desc.isEmpty()) "Your own tool" else t.desc) + " (your tool)",
            params = t.params.map { ToolParam(it, it) },
            usage = "{" + t.params.joinToString(",") { "\"$it\":\"...\"" } + "}",
            run = { _, a, done -> runTool(t, a, done) },
        )
    }

    private fun runTool(t: CustomTool, a: JSONObject, done: (ToolResult) -> Unit) {
        if (t.kind == "url") {
            val url = fill(t.template, a, encode = true)
            val ok = try {
                Store.app.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                true
            } catch (_: Exception) {
                false
            }
            done(if (ok) ToolResult(true, "Opened " + t.title) else ToolResult(false, "Could not open the link."))
        } else {
            val text = fill(t.template, a, encode = false)
            done(ToolResult(true, text, text))
        }
    }

    fun fill(tpl: String, a: JSONObject, encode: Boolean): String {
        var out = tpl
        a.keys().forEach { k ->
            val v = a.optString(k)
            out = out.replace("{" + k + "}", if (encode) URLEncoder.encode(v, "UTF-8") else v)
        }
        return out
    }
}
