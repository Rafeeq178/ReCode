package com.vethos.app.data

import android.content.Context
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import com.arm.aichat.UnsupportedArchitectureException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File

/**
 * Thin wrapper over llama.cpp's Android AI-chat library (com.arm.aichat).
 *
 * v12: the model is loaded ONCE and stays in memory until the user unloads it or
 * picks another model. A new chat only sets a new system prompt (the native side
 * clears the old conversation), so opening a chat no longer reloads the model.
 * If the upstream API changes, this is the only file that needs editing.
 */
object Engine {
    private var engine: InferenceEngine? = null
    private val lock = Mutex()
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    @Volatile var loadedPath: String? = null
        private set
    @Volatile var chatId: String? = null
        private set
    private var lastSystem: String? = null

    private fun get(ctx: Context): InferenceEngine =
        engine ?: AiChat.getInferenceEngine(ctx.applicationContext).also { engine = it }

    private fun ready(e: InferenceEngine) = e.state.value is InferenceEngine.State.ModelReady

    /** Must be called with [lock] held. Loads the model only if it is not in memory yet. */
    private suspend fun ensureModelLocked(ctx: Context, path: String): InferenceEngine {
        val e = get(ctx)
        if (loadedPath != path || !ready(e)) {
            unloadLocked(e)
            loadedPath = null; chatId = null; lastSystem = null
            try {
                e.loadModel(path)
            } catch (x: UnsupportedArchitectureException) {
                throw IllegalStateException("This model type is not supported by the engine", x)
            }
            loadedPath = path
        }
        return e
    }

    private fun unloadLocked(e: InferenceEngine?) {
        try { e?.cleanUp() } catch (_: Throwable) { }
    }

    /**
     * Makes sure [path] is in memory and the system prompt of [chat] is set.
     * Fast when the model is already loaded: only a new chat/system text costs a little time.
     */
    suspend fun load(ctx: Context, path: String, chat: String, system: String, force: Boolean = false) {
        lock.withLock {
            val e = ensureModelLocked(ctx, path)
            if (force || chat != chatId || system != lastSystem) {
                e.setSystemPrompt(system)
                chatId = chat
                lastSystem = system
            }
        }
    }

    /** Loads the last used model in the background at app start, so the first answer is quick. */
    fun preload(ctx: Context) {
        val name = Store.lastModel ?: return
        val f = File(Store.modelsDir, name)
        if (!f.isFile || isLoaded(f.absolutePath)) return
        scope.launch {
            try {
                lock.withLock { ensureModelLocked(ctx, f.absolutePath) }
            } catch (_: Throwable) {
                // the chat screen shows the error if the user opens it
            }
        }
    }

    fun isLoaded(path: String): Boolean {
        val e = engine ?: return false
        return loadedPath == path && ready(e)
    }

    fun send(ctx: Context, prompt: String, maxTokens: Int): Flow<String> =
        get(ctx).sendUserPrompt(prompt, maxTokens)

    /** Forget the loaded model (user unloaded it, deleted it or switched model). */
    fun unload() {
        unloadLocked(engine)
        loadedPath = null; chatId = null; lastSystem = null
    }
}

/** Removes the model's hidden reasoning (<think>...</think>) so only the answer is shown. */
object Think {
    fun clean(s: String): String {
        var t = s
        val close = t.lastIndexOf("</think>")
        if (close >= 0) {
            t = t.substring(close + "</think>".length)          // reasoning came first, the answer follows
        } else {
            val open = t.indexOf("<think>")
            if (open >= 0) t = t.substring(0, open)             // still thinking: show nothing yet
        }
        return t.replace("<think>", "").trim()
    }
}
