package com.vethos.app.ui

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.vethos.app.R
import com.vethos.app.tools.ExtraTools
import java.io.File

/**
 * My files & designs. Nothing opens by itself: a design (HTML) opens only when you tap it.
 */
class FilesActivity : AppCompatActivity() {
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(16))
        }
        val back = TextView(this).apply {
            text = "← Back"
            textSize = 15f
            setTextColor(ContextCompat.getColor(this@FilesActivity, R.color.v_blue))
            setPadding(0, dp(8), 0, dp(12))
            setOnClickListener { finish() }
        }
        val title = TextView(this).apply {
            text = "My files & designs"
            textSize = 26f
            setTypeface(null, Typeface.BOLD)
            setTextColor(ContextCompat.getColor(this@FilesActivity, R.color.v_text))
        }
        val hint = TextView(this).apply {
            text = "Files the assistant saved. Designs (HTML pages) open only when you tap them."
            textSize = 14f
            setTextColor(ContextCompat.getColor(this@FilesActivity, R.color.v_muted))
            setPadding(0, dp(6), 0, dp(12))
        }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(back)
        root.addView(title)
        root.addView(hint)
        root.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        list.removeAllViews()
        val files = ExtraTools.workDir.listFiles { f -> f.isFile }?.sortedByDescending { it.lastModified() } ?: emptyList()
        if (files.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "No files yet. Ask the assistant to make a page, a note or a list."
                setTextColor(ContextCompat.getColor(this@FilesActivity, R.color.v_muted))
                textSize = 15f
            })
            return
        }
        files.forEach { f ->
            val row = TextView(this).apply {
                text = f.name + "\n" + (if (f.name.endsWith(".html")) "Design" else "File") + " · " + f.length() + " bytes"
                setBackgroundResource(R.drawable.bg_row)
                setPadding(dp(14), dp(12), dp(14), dp(12))
                setTextColor(ContextCompat.getColor(this@FilesActivity, R.color.v_text))
                textSize = 15f
                setOnClickListener { open(f) }
                setOnLongClickListener { confirmDelete(f); true }
            }
            list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
    }

    private fun open(f: File) {
        if (f.name.endsWith(".html")) {
            startActivity(Intent(this, DesignActivity::class.java).putExtra("path", f.absolutePath))
        } else {
            val text = try { f.readText().take(5000) } catch (_: Exception) { "Could not read this file." }
            MaterialAlertDialogBuilder(this).setTitle(f.name).setMessage(text)
                .setPositiveButton("Close", null)
                .setNeutralButton("Delete") { _, _ -> confirmDelete(f) }
                .show()
        }
    }

    private fun confirmDelete(f: File) {
        MaterialAlertDialogBuilder(this).setTitle("Delete ${f.name}?")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ -> f.delete(); refresh() }
            .show()
    }
}
