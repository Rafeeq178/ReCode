package com.vethos.app.tools

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.CalendarContract
import com.vethos.app.R
import com.vethos.app.data.Store
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * v12 tools: alarm, timer, date and time, calendar, the assistant's own files,
 * designs (HTML pages that open only when you tap them) and two OPTIONAL web tools (off by default).
 */
object ExtraTools {
    private val main = Handler(Looper.getMainLooper())

    /** The assistant's own files: Vethos → My files & designs. */
    val workDir: File get() = File(Store.app.filesDir, "work").apply { mkdirs() }

    fun build(): List<ToolDef> = listOf(
        ToolDef(
            id = "alarm", title = "Alarm", icon = R.drawable.ic_hist, sensitive = true,
            desc = "Sets an alarm in the phone's clock app",
            params = listOf(ToolParam("hour", "hour 0-23"), ToolParam("minute", "minute 0-59"),
                ToolParam("message", "label", optional = true)),
            usage = """{"hour":7,"minute":30,"message":"label"}""",
            run = { c, a, done ->
                val h = a.optInt("hour", -1)
                val m = a.optInt("minute", 0)
                if (h !in 0..23 || m !in 0..59) done(ToolResult(false, "Give hour 0-23 and minute 0-59."))
                else {
                    val i = Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, h)
                        .putExtra(AlarmClock.EXTRA_MINUTES, m)
                        .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("message", "Vethos"))
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    done(launch(c.ctx, i, "Alarm set for %02d:%02d".format(h, m), "No clock app found on this phone."))
                }
            },
            headless = true,
        ),
        ToolDef(
            id = "timer", title = "Timer", icon = R.drawable.ic_hist, sensitive = true,
            desc = "Starts a countdown timer in the phone's clock app",
            params = listOf(ToolParam("seconds", "seconds"), ToolParam("message", "label", optional = true)),
            usage = """{"seconds":300,"message":"label"}""",
            run = { c, a, done ->
                val sec = a.optInt("seconds", 0)
                if (sec <= 0) done(ToolResult(false, "Give the time in seconds."))
                else {
                    val i = Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, sec)
                        .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("message", "Vethos"))
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    done(launch(c.ctx, i, "Timer started: $sec seconds", "No clock app found on this phone."))
                }
            },
            headless = true,
        ),
        ToolDef(
            id = "user_time", title = "Date and time", icon = R.drawable.ic_hist, sensitive = false,
            desc = "Tells the current date, time and time zone",
            params = emptyList(),
            usage = "{}",
            run = { _, _, done ->
                val text = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm (zzz)", Locale.ENGLISH).format(Date())
                done(ToolResult(true, text, "Current date and time: $text"))
            },
            headless = true,
        ),
        ToolDef(
            id = "calendar_add", title = "Calendar event", icon = R.drawable.ic_lib, sensitive = true,
            desc = "Opens the calendar app with a new event filled in (you tap Save)",
            params = listOf(ToolParam("title", "title"), ToolParam("start", "start", "yyyy-MM-dd HH:mm"),
                ToolParam("minutes", "length in minutes", optional = true)),
            usage = """{"title":"event","start":"2026-11-20 15:00","minutes":60}""",
            run = { c, a, done ->
                val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
                val start: Long? = try { fmt.parse(a.optString("start"))?.time } catch (_: Exception) { null }
                if (start == null) done(ToolResult(false, "Give the start as yyyy-MM-dd HH:mm."))
                else {
                    val mins = a.optInt("minutes", 60).coerceIn(1, 24 * 60)
                    val i = Intent(Intent.ACTION_INSERT)
                        .setData(CalendarContract.Events.CONTENT_URI)
                        .putExtra(CalendarContract.Events.TITLE, a.optString("title", "Event"))
                        .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start)
                        .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, start + mins * 60_000L)
                    done(launch(c.ctx, i, "Calendar opened. Tap Save there.", "No calendar app found on this phone."))
                }
            },
        ),
        ToolDef(
            id = "file_create", title = "Create file", icon = R.drawable.ic_dl, sensitive = false,
            desc = "Creates a text, code, markdown or CSV file in My files (no picker)",
            params = listOf(ToolParam("name", "file name", "e.g. notes.md"), ToolParam("text", "content")),
            usage = """{"name":"notes.md","text":"content"}""",
            run = { _, a, done ->
                val name = safeName(a.optString("name"))
                val text = a.optString("text")
                if (text.isEmpty()) done(ToolResult(false, "Nothing to save."))
                else {
                    File(workDir, name).writeText(text.take(300_000))
                    done(ToolResult(true, "Saved $name in My files (${text.length} characters)."))
                }
            },
            headless = true,
        ),
        ToolDef(
            id = "file_list", title = "List my files", icon = R.drawable.ic_lib, sensitive = false,
            desc = "Lists the files the assistant created in My files",
            params = emptyList(),
            usage = "{}",
            run = { _, _, done ->
                val list = workDir.listFiles { f -> f.isFile }?.sortedBy { it.name } ?: emptyList()
                if (list.isEmpty()) done(ToolResult(true, "No files yet."))
                else done(ToolResult(true, "${list.size} file(s) in My files",
                    list.joinToString("\n") { "${it.name} (${it.length()} bytes)" }))
            },
            headless = true,
        ),
        ToolDef(
            id = "file_read", title = "Read my file", icon = R.drawable.ic_clip, sensitive = false,
            desc = "Reads a file from My files",
            params = listOf(ToolParam("name", "file name")),
            usage = """{"name":"notes.md"}""",
            run = { _, a, done ->
                val f = File(workDir, safeName(a.optString("name")))
                if (!f.isFile) done(ToolResult(false, "No such file in My files."))
                else done(ToolResult(true, "Opened ${f.name}", f.readText().take(6000)))
            },
            headless = true,
        ),
        ToolDef(
            id = "file_edit", title = "Edit my file", icon = R.drawable.ic_edit, sensitive = false,
            desc = "Replaces one piece of text in a file of My files",
            params = listOf(ToolParam("name", "file name"), ToolParam("old", "text to find"), ToolParam("new", "replacement")),
            usage = """{"name":"notes.md","old":"text to find","new":"replacement"}""",
            run = { _, a, done ->
                val f = File(workDir, safeName(a.optString("name")))
                val old = a.optString("old")
                if (!f.isFile || old.isEmpty()) done(ToolResult(false, "File or text to find is missing."))
                else {
                    val t = f.readText()
                    if (!t.contains(old)) done(ToolResult(false, "That text is not in ${f.name}."))
                    else {
                        f.writeText(t.replaceFirst(old, a.optString("new")))
                        done(ToolResult(true, "Edited ${f.name}."))
                    }
                }
            },
            headless = true,
        ),
        ToolDef(
            id = "design", title = "Design / page", icon = R.drawable.ic_code, sensitive = false,
            desc = "Saves a visual page or design (one HTML file). It opens only when you tap it in My files",
            params = listOf(ToolParam("title", "title"), ToolParam("html", "HTML code")),
            usage = """{"title":"Page title","html":"<!DOCTYPE html>..."}""",
            run = { _, a, done ->
                val html = a.optString("html")
                val title = a.optString("title", "design")
                if (html.length < 20) done(ToolResult(false, "No HTML given."))
                else {
                    File(workDir, safeName(slugOf(title) + ".html")).writeText(html.take(400_000))
                    done(ToolResult(true, "Design saved: $title. Tap it in Tools → My files & designs to open it."))
                }
            },
            headless = true,
        ),
        ToolDef(
            id = "web_search", title = "Web search", icon = R.drawable.ic_search, sensitive = true,
            desc = "Searches the internet (needs Wi-Fi or data). Off by default",
            params = listOf(ToolParam("query", "what to search")),
            usage = """{"query":"search words"}""",
            run = { _, a, done ->
                val q = a.optString("query").trim()
                if (q.isEmpty()) done(ToolResult(false, "Nothing to search for."))
                else background(done) { Web.search(q) }
            },
        ),
        ToolDef(
            id = "web_fetch", title = "Read web page", icon = R.drawable.ic_share, sensitive = true,
            desc = "Reads the text of a web page (needs internet). Off by default",
            params = listOf(ToolParam("url", "web address")),
            usage = """{"url":"https://example.com"}""",
            run = { _, a, done ->
                val u = a.optString("url").trim()
                if (!u.startsWith("https://") && !u.startsWith("http://")) done(ToolResult(false, "Give a web address that starts with https://"))
                else background(done) { Web.fetch(u) }
            },
        ),
    )

    /** Starts an app screen. Works with or without a Vethos screen open. */
    private fun launch(ctx: Context, i: Intent, ok: String, fail: String): ToolResult =
        try {
            ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            ToolResult(true, ok)
        } catch (_: ActivityNotFoundException) {
            ToolResult(false, fail)
        }

    /** Runs slow work (internet) on a background thread; the answer comes back on the main thread. */
    private fun background(done: (ToolResult) -> Unit, work: () -> ToolResult) {
        Thread {
            val r = try { work() } catch (e: Exception) { ToolResult(false, "No internet: " + (e.message ?: "failed")) }
            main.post { done(r) }
        }.start()
    }

    /** "My notes: v1" → "my-notes-v1.html" style names, and never a folder path. */
    fun safeName(n: String): String {
        val base = n.trim().replace(Regex("[^A-Za-z0-9._-]+"), "_").trimStart('.').take(80)
        return base.ifEmpty { "file.txt" }
    }

    private fun slugOf(s: String): String =
        s.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').take(40).ifEmpty { "design" }

    private object Web {
        fun get(u: String): String {
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 15_000
            c.readTimeout = 20_000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) Vethos/12")
            try {
                val code = c.responseCode
                if (code !in 200..299) throw IllegalStateException("HTTP $code")
                return c.inputStream.bufferedReader().use { it.readText() }.take(300_000)
            } finally {
                c.disconnect()
            }
        }

        fun search(q: String): ToolResult {
            val html = get("https://html.duckduckgo.com/html/?q=" + URLEncoder.encode(q, "UTF-8"))
            val links = Regex("""class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>""", RegexOption.DOT_MATCHES_ALL)
                .findAll(html).take(5).toList()
            if (links.isEmpty()) return ToolResult(false, "No results.")
            val snips = Regex("""class="result__snippet"[^>]*>(.*?)</a>""", RegexOption.DOT_MATCHES_ALL)
                .findAll(html).map { clean(it.groupValues[1]) }.toList()
            val sb = StringBuilder()
            links.forEachIndexed { i, m ->
                sb.append(i + 1).append(". ").append(clean(m.groupValues[2])).append('\n')
                sb.append("   ").append(m.groupValues[1]).append('\n')
                snips.getOrNull(i)?.let { sb.append("   ").append(it).append('\n') }
            }
            return ToolResult(true, "Found ${links.size} results", sb.toString())
        }

        fun fetch(u: String): ToolResult {
            val text = clean(get(u)).take(4000)
            return ToolResult(true, "Read $u", text)
        }

        fun clean(s: String): String = s
            .replace(Regex("(?is)<(script|style)[^>]*>.*?</\\1>"), " ")
            .replace(Regex("<[^>]+>"), " ")
            .replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'")
            .replace("&lt;", "<").replace("&gt;", ">")
            .replace(Regex("\\s+"), " ")
            .trim()
    }
}
