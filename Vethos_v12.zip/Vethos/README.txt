VETHOS v12 - offline AI assistant for Android (Kotlin, llama.cpp, no WebView for chat)

Build: put Vethos_v12.zip in the GitHub repo (the workflow builds the highest Vethos_vN.zip).
Android 10+, arm64. llama.cpp = latest master (LLAMA_REF in .github/workflows/build-apk.yml).

What is new in v12
  - Model stays loaded. The model is loaded once (and preloaded when the app starts). Opening a new chat only
    sets the chat's instructions, so it no longer reloads the model. Unload button in Library.
  - Latest llama.cpp: Liquid AI LFM2 and LFM3 models work (older builds said "Cannot load model").
    Context is 4096 tokens: faster load, less RAM.
  - Liquid AI models in Library: LFM3 1.7B (newest), LFM2 1.2B, LFM2 350M.
  - Hidden reasoning (<think>...</think>) is removed from answers.
  - Skills with resources: each skill folder has SKILL.md and optional resources/ files, opened with read_skill_file.
    Built-in skills: docx, pdf, pptx, xlsx, pdf-reading, file-reading, frontend-design, docs,
    product-self-knowledge, skill-creator, import-memory, morning, email-writer, explain-simply.
    (Word, PDF, PowerPoint and Excel files can not be written on the phone: the skills write Markdown or CSV.)
  - New tools: alarm, timer, date and time, calendar event, my files (create, list, read, edit),
    design (one HTML page that opens ONLY when you tap it in My files & designs),
    web search and read web page (OFF by default, need internet; turn them on in Phone tools).
  - Your own tools: Phone tools → "+ Add my own tool". Type "reply" gives a fixed text, type "url" opens a https link
    with your inputs filled in. Long-press one of your tools to delete it.
  - Files: Phone tools → My files & designs. Files are kept in the app's private storage.

Still there from v11
  - Chat with a local GGUF model (Library: download / pick a model). Code blocks with Copy / Save.
  - Personalities (drawer -> My Offline Chatbots): General Assistant, Planner, Coder.
  - Phone tools: torch, volume, Wi-Fi, battery, open app, call, SMS, WhatsApp, navigate, camera, notification,
    calculator, random/password, hash/base64, clipboard, QR maker/scanner, read file, save to file, read aloud.
    The model asks with <tool>{"name":"...","args":{...}}</tool>. Call, SMS and the new tools that act on the phone ask "Allow?" first.
  - Agent loop: tool results that carry data are handed back to the model up to 3 times in a row.

Setup in Termux (optional, for building there): run sh setup.sh once. It fetches llama.cpp and applies
scripts/patch-llama-engine.py (keep model loaded, 4096 context).
