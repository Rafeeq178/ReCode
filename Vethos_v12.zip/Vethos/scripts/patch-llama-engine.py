#!/usr/bin/env python3
"""
Vethos v12 - two small patches on llama.cpp's Android lib (run after cloning llama.cpp):

 1. Keep the model in memory. Upstream allows setSystemPrompt() only right after a model
    load, so every new chat used to reload the whole model (slow). The native side already
    resets the KV cache when a system prompt is set, so the Kotlin guard is removed.
 2. Smaller default context (4096 instead of 8192): less RAM, faster model load on phones.

Idempotent. Fails loudly if upstream changed the code it expects.

usage: python3 patch-llama-engine.py <path-to-llama.cpp>
"""
import pathlib
import re
import sys

root = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "llama.cpp")
lib = root / "examples/llama.android/lib/src/main"

def patch(path, pattern, repl, flags=0, expect=1):
    text = path.read_text(encoding="utf-8", errors="ignore")
    if "Vethos:" in text:
        print("already patched:", path.name)
        return
    new, n = re.subn(pattern, repl, text, flags=flags)
    if n != expect:
        raise SystemExit(f"::error::{path}: expected {expect} match(es) for {pattern!r}, found {n}")
    path.write_text(new, encoding="utf-8")
    print("patched:", path.name)

kt = lib / "java/com/arm/aichat/internal/InferenceEngineImpl.kt"
patch(kt,
      r'check\(_readyForSystemPrompt\)\s*\{[^}]*\}',
      'Unit /* Vethos: system prompt may be set again for a new chat without reloading the model */')

cpp = lib / "cpp/ai_chat.cpp"
patch(cpp,
      r'(DEFAULT_CONTEXT_SIZE\s*=\s*)8192',
      r'\g<1>4096 /* Vethos: 4096 = faster load, less RAM */')

print("llama engine patches OK")
