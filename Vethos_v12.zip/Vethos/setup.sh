#!/data/data/com.termux/files/usr/bin/bash
# One-time setup in Termux: fetch llama.cpp and make its Android lib buildable here.
set -e
cd "$(dirname "$0")"
[ -d llama.cpp ] || git clone --depth 1 https://github.com/ggml-org/llama.cpp
LIB=llama.cpp/examples/llama.android/lib
[ -f $LIB/build.gradle.kts.orig ] || cp $LIB/build.gradle.kts $LIB/build.gradle.kts.orig
# upstream uses a version catalog; swap its aliases for plain plugin ids
sed -i \
 -e 's/alias(libs.plugins.android.library)/id("com.android.library")/' \
 -e 's/alias(libs.plugins.jetbrains.kotlin.android)/id("org.jetbrains.kotlin.android")/' \
 -e 's/alias(libs.plugins.kotlin.android)/id("org.jetbrains.kotlin.android")/' \
 -e 's/libs.androidx.core.ktx/"androidx.core:core-ktx:1.13.1"/' \
 -e 's/libs.androidx.datastore.preferences/"androidx.datastore:datastore-preferences:1.1.1"/' \
 -e 's/compileSdk = 36/compileSdk = 35/' -e 's/minSdk = 33/minSdk = 29/' \
 -e '/testImplementation(libs\./d' -e '/androidTestImplementation(libs\./d' \
 $LIB/build.gradle.kts
grep -n "libs\." $LIB/build.gradle.kts && echo "!! leftover libs.* aliases above: replace them by hand" || true
# Android 10: __android_log_is_loggable needs API 30
find $LIB/src/main/cpp -type f \( -name "*.h" -o -name "*.cpp" \) -exec sed -i -E 's/__android_log_is_loggable\(([^,]+),[^;]*\)/((\1) >= ANDROID_LOG_INFO)/' {} +
python3 scripts/patch-llama-engine.py llama.cpp   # v12: keep model loaded, 4096 context
echo "Done. Now run: gradle assembleRelease"
