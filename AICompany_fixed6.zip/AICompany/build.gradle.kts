// Hilt's AggregateDepsTask runs on the *Gradle plugin* classpath (buildscript), not on the app's
// configurations. AGP drags in an old javapoet there -> NoSuchMethodError ClassName.canonicalName().
// Putting javapoet 1.13.0 on the buildscript classpath is the fix.
buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath("com.squareup:javapoet:1.13.0")
    }
}

plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.compose) apply false
    alias(libs.plugins.kotlin.serialization) apply false
    alias(libs.plugins.ksp) apply false
    alias(libs.plugins.hilt) apply false
}
