pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Termux terminal libraries are published via JitPack.
        maven { url = uri("https://jitpack.io") }
    }
}

rootProject.name = "AICompany"
include(":app")
