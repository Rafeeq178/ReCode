# AICompany v6 (from fixed5)

## Local model
- CMake: Debug builds now compile llama.cpp with `-O3 -DNDEBUG` (was `-O0`).
- Native code did not compile against pinned llama.cpp b8683 (`load_mode` does not exist); now uses `use_mmap`.
- Context 4096; prompt trimmed by real token count (`PromptFitter`); status 2 (context full) and max_tokens cut-offs of JSON now raise errors.
- JNI passes UTF-8 `byte[]` (emoji safe, no CheckJNI abort).
- `nativeFree` use-after-free fixed (handle registry + shared_ptr, free waits for the running generation); `unload()` cancels first.
- Memory trim: only RUNNING_CRITICAL (15) and 60/80 unload; UI_HIDDEN/BACKGROUND no longer do; unload is deferred while generating.
- Chat template comes from the GGUF via `llama_chat_apply_template` (ChatML fallback).
- Timeout / Stop cancels native generation (also during prompt decode).
- Priority: owner chat and CEO = 0, workers = 5 (via `ChatParams.priority`).
- Token channel is unbounded, so a slow collector no longer truncates answers.
- KV cache prefix is reused between requests.
- Grammar whitespace bounded.

## API providers
- Mid-stream IOException -> `ProviderException.Network`; agent retries a failed stream up to 3 times.
- Gateway wraps IllegalArgumentException / local timeout / unexpected errors, so one broken provider no longer kills the chain.
- OpenAI: `max_completion_tokens` (+ no custom temperature for o-series/GPT-5) on api.openai.com, auto-adapts on 400; others keep `max_tokens`.
- `http://` allowed for localhost / private LAN (llama-server, Ollama); key optional there.
- Rate limits: honours Retry-After, waits instead of hammering one key; quota moves to the next provider.
- Chat has a model switcher (chip menu); selection is stored.
- Duplicate user message fixed (history read from DB after insert).
- KeyVault no longer wipes keys or uses a plaintext fallback; retries, then fails clearly. Settings has "Reset secure storage".

## Agent / company / tools
- Router is wired into worker assignment (only when the employee has no explicit provider order) and uses whole-word matching.
- `WorkTracker` keeps the foreground service alive for CEO, workers, agent runs and chat answers.
- Calculator: `-2^2 = -4`.
- `web_fetch` blocks localhost / private / metadata addresses (DNS-time and redirect checks).
- CI: proot/libtalloc fetched from Termux index when variables are unset; `libtalloc.so` bundled and proot patched via patchelf; `readelf -d` verification. `PROOT_DEB_URL` / `TALLOC_DEB_URL` are now optional.

## Terminal rootfs extraction (post-release fix)
- Extraction moved to `RootfsExtractor`: never follows symlinks (Alpine has absolute-target links such as `/bin/busybox`, `/run`),
  no `canonicalFile` escape check, hard links copied after regular files, entries below a symlink skipped, special files skipped.
- Delete of the staging/rootfs folder no longer follows symlinks.
- The error now names the failing entry: `Extract failed at '<path>': <Exception>: <message>`.
- Unit tests in `RootfsExtractorTest`; `unitTests.isReturnDefaultValues = true` so `Logger` works in JVM tests.
- Folder robustness: cache/staging/rootfs folders are created (and checked) before download/extract; CI locates proot/loader/libtalloc with find and lists the .deb on failure.
- Launcher icon (adaptive + monochrome) added; manifest has icon/roundIcon. CI: builds highest AICompany_*.zip, fixed debug.keystore support, APK checks (icon, libaicompany_llm/libproot, extractNativeLibs), llama.h API check, GitHub release.
