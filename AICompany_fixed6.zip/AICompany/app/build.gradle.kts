plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.ksp)
    alias(libs.plugins.hilt)
}

// Single constant for the app name. Rename here only.
val appDisplayName = "AI Company"

// Google OAuth client id comes from the repo variable GOOGLE_CLIENT_ID (see README).
val googleClientId = (project.findProperty("GOOGLE_CLIENT_ID") as String?)?.trim().orEmpty()
val googleRedirectScheme =
    if (googleClientId.endsWith(".apps.googleusercontent.com")) {
        "com.googleusercontent.apps." + googleClientId.removeSuffix(".apps.googleusercontent.com")
    } else {
        "com.aicompany.unset"
    }

android {
    namespace = "com.aicompany.app"
    compileSdk = 35
    ndkVersion = "29.0.13113456"

    defaultConfig {
        applicationId = "com.aicompany.app"
        externalNativeBuild {
            cmake {
                cppFlags += listOf("-std=c++17", "-fexceptions", "-frtti")
                arguments += listOf("-DANDROID_STL=c++_static", "-DANDROID_ARM_NEON=ON")
            }
        }
        // Required by the master spec: minSdk 26, targetSdk 28 (exec from app data dir).
        minSdk = 26
        targetSdk = 28
        versionCode = 6
        versionName = "0.1.6"
        resValue("string", "app_name", appDisplayName)
        ndk { abiFilters += listOf("arm64-v8a") }
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        buildConfigField("String", "GOOGLE_CLIENT_ID", "\"$googleClientId\"")
        buildConfigField("String", "GOOGLE_REDIRECT_SCHEME", "\"$googleRedirectScheme\"")
        manifestPlaceholders["appAuthRedirectScheme"] = googleRedirectScheme
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    packaging {
        jniLibs { useLegacyPackaging = true }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    testOptions {
        // android.util.Log (used by Logger) returns defaults instead of throwing in plain JVM unit tests.
        unitTests.isReturnDefaultValues = true
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.31.6"
        }
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)
    implementation(libs.androidx.material.icons)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)
    implementation(libs.androidx.datastore.preferences)
    implementation(libs.androidx.security.crypto)
    implementation(libs.hilt.android)
    ksp(libs.hilt.compiler)
    implementation(libs.androidx.hilt.navigation.compose)
    implementation(libs.okhttp)
    implementation(libs.okhttp.logging)
    implementation(libs.kotlinx.serialization.json)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.commons.compress)
    implementation(libs.appauth)
    implementation(libs.termux.terminal.emulator)
    implementation(libs.termux.terminal.view)

    testImplementation(libs.junit)
    testImplementation(libs.kotlinx.coroutines.test)
}

// Hilt's aggregate task fails with NoSuchMethodError ClassName.canonicalName() when an
// older javapoet wins conflict resolution. Force one modern version everywhere in this module.
configurations.all {
    resolutionStrategy.force("com.squareup:javapoet:1.13.0")
}
