package com.aicompany.app.terminal

import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.nio.file.Files
import java.util.zip.GZIPOutputStream

class RootfsExtractorTest {
    @get:Rule val tmp = TemporaryFolder()

    private fun TarArchiveOutputStream.file(name: String, text: String, mode: Int = 0b110_100_100) {
        val bytes = text.toByteArray()
        putArchiveEntry(TarArchiveEntry(name).apply { size = bytes.size.toLong(); this.mode = mode })
        write(bytes); closeArchiveEntry()
    }

    private fun TarArchiveOutputStream.dir(name: String) {
        putArchiveEntry(TarArchiveEntry("$name/")); closeArchiveEntry()
    }

    private fun TarArchiveOutputStream.symlink(name: String, target: String) {
        putArchiveEntry(TarArchiveEntry(name, TarArchiveEntry.LF_SYMLINK).apply { linkName = target }); closeArchiveEntry()
    }

    private fun TarArchiveOutputStream.hardlink(name: String, target: String) {
        putArchiveEntry(TarArchiveEntry(name, TarArchiveEntry.LF_LINK).apply { linkName = target }); closeArchiveEntry()
    }

    private fun archive(build: TarArchiveOutputStream.() -> Unit): File {
        val f = tmp.newFile("a.tar.gz")
        TarArchiveOutputStream(GZIPOutputStream(f.outputStream())).use { it.build() }
        return f
    }

    @Test fun extractsAlpineStyleLayoutWithAbsoluteSymlinks() {
        val dest = tmp.newFolder("root")
        val a = archive {
            dir("bin"); dir("etc"); dir("var")
            file("bin/busybox", "ELF", 0b111_101_101)
            symlink("bin/sh", "/bin/busybox")          // absolute target, does not exist on the host
            symlink("var/run", "/run")                 // dangling on the host
            file("var/run/leak.txt", "must be skipped") // below a symlink
            symlink("etc/mtab", "/proc/mounts")
            hardlink("bin/ash", "bin/busybox")
            file("etc/os-release", "NAME=Alpine")
        }
        RootfsExtractor.extract(a, dest)
        assertTrue(File(dest, "bin/busybox").isFile)
        assertTrue(Files.isSymbolicLink(File(dest, "bin/sh").toPath()))
        assertEquals("/bin/busybox", Files.readSymbolicLink(File(dest, "bin/sh").toPath()).toString())
        assertTrue(File(dest, "bin/ash").isFile)
        assertEquals("NAME=Alpine", File(dest, "etc/os-release").readText())
        assertFalse(File("/run/leak.txt").exists())
    }

    @Test fun doesNotWriteThroughAnExistingSymlinkFile() {
        val outside = tmp.newFile("outside.txt").apply { writeText("original") }
        val dest = tmp.newFolder("root2")
        val a = archive {
            symlink("evil", outside.absolutePath)
            file("evil", "overwritten")
        }
        RootfsExtractor.extract(a, dest)
        assertEquals("original", outside.readText())
        assertEquals("overwritten", File(dest, "evil").readText())
    }

    @Test fun reportsEntryNameOnFailure() {
        val dest = tmp.newFolder("root3")
        val a = archive { file("a/b", "x"); file("a/b/c", "y") }   // 'a/b' is a file, so 'a/b/c' cannot be created
        val e = runCatching { RootfsExtractor.extract(a, dest) }.exceptionOrNull()
        assertTrue(e?.message.orEmpty().contains("a/b/c"))
    }

    @Test fun deleteTreeDoesNotFollowSymlinks() {
        val keep = tmp.newFolder("keep").also { File(it, "f.txt").writeText("x") }
        val dir = tmp.newFolder("del")
        Files.createSymbolicLink(File(dir, "link").toPath(), keep.toPath())
        RootfsExtractor.deleteTree(dir)
        assertFalse(dir.exists())
        assertTrue(File(keep, "f.txt").exists())
    }

    @Test(expected = Exception::class)
    fun rejectsTraversal() {
        val dest = tmp.newFolder("root4")
        RootfsExtractor.extract(archive { file("../escape.txt", "x") }, dest)
    }
}
