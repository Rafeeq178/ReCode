package com.aicompany.app.local

import org.junit.Assert.assertTrue
import org.junit.Assert.assertFalse
import org.junit.Test

class GbnfBuilderTest {
    @Test fun grammarListsToolsSorted() {
        val g = GbnfBuilder.toolCallGrammar(listOf("get_time", "calculator"))
        assertTrue(g.contains("toolname ::= \"\\\"calculator\\\"\" | \"\\\"get_time\\\"\""))
        assertTrue(g.startsWith("root ::="))
    }

    @Test fun grammarContainsDoneAndArgumentsRules() {
        val g = GbnfBuilder.toolCallGrammar(listOf("read_file"))
        assertTrue(g.contains("donepart ::="))
        assertTrue(g.contains("\\\"arguments\\\""))
        assertTrue(g.contains("object ::="))
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsInjectedToolName() {
        GbnfBuilder.toolCallGrammar(listOf("bad\"name"))
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsEmptyToolList() {
        GbnfBuilder.toolCallGrammar(emptyList())
    }

    @Test fun ruleCountIsStable() {
        val g = GbnfBuilder.toolCallGrammar(listOf("a_tool"))
        assertFalse(g.contains("TODO"))
    }
}

class GbnfWhitespaceTest {
    @Test fun whitespaceIsBounded() {
        val g = GbnfBuilder.toolCallGrammar(listOf("a_tool"))
        assertFalse(g.contains("ws ::= [ \\t\\n\\r]*"))
        assertTrue(g.contains("ws ::= [ \\t\\n]{0,4}"))
        assertTrue(g.startsWith("root ::= \"{\""))
    }
}
