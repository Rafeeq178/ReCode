package com.aicompany.app.provider

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class OpenAiOptionsTest {
    private fun cfg(url: String, model: String) = ProviderConfig("i", "n", ApiFormat.OPENAI, url, model)

    @Test fun gpt5UsesCompletionTokensAndNoTemperature() {
        val o = OpenAiCompatClient.initialOptions(cfg("https://api.openai.com/v1", "gpt-5-mini"))
        assertTrue(o.useCompletionTokens)
        assertFalse(o.sendTemperature)
    }

    @Test fun oSeriesIsReasoning() = assertFalse(OpenAiCompatClient.initialOptions(cfg("https://api.openai.com/v1", "o3-mini")).sendTemperature)

    @Test fun gpt4oKeepsTemperature() {
        val o = OpenAiCompatClient.initialOptions(cfg("https://api.openai.com/v1", "gpt-4o"))
        assertTrue(o.useCompletionTokens)
        assertTrue(o.sendTemperature)
    }

    @Test fun compatibleProvidersKeepMaxTokens() {
        listOf("https://api.groq.com/openai/v1", "https://openrouter.ai/api/v1", "https://api.deepseek.com/v1", "http://127.0.0.1:8080/v1").forEach {
            val o = OpenAiCompatClient.initialOptions(cfg(it, "some-model"))
            assertFalse(it, o.useCompletionTokens)
            assertTrue(it, o.sendTemperature)
        }
    }

    @Test fun adaptsToServerComplaints() {
        val base = OpenAiCompatClient.BodyOptions(useCompletionTokens = false, sendTemperature = true)
        val swapped = OpenAiCompatClient.adapt(base, "Unsupported parameter: 'max_tokens' is not supported with this model. Use 'max_completion_tokens' instead.")
        assertEquals(true, swapped?.useCompletionTokens)
        val noTemp = OpenAiCompatClient.adapt(base, "Unsupported value: 'temperature' does not support 0.7 with this model. Only the default (1) value is supported.")
        assertEquals(false, noTemp?.sendTemperature)
        assertNull(OpenAiCompatClient.adapt(base, "model not found"))
    }
}
