package com.aicompany.app.scheduler

import org.junit.Assert.assertEquals
import org.junit.Test

class RouterTest {
    @Test fun codingWorkIsHeavy() {
        assertEquals(Router.Kind.HEAVY, Router.classify("Implement a login screen"))
    }

    @Test fun summaryWorkIsLight() {
        assertEquals(Router.Kind.LIGHT, Router.classify("Summarize these notes"))
    }

    @Test fun heavyAlwaysRoutesToApi() {
        assertEquals(Router.Route.API, Router.route(Router.Kind.HEAVY, localAvailable = true))
    }

    @Test fun lightUsesLocalWhenAvailable() {
        assertEquals(Router.Route.LOCAL, Router.route(Router.Kind.LIGHT, localAvailable = true))
        assertEquals(Router.Route.API, Router.route(Router.Kind.LIGHT, localAvailable = false))
    }
}

class RouterWordMatchTest {
    private fun cfg(id: String, f: com.aicompany.app.provider.ApiFormat) =
        com.aicompany.app.provider.ProviderConfig(id, id, f, "x", "m")

    @Test fun latestIsNotTest() = assertEquals(Router.Kind.LIGHT, Router.classify("What is the latest news?"))
    @Test fun planetIsNotPlan() = assertEquals(Router.Kind.LIGHT, Router.classify("Name every planet"))
    @Test fun planningIsHeavy() = assertEquals(Router.Kind.HEAVY, Router.classify("Planning the release"))
    @Test fun testingIsHeavy() = assertEquals(Router.Kind.HEAVY, Router.classify("Run testing on the app"))

    @Test fun lightPutsLocalFirst() {
        val chain = listOf(cfg("api", com.aicompany.app.provider.ApiFormat.OPENAI), cfg("loc", com.aicompany.app.provider.ApiFormat.LOCAL))
        assertEquals(listOf("loc", "api"), Router.prioritize(Router.Kind.LIGHT, chain).map { it.id })
    }

    @Test fun heavyPutsApiFirst() {
        val chain = listOf(cfg("loc", com.aicompany.app.provider.ApiFormat.LOCAL), cfg("api", com.aicompany.app.provider.ApiFormat.OPENAI))
        assertEquals(listOf("api", "loc"), Router.prioritize(Router.Kind.HEAVY, chain).map { it.id })
    }
}
