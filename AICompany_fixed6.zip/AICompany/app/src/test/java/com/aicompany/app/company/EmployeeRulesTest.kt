package com.aicompany.app.company

import org.junit.Assert.assertTrue
import org.junit.Test

class EmployeeRulesTest {
    private val tools = setOf("read_file", "write_file", "load_skill", "calculator", "get_time")
    private val providers = setOf("p1")
    private val skills = setOf("s1")

    private fun base(
        tools: List<String> = listOf("read_file", "calculator"),
        skillIds: List<String> = emptyList(),
        permission: String = "ASK",
        maxSteps: Int = 15,
        color: String = "#C9623F",
        status: String = "IDLE",
    ) = EmployeeSnapshot(
        name = "Coder",
        role = "software engineer",
        tools = tools,
        skillIds = skillIds,
        providerIds = listOf("p1"),
        terminalPermission = permission,
        maxSteps = maxSteps,
        color = color,
        status = status,
    )

    private fun errors(s: EmployeeSnapshot) = EmployeeRules.validate(s, tools, skills, providers)

    @Test fun validSnapshotPasses() = assertTrue(errors(base()).isEmpty())

    @Test fun unknownToolIsRejected() = assertTrue(errors(base(tools = listOf("nope"))).any { it.contains("Unknown tools") })

    @Test fun ceoOnlyToolIsRejected() = assertTrue(errors(base(tools = listOf("hire_worker"))).any { it.contains("CEO tools") })

    @Test fun skillNeedsLoadSkillTool() {
        assertTrue(errors(base(skillIds = listOf("s1"))).any { it.contains("load_skill") })
        assertTrue(errors(base(tools = listOf("load_skill"), skillIds = listOf("s1"))).isEmpty())
    }

    @Test fun unknownSkillIsRejected() {
        assertTrue(errors(base(tools = listOf("load_skill"), skillIds = listOf("missing"))).any { it.contains("Unknown skills") })
    }

    @Test fun badPermissionAndLimitsAreRejected() {
        assertTrue(errors(base(permission = "YOLO")).any { it.contains("Terminal permission") })
        assertTrue(errors(base(maxSteps = 0)).any { it.contains("Max steps") })
    }

    @Test fun badColorIsRejected() = assertTrue(errors(base(color = "red")).any { it.contains("Color") })

    @Test fun workingStatusCannotBeSetByOwner() = assertTrue(errors(base(status = "WORKING")).any { it.contains("IDLE or PAUSED") })
}
