package com.aicompany.app.local

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GgufValidatorTest {
    private fun header(magic: String, version: Int): ByteArray =
        magic.toByteArray(Charsets.US_ASCII) + byteArrayOf(
            (version and 0xFF).toByte(), ((version shr 8) and 0xFF).toByte(),
            ((version shr 16) and 0xFF).toByte(), ((version shr 24) and 0xFF).toByte(),
        )

    @Test fun acceptsVersion3() = assertTrue(GgufValidator.isGgufHeader(header("GGUF", 3)))
    @Test fun acceptsVersion2() = assertTrue(GgufValidator.isGgufHeader(header("GGUF", 2)))
    @Test fun rejectsWrongMagic() = assertFalse(GgufValidator.isGgufHeader(header("GGML", 3)))
    @Test fun rejectsUnknownVersion() = assertFalse(GgufValidator.isGgufHeader(header("GGUF", 9)))
    @Test fun rejectsShortHeader() = assertFalse(GgufValidator.isGgufHeader(byteArrayOf(71, 71)))
}
