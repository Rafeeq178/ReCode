package com.aicompany.app.local

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MemoryMonitorTest {
    @Test fun runningCriticalUnloads() = assertTrue(MemoryMonitor.shouldUnload(15))

    @Test fun uiHiddenAndBackgroundDoNotUnload() {
        assertFalse(MemoryMonitor.shouldUnload(20))   // TRIM_MEMORY_UI_HIDDEN
        assertFalse(MemoryMonitor.shouldUnload(40))   // TRIM_MEMORY_BACKGROUND
    }

    @Test fun mildRunningLevelsDoNotUnload() {
        assertFalse(MemoryMonitor.shouldUnload(5))
        assertFalse(MemoryMonitor.shouldUnload(10))
    }

    @Test fun cachedKillLevelsUnload() {
        assertTrue(MemoryMonitor.shouldUnload(60))
        assertTrue(MemoryMonitor.shouldUnload(80))
    }
}
