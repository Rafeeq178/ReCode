package com.aicompany.app.llama

import com.aicompany.app.provider.ChatMessage
import com.aicompany.app.provider.ProviderException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PromptFitterTest {
    // 1 token per 4 characters, close enough for the logic under test.
    private val count: (List<ChatMessage>) -> Int = { list -> list.sumOf { it.content.length / 4 + 4 } }

    private fun msg(role: String, n: Int) = ChatMessage(role, "x".repeat(n))

    @Test fun returnsInputWhenItFits() {
        val input = listOf(msg("system", 40), msg("user", 40))
        assertEquals(input, PromptFitter.fit(input, 0, 1000, count))
    }

    @Test fun dropsOldestButKeepsSystemAndNewest() {
        val input = listOf(
            msg("system", 40), msg("user", 400), msg("assistant", 400), msg("user", 400), msg("assistant", 400), msg("user", 40),
        )
        val out = PromptFitter.fit(input, 0, 150, count)
        assertEquals("system", out.first().role)
        assertTrue(out.last().content.endsWith(input.last().content))
        assertTrue(out.size < input.size)
        assertTrue(count(out) <= 150)
        assertEquals("user", out[1].role)
        assertTrue(out[1].content.startsWith(PromptFitter.MARKER))
    }

    @Test fun keepHeadProtectsGoal() {
        val input = listOf(msg("system", 40), msg("user", 40), msg("assistant", 800), msg("user", 800), msg("assistant", 40), msg("user", 40))
        val out = PromptFitter.fit(input, 2, 150, count)
        assertEquals(input[1].content, out[1].content)
    }

    @Test fun cutsHugeLastMessage() {
        val input = listOf(msg("system", 40), msg("user", 40_000))
        val out = PromptFitter.fit(input, 0, 500, count)
        assertTrue(count(out) <= 500)
        assertTrue(out.last().content.contains("cut to fit"))
    }

    @Test(expected = ProviderException.BadRequest::class)
    fun failsWhenNothingCanShrink() {
        PromptFitter.fit(listOf(msg("system", 8000), msg("user", 10)), 0, 5) { 10_000 }
    }
}
