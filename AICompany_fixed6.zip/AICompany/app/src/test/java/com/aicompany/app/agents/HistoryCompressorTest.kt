package com.aicompany.app.agents

import com.aicompany.app.provider.ChatMessage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HistoryCompressorTest {

    @Test fun shortHistoryIsUntouched() {
        val h = mutableListOf(ChatMessage("system", "s"), ChatMessage("user", "g"), ChatMessage("assistant", "a"))
        HistoryCompressor.compact(h, 5_000)
        assertEquals(3, h.size)
    }

    @Test fun oldMiddleMessagesAreDroppedAndAnchorsKept() {
        val h = mutableListOf(ChatMessage("system", "SYS"), ChatMessage("user", "GOAL"))
        repeat(20) { i -> h += ChatMessage("assistant", "x$i".padEnd(1_000, 'x')) }
        val lastBefore = h.last().content
        HistoryCompressor.compact(h, 5_000)
        assertEquals("SYS", h[0].content)
        assertEquals("GOAL", h[1].content)
        assertTrue(h.size < 22)
        assertEquals(lastBefore, h.last().content)
        assertTrue(h.any { it.content.contains("removed to save memory") })
    }
}
