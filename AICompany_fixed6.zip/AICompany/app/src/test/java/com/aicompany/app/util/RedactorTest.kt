package com.aicompany.app.util

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RedactorTest {
    @Test fun openAiStyleKeyIsRemoved() {
        val out = Redactor.redact("key sk-abcdefghijklmnop123")
        assertFalse(out.contains("sk-abcdefghijklmnop123"))
    }

    @Test fun bearerTokenIsRemoved() {
        val out = Redactor.redact("Authorization: Bearer abc.def.ghi")
        assertFalse(out.contains("abc.def.ghi"))
        assertTrue(out.contains("[REDACTED]"))
    }

    @Test fun keyValuePasswordIsRemoved() {
        val out = Redactor.redact("""{"password": "hunter2"}""")
        assertFalse(out.contains("hunter2"))
    }

    @Test fun normalTextIsUntouched() {
        assertTrue(Redactor.redact("hello world") == "hello world")
    }
}
