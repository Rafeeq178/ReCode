package com.aicompany.app.tools

import com.aicompany.app.tools.builtin.NetGuard
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.net.InetAddress

class NetGuardTest {
    private fun pub(ip: String) = NetGuard.isPublic(InetAddress.getByName(ip))   // literals: no DNS lookup

    @Test fun blocksLoopbackAndPrivate() {
        listOf("127.0.0.1", "10.1.2.3", "192.168.0.5", "172.16.0.1", "169.254.169.254", "0.0.0.0", "100.64.0.1", "::1", "fd00::1", "fe80::1")
            .forEach { assertFalse(it, pub(it)) }
    }

    @Test fun allowsPublic() {
        listOf("8.8.8.8", "1.1.1.1", "93.184.216.34", "2606:4700:4700::1111").forEach { assertTrue(it, pub(it)) }
    }
}
