package com.aicompany.app.tools.custom

import com.aicompany.app.tools.Schema
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CustomToolValidatorTest {
    private val params = Schema.obj(mapOf("city" to Schema.str("City", 80)), listOf("city"))

    private fun def(type: String, build: CustomToolDef.() -> CustomToolDef) =
        CustomToolDef(name = "weather_lookup", description = "Look up weather", type = type, parameters = params)
            .build()

    @Test fun validShellToolPasses() {
        val d = def("SHELL") { copy(command = "echo {city}") }
        assertTrue(CustomToolValidator.validate(d, setOf("calculator")).isEmpty())
    }

    @Test fun placeholderMustBeAParameter() {
        val d = def("SHELL") { copy(command = "echo {unknown}") }
        assertTrue(CustomToolValidator.validate(d, emptySet()).any { it.contains("not a parameter") })
    }

    @Test fun httpMustBeHttps() {
        val d = def("HTTP") { copy(method = "GET", url = "http://example.com/{city}") }
        assertTrue(CustomToolValidator.validate(d, emptySet()).any { it.contains("https") })
    }

    @Test fun secretsAreForbiddenInShell() {
        val d = def("SHELL") { copy(command = "curl {{secret:TOKEN}}") }
        assertTrue(CustomToolValidator.validate(d, emptySet()).any { it.contains("Secrets") })
    }

    @Test fun builtinNameClashIsRejected() {
        val d = def("PROMPT") { copy(name = "calculator", prompt = "Hi {city}") }
        assertTrue(CustomToolValidator.validate(d, setOf("calculator")).any { it.contains("clashes") })
    }

    @Test fun shellQuotingEscapesSingleQuotes() {
        assertEquals("'it'\\''s'", Template.shellQuote("it's"))
    }

    @Test fun templateFillUsesEncoder() {
        val args = buildJsonObject { put("city", "New York") }
        val out = Template.fill("q={city}", args) { java.net.URLEncoder.encode(it, "UTF-8") }
        assertEquals("q=New+York", out)
    }
}
