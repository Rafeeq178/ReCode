package com.aicompany.app.tools

import com.aicompany.app.tools.builtin.Calc
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SchemaValidatorTest {
    private val json = Json.Default
    private val schema = Schema.obj(
        mapOf(
            "path" to Schema.str("p", 10),
            "count" to Schema.int("c", 1, 5),
        ),
        listOf("path"),
    )

    private fun v(s: String): JsonElement = json.parseToJsonElement(s)

    @Test fun validArgumentsPass() {
        assertEquals(emptyList<String>(), SchemaValidator.validate(schema, v("""{"path":"a.txt","count":3}""")))
    }

    @Test fun missingRequiredIsReported() {
        val errors = SchemaValidator.validate(schema, v("""{"count":2}"""))
        assertTrue(errors.any { it.contains("path is required") })
    }

    @Test fun unknownArgumentIsRejected() {
        val errors = SchemaValidator.validate(schema, v("""{"path":"a","extra":1}"""))
        assertTrue(errors.any { it.contains("not an allowed argument") })
    }

    @Test fun wrongTypeAndRangeAreRejected() {
        assertTrue(SchemaValidator.validate(schema, v("""{"path":"a","count":"3"}""")).isNotEmpty())
        assertTrue(SchemaValidator.validate(schema, v("""{"path":"a","count":9}""")).isNotEmpty())
        assertTrue(SchemaValidator.validate(schema, v("""{"path":"a","count":2.5}""")).isNotEmpty())
    }

    @Test fun maxLengthIsEnforced() {
        assertTrue(SchemaValidator.validate(schema, v("""{"path":"this is far too long"}""")).isNotEmpty())
    }

    @Test fun calculatorBasics() {
        assertEquals(14.0, Calc.evaluate("2+3*4"), 1e-9)
        assertEquals(20.0, Calc.evaluate("(2+3)*4"), 1e-9)
        assertEquals(8.0, Calc.evaluate("2^3"), 1e-9)
        assertEquals(-5.0, Calc.evaluate("-(2+3)"), 1e-9)
    }

    @Test(expected = IllegalArgumentException::class)
    fun divisionByZeroThrows() {
        Calc.evaluate("1/0")
    }

    @Test(expected = IllegalArgumentException::class)
    fun garbageInputThrows() {
        Calc.evaluate("2+abc")
    }
}
