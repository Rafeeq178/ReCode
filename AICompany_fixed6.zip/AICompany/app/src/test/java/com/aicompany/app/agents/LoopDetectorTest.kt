package com.aicompany.app.agents

import com.aicompany.app.tools.ToolCall
import kotlinx.serialization.json.Json
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LoopDetectorTest {
    private fun call(json: String) = ToolCall("read_file", Json.Default.parseToJsonElement(json) as kotlinx.serialization.json.JsonObject)

    @Test fun thirdIdenticalCallTriggers() {
        val d = LoopDetector()
        assertFalse(d.record(call("""{"path":"a.txt"}""")))
        assertFalse(d.record(call("""{"path":"a.txt"}""")))
        assertTrue(d.record(call("""{"path":"a.txt"}""")))
    }

    @Test fun keyOrderDoesNotHideALoop() {
        val d = LoopDetector()
        assertFalse(d.record(call("""{"a":1,"b":2}""")))
        assertFalse(d.record(call("""{"b":2,"a":1}""")))
        assertTrue(d.record(call("""{"a":1,"b":2}""")))
    }

    @Test fun differentArgumentsDoNotTrigger() {
        val d = LoopDetector()
        assertFalse(d.record(call("""{"path":"a"}""")))
        assertFalse(d.record(call("""{"path":"b"}""")))
        assertFalse(d.record(call("""{"path":"c"}""")))
    }
}
