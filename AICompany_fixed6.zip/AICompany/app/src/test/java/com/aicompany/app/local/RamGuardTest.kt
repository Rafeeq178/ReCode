package com.aicompany.app.local

import org.junit.Assert.assertEquals
import org.junit.Test

class RamGuardTest {
    private val gb = 1024L * 1024 * 1024

    @Test fun smallModelIsOk() = assertEquals(RamGuard.Verdict.OK, RamGuard.assess(gb, 3 * gb))

    @Test fun modelNearLimitIsTight() = assertEquals(RamGuard.Verdict.TIGHT, RamGuard.assess(gb, (gb * 1.6).toLong()))

    @Test fun hugeModelIsTooLarge() = assertEquals(RamGuard.Verdict.TOO_LARGE, RamGuard.assess(4 * gb, gb))
}
