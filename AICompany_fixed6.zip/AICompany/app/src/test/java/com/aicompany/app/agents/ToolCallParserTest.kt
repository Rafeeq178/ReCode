package com.aicompany.app.agents

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ToolCallParserTest {

    @Test fun parsesToolCall() {
        val action = ToolCallParser.parse("""{"tool":"calculator","arguments":{"expression":"2+2"}}""")
        assertTrue(action is AgentAction.Call)
        val call = (action as AgentAction.Call).call
        assertEquals("calculator", call.name)
        assertEquals("2+2", call.arguments["expression"]!!.toString().trim('"'))
    }

    @Test fun parsesFencedToolCall() {
        val action = ToolCallParser.parse("```json\n{\"tool\":\"get_time\",\"arguments\":{}}\n```")
        assertTrue(action is AgentAction.Call)
    }

    @Test fun parsesDoneObject() {
        val action = ToolCallParser.parse("""{"done":"Finished the task"}""")
        assertEquals("Finished the task", (action as AgentAction.Done).text)
    }

    @Test fun parsesPlainDone() {
        val action = ToolCallParser.parse("Result is 4 DONE")
        assertEquals("Result is 4", (action as AgentAction.Done).text)
    }

    @Test fun rejectsPlainText() {
        assertTrue(ToolCallParser.parse("I think the answer is 4") is AgentAction.Invalid)
    }

    @Test fun rejectsEmpty() {
        assertTrue(ToolCallParser.parse("   ") is AgentAction.Invalid)
    }

    @Test fun rejectsNonObjectArguments() {
        assertTrue(ToolCallParser.parse("""{"tool":"x","arguments":"oops"}""") is AgentAction.Invalid)
    }

    @Test fun rejectsMissingToolName() {
        assertTrue(ToolCallParser.parse("""{"arguments":{}}""") is AgentAction.Invalid)
    }

    @Test fun rejectsBrokenJson() {
        assertTrue(ToolCallParser.parse("""{"tool":"x",""") is AgentAction.Invalid)
    }
}
