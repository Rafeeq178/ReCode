package com.aicompany.app.terminal

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ArchivePathGuardTest {
    @Test fun normalNamesAreAllowed() {
        assertNull(ArchivePathGuard.check("bin/sh"))
        assertNull(ArchivePathGuard.check("etc/apk/repositories"))
    }

    @Test fun parentReferencesAreBlocked() {
        assertEquals("parent folder reference", ArchivePathGuard.check("../../etc/passwd"))
        assertEquals("parent folder reference", ArchivePathGuard.check("a/../../b"))
    }

    @Test fun absolutePathsAreBlocked() {
        assertEquals("absolute path", ArchivePathGuard.check("/etc/passwd"))
    }

    @Test fun emptyAndNulNamesAreBlocked() {
        assertEquals("empty name", ArchivePathGuard.check("  "))
        assertEquals("NUL byte in name", ArchivePathGuard.check("a\u0000b"))
    }
}
