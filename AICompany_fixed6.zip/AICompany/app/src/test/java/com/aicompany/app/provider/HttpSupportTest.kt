package com.aicompany.app.provider

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HttpSupportTest {
    @Test fun httpsAlwaysAllowed() = assertTrue(isAllowedBaseUrl("https://api.openai.com/v1"))

    @Test fun localHttpAllowed() {
        listOf("http://127.0.0.1:8080/v1", "http://localhost:11434/v1", "http://192.168.1.20:8080/v1", "http://10.0.2.2:8080", "http://[::1]:8080/v1")
            .forEach { assertTrue(it, isAllowedBaseUrl(it)) }
    }

    @Test fun remoteHttpRejected() {
        listOf("http://api.example.com/v1", "http://8.8.8.8/v1", "http://127.0.0.1.evil.com/v1", "http://localhost.evil.com/v1",
            "http://127.0.0.1@evil.com/v1", "http://172.32.0.1/v1", "ftp://127.0.0.1")
            .forEach { assertFalse(it, isAllowedBaseUrl(it)) }
    }

    @Test fun rateLimitCarriesRetryAfter() {
        val e = mapHttpError(429, "slow down", 7_000) as ProviderException.RateLimited
        assertEquals(7_000L, e.retryAfterMs)
    }

    @Test fun quotaBodyIsQuota() = assertTrue(mapHttpError(429, "You exceeded your current quota") is ProviderException.Quota)
}
