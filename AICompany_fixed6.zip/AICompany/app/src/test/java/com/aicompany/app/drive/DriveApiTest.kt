package com.aicompany.app.drive

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DriveApiTest {
    @Test fun escapesQuotesAndBackslashes() {
        assertEquals("it\\'s a \\\\ test", DriveApi.escapeQuery("it's a \\ test"))
    }

    @Test fun fileIdShapeIsChecked() {
        assertTrue(DriveApi.FILE_ID.matches("1AbCdEfGhIjKlMnOpQrS"))
        assertFalse(DriveApi.FILE_ID.matches("../../etc"))
        assertFalse(DriveApi.FILE_ID.matches("short"))
    }
}
