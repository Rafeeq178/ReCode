package com.aicompany.app.tools

import com.aicompany.app.tools.builtin.Calc
import org.junit.Assert.assertEquals
import org.junit.Test

class CalcTest {
    private fun e(s: String) = Calc.evaluate(s)

    @Test fun unaryMinusIsLooserThanPower() = assertEquals(-4.0, e("-2^2"), 0.0)
    @Test fun parenthesisedNegativeBase() = assertEquals(4.0, e("(-2)^2"), 0.0)
    @Test fun negativeExponent() = assertEquals(0.25, e("2^-2"), 0.0)
    @Test fun powerIsRightAssociative() = assertEquals(512.0, e("2^3^2"), 0.0)
    @Test fun doubleNegative() = assertEquals(2.0, e("--2"), 0.0)
    @Test fun mixed() = assertEquals(14.0, e("2+3*4"), 0.0)
    @Test fun minusAfterMultiply() = assertEquals(-6.0, e("2*-3"), 0.0)
    @Test(expected = IllegalArgumentException::class) fun divisionByZero() { e("1/0") }
}
