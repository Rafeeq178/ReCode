package com.aicompany.app.tools

import org.junit.After
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.File
import java.util.UUID

class WorkspaceSandboxTest {
    private lateinit var root: File
    private lateinit var sandbox: WorkspaceSandbox

    @Before fun setUp() {
        root = File(System.getProperty("java.io.tmpdir"), "ws-${UUID.randomUUID()}")
        sandbox = WorkspaceSandbox(root)
    }

    @After fun tearDown() {
        root.deleteRecursively()
    }

    @Test fun normalRelativePathResolvesInside() {
        val f = sandbox.resolve("notes/today.txt")
        assertTrue(f.path.startsWith(sandbox.root.path + File.separator))
    }

    @Test(expected = IllegalArgumentException::class)
    fun parentTraversalIsBlocked() {
        sandbox.resolve("../secret.txt")
    }

    @Test(expected = IllegalArgumentException::class)
    fun nestedTraversalIsBlocked() {
        sandbox.resolve("a/../../secret.txt")
    }

    @Test(expected = IllegalArgumentException::class)
    fun absolutePathIsBlocked() {
        sandbox.resolve("/etc/passwd")
    }

    @Test(expected = IllegalArgumentException::class)
    fun windowsDriveIsBlocked() {
        sandbox.resolve("C:\\Windows\\win.ini")
    }

    @Test(expected = IllegalArgumentException::class)
    fun nulByteIsBlocked() {
        sandbox.resolve("a\u0000b")
    }
}
