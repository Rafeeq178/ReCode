package com.aicompany.app.tools.social

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MessagingRulesTest {
    @Test fun acceptsNumericChatAndChannel() {
        assertTrue(MessagingRules.CHAT.matches("-1001234567890"))
        assertTrue(MessagingRules.CHAT.matches("@my_channel"))
    }

    @Test fun rejectsInjectionLikeChatIds() {
        assertFalse(MessagingRules.CHAT.matches("123/../../x"))
        assertFalse(MessagingRules.CHAT.matches("@a"))
    }

    @Test fun phoneNeedsDigitsOnly() {
        assertTrue(MessagingRules.PHONE.matches("923001234567"))
        assertFalse(MessagingRules.PHONE.matches("+92 300 1234567"))
        assertFalse(MessagingRules.PHONE.matches("123"))
    }
}
