// JNI bridge between LlamaNative (Kotlin) and llama.cpp.
//
// Design notes
//  * Handles are opaque ids kept in a registry of shared_ptr<Engine>. nativeFree removes the id,
//    cancels any running generation, waits for it to leave the engine, and only then releases the
//    llama objects. A caller that was still waiting on the engine holds its own shared_ptr, so the
//    Engine object is destroyed only after the last user is gone (no use-after-free).
//  * All text crosses JNI as UTF-8 byte arrays. NewStringUTF / GetStringUTFChars use *modified*
//    UTF-8 (4-byte characters such as emoji become surrogate pairs), which corrupts prompts and
//    can abort the VM under CheckJNI in debug builds.
//  * Chat templates are applied here with llama_chat_apply_template, using the template stored
//    in the GGUF file, so Llama / Gemma / Phi / Mistral / Qwen models all get their own format.
//  * The KV cache is kept between requests. A new prompt reuses the longest common token prefix
//    with what is already cached, so an agent loop only processes the newly added tail.
#include <jni.h>
#include <android/log.h>
#include <algorithm>
#include <atomic>
#include <cstdint>
#include <cstring>
#include <memory>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>
#include "llama.h"

#define LOG_TAG "AICompanyLLM"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

namespace {

constexpr int kStatusOk = 0;
constexpr int kStatusCancelled = 1;
constexpr int kStatusContextFull = 2;   // prompt does not fit, or the window ran out mid-answer
constexpr int kStatusLength = 3;        // stopped because max_tokens was reached
constexpr int kErrDecode = -1;
constexpr int kErrTokenize = -2;
constexpr int kErrHandle = -3;
constexpr int kErrSampler = -4;

constexpr int kMinCtx = 256;
constexpr int kMaxCtx = 8192;
constexpr int kMaxThreads = 16;
constexpr int kBatch = 512;                    // prompt is decoded in chunks of this size
constexpr size_t kMaxPromptBytes = 4u << 20;   // 4 MiB of UTF-8 is far beyond any context window
constexpr int kMaxMessages = 512;

struct Engine {
    llama_model * model = nullptr;
    llama_context * ctx = nullptr;
    const llama_vocab * vocab = nullptr;
    int n_ctx = 0;
    std::mutex run_lock;
    std::atomic<bool> cancel{false};
    // Tokens whose KV entries are currently in the cache (positions 0..size-1). run_lock protects it.
    std::vector<llama_token> cache_tokens;
};

std::once_flag backend_once;
std::mutex g_registry_lock;
std::unordered_map<jlong, std::shared_ptr<Engine>> g_engines;
std::atomic<jlong> g_next_id{1};

std::shared_ptr<Engine> acquire(jlong handle) {
    std::lock_guard<std::mutex> guard(g_registry_lock);
    auto it = g_engines.find(handle);
    return it == g_engines.end() ? nullptr : it->second;
}

bool abort_callback(void * data) {
    return static_cast<Engine *>(data)->cancel.load(std::memory_order_relaxed);
}

// Returns how many leading bytes form complete UTF-8 characters, so a multi-byte
// character split across tokens is never handed to Kotlin half-finished.
size_t complete_utf8_prefix(const std::string & s) {
    const size_t n = s.size();
    for (size_t back = 1; back <= 3 && back <= n; ++back) {
        const unsigned char c = static_cast<unsigned char>(s[n - back]);
        if ((c & 0xC0) == 0x80) continue;  // continuation byte, keep looking for the lead
        size_t need = 1;
        if ((c & 0xE0) == 0xC0) need = 2;
        else if ((c & 0xF0) == 0xE0) need = 3;
        else if ((c & 0xF8) == 0xF0) need = 4;
        return need > back ? n - back : n;
    }
    return n;
}

bool bytes_to_string(JNIEnv * env, jbyteArray arr, std::string & out) {
    out.clear();
    if (arr == nullptr) return false;
    const jsize len = env->GetArrayLength(arr);
    if (len < 0 || static_cast<size_t>(len) > kMaxPromptBytes) return false;
    out.resize(static_cast<size_t>(len));
    if (len > 0) {
        env->GetByteArrayRegion(arr, 0, len, reinterpret_cast<jbyte *>(&out[0]));
        if (env->ExceptionCheck()) {
            env->ExceptionClear();
            return false;
        }
    }
    return true;
}

jbyteArray string_to_bytes(JNIEnv * env, const char * data, size_t len) {
    jbyteArray arr = env->NewByteArray(static_cast<jsize>(len));
    if (arr == nullptr) return nullptr;
    if (len > 0) env->SetByteArrayRegion(arr, 0, static_cast<jsize>(len), reinterpret_cast<const jbyte *>(data));
    return arr;
}

// Tokenizes UTF-8 text. Special tokens in the text are parsed because the chat template emits them.
// A model that adds BOS on its own while the template already wrote one would see BOS twice; drop the duplicate.
bool tokenize(const Engine & e, const std::string & text, std::vector<llama_token> & out) {
    const int32_t len = static_cast<int32_t>(text.size());
    out.assign(static_cast<size_t>(len) + 16, 0);
    int32_t n = llama_tokenize(e.vocab, text.data(), len, out.data(), static_cast<int32_t>(out.size()), true, true);
    if (n < 0) {
        out.assign(static_cast<size_t>(-n), 0);
        n = llama_tokenize(e.vocab, text.data(), len, out.data(), static_cast<int32_t>(out.size()), true, true);
    }
    if (n <= 0) {
        out.clear();
        return false;
    }
    out.resize(static_cast<size_t>(n));
    const llama_token bos = llama_vocab_bos(e.vocab);
    if (bos >= 0 && out.size() >= 2 && out[0] == bos && out[1] == bos) out.erase(out.begin());
    return true;
}

void reset_cache(Engine & e) {
    llama_memory_clear(llama_get_memory(e.ctx), true);
    e.cache_tokens.clear();
}

}  // namespace

extern "C" JNIEXPORT jlong JNICALL
Java_com_aicompany_app_llama_LlamaNative_nativeLoad(
        JNIEnv * env, jclass, jbyteArray jpath, jint n_ctx, jint n_threads, jboolean use_mmap) {
    std::call_once(backend_once, [] { llama_backend_init(); });
    if (jpath == nullptr || n_ctx < kMinCtx || n_ctx > kMaxCtx || n_threads < 1 || n_threads > kMaxThreads) {
        return 0;
    }
    std::string path;
    if (!bytes_to_string(env, jpath, path) || path.empty()) return 0;

    llama_model_params mparams = llama_model_default_params();
    mparams.use_mmap = use_mmap == JNI_TRUE;
    mparams.n_gpu_layers = 0;
    llama_model * model = llama_model_load_from_file(path.c_str(), mparams);
    if (model == nullptr) {
        LOGE("model load failed");
        return 0;
    }

    llama_context_params cparams = llama_context_default_params();
    cparams.n_ctx = static_cast<uint32_t>(n_ctx);
    cparams.n_batch = static_cast<uint32_t>(std::min(kBatch, static_cast<int>(n_ctx)));
    cparams.n_ubatch = cparams.n_batch;
    cparams.n_threads = n_threads;
    cparams.n_threads_batch = n_threads;
    llama_context * ctx = llama_init_from_model(model, cparams);
    if (ctx == nullptr) {
        LOGE("context creation failed");
        llama_model_free(model);
        return 0;
    }

    auto engine = std::make_shared<Engine>();
    engine->model = model;
    engine->ctx = ctx;
    engine->vocab = llama_model_get_vocab(model);
    engine->n_ctx = n_ctx;
    // Lets a cancel request interrupt a long prompt decode, not only token sampling.
    llama_set_abort_callback(ctx, abort_callback, engine.get());

    const jlong id = g_next_id.fetch_add(1);
    {
        std::lock_guard<std::mutex> guard(g_registry_lock);
        g_engines[id] = engine;
    }
    LOGI("model loaded, n_ctx=%d", n_ctx);
    return id;
}

extern "C" JNIEXPORT void JNICALL
Java_com_aicompany_app_llama_LlamaNative_nativeFree(JNIEnv *, jclass, jlong handle) {
    std::shared_ptr<Engine> engine;
    {
        std::lock_guard<std::mutex> guard(g_registry_lock);
        auto it = g_engines.find(handle);
        if (it == g_engines.end()) return;
        engine = it->second;
        g_engines.erase(it);  // no new caller can acquire this handle from now on
    }
    engine->cancel.store(true);
    {
        // Waits for a running generation to notice the cancel and leave. The guard is released
        // before the Engine can be destroyed (that happens when the last shared_ptr goes away).
        std::lock_guard<std::mutex> guard(engine->run_lock);
        if (engine->ctx != nullptr) {
            llama_free(engine->ctx);
            engine->ctx = nullptr;
        }
        if (engine->model != nullptr) {
            llama_model_free(engine->model);
            engine->model = nullptr;
        }
        engine->cache_tokens.clear();
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_aicompany_app_llama_LlamaNative_nativeCancel(JNIEnv *, jclass, jlong handle) {
    auto engine = acquire(handle);
    if (engine != nullptr) engine->cancel.store(true);
}

// Formats messages with the chat template stored in the GGUF (falls back to ChatML when the model
// has none, or when the template is not one llama.cpp recognises). Returns null on failure.
extern "C" JNIEXPORT jbyteArray JNICALL
Java_com_aicompany_app_llama_LlamaNative_nativeApplyTemplate(
        JNIEnv * env, jclass, jlong handle, jobjectArray roles, jobjectArray contents) {
    auto engine = acquire(handle);
    if (engine == nullptr || roles == nullptr || contents == nullptr) return nullptr;
    const jsize n = env->GetArrayLength(roles);
    if (n <= 0 || n > kMaxMessages || env->GetArrayLength(contents) != n) return nullptr;

    std::vector<std::string> role_s(static_cast<size_t>(n));
    std::vector<std::string> content_s(static_cast<size_t>(n));
    size_t total = 0;
    for (jsize i = 0; i < n; ++i) {
        auto jrole = static_cast<jbyteArray>(env->GetObjectArrayElement(roles, i));
        auto jcontent = static_cast<jbyteArray>(env->GetObjectArrayElement(contents, i));
        const bool ok = bytes_to_string(env, jrole, role_s[i]) && bytes_to_string(env, jcontent, content_s[i]);
        if (jrole != nullptr) env->DeleteLocalRef(jrole);
        if (jcontent != nullptr) env->DeleteLocalRef(jcontent);
        if (!ok) return nullptr;
        total += role_s[i].size() + content_s[i].size();
        if (total > kMaxPromptBytes) return nullptr;
    }
    std::vector<llama_chat_message> msgs(static_cast<size_t>(n));
    for (jsize i = 0; i < n; ++i) {
        msgs[i].role = role_s[i].c_str();
        msgs[i].content = content_s[i].c_str();
    }

    std::lock_guard<std::mutex> guard(engine->run_lock);
    if (engine->model == nullptr) return nullptr;
    const char * model_tmpl = llama_model_chat_template(engine->model, nullptr);

    std::string buf(total * 2 + 1024, '\0');
    auto apply = [&](const char * tmpl) -> int32_t {
        int32_t r = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true,
                                              &buf[0], static_cast<int32_t>(buf.size()));
        if (r > static_cast<int32_t>(buf.size())) {
            buf.assign(static_cast<size_t>(r) + 16, '\0');
            r = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true,
                                          &buf[0], static_cast<int32_t>(buf.size()));
        }
        return r;
    };

    int32_t written = model_tmpl != nullptr ? apply(model_tmpl) : -1;
    if (written < 0) {
        if (model_tmpl != nullptr) LOGE("model chat template not recognised, using chatml");
        written = apply("chatml");
    }
    if (written < 0 || static_cast<size_t>(written) > buf.size()) return nullptr;
    return string_to_bytes(env, buf.data(), static_cast<size_t>(written));
}

extern "C" JNIEXPORT jint JNICALL
Java_com_aicompany_app_llama_LlamaNative_nativeCountTokens(
        JNIEnv * env, jclass, jlong handle, jbyteArray jtext) {
    auto engine = acquire(handle);
    if (engine == nullptr) return kErrHandle;
    std::string text;
    if (!bytes_to_string(env, jtext, text)) return kErrTokenize;
    std::lock_guard<std::mutex> guard(engine->run_lock);
    if (engine->ctx == nullptr) return kErrHandle;
    std::vector<llama_token> tokens;
    if (!tokenize(*engine, text, tokens)) return kErrTokenize;
    return static_cast<jint>(tokens.size());
}

extern "C" JNIEXPORT jint JNICALL
Java_com_aicompany_app_llama_LlamaNative_nativeGenerate(
        JNIEnv * env, jclass, jlong handle, jbyteArray jprompt, jint max_tokens, jfloat temperature,
        jlong seed, jbyteArray jgrammar, jbyteArray jgrammar_root, jobject sink) {
    auto engine_ptr = acquire(handle);
    if (engine_ptr == nullptr || jprompt == nullptr || sink == nullptr || max_tokens < 1) return kErrHandle;
    Engine & engine = *engine_ptr;

    std::string prompt;
    if (!bytes_to_string(env, jprompt, prompt) || prompt.empty()) return kErrTokenize;
    std::string grammar, grammar_root;
    const bool use_grammar = jgrammar != nullptr && jgrammar_root != nullptr &&
                             bytes_to_string(env, jgrammar, grammar) &&
                             bytes_to_string(env, jgrammar_root, grammar_root) &&
                             !grammar.empty() && !grammar_root.empty();

    // Callback target: TokenSink.onToken(byte[]): boolean
    jclass sink_class = env->GetObjectClass(sink);
    jmethodID on_token = env->GetMethodID(sink_class, "onToken", "([B)Z");
    env->DeleteLocalRef(sink_class);
    if (on_token == nullptr) {
        env->ExceptionClear();
        return kErrHandle;
    }

    std::lock_guard<std::mutex> guard(engine.run_lock);
    if (engine.ctx == nullptr) return kErrHandle;  // freed while this call was waiting
    engine.cancel.store(false);

    std::vector<llama_token> tokens;
    if (!tokenize(engine, prompt, tokens)) return kErrTokenize;
    const int n_tokens = static_cast<int>(tokens.size());
    const int budget = engine.n_ctx - n_tokens;
    if (budget <= 0) return kStatusContextFull;
    const int limit = std::min<int>(max_tokens, budget);

    // Reuse whatever prefix of the new prompt is already in the KV cache.
    size_t n_past = 0;
    {
        const auto & cached = engine.cache_tokens;
        const size_t max_common = std::min(cached.size(), tokens.size());
        while (n_past < max_common && cached[n_past] == tokens[n_past]) ++n_past;
        // At least one token must be decoded so there are logits to sample from.
        if (n_past >= tokens.size()) n_past = tokens.size() - 1;
    }
    llama_memory_t mem = llama_get_memory(engine.ctx);
    if (n_past == 0 || !llama_memory_seq_rm(mem, 0, static_cast<llama_pos>(n_past), -1)) {
        reset_cache(engine);
        n_past = 0;
    }
    engine.cache_tokens.resize(n_past);

    for (size_t i = n_past; i < tokens.size(); i += static_cast<size_t>(kBatch)) {
        if (engine.cancel.load()) {
            reset_cache(engine);
            return kStatusCancelled;
        }
        const int32_t chunk = static_cast<int32_t>(std::min<size_t>(kBatch, tokens.size() - i));
        if (llama_decode(engine.ctx, llama_batch_get_one(tokens.data() + i, chunk)) != 0) {
            const bool cancelled = engine.cancel.load();
            reset_cache(engine);
            if (cancelled) return kStatusCancelled;
            LOGE("prompt decode failed");
            return kErrDecode;
        }
        engine.cache_tokens.insert(engine.cache_tokens.end(), tokens.begin() + i, tokens.begin() + i + chunk);
    }

    // Sampler chain. Grammar (if any) must come first so it filters every candidate.
    llama_sampler * smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    if (smpl == nullptr) return kErrSampler;
    if (use_grammar) {
        llama_sampler * gs = llama_sampler_init_grammar(engine.vocab, grammar.c_str(), grammar_root.c_str());
        if (gs == nullptr) {
            llama_sampler_free(smpl);
            return kErrSampler;
        }
        llama_sampler_chain_add(smpl, gs);
    }
    if (temperature <= 0.0f) {
        llama_sampler_chain_add(smpl, llama_sampler_init_greedy());
    } else {
        llama_sampler_chain_add(smpl, llama_sampler_init_top_k(40));
        llama_sampler_chain_add(smpl, llama_sampler_init_top_p(0.95f, 1));
        llama_sampler_chain_add(smpl, llama_sampler_init_temp(temperature));
        llama_sampler_chain_add(smpl, llama_sampler_init_dist(static_cast<uint32_t>(seed)));
    }

    int status = kStatusOk;
    bool finished = false;   // model produced an end-of-generation token
    std::string pending;     // bytes not yet emitted (incomplete UTF-8 tail)
    std::string piece(256, '\0');
    for (int produced = 0; produced < limit; ++produced) {
        if (engine.cancel.load()) {
            status = kStatusCancelled;
            break;
        }
        llama_token tok = llama_sampler_sample(smpl, engine.ctx, -1);
        if (llama_vocab_is_eog(engine.vocab, tok)) {
            finished = true;
            break;
        }

        int32_t len = llama_token_to_piece(engine.vocab, tok, &piece[0], static_cast<int32_t>(piece.size()), 0, false);
        if (len < 0) {
            piece.assign(static_cast<size_t>(-len) + 8, '\0');
            len = llama_token_to_piece(engine.vocab, tok, &piece[0], static_cast<int32_t>(piece.size()), 0, false);
        }
        if (len > 0) {
            pending.append(piece.data(), static_cast<size_t>(len));
            const size_t emit_len = complete_utf8_prefix(pending);
            if (emit_len > 0) {
                jbyteArray bytes = string_to_bytes(env, pending.data(), emit_len);
                pending.erase(0, emit_len);
                if (bytes == nullptr) {
                    env->ExceptionClear();
                    status = kErrHandle;
                    break;
                }
                const jboolean keep_going = env->CallBooleanMethod(sink, on_token, bytes);
                env->DeleteLocalRef(bytes);
                if (env->ExceptionCheck()) {
                    env->ExceptionClear();
                    status = kErrHandle;
                    break;
                }
                if (keep_going == JNI_FALSE) {
                    status = kStatusCancelled;
                    break;
                }
            }
        }

        if (llama_decode(engine.ctx, llama_batch_get_one(&tok, 1)) != 0) {
            const bool cancelled = engine.cancel.load();
            reset_cache(engine);
            status = cancelled ? kStatusCancelled : kErrDecode;
            break;
        }
        engine.cache_tokens.push_back(tok);
        // Reaching the limit without an end token is reported, so callers can tell a cut-off answer from a finished one.
        if (produced + 1 == limit && !finished) status = limit < max_tokens ? kStatusContextFull : kStatusLength;
    }
    llama_sampler_free(smpl);
    return status;
}
