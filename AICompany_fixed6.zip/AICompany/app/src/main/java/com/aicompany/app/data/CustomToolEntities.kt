package com.aicompany.app.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query

@Entity(tableName = "custom_tools")
data class CustomToolEntity(
    @PrimaryKey val name: String,
    val definition: String,        // JSON of CustomToolDef
    val createdAt: Long,
)

@Dao
interface CustomToolDao {
    @Query("SELECT * FROM custom_tools ORDER BY name ASC")
    suspend fun all(): List<CustomToolEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(entity: CustomToolEntity)

    @Query("DELETE FROM custom_tools WHERE name = :name")
    suspend fun delete(name: String)
}
