package com.aicompany.app.local

import java.io.InputStream

/** Checks the GGUF file header ("GGUF" magic + little-endian version 2 or 3) before a model is accepted. */
object GgufValidator {
    private const val HEADER_BYTES = 8

    fun isGgufHeader(header: ByteArray): Boolean {
        if (header.size < HEADER_BYTES) return false
        val magicOk = header[0] == 'G'.code.toByte() && header[1] == 'G'.code.toByte() &&
            header[2] == 'U'.code.toByte() && header[3] == 'F'.code.toByte()
        if (!magicOk) return false
        val version = (header[4].toInt() and 0xFF) or
            ((header[5].toInt() and 0xFF) shl 8) or
            ((header[6].toInt() and 0xFF) shl 16) or
            ((header[7].toInt() and 0xFF) shl 24)
        return version == 2 || version == 3
    }

    /** Reads up to 8 bytes without assuming API 33 helpers like readNBytes. */
    fun readHeader(input: InputStream): ByteArray {
        val buf = ByteArray(HEADER_BYTES)
        var off = 0
        while (off < HEADER_BYTES) {
            val n = input.read(buf, off, HEADER_BYTES - off)
            if (n < 0) break
            off += n
        }
        return buf.copyOf(off)
    }
}
