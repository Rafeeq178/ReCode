package com.aicompany.app.tools.builtin

import com.aicompany.app.tools.ApprovalLevel
import com.aicompany.app.tools.Schema
import com.aicompany.app.tools.Tool
import com.aicompany.app.tools.ToolContext
import com.aicompany.app.tools.ToolResult
import com.aicompany.app.tools.ToolSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonPrimitive
import java.io.File
import javax.inject.Inject

private const val MAX_READ_BYTES = 512 * 1024L
private const val MAX_WRITE_CHARS = 200_000

private fun stringArg(args: JsonObject, key: String): String =
    (args[key] as? JsonPrimitive)?.takeIf { it.isString }?.content
        ?: throw IllegalArgumentException("$key must be a string")

class ReadFileTool @Inject constructor() : Tool {
    override val spec = ToolSpec(
        name = "read_file",
        description = "Read a UTF-8 text file inside the workspace.",
        schema = Schema.obj(mapOf("path" to Schema.str("Relative path inside the workspace", 512)), listOf("path")),
        approval = ApprovalLevel.AUTO,
    )

    override suspend fun execute(args: JsonObject, ctx: ToolContext): ToolResult = withContext(Dispatchers.IO) {
        val file = try {
            ctx.workspace.resolve(stringArg(args, "path"))
        } catch (e: IllegalArgumentException) {
            return@withContext ToolResult.Error("invalid_path", e.message ?: "Invalid path")
        }
        if (!file.isFile) return@withContext ToolResult.Error("not_found", "File does not exist")
        if (file.length() > MAX_READ_BYTES) return@withContext ToolResult.Error("too_large", "File is larger than 512 KB")
        ToolResult.Ok(file.readText(Charsets.UTF_8))
    }
}

class WriteFileTool @Inject constructor() : Tool {
    override val spec = ToolSpec(
        name = "write_file",
        description = "Create or overwrite a UTF-8 text file inside the workspace.",
        schema = Schema.obj(
            mapOf(
                "path" to Schema.str("Relative path inside the workspace", 512),
                "content" to Schema.str("Full file content", MAX_WRITE_CHARS),
            ),
            listOf("path", "content"),
        ),
        approval = ApprovalLevel.AUTO,
    )

    override suspend fun execute(args: JsonObject, ctx: ToolContext): ToolResult = withContext(Dispatchers.IO) {
        val target = try {
            ctx.workspace.resolve(stringArg(args, "path"))
        } catch (e: IllegalArgumentException) {
            return@withContext ToolResult.Error("invalid_path", e.message ?: "Invalid path")
        }
        val content = stringArg(args, "content")
        if (target.isDirectory) return@withContext ToolResult.Error("is_directory", "Path is a folder")
        target.parentFile?.mkdirs()
        // Write to a temp file first so a crash never leaves a half-written file.
        val tmp = File(target.parentFile, target.name + ".tmp")
        tmp.writeText(content, Charsets.UTF_8)
        if (!tmp.renameTo(target)) {
            target.delete()
            if (!tmp.renameTo(target)) {
                tmp.delete()
                return@withContext ToolResult.Error("write_failed", "Could not save the file")
            }
        }
        ToolResult.Ok("Wrote ${content.toByteArray(Charsets.UTF_8).size} bytes to ${target.relativeTo(ctx.workspace.root).path}")
    }
}

class ListDirTool @Inject constructor() : Tool {
    override val spec = ToolSpec(
        name = "list_dir",
        description = "List files and folders inside a workspace folder. Use '.' for the workspace root.",
        schema = Schema.obj(
            mapOf("path" to Schema.str("Relative folder path, use '.' for root", 512)),
            listOf("path"),
        ),
        approval = ApprovalLevel.AUTO,
    )

    override suspend fun execute(args: JsonObject, ctx: ToolContext): ToolResult = withContext(Dispatchers.IO) {
        val dir = try {
            ctx.workspace.resolve(stringArg(args, "path"))
        } catch (e: IllegalArgumentException) {
            return@withContext ToolResult.Error("invalid_path", e.message ?: "Invalid path")
        }
        if (!dir.isDirectory) return@withContext ToolResult.Error("not_found", "Folder does not exist")
        val entries = dir.listFiles().orEmpty()
            .sortedBy { it.name }
            .take(MAX_ENTRIES)
            .joinToString("\n") { f ->
                if (f.isDirectory) "[dir]  ${f.name}/" else "[file] ${f.name} (${f.length()} bytes)"
            }
        ToolResult.Ok(entries.ifEmpty { "(empty folder)" })
    }

    private companion object {
        const val MAX_ENTRIES = 200
    }
}
