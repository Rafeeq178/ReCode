package com.aicompany.app.company

import com.aicompany.app.data.EmployeeEntity
import kotlinx.serialization.Serializable

/** Everything the owner can edit on an employee. Stored as JSON in version history and templates. */
@Serializable
data class EmployeeSnapshot(
    val name: String,
    val role: String,
    val systemPrompt: String = "",
    val tools: List<String>,
    val skillIds: List<String> = emptyList(),
    val providerIds: List<String> = emptyList(),
    val model: String = "",
    val maxSteps: Int = 15,
    val timeoutSeconds: Long = 600,
    val maxTokens: Int = 1024,
    val temperature: Double = 0.2,
    val terminalPermission: String = "ASK",
    val localPriority: Int = 5,
    val ceoCanModify: Boolean = false,
    val color: String = "#C9623F",
    val status: String = EmployeeStatus.IDLE.name,
)

object EmployeeRules {
    val PERMISSIONS = setOf("ASK", "AUTO_SAFE", "FULL_AUTO")
    val OWNER_STATUSES = setOf(EmployeeStatus.IDLE.name, EmployeeStatus.PAUSED.name)
    const val MAX_PROMPT = 4_000
    const val MAX_INSTRUCTIONS = 20_000
    private val COLOR = Regex("^#[0-9A-Fa-f]{6}$")
    private val MODEL = Regex("^[A-Za-z0-9._/:\\-]{0,120}$")

    fun validate(
        s: EmployeeSnapshot,
        knownTools: Set<String>,
        knownSkills: Set<String>,
        knownProviders: Set<String>,
    ): List<String> {
        val errors = mutableListOf<String>()
        if (s.name.trim().length !in 1..CompanyRules.MAX_NAME) errors += "Name must be 1-${CompanyRules.MAX_NAME} characters"
        if (s.role.trim().length !in 1..CompanyRules.MAX_ROLE) errors += "Role must be 1-${CompanyRules.MAX_ROLE} characters"
        if (s.systemPrompt.length > MAX_PROMPT) errors += "System prompt is too long (max $MAX_PROMPT)"
        if (s.tools.isEmpty() || s.tools.size > CompanyRules.MAX_TOOLS_PER_WORKER) {
            errors += "Assign 1-${CompanyRules.MAX_TOOLS_PER_WORKER} tools"
        }
        val unknownTools = s.tools.filter { it !in knownTools }
        if (unknownTools.isNotEmpty()) errors += "Unknown tools: ${unknownTools.joinToString()}"
        val ceoOnly = s.tools.filter { it in CompanyRules.CEO_ONLY_TOOLS }
        if (ceoOnly.isNotEmpty()) errors += "Workers cannot use CEO tools: ${ceoOnly.joinToString()}"
        if (s.skillIds.size > CompanyRules.MAX_SKILLS_PER_WORKER) errors += "Too many skills"
        val unknownSkills = s.skillIds.filter { it !in knownSkills }
        if (unknownSkills.isNotEmpty()) errors += "Unknown skills: ${unknownSkills.joinToString()}"
        if (s.skillIds.isNotEmpty() && CompanyRules.SKILL_LOAD_TOOL !in s.tools) {
            errors += "Add ${CompanyRules.SKILL_LOAD_TOOL} to the tools to use skills"
        }
        val unknownProviders = s.providerIds.filter { it !in knownProviders }
        if (unknownProviders.isNotEmpty()) errors += "Unknown providers"
        if (!MODEL.matches(s.model)) errors += "Model name has invalid characters"
        if (s.maxSteps !in 1..200) errors += "Max steps must be 1-200"
        if (s.timeoutSeconds !in 10..3_600) errors += "Timeout must be 10-3600 seconds"
        if (s.maxTokens !in 64..32_000) errors += "Max tokens must be 64-32000"
        if (s.temperature !in 0.0..2.0) errors += "Temperature must be 0-2"
        if (s.terminalPermission !in PERMISSIONS) errors += "Terminal permission is invalid"
        if (s.localPriority !in 0..9) errors += "Local priority must be 0-9"
        if (!COLOR.matches(s.color)) errors += "Color must look like #RRGGBB"
        if (s.status !in OWNER_STATUSES) errors += "Status must be IDLE or PAUSED"
        return errors
    }
}

fun EmployeeSnapshot.toEntity(id: String, createdAt: Long, version: Int, currentStatus: String): EmployeeEntity =
    EmployeeEntity(
        id = id,
        name = name.trim(),
        role = role.trim(),
        allowedTools = tools.map { it.trim() }.distinct().sorted().joinToString(","),
        status = currentStatus,
        createdAt = createdAt,
        systemPrompt = systemPrompt,
        providerIds = providerIds.joinToString(","),
        model = model.trim(),
        maxSteps = maxSteps,
        timeoutSeconds = timeoutSeconds,
        maxTokens = maxTokens,
        temperature = temperature,
        terminalPermission = terminalPermission,
        localPriority = localPriority,
        skillIds = skillIds.distinct().sorted().joinToString(","),
        ceoCanModify = ceoCanModify,
        color = color,
        version = version,
    )

fun EmployeeEntity.toSnapshot(): EmployeeSnapshot =
    EmployeeSnapshot(
        name = name,
        role = role,
        systemPrompt = systemPrompt,
        tools = toolSet().sorted(),
        skillIds = skillSet().sorted(),
        providerIds = providerList(),
        model = model,
        maxSteps = maxSteps,
        timeoutSeconds = timeoutSeconds,
        maxTokens = maxTokens,
        temperature = temperature,
        terminalPermission = terminalPermission,
        localPriority = localPriority,
        ceoCanModify = ceoCanModify,
        color = color,
        status = if (status == EmployeeStatus.PAUSED.name) EmployeeStatus.PAUSED.name else EmployeeStatus.IDLE.name,
    )

object EmployeeDefaults {
    fun snapshot(): EmployeeSnapshot = EmployeeSnapshot(
        name = "New worker",
        role = "general assistant",
        tools = CompanyRules.DEFAULT_WORKER_TOOLS.sorted(),
    )
}
