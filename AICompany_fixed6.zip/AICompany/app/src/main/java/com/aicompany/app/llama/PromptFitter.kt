package com.aicompany.app.llama

import com.aicompany.app.provider.ChatMessage
import com.aicompany.app.provider.ProviderException

/**
 * Makes a conversation fit the local model's context window, measured in real tokens.
 *
 * 1. Drops the oldest messages after the pinned head (system prompt, agent goal), always keeping the newest one.
 * 2. If that is not enough, cuts the middle out of the largest message (a huge tool result, say).
 *
 * [count] returns the token count of the fully formatted prompt for a candidate message list.
 */
object PromptFitter {
    const val MARKER = "[earlier messages were removed to fit the model's memory]"
    private const val CUT = "\n...[cut to fit the model's memory]...\n"
    private const val MIN_CUT_CHARS = 200
    private const val MAX_SHRINK_ROUNDS = 24

    fun fit(
        messages: List<ChatMessage>,
        keepHead: Int,
        budget: Int,
        count: (List<ChatMessage>) -> Int,
    ): List<ChatMessage> {
        require(budget > 0) { "Token budget must be positive" }
        if (messages.isEmpty() || count(messages) <= budget) return messages

        val work = messages.toMutableList()
        val leadingSystem = work.takeWhile { it.role == "system" }.size
        val pinned = maxOf(keepHead, leadingSystem).coerceIn(0, work.size - 1)

        // Phase 1: drop oldest droppable messages (never the pinned head, never the newest message).
        var dropped = 0
        while (work.size > pinned + 1 && count(work) > budget) {
            work.removeAt(pinned)
            dropped++
        }
        if (dropped > 0) {
            // Start the kept history on a user turn, which every chat template accepts.
            while (work.size > pinned + 1 && work[pinned].role == "assistant") work.removeAt(pinned)
            if (work[pinned].role == "user") {
                work[pinned] = work[pinned].copy(content = "$MARKER\n${work[pinned].content}")
            }
        }

        // Phase 2: shrink the biggest message until the prompt fits.
        var rounds = 0
        while (count(work) > budget) {
            if (++rounds > MAX_SHRINK_ROUNDS) throw tooLong()
            val index = work.indices.maxByOrNull { work[it].content.length } ?: throw tooLong()
            val text = work[index].content
            if (text.length <= MIN_CUT_CHARS) throw tooLong()
            work[index] = work[index].copy(content = middleCut(text, (text.length * 0.6).toInt()))
        }
        return work
    }

    /** Keeps the start and the end of [text], removing the middle so the result is about [target] characters. */
    internal fun middleCut(text: String, target: Int): String {
        if (text.length <= target) return text
        val keep = (target - CUT.length).coerceAtLeast(MIN_CUT_CHARS / 2)
        val head = keep / 2
        val tail = keep - head
        if (head + tail >= text.length) return text
        return text.substring(0, head) + CUT + text.substring(text.length - tail)
    }

    private fun tooLong() =
        ProviderException.BadRequest("The prompt cannot be made small enough for the local model. Use a shorter request or a larger context.")
}
