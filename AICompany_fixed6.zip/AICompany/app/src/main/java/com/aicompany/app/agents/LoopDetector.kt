package com.aicompany.app.agents

import com.aicompany.app.tools.ToolCall
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject

/** Counts identical tool calls in one run. Key order inside arguments does not matter. */
class LoopDetector(private val threshold: Int = THRESHOLD) {
    private val counts = HashMap<String, Int>()

    /** Returns true when this call has now been seen [threshold] times. */
    fun record(call: ToolCall): Boolean {
        val key = call.name + "|" + canonical(call.arguments)
        val next = (counts[key] ?: 0) + 1
        counts[key] = next
        return next >= threshold
    }

    companion object {
        const val THRESHOLD = 3

        internal fun canonical(e: JsonElement): String = when (e) {
            is JsonObject -> e.toSortedMap().entries.joinToString(",", "{", "}") {
                "\"${it.key}\":${canonical(it.value)}"
            }
            is JsonArray -> e.joinToString(",", "[", "]") { canonical(it) }
            else -> e.toString()
        }
    }
}
