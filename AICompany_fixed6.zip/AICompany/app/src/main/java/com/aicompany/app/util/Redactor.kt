package com.aicompany.app.util

/** Removes secrets from any text before it is logged, audited, or sent to a model. */
object Redactor {
    private val rules: List<Pair<Regex, String>> = listOf(
        Regex("(?i)(bearer\\s+)[A-Za-z0-9._\\-]+") to "\$1[REDACTED]",
        Regex("sk-[A-Za-z0-9_\\-]{8,}") to "[REDACTED]",
        Regex("AIza[0-9A-Za-z_\\-]{20,}") to "[REDACTED]",
        Regex("(?i)((?:api[_-]?key|token|secret|password|passwd|cookie|session)\"?\\s*[:=]\\s*\"?)[^\\s\",}]+") to "\$1[REDACTED]",
    )

    fun redact(text: String): String =
        rules.fold(text) { acc, (regex, replacement) -> regex.replace(acc, replacement) }
}
