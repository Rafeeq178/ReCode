package com.aicompany.app.tools.custom

import com.aicompany.app.provider.JSON_MEDIA
import com.aicompany.app.tools.Schema
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

data class McpToolInfo(val name: String, val description: String, val inputSchema: JsonObject)

/**
 * Minimal MCP client over HTTP JSON-RPC (streamable HTTP, JSON or SSE replies).
 * Each call opens a fresh session. Only https servers are allowed.
 */
@Singleton
class McpClient @Inject constructor(
    private val http: OkHttpClient,
    private val json: Json,
) {
    suspend fun listTools(url: String): List<McpToolInfo> = withContext(Dispatchers.IO) {
        val session = openSession(url)
        val result = request(url, "tools/list", JsonObject(emptyMap()), session)
        val arr = result["tools"] as? JsonArray ?: return@withContext emptyList()
        arr.take(MAX_TOOLS).mapNotNull { el ->
            val o = el as? JsonObject ?: return@mapNotNull null
            val name = (o["name"] as? JsonPrimitive)?.contentOrNull ?: return@mapNotNull null
            val description = (o["description"] as? JsonPrimitive)?.contentOrNull.orEmpty()
            val schema = (o["inputSchema"] as? JsonObject)
                ?.takeIf { (it["type"] as? JsonPrimitive)?.contentOrNull == "object" }
                ?: Schema.obj(emptyMap())
            McpToolInfo(name, description, schema)
        }
    }

    suspend fun callTool(url: String, name: String, args: JsonObject): String = withContext(Dispatchers.IO) {
        val session = openSession(url)
        val result = request(
            url,
            "tools/call",
            buildJsonObject {
                put("name", name)
                put("arguments", args)
            },
            session,
        )
        val text = (result["content"] as? JsonArray)
            ?.mapNotNull { (it as? JsonObject)?.get("text")?.let { t -> (t as? JsonPrimitive)?.contentOrNull } }
            ?.joinToString("\n")
            .orEmpty()
        val isError = (result["isError"] as? JsonPrimitive)?.booleanOrNull == true
        if (isError) throw IllegalStateException(text.take(300))
        text
    }

    private fun openSession(url: String): String? {
        val init = buildJsonObject {
            put("protocolVersion", PROTOCOL_VERSION)
            put("capabilities", JsonObject(emptyMap()))
            put("clientInfo", buildJsonObject {
                put("name", "AICompany")
                put("version", "0.1.0")
            })
        }
        val first = post(url, buildJsonObject {
            put("jsonrpc", "2.0")
            put("id", 1)
            put("method", "initialize")
            put("params", init)
        }, null)
        parseMessage(first.text)["error"]?.let { throw IllegalStateException("MCP initialize was refused") }
        // Notification: no id, no reply expected. Errors here are not fatal.
        post(url, buildJsonObject {
            put("jsonrpc", "2.0")
            put("method", "notifications/initialized")
        }, first.session)
        return first.session
    }

    private fun request(url: String, method: String, params: JsonObject, session: String?): JsonObject {
        val ex = post(url, buildJsonObject {
            put("jsonrpc", "2.0")
            put("id", 2)
            put("method", method)
            put("params", params)
        }, session)
        val message = parseMessage(ex.text)
        if (message["error"] != null) throw IllegalStateException("MCP server returned an error")
        return message["result"] as? JsonObject ?: throw IllegalStateException("MCP response had no result")
    }

    private data class Exchange(val text: String, val session: String?)

    private fun post(url: String, payload: JsonObject, session: String?): Exchange {
        require(url.startsWith("https://")) { "MCP servers must use https" }
        val req = Request.Builder()
            .url(url)
            .header("Accept", "application/json, text/event-stream")
            .header("MCP-Protocol-Version", PROTOCOL_VERSION)
            .apply { if (session != null) header("Mcp-Session-Id", session) }
            .post(payload.toString().toRequestBody(JSON_MEDIA))
            .build()
        http.newBuilder().callTimeout(30, TimeUnit.SECONDS).build().newCall(req).execute().use { resp ->
            if (!resp.isSuccessful && resp.code != 202) throw IOException("MCP server returned HTTP ${resp.code}")
            val source = resp.body?.source()
            val text = if (source == null) "" else {
                source.request(MAX_BYTES.toLong())
                source.buffer.readUtf8(minOf(source.buffer.size, MAX_BYTES.toLong()))
            }
            return Exchange(text, resp.header("Mcp-Session-Id"))
        }
    }

    /** Accepts a plain JSON reply or an SSE stream. Uses the last data event that carries a result or error. */
    private fun parseMessage(text: String): JsonObject {
        val candidates = if (text.contains("data:")) {
            text.lineSequence().filter { it.startsWith("data:") }.map { it.removePrefix("data:").trim() }.toList().reversed()
        } else {
            listOf(text.trim())
        }
        for (c in candidates) {
            val obj = runCatching { json.parseToJsonElement(c) }.getOrNull() as? JsonObject ?: continue
            if (obj.containsKey("result") || obj.containsKey("error")) return obj
        }
        throw IllegalStateException("MCP response could not be read")
    }

    companion object {
        /** MCP spec revision used for the handshake. Check against the server if imports fail. */
        const val PROTOCOL_VERSION = "2025-03-26"
        const val MAX_BYTES = 256 * 1024
        const val MAX_TOOLS = 50
    }
}
