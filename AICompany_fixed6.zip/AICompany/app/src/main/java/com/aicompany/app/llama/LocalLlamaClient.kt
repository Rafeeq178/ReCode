package com.aicompany.app.llama

import com.aicompany.app.local.LocalScheduler
import com.aicompany.app.local.ModelStore
import com.aicompany.app.provider.ChatMessage
import com.aicompany.app.provider.ChatParams
import com.aicompany.app.provider.ProviderClient
import com.aicompany.app.provider.ProviderConfig
import com.aicompany.app.provider.ProviderException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.async
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.withContext
import javax.inject.Inject

/**
 * Runs a GGUF model from ModelStore on device. The config.model is the file name.
 * Requests queue by [ChatParams.priority]: the owner's chat and the CEO go first, workers after.
 */
class LocalLlamaClient @Inject constructor(
    private val engine: LlamaEngine,
    private val scheduler: LocalScheduler,
    private val models: ModelStore,
) : ProviderClient {

    override fun chat(
        config: ProviderConfig,
        apiKey: String,
        messages: List<ChatMessage>,
        params: ChatParams,
    ): Flow<String> = channelFlow {
        val file = models.file(config.model)
        val clean = ChatTemplate.sanitize(messages)
        var emitted = 0
        try {
            scheduler.submit(params.priority, config.timeoutSeconds * 1000) {
                engine.ensureLoaded(file).getOrElse {
                    throw ProviderException.BadRequest(it.message ?: "Model load failed")
                }
                val prompt = fitPrompt(clean, params)
                val status = generateCancellable(prompt, params) { text ->
                    emitted++
                    // The channel is unbounded, so this only fails when the collector is gone.
                    trySend(text).isSuccess
                }
                when {
                    status < 0 -> throw ProviderException.Server("Local model failed (code $status)", 500)
                    status == LlamaStatus.CONTEXT_FULL && emitted == 0 -> throw ProviderException.BadRequest(
                        "The conversation does not fit in the local model's context window. Start a new chat or shorten the request."
                    )
                    status == LlamaStatus.CONTEXT_FULL -> throw ProviderException.OutputTruncated(
                        "The local model ran out of context window before it finished answering."
                    )
                    // A grammar-constrained answer (agent JSON) that was cut at max_tokens is incomplete.
                    status == LlamaStatus.LENGTH && params.grammar != null -> throw ProviderException.OutputTruncated(
                        "The local model's answer was cut off at max tokens (${params.maxTokens}) before the JSON was complete."
                    )
                    else -> Unit
                }
            }
        } catch (e: LocalScheduler.LocalTimeoutException) {
            throw ProviderException.Timeout(e.message ?: "Local model timed out")
        }
    }.buffer(Channel.UNLIMITED)

    /** Trims the conversation to the context window in real tokens, then formats it with the model's template. */
    private fun fitPrompt(messages: List<ChatMessage>, params: ChatParams): ByteArray {
        val nCtx = engine.contextSize
        val reserveForAnswer = minOf(params.maxTokens, nCtx / 2)
        val budget = nCtx - reserveForAnswer - SAFETY_TOKENS
        if (budget <= 0) throw ProviderException.BadRequest("Local context window is too small")
        val fitted = PromptFitter.fit(messages, params.keepHead, budget) { candidate ->
            engine.countTokens(engine.buildPrompt(candidate))
        }
        return engine.buildPrompt(fitted)
    }

    /**
     * Runs native generation on the IO dispatcher. The native call blocks and cannot be interrupted by
     * coroutine cancellation, so on cancel (Stop, timeout, caller gone) the engine is told to stop and
     * we wait for it to actually return before the next request may start.
     */
    private suspend fun generateCancellable(
        prompt: ByteArray,
        params: ChatParams,
        onToken: (String) -> Boolean,
    ): Int = coroutineScope {
        val work = async(Dispatchers.IO) {
            engine.generate(
                prompt = prompt,
                maxTokens = params.maxTokens,
                temperature = params.temperature,
                seed = System.nanoTime(),
                grammar = params.grammar,
                grammarRoot = params.grammarRoot,
                onToken = onToken,
            )
        }
        try {
            work.await()
        } catch (e: CancellationException) {
            engine.cancel()
            withContext(NonCancellable) { work.join() }
            throw e
        }
    }

    private companion object {
        const val SAFETY_TOKENS = 64
    }
}
