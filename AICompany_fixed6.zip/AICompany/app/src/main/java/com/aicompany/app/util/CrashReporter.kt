package com.aicompany.app.util

import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/**
 * Writes the last crash (or a caught startup failure) to filesDir/last-crash.txt so the next launch
 * can show it on screen. Useful when there is no adb/logcat.
 */
object CrashReporter {
    private const val FILE = "last-crash.txt"

    fun install(context: Context) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            record(context, "Uncaught on thread ${thread.name}", error)
            previous?.uncaughtException(thread, error)
        }
    }

    fun record(context: Context, label: String, error: Throwable) {
        runCatching {
            val sw = StringWriter()
            error.printStackTrace(PrintWriter(sw))
            File(context.filesDir, FILE).writeText("$label\n\n$sw")
        }
    }

    fun read(context: Context): String? = runCatching {
        File(context.filesDir, FILE).takeIf { it.isFile }?.readText()
    }.getOrNull()

    fun clear(context: Context) {
        runCatching { File(context.filesDir, FILE).delete() }
    }
}
