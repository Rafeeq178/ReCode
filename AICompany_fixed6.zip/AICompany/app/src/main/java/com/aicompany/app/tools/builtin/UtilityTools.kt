package com.aicompany.app.tools.builtin

import com.aicompany.app.tools.ApprovalLevel
import com.aicompany.app.tools.Schema
import com.aicompany.app.tools.Tool
import com.aicompany.app.tools.ToolContext
import com.aicompany.app.tools.ToolResult
import com.aicompany.app.tools.ToolSpec
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import java.time.ZonedDateTime
import javax.inject.Inject
import kotlin.math.abs

class GetTimeTool @Inject constructor() : Tool {
    override val spec = ToolSpec(
        name = "get_time",
        description = "Return the current date and time on the device with its zone.",
        schema = Schema.obj(emptyMap()),
        approval = ApprovalLevel.AUTO,
    )

    override suspend fun execute(args: JsonObject, ctx: ToolContext): ToolResult =
        ToolResult.Ok(ZonedDateTime.now().toString())
}

class CalculatorTool @Inject constructor() : Tool {
    override val spec = ToolSpec(
        name = "calculator",
        description = "Evaluate an arithmetic expression with + - * / ^ and parentheses.",
        schema = Schema.obj(
            mapOf("expression" to Schema.str("Arithmetic expression, for example (2+3)*4", 200)),
            listOf("expression"),
        ),
        approval = ApprovalLevel.AUTO,
    )

    override suspend fun execute(args: JsonObject, ctx: ToolContext): ToolResult {
        val expr = (args["expression"] as? JsonPrimitive)?.takeIf { it.isString }?.content
            ?: return ToolResult.Error("invalid_args", "expression must be a string")
        return try {
            ToolResult.Ok(format(Calc.evaluate(expr)))
        } catch (e: IllegalArgumentException) {
            ToolResult.Error("math_error", e.message ?: "Could not evaluate the expression")
        }
    }

    private fun format(v: Double): String =
        if (v % 1.0 == 0.0 && abs(v) < 1e15) v.toLong().toString() else v.toString()
}

/** Recursive-descent evaluator. No eval, no reflection, depth and length limited. */
object Calc {
    private const val MAX_LEN = 200
    private const val MAX_DEPTH = 50

    fun evaluate(input: String): Double {
        require(input.length <= MAX_LEN) { "Expression is too long" }
        require(input.isNotBlank()) { "Expression is empty" }
        val parser = Parser(input)
        val result = parser.parse()
        require(result.isFinite()) { "Result is not a finite number" }
        return result
    }

    private class Parser(private val s: String) {
        private var pos = 0

        fun parse(): Double {
            val v = expr(0)
            skip()
            require(pos == s.length) { "Unexpected character at position ${pos + 1}" }
            return v
        }

        private fun expr(depth: Int): Double {
            require(depth < MAX_DEPTH) { "Expression is nested too deeply" }
            var v = term(depth + 1)
            while (true) {
                skip()
                v = when {
                    match('+') -> v + term(depth + 1)
                    match('-') -> v - term(depth + 1)
                    else -> break
                }
            }
            return v
        }

        private fun term(depth: Int): Double {
            var v = factor(depth + 1)
            while (true) {
                skip()
                v = when {
                    match('*') -> v * factor(depth + 1)
                    match('/') -> {
                        val r = factor(depth + 1)
                        require(r != 0.0) { "Division by zero" }
                        v / r
                    }
                    else -> break
                }
            }
            return v
        }

        // Precedence, loosest to tightest: + -  then  * /  then unary sign  then ^ (right-associative).
        // So -2^2 = -(2^2) = -4, and 2^-1 = 0.5.
        private fun factor(depth: Int): Double {
            require(depth < MAX_DEPTH) { "Expression is nested too deeply" }
            skip()
            return when {
                match('-') -> -factor(depth + 1)
                match('+') -> factor(depth + 1)
                else -> power(depth + 1)
            }
        }

        private fun power(depth: Int): Double {
            require(depth < MAX_DEPTH) { "Expression is nested too deeply" }
            val base = primary(depth + 1)
            skip()
            return if (match('^')) Math.pow(base, factor(depth + 1)) else base
        }

        private fun primary(depth: Int): Double {
            require(depth < MAX_DEPTH) { "Expression is nested too deeply" }
            skip()
            if (match('(')) {
                val v = expr(depth + 1)
                skip()
                require(match(')')) { "Missing closing parenthesis" }
                return v
            }
            return number()
        }

        private fun number(): Double {
            val start = pos
            while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
            require(pos > start) { "Expected a number at position ${start + 1}" }
            return s.substring(start, pos).toDoubleOrNull()
                ?: throw IllegalArgumentException("Invalid number")
        }

        private fun match(c: Char): Boolean {
            if (pos < s.length && s[pos] == c) {
                pos++
                return true
            }
            return false
        }

        private fun skip() {
            while (pos < s.length && s[pos].isWhitespace()) pos++
        }
    }
}
