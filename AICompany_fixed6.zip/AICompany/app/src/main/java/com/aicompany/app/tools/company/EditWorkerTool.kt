package com.aicompany.app.tools.company

import com.aicompany.app.company.CompanyRules
import com.aicompany.app.company.CompanyService
import com.aicompany.app.tools.ApprovalLevel
import com.aicompany.app.tools.Schema
import com.aicompany.app.tools.Tool
import com.aicompany.app.tools.ToolContext
import com.aicompany.app.tools.ToolResult
import com.aicompany.app.tools.ToolSpec
import com.aicompany.app.tools.builtin.stringArgument
import dagger.Lazy
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.intOrNull
import javax.inject.Inject

/** CEO edits a worker's role, tools or step limit. Blocked unless the owner enabled CEO edits for that worker. */
class EditWorkerTool @Inject constructor(private val company: Lazy<CompanyService>) : Tool {
    override val spec = ToolSpec(
        name = "edit_worker",
        description = "Change a worker's role, tools or max steps. Only works when the owner allowed CEO edits. Needs owner approval.",
        schema = Schema.obj(
            mapOf(
                "worker_id" to Schema.str("Worker id", 64),
                "role" to Schema.str("New role", CompanyRules.MAX_ROLE),
                "tools" to Schema.arrayStr("New full tool list", CompanyRules.MAX_TOOLS_PER_WORKER),
                "max_steps" to Schema.int("New max steps", 1, 200),
            ),
            listOf("worker_id"),
        ),
        approval = ApprovalLevel.ASK,
    )

    override suspend fun execute(args: JsonObject, ctx: ToolContext): ToolResult {
        val id = stringArgument(args, "worker_id", 64)
        val role = args["role"]?.let { stringArgument(args, "role", CompanyRules.MAX_ROLE) }
        val tools = (args["tools"] as? JsonArray)?.let { arr ->
            require(arr.size <= CompanyRules.MAX_TOOLS_PER_WORKER) { "Too many tools" }
            arr.map { (it as? JsonPrimitive)?.takeIf { p -> p.isString }?.content ?: throw IllegalArgumentException("tools must be strings") }.toSet()
        }
        val steps = args["max_steps"]?.let { (it as? JsonPrimitive)?.intOrNull ?: throw IllegalArgumentException("max_steps must be an integer") }
        val version = company.get().ceoEditWorker(id, role, tools, steps)
        return ToolResult.Ok("Worker updated. Saved as version $version")
    }
}
