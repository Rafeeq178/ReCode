package com.aicompany.app.service

import android.content.Context
import com.aicompany.app.util.Logger
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Counts every piece of long-running work (CEO run, worker task, agent run, owner chat answer).
 * The first piece of work starts [AgentForegroundService]; the service stops itself a few seconds
 * after the count returns to zero. Without this, only the CEO run kept the process alive and a
 * worker, an agent run or a chat answer could be killed as soon as the app went to the background.
 */
@Singleton
class WorkTracker @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private var count = 0
    private val _active = MutableStateFlow(0)
    val active: StateFlow<Int> = _active.asStateFlow()

    fun begin() {
        val first: Boolean
        synchronized(this) {
            count++
            first = count == 1
            _active.value = count
        }
        if (first) ensureService()
    }

    fun end() {
        synchronized(this) {
            if (count > 0) count--
            _active.value = count
        }
    }

    /** Runs [block] while counted as active work. */
    suspend fun <T> track(block: suspend () -> T): T {
        begin()
        try {
            return block()
        } finally {
            end()
        }
    }

    private fun ensureService() {
        // Android 12+ refuses to start a foreground service from the background; the work still runs.
        runCatching { AgentForegroundService.start(context) }
            .onFailure { Logger.w("Work", "Could not start the foreground service: ${it.javaClass.simpleName}") }
    }
}
