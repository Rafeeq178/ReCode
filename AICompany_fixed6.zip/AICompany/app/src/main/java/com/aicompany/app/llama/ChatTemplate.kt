package com.aicompany.app.llama

import com.aicompany.app.provider.ChatMessage

/**
 * Prepares messages for the local model's own chat template (applied natively by llama.cpp, so
 * Qwen, Llama, Gemma, Phi and Mistral models each get their correct format).
 *
 * The prompt is tokenized with special tokens enabled, so text that merely looks like a control
 * marker would be read as a real one. [sanitize] therefore removes the common role/turn markers
 * from message text and restricts roles to system, user and assistant.
 */
object ChatTemplate {
    private val ROLES = setOf("system", "user", "assistant")

    private val CONTROL_MARKERS = Regex(
        "<\\|[^|<>\\n]{1,40}\\|>" +                       // <|im_start|>, <|eot_id|>, <|start_header_id|> ...
            "|<start_of_turn>|<end_of_turn>" +            // Gemma
            "|\\[/?INST]|<<SYS>>|<</SYS>>" +              // Llama 2 / Mistral
            "|</?s>|<bos>|<eos>"                          // sentence markers
    )

    /** Validates roles and strips control markers and NUL characters from every message. */
    fun sanitize(messages: List<ChatMessage>): List<ChatMessage> {
        require(messages.isNotEmpty()) { "No messages to send" }
        return messages.map { m ->
            require(m.role in ROLES) { "Unsupported role" }
            ChatMessage(m.role, m.content.replace('\u0000', ' ').replace(CONTROL_MARKERS, ""))
        }
    }

    /**
     * ChatML (Qwen and many others). Used only as a plain-Kotlin fallback and in tests;
     * the real prompt comes from the model's own template.
     */
    fun chatMl(messages: List<ChatMessage>): String = buildString {
        sanitize(messages).forEach { m ->
            append("<|im_start|>").append(m.role).append('\n')
            append(m.content)
            append("<|im_end|>\n")
        }
        append("<|im_start|>assistant\n")
    }
}
