package com.aicompany.app.tools.builtin

import okhttp3.Dns
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.net.UnknownHostException

/**
 * Keeps web_fetch on the public internet. A page the model reads must not be able to reach
 * localhost, the phone's LAN, or cloud metadata addresses (SSRF).
 */
object NetGuard {

    /** True only for addresses that are routable on the public internet. */
    fun isPublic(addr: InetAddress): Boolean {
        if (addr.isAnyLocalAddress || addr.isLoopbackAddress || addr.isLinkLocalAddress ||
            addr.isSiteLocalAddress || addr.isMulticastAddress
        ) return false
        val b = addr.address
        return when (addr) {
            is Inet4Address -> {
                val o0 = b[0].toInt() and 0xFF
                val o1 = b[1].toInt() and 0xFF
                !(o0 == 0 ||                                  // 0.0.0.0/8
                    (o0 == 100 && o1 in 64..127) ||           // carrier-grade NAT
                    (o0 == 192 && o1 == 0 && (b[2].toInt() and 0xFF) == 0) ||  // 192.0.0.0/24
                    (o0 == 198 && o1 in 18..19) ||            // benchmarking
                    o0 >= 240)                                // reserved + broadcast
            }
            is Inet6Address -> {
                val first = b[0].toInt() and 0xFF
                !((first and 0xFE) == 0xFC)                   // fc00::/7 unique local
            }
            else -> false
        }
    }

    /** Resolves [host] and fails unless every address it points to is public. */
    fun resolvePublic(host: String): List<InetAddress> {
        val all = InetAddress.getAllByName(host).toList()
        if (all.isEmpty() || all.any { !isPublic(it) }) {
            throw UnknownHostException("Blocked: $host is not a public internet address")
        }
        return all
    }

    /** OkHttp DNS that refuses private targets at connection time, which also defeats DNS rebinding. */
    val safeDns = Dns { host -> resolvePublic(host) }
}
