package com.aicompany.app.provider

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import javax.inject.Inject

class AnthropicClient @Inject constructor(
    private val http: OkHttpClient,
    private val json: Json,
) : ProviderClient {

    override fun chat(
        config: ProviderConfig,
        apiKey: String,
        messages: List<ChatMessage>,
        params: ChatParams,
    ): Flow<String> = flow {
        requireSafeBaseUrl(config.baseUrl)
        val system = messages.filter { it.role == "system" }.joinToString("\n") { it.content }
        val turns = messages.filter { it.role != "system" }
        val body = buildJsonObject {
            put("model", config.model)
            put("max_tokens", params.maxTokens)
            put("temperature", params.temperature)
            put("stream", true)
            if (system.isNotBlank()) put("system", system)
            put("messages", buildJsonArray {
                turns.forEach { m ->
                    add(buildJsonObject {
                        put("role", m.role)
                        put("content", m.content)
                    })
                }
            })
        }
        val request = Request.Builder()
            .url(joinUrl(config.baseUrl, "/v1/messages"))
            .header("x-api-key", apiKey)
            .header("anthropic-version", "2023-06-01")
            .header("Accept", "text/event-stream")
            .applyExtraHeaders(config)
            .post(body.toString().toRequestBody(JSON_MEDIA))
            .build()

        http.forProvider(config).executeOrThrow(request).use { response ->
            if (!response.isSuccessful) throw response.toProviderException()
            val source = response.body?.source()
                ?: throw ProviderException.Server("Empty response", 502)
            while (true) {
                val line = source.readLineOrThrow() ?: break
                if (!line.startsWith("data:")) continue
                val obj = json.parseEvent(line.removePrefix("data:").trim())
                when (obj["type"]?.jsonPrimitive?.contentOrNull) {
                    "content_block_delta" -> {
                        val delta = obj["delta"]?.jsonObject ?: continue
                        if (delta["type"]?.jsonPrimitive?.contentOrNull == "text_delta") {
                            delta["text"]?.jsonPrimitive?.contentOrNull?.let { if (it.isNotEmpty()) emit(it) }
                        }
                    }
                    "message_stop" -> break
                    "error" -> throw ProviderException.Server("Stream error from provider", 502)
                }
            }
        }
    }.flowOn(Dispatchers.IO)
}
