package com.aicompany.app.local

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import java.util.PriorityQueue
import java.util.concurrent.atomic.AtomicLong
import javax.inject.Inject
import javax.inject.Singleton

/**
 * One local model, one request at a time. Requests wait in a priority queue:
 * lower number = more urgent (owner chat and CEO use 0, workers use 5).
 * Each request has its own timeout. Queued requests whose caller gave up are skipped, and a
 * running request is cancelled when its caller goes away or its timeout expires (the block is
 * expected to stop native generation when it is cancelled).
 */
@Singleton
class LocalScheduler @Inject constructor() {

    private data class Request(val priority: Int, val seq: Long, val run: suspend () -> Unit)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val queue = PriorityQueue<Request>(compareBy<Request>({ it.priority }, { it.seq }))
    private val signals = Channel<Unit>(Channel.UNLIMITED)
    private val sequence = AtomicLong(0)

    init {
        scope.launch {
            for (ignored in signals) {
                drain()
            }
        }
    }

    suspend fun <T> submit(priority: Int, timeoutMs: Long, block: suspend () -> T): T {
        require(priority in 0..9) { "Priority must be 0-9" }
        require(timeoutMs in 1_000..600_000) { "Timeout must be 1-600 s" }
        val result = CompletableDeferred<T>()
        val request = Request(priority, sequence.incrementAndGet()) {
            if (result.isActive) {
                val running = scope.launch {
                    try {
                        result.complete(withTimeout(timeoutMs) { block() })
                    } catch (e: TimeoutCancellationException) {
                        result.completeExceptionally(LocalTimeoutException(timeoutMs))
                    } catch (e: CancellationException) {
                        result.cancel()
                    } catch (e: Throwable) {
                        result.completeExceptionally(e)
                    }
                }
                // Caller gone (Stop pressed, run cancelled): stop the work that is running for it.
                result.invokeOnCompletion { cause -> if (cause is CancellationException) running.cancel() }
                running.join()
            }
        }
        synchronized(queue) { queue.add(request) }
        signals.trySend(Unit)
        return try {
            result.await()
        } catch (e: CancellationException) {
            result.cancel(e)
            throw e
        }
    }

    /** Number of requests waiting (not counting the one running). */
    fun waiting(): Int = synchronized(queue) { queue.size }

    private suspend fun drain() {
        while (true) {
            val next = synchronized(queue) { queue.poll() } ?: return
            next.run()
        }
    }

    class LocalTimeoutException(timeoutMs: Long) : RuntimeException("Local model timed out after ${timeoutMs / 1000} s")
}
