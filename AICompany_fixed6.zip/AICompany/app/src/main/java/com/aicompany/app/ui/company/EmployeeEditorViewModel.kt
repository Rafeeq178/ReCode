package com.aicompany.app.ui.company

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aicompany.app.company.CompanyRules
import com.aicompany.app.company.CompanyService
import com.aicompany.app.company.EmployeeDefaults
import com.aicompany.app.company.EmployeeSnapshot
import com.aicompany.app.company.toSnapshot
import com.aicompany.app.data.CompanyRepository
import com.aicompany.app.data.EmployeeVersionEntity
import com.aicompany.app.data.SkillEntity
import com.aicompany.app.provider.ProviderConfig
import com.aicompany.app.data.ProviderRepository
import com.aicompany.app.tools.ToolRegistry
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

const val NEW_EMPLOYEE_ID = "new"

@HiltViewModel
class EmployeeEditorViewModel @Inject constructor(
    savedState: SavedStateHandle,
    private val company: CompanyService,
    private val repo: CompanyRepository,
    private val providers: ProviderRepository,
    private val registry: ToolRegistry,
) : ViewModel() {

    val employeeId: String = savedState.get<String>("employeeId") ?: NEW_EMPLOYEE_ID
    val isNew: Boolean get() = employeeId == NEW_EMPLOYEE_ID

    private val _snapshot = MutableStateFlow<EmployeeSnapshot?>(null)
    val snapshot: StateFlow<EmployeeSnapshot?> = _snapshot.asStateFlow()

    /** Tools an owner can give a worker (CEO-only tools are hidden). */
    val toolNames: List<String> = registry.allNames()
        .filter { it !in CompanyRules.CEO_ONLY_TOOLS }
        .sorted()

    val providerList: StateFlow<List<ProviderConfig>> = providers.observe()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val skills: StateFlow<List<SkillEntity>> = repo.observeSkills()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val versions: StateFlow<List<EmployeeVersionEntity>> =
        (if (isNew) flowOf(emptyList()) else repo.observeVersions(employeeId))
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _notice = MutableStateFlow<String?>(null)
    val notice: StateFlow<String?> = _notice.asStateFlow()

    private val _created = MutableStateFlow<String?>(null)
    val created: StateFlow<String?> = _created.asStateFlow()

    init {
        viewModelScope.launch { reload() }
    }

    private suspend fun reload() {
        _snapshot.value = if (isNew) {
            EmployeeDefaults.snapshot()
        } else {
            repo.getEmployee(employeeId)?.toSnapshot()
                ?: run {
                    _notice.value = "Employee not found"
                    EmployeeDefaults.snapshot()
                }
        }
    }

    fun save(snapshot: EmployeeSnapshot) {
        viewModelScope.launch {
            runCatching {
                if (isNew) {
                    val id = company.createEmployee(snapshot)
                    _created.value = id
                    "Worker hired"
                } else {
                    val version = company.updateEmployee(employeeId, snapshot)
                    reload()
                    "Saved as version $version"
                }
            }.onSuccess { _notice.value = it }
                .onFailure { _notice.value = it.message ?: "Could not save" }
        }
    }

    fun rollback(version: Int) {
        viewModelScope.launch {
            runCatching { company.rollback(employeeId, version) }
                .onSuccess {
                    reload()
                    _notice.value = "Restored version $version as version $it"
                }
                .onFailure { _notice.value = it.message ?: "Rollback failed" }
        }
    }

    fun fire() {
        viewModelScope.launch {
            runCatching { company.fire(employeeId) }
                .onSuccess { _created.value = employeeId }
                .onFailure { _notice.value = it.message ?: "Could not fire" }
        }
    }

    fun saveTemplate(name: String) {
        viewModelScope.launch {
            runCatching { company.saveTemplate(employeeId, name) }
                .onSuccess { _notice.value = "Template saved" }
                .onFailure { _notice.value = it.message ?: "Could not save template" }
        }
    }

    fun addSkill(name: String, description: String, instructions: String) {
        viewModelScope.launch {
            runCatching { company.saveSkill(name, description, instructions) }
                .onSuccess { _notice.value = "Skill saved" }
                .onFailure { _notice.value = it.message ?: "Could not save skill" }
        }
    }

    fun report(message: String) {
        _notice.value = message
    }

    fun clearNotice() {
        _notice.value = null
    }

    fun clearCreated() {
        _created.value = null
    }
}
