package com.aicompany.app.ui.chat

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aicompany.app.data.ChatMessageUi
import com.aicompany.app.data.ChatRepository
import com.aicompany.app.data.ConversationManager
import com.aicompany.app.data.ProviderRepository
import com.aicompany.app.local.LocalModelService
import com.aicompany.app.prefs.UiPrefs
import com.aicompany.app.provider.ChatGateway
import com.aicompany.app.provider.ChatMessage
import com.aicompany.app.provider.ChatParams
import com.aicompany.app.provider.ProviderConfig
import com.aicompany.app.provider.ApiFormat
import com.aicompany.app.provider.ProviderException
import com.aicompany.app.service.WorkTracker
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

private const val MAX_HISTORY_MESSAGES = 30
private const val MAX_INPUT_CHARS = 8000

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class ChatViewModel @Inject constructor(
    private val chatRepo: ChatRepository,
    private val providerRepo: ProviderRepository,
    private val gateway: ChatGateway,
    private val conversations: ConversationManager,
    private val modelService: LocalModelService,
    private val prefs: UiPrefs,
    private val tracker: WorkTracker,
) : ViewModel() {

    val userName: StateFlow<String> = prefs.userName

    val messages: StateFlow<List<ChatMessageUi>> = conversations.currentId
        .flatMapLatest { id -> chatRepo.observe(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val providers: StateFlow<List<ProviderConfig>> = providerRepo.observe()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Id of the provider the owner picked in the model switcher; null means "the first one". */
    val selectedProviderId: StateFlow<String?> = prefs.selectedProviderId

    /** Providers in the order chat uses them: the chosen one first, the rest as fallbacks. */
    private val activeChain: StateFlow<List<ProviderConfig>> = combine(providers, prefs.selectedProviderId, ::orderChain)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Short label for the model chip in the composer (the provider chat uses first). */
    val modelLabel: StateFlow<String?> = activeChain
        .map { list -> list.firstOrNull()?.let(::providerLabel) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    fun selectProvider(id: String) {
        prefs.setSelectedProviderId(id)
    }

    private val _importing = MutableStateFlow(false)
    val importing: StateFlow<Boolean> = _importing.asStateFlow()

    private val _notice = MutableStateFlow<String?>(null)
    val notice: StateFlow<String?> = _notice.asStateFlow()

    private val _streaming = MutableStateFlow<String?>(null)
    val streaming: StateFlow<String?> = _streaming.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private var job: Job? = null

    fun send(raw: String) {
        val text = raw.trim()
        if (text.isEmpty() || _busy.value) return
        if (text.length > MAX_INPUT_CHARS) {
            _error.value = "Message is too long (max $MAX_INPUT_CHARS characters)"
            return
        }
        val conversationId = conversations.currentId.value
        job = viewModelScope.launch {
            _busy.value = true
            _error.value = null
            // Read straight from the repository so the chain is never a stale StateFlow value.
            val chain = orderChain(providerRepo.observe().first(), prefs.selectedProviderId.value)
            if (chain.isEmpty()) {
                _error.value = "Pehle Providers screen mein koi provider add karein"
                _busy.value = false
                return@launch
            }
            val userMessageId = chatRepo.append(conversationId, "user", text, null)

            // Build the history from the database after the insert. Mixing the observed list with a
            // hand-added copy of the new message duplicated it whenever the list had already refreshed.
            val stored = chatRepo.snapshot(conversationId)
            val history = (if (stored.any { it.id == userMessageId }) stored
            else stored + ChatMessageUi(userMessageId, "user", text, null))
                .takeLast(MAX_HISTORY_MESSAGES)
                .map { ChatMessage(it.role, it.content) }

            val primary = chain.first()
            val params = ChatParams(
                maxTokens = primary.maxTokens,
                temperature = primary.temperature,
                priority = ChatParams.PRIORITY_OWNER,
            )
            val answer = StringBuilder()
            _streaming.value = ""
            try {
                tracker.track {
                    gateway.stream(chain, history, params).collect { token ->
                        answer.append(token)
                        _streaming.value = answer.toString()
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: ProviderException) {
                _error.value = e.message ?: "Provider error"
            } catch (e: Exception) {
                _error.value = "Unexpected error: ${e.javaClass.simpleName}" + (e.message?.let { " - ${it.take(160)}" } ?: "")
            } finally {
                // Keep partial answers even when the owner pressed Stop.
                withContext(NonCancellable) {
                    if (answer.isNotEmpty()) {
                        chatRepo.append(conversationId, "assistant", answer.toString(), null)
                    }
                    _streaming.value = null
                    _busy.value = false
                }
            }
        }
    }

    fun stop() {
        job?.cancel()
    }

    fun clearError() {
        _error.value = null
    }

    /** Deletes the open chat and returns to a fresh empty one. */
    fun deleteChat() {
        if (_busy.value) return
        viewModelScope.launch { conversations.delete(conversations.currentId.value) }
    }

    fun newChat() {
        if (_busy.value) return
        conversations.newChat()
    }

    /** One-tap: copy a .gguf from the phone and register it as a local provider. */
    fun addModelFromPhone(uri: Uri, displayName: String?) {
        if (_importing.value) return
        viewModelScope.launch {
            _importing.value = true
            _notice.value = "Model copy ho raha hai... (bade model mein kuch minute lag sakte hain)"
            val result = modelService.importAndRegister(uri, displayName)
            _importing.value = false
            _notice.value = result.fold(
                onSuccess = { "Model add ho gaya: $it" },
                onFailure = { it.message ?: "Model import fail ho gaya" },
            )
        }
    }

    fun clearNotice() {
        _notice.value = null
    }
}

/** The chosen provider first, then the others in their saved order. An unknown or deleted choice is ignored. */
internal fun orderChain(all: List<ProviderConfig>, selectedId: String?): List<ProviderConfig> {
    val chosen = all.firstOrNull { it.id == selectedId } ?: return all
    return listOf(chosen) + all.filter { it.id != chosen.id }
}

internal fun providerLabel(p: ProviderConfig): String {
    val base = p.model.removeSuffix(".gguf").ifBlank { p.name }
    return if (p.format == ApiFormat.LOCAL) "$base (local)" else base
}
