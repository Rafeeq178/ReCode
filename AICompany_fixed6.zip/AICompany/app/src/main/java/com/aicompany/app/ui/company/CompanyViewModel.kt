package com.aicompany.app.ui.company

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aicompany.app.company.CompanyRules
import com.aicompany.app.company.CompanyService
import com.aicompany.app.data.CompanyRepository
import com.aicompany.app.data.EmployeeEntity
import com.aicompany.app.data.TaskEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CompanyViewModel @Inject constructor(
    private val company: CompanyService,
    private val repo: CompanyRepository,
) : ViewModel() {

    val employees: StateFlow<List<EmployeeEntity>> = repo.observeEmployees()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val tasks: StateFlow<List<TaskEntity>> = repo.observeTasks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val active: StateFlow<Int> = company.activeCount

    private val _notice = MutableStateFlow<String?>(null)
    val notice: StateFlow<String?> = _notice.asStateFlow()

    fun runCeo(goal: String) {
        viewModelScope.launch {
            runCatching { company.startCeo(goal) }
                .onSuccess { _notice.value = "CEO started" }
                .onFailure { _notice.value = it.message ?: "Could not start the CEO" }
        }
    }

    fun hire(name: String, role: String) {
        viewModelScope.launch {
            runCatching { company.hire(name, role, CompanyRules.DEFAULT_WORKER_TOOLS) }
                .onSuccess { _notice.value = "Hired $name" }
                .onFailure { _notice.value = it.message ?: "Could not hire" }
        }
    }

    fun fire(employeeId: String) {
        viewModelScope.launch {
            runCatching { company.fire(employeeId) }
                .onFailure { _notice.value = it.message ?: "Could not fire" }
        }
    }

    fun stopAll() {
        company.stopAll()
        _notice.value = "All company work stopped"
    }

    fun clearNotice() {
        _notice.value = null
    }
}
