package com.aicompany.app.scheduler

import com.aicompany.app.provider.ApiFormat
import com.aicompany.app.provider.ProviderConfig

/**
 * Heavy work (code, planning, research) goes to API models.
 * Light, private work goes to the local model when one is available.
 * [prioritize] applies that decision to a provider chain.
 */
object Router {
    enum class Kind { HEAVY, LIGHT }
    enum class Route { API, LOCAL }

    /** Whole words only (with a few endings), so "latest" is not "test" and "planet" is not "plan". */
    private val HEAVY_HINTS = Regex(
        "\\b(?:code|coding|implement|debug|debugging|plan|planning|research|analy[sz]e|analysis|build|design|refactor|test)" +
            "(?:s|es|ed|d|ing)?\\b",
        RegexOption.IGNORE_CASE,
    )

    fun classify(text: String): Kind =
        if (HEAVY_HINTS.containsMatchIn(text)) Kind.HEAVY else Kind.LIGHT

    fun route(kind: Kind, localAvailable: Boolean): Route = when {
        kind == Kind.HEAVY -> Route.API
        localAvailable -> Route.LOCAL
        else -> Route.API
    }

    /**
     * Orders a provider chain for a task: for the local route the local providers go first, otherwise
     * the API providers go first. The other kind stays in the chain as a fallback, and the relative
     * order inside each group is kept.
     */
    fun prioritize(kind: Kind, chain: List<ProviderConfig>): List<ProviderConfig> {
        val localAvailable = chain.any { it.format == ApiFormat.LOCAL }
        val localFirst = route(kind, localAvailable) == Route.LOCAL
        return chain.sortedBy { if ((it.format == ApiFormat.LOCAL) == localFirst) 0 else 1 }
    }
}
