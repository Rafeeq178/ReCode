package com.aicompany.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

data class ChatMessageUi(val id: Long, val role: String, val content: String, val providerName: String?)

@Singleton
class ChatRepository @Inject constructor(private val dao: MessageDao) {

    fun observe(conversationId: String): Flow<List<ChatMessageUi>> =
        dao.observe(conversationId).map { rows ->
            rows.map { ChatMessageUi(it.id, it.role, it.content, it.providerName) }
        }

    /** Current messages of a chat, read straight from the database (not from a possibly stale StateFlow). */
    suspend fun snapshot(conversationId: String): List<ChatMessageUi> =
        observe(conversationId).first()

    suspend fun append(conversationId: String, role: String, content: String, providerName: String?): Long =
        withContext(Dispatchers.IO) {
            dao.insert(
                MessageEntity(
                    conversationId = conversationId,
                    role = role,
                    content = content,
                    providerName = providerName,
                    createdAt = System.currentTimeMillis(),
                )
            )
        }

    suspend fun updateContent(id: Long, content: String) = withContext(Dispatchers.IO) {
        dao.updateContent(id, content)
    }

    suspend fun clear(conversationId: String) = withContext(Dispatchers.IO) {
        dao.clear(conversationId)
    }
}
