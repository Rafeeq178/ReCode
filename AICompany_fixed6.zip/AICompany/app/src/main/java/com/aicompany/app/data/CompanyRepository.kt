package com.aicompany.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CompanyRepository @Inject constructor(private val dao: CompanyDao) {
    fun observeEmployees() = dao.observeEmployees()
    fun observeTasks() = dao.observeTasks()
    fun observeTask(id: Long) = dao.observeTask(id)
    fun observeVersions(employeeId: String) = dao.observeVersions(employeeId)
    fun observeTemplates() = dao.observeTemplates()
    fun observeSkills() = dao.observeSkills()

    suspend fun getEmployee(id: String): EmployeeEntity? = withContext(Dispatchers.IO) { dao.getEmployee(id) }
    suspend fun activeEmployeeCount(): Int = withContext(Dispatchers.IO) { dao.activeEmployeeCount() }
    suspend fun saveEmployee(e: EmployeeEntity) = withContext(Dispatchers.IO) { dao.saveEmployee(e) }
    suspend fun insertTask(t: TaskEntity): Long = withContext(Dispatchers.IO) { dao.insertTask(t) }

    suspend fun updateTask(id: Long, status: String, result: String, runId: Long) = withContext(Dispatchers.IO) {
        dao.updateTask(id, status, result.take(MAX_RESULT_CHARS), runId, System.currentTimeMillis())
    }

    suspend fun saveVersion(employeeId: String, version: Int, snapshotJson: String) = withContext(Dispatchers.IO) {
        require(snapshotJson.length <= MAX_SNAPSHOT_CHARS) { "Snapshot is too large" }
        dao.insertVersion(
            EmployeeVersionEntity(
                employeeId = employeeId,
                version = version,
                createdAt = System.currentTimeMillis(),
                snapshot = snapshotJson,
            )
        )
    }

    suspend fun getVersion(employeeId: String, version: Int): EmployeeVersionEntity? =
        withContext(Dispatchers.IO) { dao.getVersion(employeeId, version) }

    suspend fun saveTemplate(name: String, snapshotJson: String): Long = withContext(Dispatchers.IO) {
        dao.insertTemplate(TemplateEntity(name = name, snapshot = snapshotJson, createdAt = System.currentTimeMillis()))
    }

    suspend fun getTemplate(id: Long): TemplateEntity? = withContext(Dispatchers.IO) { dao.getTemplate(id) }

    suspend fun saveSkill(skill: SkillEntity) = withContext(Dispatchers.IO) { dao.saveSkill(skill) }

    suspend fun getSkill(id: String): SkillEntity? = withContext(Dispatchers.IO) { dao.getSkill(id) }

    suspend fun skillIds(): Set<String> = withContext(Dispatchers.IO) { dao.skillIds().toSet() }

    companion object {
        const val MAX_RESULT_CHARS = 4_000
        const val MAX_SNAPSHOT_CHARS = 32_000
    }
}
