package com.aicompany.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

// Warm "paper" palette: off-white background, white cards, black pill buttons, orange accent.
val AccentOrange = Color(0xFFD97757)
val SwitchBlue = Color(0xFF1A73E8)

private val LightColors = lightColorScheme(
    primary = Color(0xFF141413),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFEFEDE5),
    onPrimaryContainer = Color(0xFF141413),
    secondary = Color(0xFF5E5D59),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFEAE6DA),
    onSecondaryContainer = Color(0xFF141413),
    tertiary = AccentOrange,
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFF8E4DB),
    onTertiaryContainer = Color(0xFF7A3B26),
    background = Color(0xFFFAF9F5),
    onBackground = Color(0xFF1F1E1D),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1F1E1D),
    surfaceVariant = Color(0xFFF0EEE6),
    onSurfaceVariant = Color(0xFF73726C),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFFFFFFF),
    surfaceContainer = Color(0xFFFFFFFF),
    surfaceContainerHigh = Color(0xFFFFFFFF),
    surfaceContainerHighest = Color(0xFFF0EEE6),
    outline = Color(0xFFD9D6CB),
    outlineVariant = Color(0xFFE8E5DC),
    error = Color(0xFFC0392B),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFCE8E5),
    onErrorContainer = Color(0xFF7A1F15),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFF0EEE6),
    onPrimary = Color(0xFF1F1E1D),
    primaryContainer = Color(0xFF3A3935),
    onPrimaryContainer = Color(0xFFF0EEE6),
    secondary = Color(0xFFB8B6AD),
    onSecondary = Color(0xFF1F1E1D),
    secondaryContainer = Color(0xFF45433F),
    onSecondaryContainer = Color(0xFFF0EEE6),
    tertiary = Color(0xFFDA7756),
    onTertiary = Color(0xFF1F1E1D),
    tertiaryContainer = Color(0xFF4A2A1E),
    onTertiaryContainer = Color(0xFFF1D2C4),
    background = Color(0xFF262624),
    onBackground = Color(0xFFF0EEE6),
    surface = Color(0xFF30302E),
    onSurface = Color(0xFFF0EEE6),
    surfaceVariant = Color(0xFF1F1E1D),
    onSurfaceVariant = Color(0xFFA9A79F),
    surfaceContainerLowest = Color(0xFF1F1E1D),
    surfaceContainerLow = Color(0xFF30302E),
    surfaceContainer = Color(0xFF30302E),
    surfaceContainerHigh = Color(0xFF3A3935),
    surfaceContainerHighest = Color(0xFF45433F),
    outline = Color(0xFF4D4C48),
    outlineVariant = Color(0xFF3A3935),
    error = Color(0xFFFF8A7D),
    onError = Color(0xFF3A0B05),
    errorContainer = Color(0xFF5C1E1C),
    onErrorContainer = Color(0xFFFFDAD5),
)

private val Serif = FontFamily.Serif

private val AppTypography: Typography = Typography().let { t ->
    t.copy(
        headlineLarge = t.headlineLarge.copy(fontFamily = Serif),
        headlineMedium = t.headlineMedium.copy(fontFamily = Serif),
        headlineSmall = t.headlineSmall.copy(fontFamily = Serif),
        titleLarge = t.titleLarge.copy(fontFamily = Serif, fontWeight = FontWeight.Medium),
    )
}

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(12.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun AICompanyTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography,
        shapes = AppShapes,
        content = content,
    )
}
