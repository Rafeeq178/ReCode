package com.aicompany.app.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.aicompany.app.util.CrashReporter
import dagger.hilt.android.qualifiers.ApplicationContext
import java.security.KeyStore
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Stores API keys and named secrets in Android Keystore-backed encrypted preferences.
 * Provider keys are keyed by provider id; secrets are keyed by "secret:NAME".
 * Nothing here is written to Room, logs, or prompts.
 */
@Singleton
class KeyVault @Inject constructor(@ApplicationContext context: Context) {

    @Volatile private var opened: SharedPreferences? = null
    private val appContext = context.applicationContext

    /**
     * Opens the encrypted store. Keystore errors are often temporary (right after boot, or while the
     * device is locked), so this retries before giving up. It never deletes keys and never falls back
     * to a plaintext file: if the store cannot be opened, reads return nothing and writes fail with a
     * clear message. A permanently broken store (restored backup, lost master key) is only wiped when
     * the owner asks for it via [resetSecureStorage].
     */
    private fun prefsOrNull(): SharedPreferences? {
        opened?.let { return it }
        synchronized(this) {
            opened?.let { return it }
            var last: Exception? = null
            repeat(OPEN_ATTEMPTS) { attempt ->
                try {
                    return create().also { opened = it }
                } catch (e: Exception) {
                    last = e
                    if (attempt < OPEN_ATTEMPTS - 1) Thread.sleep(OPEN_RETRY_DELAY_MS)
                }
            }
            last?.let { CrashReporter.record(appContext, "KeyVault: secure storage unavailable (keys were NOT deleted)", it) }
            return null
        }
    }

    private fun create(): SharedPreferences = EncryptedSharedPreferences.create(
        appContext,
        PREFS_FILE,
        // A key scheme MUST be set: MasterKey.Builder(context).build() alone throws IllegalArgumentException.
        MasterKey.Builder(appContext).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
    )

    private fun prefsForWrite(): SharedPreferences =
        prefsOrNull() ?: throw IllegalStateException(
            "Secure key storage is not available on this device right now. Restart the app. " +
                "If it keeps happening, use Settings > Reset secure storage (this deletes saved API keys)."
        )

    /** True when the encrypted store can be opened. */
    val isAvailable: Boolean get() = prefsOrNull() != null

    /** Owner-requested recovery: deletes the encrypted file and its master key so a fresh store can be created. */
    fun resetSecureStorage(): Boolean {
        synchronized(this) {
            opened = null
            runCatching { appContext.deleteSharedPreferences(PREFS_FILE) }
            runCatching {
                KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
                    .deleteEntry(MasterKey.DEFAULT_MASTER_KEY_ALIAS)
            }
        }
        return prefsOrNull() != null
    }

    fun keysFor(providerId: String): List<String> =
        prefsOrNull()?.getString(providerId, null)
            ?.split('\n')
            ?.map { it.trim() }
            ?.filter { it.isNotEmpty() }
            ?: emptyList()

    fun saveKeys(providerId: String, keys: List<String>) {
        val cleaned = keys.map { it.trim() }.filter { it.isNotEmpty() }
        require(cleaned.all { it.length <= MAX_KEY_LENGTH && !it.contains('\n') }) { "Invalid key format" }
        prefsForWrite().edit().putString(providerId, cleaned.joinToString("\n")).apply()
    }

    fun deleteKeys(providerId: String) {
        prefsForWrite().edit().remove(providerId).apply()
    }

    fun saveSecret(name: String, value: String) {
        require(SECRET_NAME.matches(name)) { "Secret name must be UPPER_CASE letters, digits or underscores" }
        require(value.isNotEmpty() && value.length <= MAX_SECRET_LENGTH) { "Secret value must be 1-2048 characters" }
        prefsForWrite().edit().putString("$SECRET_PREFIX$name", value).apply()
    }

    /** Returns the secret value. Callers must never show it to a model or log it. */
    fun getSecret(name: String): String? {
        if (!SECRET_NAME.matches(name)) return null
        return prefsOrNull()?.getString("$SECRET_PREFIX$name", null)
    }

    fun deleteSecret(name: String) {
        prefsForWrite().edit().remove("$SECRET_PREFIX$name").apply()
    }

    /** Stores a larger encrypted value, for example an OAuth state. Never shown to models. */
    fun saveBlob(name: String, value: String) {
        require(SECRET_NAME.matches(name)) { "Blob name is invalid" }
        require(value.isNotEmpty() && value.length <= MAX_BLOB_LENGTH) { "Value is too large" }
        prefsForWrite().edit().putString("$BLOB_PREFIX$name", value).apply()
    }

    fun getBlob(name: String): String? {
        if (!SECRET_NAME.matches(name)) return null
        return prefsOrNull()?.getString("$BLOB_PREFIX$name", null)
    }

    fun deleteBlob(name: String) {
        prefsForWrite().edit().remove("$BLOB_PREFIX$name").apply()
    }

    companion object {
        private const val PREFS_FILE = "ai_company_keys"
        private const val OPEN_ATTEMPTS = 3
        private const val OPEN_RETRY_DELAY_MS = 150L
        const val MAX_KEY_LENGTH = 512
        const val MAX_BLOB_LENGTH = 16_384
        private const val BLOB_PREFIX = "blob:"
        const val MAX_SECRET_LENGTH = 2048
        private const val SECRET_PREFIX = "secret:"
        private val SECRET_NAME = Regex("^[A-Z][A-Z0-9_]{0,39}$")
    }
}
