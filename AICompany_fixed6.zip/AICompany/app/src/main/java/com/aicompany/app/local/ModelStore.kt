package com.aicompany.app.local

import android.content.Context
import android.net.Uri
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import javax.inject.Inject
import javax.inject.Singleton

/** Imports and lists GGUF files in the app's private models folder. */
@Singleton
class ModelStore @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val dir = File(context.filesDir, "models").apply { mkdirs() }

    data class LocalModelFile(val name: String, val sizeBytes: Long)

    fun list(): List<LocalModelFile> =
        dir.listFiles { f -> f.isFile && f.name.endsWith(".gguf") }
            .orEmpty()
            .sortedBy { it.name }
            .map { LocalModelFile(it.name, it.length()) }

    fun file(name: String): File {
        require(NAME.matches(name)) { "Invalid model name" }
        val f = File(dir, name)
        require(f.canonicalPath.startsWith(dir.canonicalPath + File.separator)) { "Invalid model path" }
        return f
    }

    /**
     * Copies a picked file into the models folder. The copy goes to a temp file first,
     * then the GGUF header is checked. Invalid or oversized files are deleted.
     */
    suspend fun importFile(uri: Uri, displayName: String?): Result<LocalModelFile> = withContext(Dispatchers.IO) {
        runCatching {
            val name = sanitize(displayName)
            val target = file(name)
            val tmp = File(dir, "$name.part")
            val input = context.contentResolver.openInputStream(uri)
                ?: throw IllegalArgumentException("Could not open the picked file")
            input.use { src ->
                FileOutputStream(tmp).use { out ->
                    val buf = ByteArray(64 * 1024)
                    var total = 0L
                    while (true) {
                        val n = src.read(buf)
                        if (n < 0) break
                        total += n
                        if (total > MAX_MODEL_BYTES) {
                            tmp.delete()
                            throw IllegalArgumentException("Model is larger than 4 GB")
                        }
                        out.write(buf, 0, n)
                    }
                }
            }
            val header = tmp.inputStream().use { GgufValidator.readHeader(it) }
            if (!GgufValidator.isGgufHeader(header)) {
                tmp.delete()
                throw IllegalArgumentException("This file is not a valid GGUF model")
            }
            target.delete()
            if (!tmp.renameTo(target)) {
                tmp.delete()
                throw IllegalStateException("Could not save the model")
            }
            LocalModelFile(target.name, target.length())
        }
    }

    fun delete(name: String): Boolean = file(name).delete()

    private fun sanitize(displayName: String?): String {
        val base = (displayName ?: "model.gguf").replace(Regex("[^A-Za-z0-9._-]"), "_").take(70)
        val withExt = if (base.endsWith(".gguf")) base else "$base.gguf"
        require(NAME.matches(withExt)) { "Invalid file name" }
        return withExt
    }

    companion object {
        const val MAX_MODEL_BYTES = 4L * 1024 * 1024 * 1024
        private val NAME = Regex("^[A-Za-z0-9._-]{1,80}\\.gguf$")
    }
}
