package com.aicompany.app.data

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        ProviderEntity::class,
        MessageEntity::class,
        AuditEntity::class,
        AgentRunEntity::class,
        AgentLogEntity::class,
        EmployeeEntity::class,
        TaskEntity::class,
        EmployeeVersionEntity::class,
        TemplateEntity::class,
        SkillEntity::class,
        CustomToolEntity::class,
    ],
    version = 6,
    exportSchema = false,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun providerDao(): ProviderDao
    abstract fun messageDao(): MessageDao
    abstract fun auditDao(): AuditDao
    abstract fun agentDao(): AgentDao
    abstract fun companyDao(): CompanyDao
    abstract fun customToolDao(): CustomToolDao

    companion object {
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `audit_log` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`createdAt` INTEGER NOT NULL, " +
                        "`agentId` TEXT NOT NULL, " +
                        "`toolName` TEXT NOT NULL, " +
                        "`summary` TEXT NOT NULL, " +
                        "`approvalLevel` TEXT NOT NULL, " +
                        "`decision` TEXT NOT NULL, " +
                        "`outcome` TEXT NOT NULL)"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_audit_log_createdAt` ON `audit_log` (`createdAt`)")
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `agent_runs` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`agentName` TEXT NOT NULL, " +
                        "`goal` TEXT NOT NULL, " +
                        "`status` TEXT NOT NULL, " +
                        "`reason` TEXT NOT NULL, " +
                        "`startedAt` INTEGER NOT NULL, " +
                        "`endedAt` INTEGER NOT NULL, " +
                        "`steps` INTEGER NOT NULL)"
                )
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `agent_logs` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`runId` INTEGER NOT NULL, " +
                        "`step` INTEGER NOT NULL, " +
                        "`kind` TEXT NOT NULL, " +
                        "`text` TEXT NOT NULL, " +
                        "`createdAt` INTEGER NOT NULL)"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_agent_logs_runId` ON `agent_logs` (`runId`)")
            }
        }

        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `employees` (" +
                        "`id` TEXT NOT NULL, " +
                        "`name` TEXT NOT NULL, " +
                        "`role` TEXT NOT NULL, " +
                        "`allowedTools` TEXT NOT NULL, " +
                        "`status` TEXT NOT NULL, " +
                        "`createdAt` INTEGER NOT NULL, " +
                        "PRIMARY KEY(`id`))"
                )
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `tasks` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`title` TEXT NOT NULL, " +
                        "`description` TEXT NOT NULL, " +
                        "`assigneeId` TEXT NOT NULL, " +
                        "`status` TEXT NOT NULL, " +
                        "`result` TEXT NOT NULL, " +
                        "`runId` INTEGER NOT NULL, " +
                        "`createdAt` INTEGER NOT NULL, " +
                        "`updatedAt` INTEGER NOT NULL)"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_tasks_assigneeId` ON `tasks` (`assigneeId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_tasks_status` ON `tasks` (`status`)")
            }
        }

        val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `custom_tools` (" +
                        "`name` TEXT NOT NULL, " +
                        "`definition` TEXT NOT NULL, " +
                        "`createdAt` INTEGER NOT NULL, " +
                        "PRIMARY KEY(`name`))"
                )
            }
        }

        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `employees` ADD COLUMN `systemPrompt` TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE `employees` ADD COLUMN `providerIds` TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE `employees` ADD COLUMN `model` TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE `employees` ADD COLUMN `maxSteps` INTEGER NOT NULL DEFAULT 15")
                db.execSQL("ALTER TABLE `employees` ADD COLUMN `timeoutSeconds` INTEGER NOT NULL DEFAULT 600")
                db.execSQL("ALTER TABLE `employees` ADD COLUMN `maxTokens` INTEGER NOT NULL DEFAULT 1024")
                db.execSQL("ALTER TABLE `employees` ADD COLUMN `temperature` REAL NOT NULL DEFAULT 0.2")
                db.execSQL("ALTER TABLE `employees` ADD COLUMN `terminalPermission` TEXT NOT NULL DEFAULT 'ASK'")
                db.execSQL("ALTER TABLE `employees` ADD COLUMN `localPriority` INTEGER NOT NULL DEFAULT 5")
                db.execSQL("ALTER TABLE `employees` ADD COLUMN `skillIds` TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE `employees` ADD COLUMN `ceoCanModify` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `employees` ADD COLUMN `color` TEXT NOT NULL DEFAULT '#C9623F'")
                db.execSQL("ALTER TABLE `employees` ADD COLUMN `version` INTEGER NOT NULL DEFAULT 1")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `employee_versions` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`employeeId` TEXT NOT NULL, " +
                        "`version` INTEGER NOT NULL, " +
                        "`createdAt` INTEGER NOT NULL, " +
                        "`snapshot` TEXT NOT NULL)"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_employee_versions_employeeId` ON `employee_versions` (`employeeId`)")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `templates` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`name` TEXT NOT NULL, " +
                        "`snapshot` TEXT NOT NULL, " +
                        "`createdAt` INTEGER NOT NULL)"
                )
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `skills` (" +
                        "`id` TEXT NOT NULL, " +
                        "`name` TEXT NOT NULL, " +
                        "`description` TEXT NOT NULL, " +
                        "`instructions` TEXT NOT NULL, " +
                        "`createdAt` INTEGER NOT NULL, " +
                        "PRIMARY KEY(`id`))"
                )
            }
        }
    }
}
