package com.aicompany.app.local

import android.net.Uri
import com.aicompany.app.data.ProviderDraft
import com.aicompany.app.data.ProviderRepository
import com.aicompany.app.provider.ApiFormat
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

/**
 * One-tap "add a model from the phone": copies the picked .gguf into the app and makes sure a
 * LOCAL provider points at it, so the model can be used right away.
 */
@Singleton
class LocalModelService @Inject constructor(
    private val store: ModelStore,
    private val providers: ProviderRepository,
) {
    /** Returns the stored file name. */
    suspend fun importAndRegister(uri: Uri, displayName: String?): Result<String> {
        val imported = store.importFile(uri, displayName).getOrElse { return Result.failure(it) }
        return runCatching {
            val existing = providers.observe().first()
            val already = existing.any { it.format == ApiFormat.LOCAL && it.model == imported.name }
            if (!already) {
                providers.save(
                    ProviderDraft(
                        name = imported.name.removeSuffix(".gguf").take(60),
                        format = ApiFormat.LOCAL,
                        baseUrl = "local",
                        model = imported.name,
                        keysText = "",
                        maxTokens = 1024,
                        temperature = 0.7,
                        timeoutSeconds = 300,
                    )
                )
            }
            imported.name
        }
    }
}
