package com.aicompany.app.agents

import com.aicompany.app.tools.ToolCall
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.Json

/**
 * Turns raw model text into one action. Accepts a JSON tool call, a JSON done object,
 * or plain "...DONE". Anything else is Invalid and is sent back to the model as an error.
 */
object ToolCallParser {
    private const val MAX_INPUT = 20_000
    private const val MAX_DONE = 4_000
    private val json = Json.Default

    fun parse(raw: String): AgentAction {
        val text = raw.trim()
            .removePrefix("```json").removePrefix("```")
            .removeSuffix("```").trim()
        if (text.isEmpty()) return AgentAction.Invalid("Your reply was empty")
        if (text.length > MAX_INPUT) return AgentAction.Invalid("Your reply is too long")
        if (text.endsWith("DONE")) {
            return AgentAction.Done(text.removeSuffix("DONE").trim().take(MAX_DONE))
        }

        val start = text.indexOf('{')
        val end = text.lastIndexOf('}')
        if (start < 0 || end <= start) {
            return AgentAction.Invalid("Reply with one JSON object only")
        }
        val obj: JsonObject = try {
            json.parseToJsonElement(text.substring(start, end + 1)) as? JsonObject
                ?: return AgentAction.Invalid("Reply with one JSON object only")
        } catch (e: Exception) {
            return AgentAction.Invalid("Reply is not valid JSON")
        }

        obj["done"]?.let { done ->
            val s = (done as? JsonPrimitive)?.takeIf { it.isString }?.content
                ?: return AgentAction.Invalid("\"done\" must be a string")
            return AgentAction.Done(s.take(MAX_DONE))
        }
        val tool = (obj["tool"] as? JsonPrimitive)?.takeIf { it.isString }?.content
            ?: return AgentAction.Invalid("Missing \"tool\" name")
        val args: JsonElement = obj["arguments"] ?: JsonObject(emptyMap())
        val argsObj = args as? JsonObject
            ?: return AgentAction.Invalid("\"arguments\" must be a JSON object")
        return AgentAction.Call(ToolCall(tool, argsObj))
    }
}
