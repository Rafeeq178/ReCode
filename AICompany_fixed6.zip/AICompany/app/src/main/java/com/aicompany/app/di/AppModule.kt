package com.aicompany.app.di

import android.content.Context
import androidx.room.Room
import com.aicompany.app.data.AgentDao
import com.aicompany.app.data.CompanyDao
import com.aicompany.app.data.AppDatabase
import com.aicompany.app.data.AuditDao
import com.aicompany.app.data.MessageDao
import com.aicompany.app.data.ProviderDao
import com.aicompany.app.provider.AnthropicClient
import com.aicompany.app.provider.ApiFormat
import com.aicompany.app.provider.GeminiClient
import com.aicompany.app.provider.OpenAiCompatClient
import com.aicompany.app.provider.ProviderClient
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import dagger.multibindings.IntoMap
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides @Singleton
    fun provideJson(): Json = Json { ignoreUnknownKeys = true; isLenient = false }

    @Provides @Singleton
    fun provideHttp(): OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .retryOnConnectionFailure(false)
        .build()

    @Provides @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase =
        Room.databaseBuilder(context, AppDatabase::class.java, "ai_company.db")
            .addMigrations(
                AppDatabase.MIGRATION_1_2,
                AppDatabase.MIGRATION_2_3,
                AppDatabase.MIGRATION_3_4,
                AppDatabase.MIGRATION_4_5,
                AppDatabase.MIGRATION_5_6,
            )
            .build()

    @Provides
    fun provideProviderDao(db: AppDatabase): ProviderDao = db.providerDao()

    @Provides
    fun provideMessageDao(db: AppDatabase): MessageDao = db.messageDao()

    @Provides
    fun provideAuditDao(db: AppDatabase): AuditDao = db.auditDao()

    @Provides
    fun provideAgentDao(db: AppDatabase): AgentDao = db.agentDao()

    @Provides
    fun provideCompanyDao(db: AppDatabase): CompanyDao = db.companyDao()

    @Provides
    fun provideCustomToolDao(db: AppDatabase): com.aicompany.app.data.CustomToolDao = db.customToolDao()
}

@Module
@InstallIn(SingletonComponent::class)
abstract class ClientBindings {
    @Binds @IntoMap @ApiFormatKey(ApiFormat.OPENAI)
    abstract fun openAi(impl: OpenAiCompatClient): ProviderClient

    @Binds @IntoMap @ApiFormatKey(ApiFormat.ANTHROPIC)
    abstract fun anthropic(impl: AnthropicClient): ProviderClient

    @Binds @IntoMap @ApiFormatKey(ApiFormat.GEMINI)
    abstract fun gemini(impl: GeminiClient): ProviderClient

    @Binds @IntoMap @ApiFormatKey(ApiFormat.LOCAL)
    abstract fun local(impl: com.aicompany.app.llama.LocalLlamaClient): ProviderClient
}
