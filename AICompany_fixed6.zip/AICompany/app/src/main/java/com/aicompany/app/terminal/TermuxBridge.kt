package com.aicompany.app.terminal

import android.content.Context
import android.view.View
import com.termux.terminal.TerminalSession
import com.termux.terminal.TerminalSessionClient
import com.termux.view.TerminalView
import com.termux.view.TerminalViewClient
import com.aicompany.app.util.Logger
import android.view.MotionEvent
import android.view.KeyEvent

/**
 * The ONLY file that talks to the Termux libraries (terminal-emulator, terminal-view v0.118.3).
 * Every other part of the app uses ShellLauncher and TerminalScreen, so a library API change
 * touches just this file.
 */
object TermuxBridge {

    fun createSession(
        argv: List<String>,
        environment: Map<String, String>,
        cwd: String,
        onFinished: (Int) -> Unit,
    ): TerminalSession {
        require(argv.isNotEmpty()) { "Empty shell command" }
        val env = environment.map { (k, v) -> "$k=$v" }.toTypedArray()
        return TerminalSession(
            argv[0],
            cwd,
            argv.drop(1).toTypedArray(),
            env,
            TRANSCRIPT_ROWS,
            object : TerminalSessionClient {
                override fun onTextChanged(session: TerminalSession) = Unit
                override fun onTitleChanged(session: TerminalSession) = Unit
                override fun onSessionFinished(session: TerminalSession) = onFinished(session.exitStatus)
                override fun onCopyTextToClipboard(session: TerminalSession, text: String) = Unit
                override fun onPasteTextFromClipboard(session: TerminalSession?) = Unit
                override fun onBell(session: TerminalSession) = Unit
                override fun onColorsChanged(session: TerminalSession) = Unit
                override fun onTerminalCursorStateChange(enabled: Boolean) = Unit
                override fun getTerminalCursorStyle(): Int? = null
                override fun logError(tag: String, message: String) = Logger.e(tag, message)
                override fun logWarn(tag: String, message: String) = Logger.w(tag, message)
                override fun logInfo(tag: String, message: String) = Logger.i(tag, message)
                override fun logDebug(tag: String, message: String) = Unit
                override fun logVerbose(tag: String, message: String) = Unit
                override fun logStackTraceWithMessage(tag: String, message: String, e: Exception) = Logger.e(tag, message, e)
                override fun logStackTrace(tag: String, e: Exception) = Logger.e(tag, "stack trace", e)
            },
        )
    }

    fun createView(context: Context): TerminalView = TerminalView(context, null).apply {
        setTextSize(TEXT_SIZE_SP)
        setTerminalViewClient(object : TerminalViewClient {
            override fun onScale(scale: Float): Float = scale.coerceIn(MIN_SCALE, MAX_SCALE)
            override fun onSingleTapUp(e: MotionEvent) = Unit
            override fun shouldBackButtonBeMappedToEscape(): Boolean = false
            override fun shouldEnforceCharBasedInput(): Boolean = true
            override fun shouldUseCtrlSpaceWorkaround(): Boolean = false
            override fun isTerminalViewSelected(): Boolean = true
            override fun copyModeChanged(copyMode: Boolean) = Unit
            override fun onKeyDown(keyCode: Int, e: KeyEvent, session: TerminalSession?): Boolean = false
            override fun onKeyUp(keyCode: Int, e: KeyEvent): Boolean = false
            override fun onLongPress(event: MotionEvent): Boolean = false
            override fun readControlKey(): Boolean = false
            override fun readAltKey(): Boolean = false
            override fun readShiftKey(): Boolean = false
            override fun readFnKey(): Boolean = false
            override fun onCodePoint(codePoint: Int, ctrlDown: Boolean, session: TerminalSession?): Boolean = false
            override fun onEmulatorSet() = Unit
            override fun logError(tag: String, message: String) = Logger.e(tag, message)
            override fun logWarn(tag: String, message: String) = Logger.w(tag, message)
            override fun logInfo(tag: String, message: String) = Logger.i(tag, message)
            override fun logDebug(tag: String, message: String) = Unit
            override fun logVerbose(tag: String, message: String) = Unit
            override fun logStackTraceWithMessage(tag: String, message: String, e: Exception) = Logger.e(tag, message, e)
            override fun logStackTrace(tag: String, e: Exception) = Logger.e(tag, "stack trace", e)
        })
        isFocusable = true
        isFocusableInTouchMode = true
        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
    }

    private const val TRANSCRIPT_ROWS = 2000
    private const val TEXT_SIZE_SP = 14
    private const val MIN_SCALE = 0.8f
    private const val MAX_SCALE = 2.5f
}
