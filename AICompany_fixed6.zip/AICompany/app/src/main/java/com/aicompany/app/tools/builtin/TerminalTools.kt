package com.aicompany.app.tools.builtin

import com.aicompany.app.terminal.CommandResult
import com.aicompany.app.terminal.CommandRunner
import com.aicompany.app.terminal.ShellLauncher
import com.aicompany.app.tools.ApprovalLevel
import com.aicompany.app.tools.Schema
import com.aicompany.app.tools.Tool
import com.aicompany.app.tools.ToolContext
import com.aicompany.app.tools.ToolResult
import com.aicompany.app.tools.ToolSpec
import com.aicompany.app.tools.WorkspaceProvider
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonPrimitive
import java.util.UUID
import javax.inject.Inject

private const val DEFAULT_TIMEOUT_SEC = 60
private const val MAX_TIMEOUT_SEC = 280
private const val MAX_CODE_CHARS = 20_000
private const val OUTPUT_CHARS = 8_000
private val PACKAGE_NAME = Regex("^[A-Za-z0-9._@/+\\-]{1,80}$")

/** Shared helpers: every terminal tool runs through the same guarded path. */
abstract class TerminalTool(
    protected val shell: ShellLauncher,
    protected val runner: CommandRunner,
) : Tool {

    protected suspend fun runShell(command: String, timeoutSec: Int): ToolResult {
        val reason = shell.notReadyReason()
            ?: return runCatching {
                formatResult(runner.run(shell.commandArgv(command), shell.environment(), timeoutSec * 1000L, OUTPUT_CHARS))
            }.getOrElse { ToolResult.Error("run_failed", it.message ?: "Command could not start") }
        return ToolResult.Error("terminal_not_ready", reason)
    }

    protected fun timeoutArg(args: JsonObject): Int {
        val v = args["timeout_seconds"]?.jsonPrimitive?.intOrNull ?: DEFAULT_TIMEOUT_SEC
        require(v in 1..MAX_TIMEOUT_SEC) { "timeout_seconds must be 1-$MAX_TIMEOUT_SEC" }
        return v
    }

    private fun formatResult(r: CommandResult): ToolResult {
        val header = when {
            r.timedOut -> "[timed out]"
            else -> "[exit ${r.exitCode}]"
        }
        val trunc = if (r.outputTruncated) "\n[output truncated]" else ""
        return ToolResult.Ok("$header\n${r.output}$trunc")
    }
}

internal fun stringArgument(args: JsonObject, key: String, maxChars: Int): String {
    val v = (args[key] as? JsonPrimitive)?.takeIf { it.isString }?.content
        ?: throw IllegalArgumentException("$key must be a string")
    require(v.isNotBlank()) { "$key is empty" }
    require(v.length <= maxChars) { "$key is too long (max $maxChars)" }
    require(!v.contains('\u0000')) { "$key contains an invalid character" }
    return v
}

class RunCommandTool @Inject constructor(
    shell: ShellLauncher,
    runner: CommandRunner,
) : TerminalTool(shell, runner) {
    override val spec = ToolSpec(
        name = "run_command",
        description = "Run a shell command inside the Alpine Linux environment. Needs owner approval.",
        schema = Schema.obj(
            mapOf(
                "command" to Schema.str("Shell command to run", ShellLauncher.MAX_COMMAND_CHARS),
                "timeout_seconds" to Schema.int("Timeout in seconds", 1, MAX_TIMEOUT_SEC.toLong()),
            ),
            listOf("command"),
        ),
        approval = ApprovalLevel.ASK,
        timeoutMs = 300_000,
        maxOutputChars = OUTPUT_CHARS,
    )

    override suspend fun execute(args: JsonObject, ctx: ToolContext): ToolResult {
        val command = stringArgument(args, "command", ShellLauncher.MAX_COMMAND_CHARS)
        return runShell(command, timeoutArg(args))
    }
}

class RunPythonTool @Inject constructor(
    shell: ShellLauncher,
    runner: CommandRunner,
    private val workspace: WorkspaceProvider,
) : TerminalTool(shell, runner) {
    override val spec = ToolSpec(
        name = "run_python",
        description = "Run Python 3 code inside Alpine. The code is stored in a temporary workspace file. Needs owner approval.",
        schema = Schema.obj(
            mapOf(
                "code" to Schema.str("Python source code", MAX_CODE_CHARS),
                "timeout_seconds" to Schema.int("Timeout in seconds", 1, MAX_TIMEOUT_SEC.toLong()),
            ),
            listOf("code"),
        ),
        approval = ApprovalLevel.ASK,
        timeoutMs = 300_000,
        maxOutputChars = OUTPUT_CHARS,
    )

    override suspend fun execute(args: JsonObject, ctx: ToolContext): ToolResult =
        runScript(args, "py", "python3")

    private suspend fun runScript(args: JsonObject, ext: String, interpreter: String): ToolResult {
        val code = stringArgument(args, "code", MAX_CODE_CHARS)
        val rel = ".tmp/run_${UUID.randomUUID()}.$ext"
        val file = workspace.sandbox.resolve(rel)
        file.parentFile?.mkdirs()
        file.writeText(code, Charsets.UTF_8)
        try {
            return runShell("$interpreter /workspace/$rel", timeoutArg(args))
        } finally {
            file.delete()
        }
    }
}

class RunNodeTool @Inject constructor(
    shell: ShellLauncher,
    runner: CommandRunner,
    private val workspace: WorkspaceProvider,
) : TerminalTool(shell, runner) {
    override val spec = ToolSpec(
        name = "run_node",
        description = "Run JavaScript (Node.js) code inside Alpine. The code is stored in a temporary workspace file. Needs owner approval.",
        schema = Schema.obj(
            mapOf(
                "code" to Schema.str("JavaScript source code", MAX_CODE_CHARS),
                "timeout_seconds" to Schema.int("Timeout in seconds", 1, MAX_TIMEOUT_SEC.toLong()),
            ),
            listOf("code"),
        ),
        approval = ApprovalLevel.ASK,
        timeoutMs = 300_000,
        maxOutputChars = OUTPUT_CHARS,
    )

    override suspend fun execute(args: JsonObject, ctx: ToolContext): ToolResult {
        val code = stringArgument(args, "code", MAX_CODE_CHARS)
        val rel = ".tmp/run_${UUID.randomUUID()}.js"
        val file = workspace.sandbox.resolve(rel)
        file.parentFile?.mkdirs()
        file.writeText(code, Charsets.UTF_8)
        try {
            return runShell("node /workspace/$rel", timeoutArg(args))
        } finally {
            file.delete()
        }
    }
}

class InstallPackageTool @Inject constructor(
    shell: ShellLauncher,
    runner: CommandRunner,
) : TerminalTool(shell, runner) {
    override val spec = ToolSpec(
        name = "install_package",
        description = "Install a package with apk (system), pip (Python), or npm (global). Needs owner approval.",
        schema = Schema.obj(
            mapOf(
                "manager" to Schema.enumStr("Package manager", listOf("apk", "pip", "npm")),
                "package" to Schema.str("Package name, letters digits . _ @ / + - only", 80),
                "timeout_seconds" to Schema.int("Timeout in seconds", 1, MAX_TIMEOUT_SEC.toLong()),
            ),
            listOf("manager", "package"),
        ),
        approval = ApprovalLevel.ASK,
        timeoutMs = 300_000,
        maxOutputChars = OUTPUT_CHARS,
    )

    override suspend fun execute(args: JsonObject, ctx: ToolContext): ToolResult {
        val manager = stringArgument(args, "manager", 8)
        val pkg = stringArgument(args, "package", 80)
        require(PACKAGE_NAME.matches(pkg)) { "Package name has invalid characters" }
        val command = when (manager) {
            "apk" -> "apk add --no-cache '$pkg'"
            "pip" -> "pip install --no-input --break-system-packages '$pkg'"
            "npm" -> "npm install -g '$pkg'"
            else -> throw IllegalArgumentException("manager must be apk, pip or npm")
        }
        return runShell(command, timeoutArg(args))
    }
}
