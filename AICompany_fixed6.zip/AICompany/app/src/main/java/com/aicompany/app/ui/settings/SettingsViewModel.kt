package com.aicompany.app.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aicompany.app.data.ProviderRepository
import com.aicompany.app.local.ModelStore
import com.aicompany.app.prefs.UiPrefs
import com.aicompany.app.provider.ProviderConfig
import com.aicompany.app.security.KeyVault
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    providerRepo: ProviderRepository,
    private val modelStore: ModelStore,
    private val prefs: UiPrefs,
    private val vault: KeyVault,
) : ViewModel() {

    val providers: StateFlow<List<ProviderConfig>> = providerRepo.observe()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val userName: StateFlow<String> = prefs.userName
    val themeMode: StateFlow<String> = prefs.themeMode

    fun localModelCount(): Int = modelStore.list().size

    /** True when the encrypted key store opens. Checked off the main thread by the caller. */
    fun secureStorageOk(): Boolean = vault.isAvailable

    /** Deletes the encrypted key store and its master key (owner-confirmed recovery). */
    fun resetSecureStorage(): Boolean = vault.resetSecureStorage()

    fun setUserName(name: String) = prefs.setUserName(name)
    fun setThemeMode(mode: String) = prefs.setThemeMode(mode)
}
