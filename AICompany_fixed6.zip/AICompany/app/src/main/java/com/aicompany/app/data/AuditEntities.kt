package com.aicompany.app.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "audit_log", indices = [Index("createdAt")])
data class AuditEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val createdAt: Long,
    val agentId: String,
    val toolName: String,
    val summary: String,
    val approvalLevel: String,
    val decision: String,
    val outcome: String,
)

@Dao
interface AuditDao {
    @Insert
    suspend fun insert(entity: AuditEntity)

    @Query("SELECT * FROM audit_log ORDER BY id DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<AuditEntity>>

    @Query("SELECT COUNT(*) FROM audit_log WHERE toolName = :tool AND outcome = 'ok' AND createdAt >= :since")
    suspend fun countOk(tool: String, since: Long): Int

    @Query("DELETE FROM audit_log WHERE createdAt < :cutoff")
    suspend fun pruneBefore(cutoff: Long)
}
