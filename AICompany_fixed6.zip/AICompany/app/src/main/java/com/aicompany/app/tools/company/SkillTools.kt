package com.aicompany.app.tools.company

import com.aicompany.app.company.CompanyRules
import com.aicompany.app.data.CompanyRepository
import com.aicompany.app.tools.ApprovalLevel
import com.aicompany.app.tools.Schema
import com.aicompany.app.tools.Tool
import com.aicompany.app.tools.ToolContext
import com.aicompany.app.tools.ToolResult
import com.aicompany.app.tools.ToolSpec
import com.aicompany.app.tools.builtin.stringArgument
import kotlinx.serialization.json.JsonObject
import javax.inject.Inject

private const val MAX_SKILL_OUTPUT = 8_000

/** Loads one assigned skill's instructions on demand, to keep the prompt small. */
class LoadSkillTool @Inject constructor(
    private val repo: CompanyRepository,
) : Tool {
    override val spec = ToolSpec(
        name = CompanyRules.SKILL_LOAD_TOOL,
        description = "Load the full instructions of one of your assigned skills by skill_id.",
        schema = Schema.obj(
            mapOf("skill_id" to Schema.str("Skill id from your assigned skills list", 64)),
            listOf("skill_id"),
        ),
        approval = ApprovalLevel.AUTO,
        maxOutputChars = MAX_SKILL_OUTPUT,
    )

    override suspend fun execute(args: JsonObject, ctx: ToolContext): ToolResult {
        val id = stringArgument(args, "skill_id", 64)
        if (id !in ctx.skills) return ToolResult.Error("not_assigned", "This skill is not assigned to you.")
        val skill = repo.getSkill(id) ?: return ToolResult.Error("not_found", "Skill does not exist")
        return ToolResult.Ok("Skill: ${skill.name}\n${skill.instructions}")
    }
}
