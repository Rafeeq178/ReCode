package com.aicompany.app.ui.chat

import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.outlined.Cloud
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.ListAlt
import androidx.compose.material.icons.outlined.VpnKey
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.aicompany.app.data.ChatMessageUi
import com.aicompany.app.provider.ProviderConfig
import com.aicompany.app.ui.components.BurstIcon
import com.aicompany.app.ui.components.AppTopBar
import com.aicompany.app.ui.components.RowDivider
import com.aicompany.app.ui.components.SettingsGroup
import com.aicompany.app.ui.components.SettingsRow
import kotlinx.coroutines.launch
import java.time.LocalTime

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    onMenu: () -> Unit,
    onOpenProviders: () -> Unit,
    onOpenLogs: () -> Unit,
    onOpenTerminal: () -> Unit,
    onOpenCompany: () -> Unit,
    onOpenDrive: () -> Unit,
    viewModel: ChatViewModel = hiltViewModel(),
) {
    val messages by viewModel.messages.collectAsState()
    val streaming by viewModel.streaming.collectAsState()
    val busy by viewModel.busy.collectAsState()
    val error by viewModel.error.collectAsState()
    val notice by viewModel.notice.collectAsState()
    val importing by viewModel.importing.collectAsState()
    val providers by viewModel.providers.collectAsState()
    val modelLabel by viewModel.modelLabel.collectAsState()
    val selectedProviderId by viewModel.selectedProviderId.collectAsState()
    val userName by viewModel.userName.collectAsState()

    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    var input by rememberSaveable { mutableStateOf("") }
    var showSheet by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }

    // GGUF files have no MIME type, so the picker must accept "*/*". It shows the phone's
    // Downloads / internal storage / SD card and needs no storage permission.
    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val name = runCatching {
                context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
            }.getOrNull()
            viewModel.addModelFromPhone(uri, name)
        }
    }

    LaunchedEffect(error) {
        error?.let {
            scope.launch { snackbar.showSnackbar(it) }
            viewModel.clearError()
        }
    }
    LaunchedEffect(notice) {
        notice?.let {
            scope.launch { snackbar.showSnackbar(it) }
            viewModel.clearNotice()
        }
    }
    LaunchedEffect(messages.size, streaming) {
        val total = messages.size + if (streaming != null) 1 else 0
        if (total > 0) listState.animateScrollToItem(total - 1)
    }

    val chatTitle = messages.firstOrNull { it.role == "user" }?.content
        ?.lineSequence()?.firstOrNull()?.trim().orEmpty()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            AppTopBar(
                title = chatTitle.take(32),
                navIcon = Icons.Default.Menu,
                navDescription = "Menu",
                onNav = onMenu,
                actions = {
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "More")
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text("New chat") },
                                onClick = { menuOpen = false; viewModel.newChat() },
                            )
                            DropdownMenuItem(
                                text = { Text("Delete this chat") },
                                enabled = messages.isNotEmpty() && !busy,
                                onClick = { menuOpen = false; viewModel.deleteChat() },
                            )
                            DropdownMenuItem(
                                text = { Text("Live logs") },
                                onClick = { menuOpen = false; onOpenLogs() },
                            )
                        }
                    }
                },
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .navigationBarsPadding()
                .imePadding(),
        ) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                if (messages.isEmpty() && streaming == null) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(bottom = 48.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        BurstIcon(iconSize = 44.dp)
                        Spacer(Modifier.height(20.dp))
                        Text(
                            greeting(userName),
                            style = MaterialTheme.typography.headlineSmall,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 24.dp),
                        )
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(18.dp),
                    ) {
                        items(messages, key = { it.id }) { msg -> MessageItem(msg) }
                        streaming?.let { partial ->
                            item(key = "streaming") {
                                MessageItem(ChatMessageUi(-2, "assistant", partial.ifEmpty { "..." }, null))
                            }
                        }
                    }
                }
            }

            Composer(
                input = input,
                onInput = { if (it.length <= 8000) input = it },
                busy = busy,
                modelLabel = modelLabel,
                hasProviders = providers.isNotEmpty(),
                providers = providers,
                selectedProviderId = selectedProviderId ?: providers.firstOrNull()?.id,
                onSelectProvider = viewModel::selectProvider,
                onAdd = { showSheet = true },
                onModel = onOpenProviders,
                onSend = {
                    viewModel.send(input)
                    input = ""
                },
                onStop = viewModel::stop,
            )
        }
    }

    if (showSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        fun closeSheet(after: () -> Unit = {}) {
            scope.launch { sheetState.hide() }.invokeOnCompletion {
                showSheet = false
                after()
            }
        }
        ModalBottomSheet(
            onDismissRequest = { showSheet = false },
            sheetState = sheetState,
            containerColor = MaterialTheme.colorScheme.background,
        ) {
            AddToChatSheet(
                importing = importing,
                providerCount = providers.size,
                onClose = { closeSheet() },
                onPickModel = { closeSheet { modelPicker.launch(arrayOf("*/*")) } },
                onTerminal = { closeSheet { onOpenTerminal() } },
                onCompany = { closeSheet { onOpenCompany() } },
                onProviders = { closeSheet { onOpenProviders() } },
                onDrive = { closeSheet { onOpenDrive() } },
                onLogs = { closeSheet { onOpenLogs() } },
            )
        }
    }
}

private fun greeting(name: String): String {
    val hour = LocalTime.now().hour
    val part = when {
        hour in 5..11 -> "Good morning"
        hour in 12..16 -> "Good afternoon"
        else -> "Good evening"
    }
    val n = name.trim()
    return if (n.isEmpty()) part else "$part, $n"
}

@Composable
private fun Composer(
    input: String,
    onInput: (String) -> Unit,
    busy: Boolean,
    modelLabel: String?,
    hasProviders: Boolean,
    providers: List<ProviderConfig>,
    selectedProviderId: String?,
    onSelectProvider: (String) -> Unit,
    onAdd: () -> Unit,
    onModel: () -> Unit,
    onSend: () -> Unit,
    onStop: () -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    val expanded = focused || input.isNotEmpty()
    val canSend = input.isNotBlank()
    val outline = MaterialTheme.colorScheme.outlineVariant

    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 3.dp,
        border = BorderStroke(1.dp, outline),
    ) {
        Column(modifier = Modifier.animateContentSize().padding(horizontal = 8.dp, vertical = 6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!expanded) {
                    RoundIconButton(Icons.Default.Add, "Add to chat", onAdd)
                    Spacer(Modifier.size(8.dp))
                }
                BasicTextField(
                    value = input,
                    onValueChange = onInput,
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = if (expanded) 10.dp else 0.dp, vertical = 10.dp)
                        .onFocusChanged { focused = it.isFocused },
                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onSurface),
                    cursorBrush = SolidColor(MaterialTheme.colorScheme.onSurface),
                    maxLines = 6,
                    decorationBox = { inner ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (input.isEmpty()) {
                                Text(
                                    "Goal ya message likhein",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            inner()
                        }
                    },
                )
                if (!expanded) {
                    Spacer(Modifier.size(8.dp))
                    SendButton(busy = busy, canSend = canSend, onSend = onSend, onStop = onStop)
                }
            }
            if (expanded) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    RoundIconButton(Icons.Default.Add, "Add to chat", onAdd)
                    Spacer(Modifier.size(8.dp))
                    var modelMenuOpen by remember { mutableStateOf(false) }
                    Box {
                        ModelChip(
                            label = if (hasProviders) (modelLabel ?: "Model") else "Add a model",
                            onClick = { if (hasProviders) modelMenuOpen = true else onModel() },
                        )
                        DropdownMenu(expanded = modelMenuOpen, onDismissRequest = { modelMenuOpen = false }) {
                            providers.forEach { p ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            (if (p.id == selectedProviderId) "\u2713  " else "") + providerLabel(p),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                    },
                                    onClick = {
                                        modelMenuOpen = false
                                        onSelectProvider(p.id)
                                    },
                                )
                            }
                            DropdownMenuItem(
                                text = { Text("Manage providers...") },
                                onClick = {
                                    modelMenuOpen = false
                                    onModel()
                                },
                            )
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    SendButton(busy = busy, canSend = canSend, onSend = onSend, onStop = onStop)
                }
            }
        }
    }
}

@Composable
private fun RoundIconButton(icon: ImageVector, description: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = description, modifier = Modifier.size(22.dp), tint = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun SendButton(busy: Boolean, canSend: Boolean, onSend: () -> Unit, onStop: () -> Unit) {
    val active = busy || canSend
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
            .clickable(enabled = active, onClick = { if (busy) onStop() else onSend() }),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            if (busy) Icons.Default.Stop else Icons.Default.ArrowUpward,
            contentDescription = if (busy) "Stop" else "Send",
            modifier = Modifier.size(22.dp),
            tint = if (active) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun ModelChip(label: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .height(36.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.widthIn(max = 170.dp),
        )
        Icon(Icons.Default.KeyboardArrowDown, contentDescription = null, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun MessageItem(msg: ChatMessageUi) {
    if (msg.role == "user") {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(20.dp, 20.dp, 6.dp, 20.dp),
                modifier = Modifier.widthIn(max = 300.dp),
            ) {
                Text(
                    text = msg.content,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                )
            }
        }
    } else {
        SelectionContainer {
            Text(
                text = msg.content,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                style = MaterialTheme.typography.bodyLarge.copy(fontFamily = FontFamily.Serif, lineHeight = 26.sp),
                color = MaterialTheme.colorScheme.onBackground,
            )
        }
    }
}

@Composable
private fun AddToChatSheet(
    importing: Boolean,
    providerCount: Int,
    onClose: () -> Unit,
    onPickModel: () -> Unit,
    onTerminal: () -> Unit,
    onCompany: () -> Unit,
    onProviders: () -> Unit,
    onDrive: () -> Unit,
    onLogs: () -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp).padding(bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(modifier = Modifier.fillMaxWidth().height(48.dp), contentAlignment = Alignment.Center) {
            IconButton(onClick = onClose, modifier = Modifier.align(Alignment.CenterStart)) {
                Icon(Icons.Default.Close, contentDescription = "Close")
            }
            Text("Add to chat", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ActionCard(
                icon = Icons.Outlined.FolderOpen,
                label = if (importing) "Copying..." else "Model",
                onClick = onPickModel,
                enabled = !importing,
                modifier = Modifier.weight(1f),
            )
            ActionCard(Icons.Outlined.Code, "Terminal", onTerminal, modifier = Modifier.weight(1f))
            ActionCard(Icons.Outlined.Groups, "Company", onCompany, modifier = Modifier.weight(1f))
        }

        SettingsGroup {
            SettingsRow(
                title = "Providers & keys",
                subtitle = if (providerCount == 0) "None yet" else "$providerCount configured",
                icon = Icons.Outlined.VpnKey,
                chevron = true,
                onClick = onProviders,
            )
            RowDivider(54.dp)
            SettingsRow(title = "Google Drive", icon = Icons.Outlined.Cloud, chevron = true, onClick = onDrive)
            RowDivider(54.dp)
            SettingsRow(title = "Live logs", icon = Icons.Outlined.ListAlt, chevron = true, onClick = onLogs)
        }

        if (importing) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                Spacer(Modifier.size(10.dp))
                Text("Model copy ho raha hai...", style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun ActionCard(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    Surface(
        modifier = modifier.clip(RoundedCornerShape(20.dp)).clickable(enabled = enabled, onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Box(
                modifier = Modifier.size(44.dp).background(MaterialTheme.colorScheme.surfaceVariant, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, contentDescription = null, modifier = Modifier.size(22.dp))
            }
            Text(label, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
