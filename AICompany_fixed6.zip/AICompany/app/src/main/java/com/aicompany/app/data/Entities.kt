package com.aicompany.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "providers")
data class ProviderEntity(
    @PrimaryKey val id: String,
    val name: String,
    val format: String,            // OPENAI | ANTHROPIC | GEMINI
    val baseUrl: String,
    val model: String,
    val timeoutSeconds: Long,
    val maxTokens: Int,
    val temperature: Double,
    val extraHeaders: String,      // one "Header: value" per line; never holds secrets
    val createdAt: Long,
)

@Entity(
    tableName = "messages",
    indices = [Index("conversationId")],
)
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val conversationId: String,
    val role: String,              // system | user | assistant
    val content: String,
    val providerName: String?,
    val createdAt: Long,
)
