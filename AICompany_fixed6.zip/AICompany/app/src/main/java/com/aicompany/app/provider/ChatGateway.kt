package com.aicompany.app.provider

import com.aicompany.app.local.LocalScheduler
import com.aicompany.app.security.KeyVault
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject
import javax.inject.Singleton

/** A provider with its key source resolved, ready to call. */
data class RoutedProvider(val config: ProviderConfig)

/**
 * Sends a chat through an ordered fallback chain of providers.
 * - Rotates keys on rate limit / quota. With one key (or all keys cooling) it waits for the
 *   Retry-After / cooldown instead of hammering the same key.
 * - Retries transient errors with exponential backoff.
 * - Turns every failure inside a provider (bad URL, bad model name, local timeout, unexpected bug)
 *   into a typed error, so one broken provider never ends the whole chain.
 * - Moves to the next provider on failure, but only before any token was shown,
 *   so the owner never sees a half answer glued to a different model's answer.
 */
@Singleton
class ChatGateway @Inject constructor(
    private val clients: Map<ApiFormat, @JvmSuppressWildcards ProviderClient>,
    private val vault: KeyVault,
    private val rotator: KeyRotator,
) {
    fun stream(
        chain: List<ProviderConfig>,
        messages: List<ChatMessage>,
        params: ChatParams,
    ): Flow<String> = flow {
        require(chain.isNotEmpty()) { "No provider configured" }
        var lastError: Throwable? = null

        for (config in chain) {
            val keys = keysFor(config)
            if (keys.isEmpty()) {
                lastError = ProviderException.Auth("No API key for ${config.name}")
                continue
            }
            val client = clients[config.format]
            if (client == null) {
                lastError = ProviderException.BadRequest("No client for ${config.format}")
                continue
            }

            var attempt = 0
            var emittedAny = false
            providerLoop@ while (attempt < MAX_ATTEMPTS_PER_PROVIDER) {
                attempt++
                val key = rotator.nextKey(config.id, keys) ?: break@providerLoop
                try {
                    client.chat(config, key, messages, params).collect { token ->
                        emittedAny = true
                        emit(token)
                    }
                    return@flow
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    // After output started, anything that is not a provider error (for example an exception
                    // thrown by the collector) passes through unchanged.
                    if (emittedAny && e !is ProviderException) throw e
                    val failure = toProviderException(e)
                    lastError = failure
                    if (emittedAny) throw failure
                    when (failure) {
                        is ProviderException.RateLimited -> {
                            val cooldown = failure.retryAfterMs?.coerceIn(1_000L, MAX_COOLDOWN_MS)
                                ?: (RATE_LIMIT_BASE_MS shl (attempt - 1).coerceAtMost(4)).coerceAtMost(MAX_COOLDOWN_MS)
                            rotator.markCooling(config.id, key, cooldown)
                            if (!waitForAnyKey(config, keys)) break@providerLoop
                            continue@providerLoop
                        }
                        is ProviderException.Quota -> {
                            rotator.markCooling(config.id, key, QUOTA_COOLDOWN_MS)
                            // Quota does not clear in seconds: only continue here if another key is usable now.
                            if (rotator.millisUntilAvailable(config.id, keys) > 0) break@providerLoop
                            continue@providerLoop
                        }
                        is ProviderException.Server, is ProviderException.Network -> {
                            delay(backoffMillis(attempt))
                            continue@providerLoop
                        }
                        else -> break@providerLoop
                    }
                }
            }
        }
        throw lastError ?: ProviderException.Server("All providers failed", 503)
    }

    private fun keysFor(config: ProviderConfig): List<String> = when {
        config.format == ApiFormat.LOCAL -> listOf(LOCAL_KEY)
        else -> vault.keysFor(config.id).ifEmpty {
            // A llama-server / Ollama on this phone or LAN usually needs no key.
            if (isLocalNetworkUrl(config.baseUrl)) listOf(NO_API_KEY) else emptyList()
        }
    }

    /** Waits for a cooling key when the wait is short. Returns false when it would take too long. */
    private suspend fun waitForAnyKey(config: ProviderConfig, keys: List<String>): Boolean {
        val wait = rotator.millisUntilAvailable(config.id, keys)
        if (wait > MAX_INLINE_WAIT_MS) return false
        if (wait > 0) delay(wait)
        return true
    }

    private fun toProviderException(e: Throwable): ProviderException = when (e) {
        is ProviderException -> e
        is LocalScheduler.LocalTimeoutException -> ProviderException.Timeout(e.message ?: "Local model timed out")
        // requireHttps, model-name checks and template checks all throw IllegalArgumentException.
        is IllegalArgumentException -> ProviderException.BadRequest(e.message ?: "Invalid request")
        else -> ProviderException.Unexpected(
            "Provider failed: ${e.javaClass.simpleName}" + (e.message?.let { ": ${it.take(200)}" } ?: ""),
            e,
        )
    }

    private fun backoffMillis(attempt: Int): Long = (500L shl (attempt - 1).coerceAtMost(4))

    companion object {
        private const val MAX_ATTEMPTS_PER_PROVIDER = 3
        private const val LOCAL_KEY = "local-no-key"
        private const val RATE_LIMIT_BASE_MS = 2_000L
        private const val MAX_COOLDOWN_MS = 60_000L
        private const val QUOTA_COOLDOWN_MS = 10 * 60_000L
        private const val MAX_INLINE_WAIT_MS = 20_000L
    }
}
