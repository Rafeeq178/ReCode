package com.aicompany.app.ui.logs

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aicompany.app.agents.AgentDefaults
import com.aicompany.app.agents.AgentRunner
import com.aicompany.app.data.AgentLogEntity
import com.aicompany.app.data.AgentRunEntity
import com.aicompany.app.data.AgentRunRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

private val LOG_KINDS = setOf("all", "model", "tool", "error")

@HiltViewModel
class AgentsViewModel @Inject constructor(
    private val runner: AgentRunner,
    private val repo: AgentRunRepository,
    private val company: com.aicompany.app.company.CompanyService,
) : ViewModel() {

    val runs: StateFlow<List<AgentRunEntity>> = repo.observeRuns(100)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _selected = MutableStateFlow<Long?>(null)
    val selected: StateFlow<Long?> = _selected.asStateFlow()

    private val _filter = MutableStateFlow("all")
    val filter: StateFlow<String> = _filter.asStateFlow()

    private val _notice = MutableStateFlow<String?>(null)
    val notice: StateFlow<String?> = _notice.asStateFlow()

    val logs: StateFlow<List<AgentLogEntity>> = combine(_selected, _filter) { id, f -> id to f }
        .flatMapLatest { (id, f) ->
            if (id == null) {
                flowOf(emptyList())
            } else {
                repo.observeLogs(id).map { list -> list.filter { f == "all" || it.kind == f } }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun select(runId: Long?) {
        _selected.value = runId
    }

    fun setFilter(kind: String) {
        require(kind in LOG_KINDS) { "Unknown filter" }
        _filter.value = kind
    }

    fun start(goal: String) {
        viewModelScope.launch {
            runCatching { runner.start(AgentDefaults.assistant(), goal) }
                .onSuccess { id ->
                    _selected.value = id
                    _notice.value = null
                }
                .onFailure { _notice.value = it.message ?: "Could not start the agent" }
        }
    }

    fun pause(runId: Long) = viewModelScope.launch { runner.pause(runId) }
    fun resume(runId: Long) = viewModelScope.launch { runner.resume(runId) }
    fun stop(runId: Long) = runner.stop(runId)

    fun killSwitch() {
        runner.stopAll()
        company.stopAll()
        _notice.value = "All agents stopped"
    }

    fun clearNotice() {
        _notice.value = null
    }
}
