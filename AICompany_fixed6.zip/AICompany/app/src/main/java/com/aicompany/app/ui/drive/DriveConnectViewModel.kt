package com.aicompany.app.ui.drive

import android.content.Intent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aicompany.app.drive.DriveAuth
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DriveConnectViewModel @Inject constructor(
    private val auth: DriveAuth,
) : ViewModel() {

    private val _status = MutableStateFlow(
        when {
            !auth.isConfigured() -> "This build has no Google client ID. See the README."
            auth.isConnected() -> "Connected (read-only)"
            else -> "Not connected"
        }
    )
    val status: StateFlow<String> = _status.asStateFlow()

    fun signInIntent(): Intent? = runCatching { auth.buildSignInIntent() }
        .onFailure { _status.value = it.message ?: "Could not start sign-in" }
        .getOrNull()

    fun onSignInResult(data: Intent?) {
        if (data == null) {
            _status.value = "Sign-in was cancelled"
            return
        }
        viewModelScope.launch {
            auth.completeSignIn(data)
                .onSuccess { _status.value = "Connected (read-only)" }
                .onFailure { _status.value = it.message ?: "Sign-in failed" }
        }
    }

    fun disconnect() {
        auth.disconnect()
        _status.value = "Disconnected"
    }
}
