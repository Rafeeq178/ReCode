package com.aicompany.app.scheduler

import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Limits API work: at most MAX_PARALLEL worker tasks overall, and PER_PROVIDER per provider,
 * so one provider's rate limit is not hammered by every worker at once.
 */
@Singleton
class ApiScheduler @Inject constructor() {
    private val global = Semaphore(MAX_PARALLEL)
    private val perProvider = ConcurrentHashMap<String, Semaphore>()

    suspend fun <T> run(providerKey: String, block: suspend () -> T): T {
        require(providerKey.isNotBlank()) { "Provider key is empty" }
        val providerSemaphore = perProvider.getOrPut(providerKey) { Semaphore(PER_PROVIDER) }
        return global.withPermit {
            providerSemaphore.withPermit { block() }
        }
    }

    companion object {
        const val MAX_PARALLEL = 5
        const val PER_PROVIDER = 2
    }
}
