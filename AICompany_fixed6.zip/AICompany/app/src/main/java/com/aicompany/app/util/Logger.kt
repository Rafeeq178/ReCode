package com.aicompany.app.util

import android.util.Log

/** Every message passes through Redactor before it reaches logcat. */
object Logger {
    private const val PREFIX = "AICompany"

    fun i(tag: String, message: String) {
        Log.i("$PREFIX/$tag", Redactor.redact(message))
    }

    fun w(tag: String, message: String, t: Throwable? = null) {
        Log.w("$PREFIX/$tag", Redactor.redact(message), t)
    }

    fun e(tag: String, message: String, t: Throwable? = null) {
        Log.e("$PREFIX/$tag", Redactor.redact(message), t)
    }
}
