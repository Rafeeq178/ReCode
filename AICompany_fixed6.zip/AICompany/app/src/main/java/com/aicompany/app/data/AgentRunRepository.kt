package com.aicompany.app.data

import com.aicompany.app.agents.RunStatus
import com.aicompany.app.util.Redactor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AgentRunRepository @Inject constructor(private val dao: AgentDao) {

    suspend fun createRun(agentName: String, goal: String): Long = withContext(Dispatchers.IO) {
        dao.insertRun(
            AgentRunEntity(
                agentName = agentName.take(60),
                goal = Redactor.redact(goal).take(MAX_GOAL_CHARS),
                status = RunStatus.RUNNING.name,
                reason = "",
                startedAt = System.currentTimeMillis(),
                endedAt = 0L,
                steps = 0,
            )
        )
    }

    suspend fun setStatus(runId: Long, status: RunStatus) = withContext(Dispatchers.IO) {
        dao.updateStatus(runId, status.name)
    }

    suspend fun finish(runId: Long, status: RunStatus, reason: String, steps: Int) = withContext(Dispatchers.IO) {
        dao.finish(
            runId,
            status.name,
            Redactor.redact(reason).take(300),
            System.currentTimeMillis(),
            steps,
        )
    }

    suspend fun log(runId: Long, step: Int, kind: String, text: String) = withContext(Dispatchers.IO) {
        dao.insertLog(
            AgentLogEntity(
                runId = runId,
                step = step,
                kind = kind.take(16),
                text = Redactor.redact(text).take(MAX_LOG_CHARS),
                createdAt = System.currentTimeMillis(),
            )
        )
    }

    fun observeRuns(limit: Int = 100): Flow<List<AgentRunEntity>> {
        require(limit in 1..500) { "Limit out of range" }
        return dao.observeRuns(limit)
    }

    fun observeLogs(runId: Long): Flow<List<AgentLogEntity>> = dao.observeLogs(runId)

    companion object {
        const val MAX_GOAL_CHARS = 4_000
        const val MAX_LOG_CHARS = 2_000
    }
}
