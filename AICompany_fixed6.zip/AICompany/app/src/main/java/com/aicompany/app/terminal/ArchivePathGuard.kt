package com.aicompany.app.terminal

/** Rejects archive entry names that could escape the extraction folder. */
object ArchivePathGuard {
    const val MAX_NAME = 512
    const val MAX_LINK = 512

    /** Returns null when the name is safe, otherwise a short reason. */
    fun check(name: String): String? = when {
        name.isBlank() -> "empty name"
        name.length > MAX_NAME -> "name too long"
        name.contains('\u0000') -> "NUL byte in name"
        name.startsWith("/") || name.startsWith("\\") -> "absolute path"
        name.split('/', '\\').any { it == ".." } -> "parent folder reference"
        else -> null
    }
}
