package com.aicompany.app.ui.nav

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aicompany.app.data.ConversationManager
import com.aicompany.app.data.ConversationRow
import com.aicompany.app.prefs.UiPrefs
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/** Feeds the side drawer: recent chats, which one is open, and the display name. */
@HiltViewModel
class AppViewModel @Inject constructor(
    private val conversations: ConversationManager,
    prefs: UiPrefs,
) : ViewModel() {

    val recents: StateFlow<List<ConversationRow>> = conversations.recents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val currentId: StateFlow<String> = conversations.currentId
    val userName: StateFlow<String> = prefs.userName

    fun newChat() = conversations.newChat()
    fun open(id: String) = conversations.open(id)
    fun delete(id: String) {
        viewModelScope.launch { conversations.delete(id) }
    }
}
