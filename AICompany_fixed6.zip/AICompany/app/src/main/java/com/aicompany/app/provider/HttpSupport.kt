package com.aicompany.app.provider

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okio.BufferedSource
import java.io.IOException
import java.net.URI
import java.net.URISyntaxException
import java.util.concurrent.TimeUnit

internal val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()

internal fun OkHttpClient.forProvider(config: ProviderConfig): OkHttpClient =
    newBuilder()
        .connectTimeout(config.timeoutSeconds, TimeUnit.SECONDS)
        .readTimeout(config.timeoutSeconds, TimeUnit.SECONDS)
        .callTimeout(config.timeoutSeconds * 4, TimeUnit.SECONDS)
        // An API key must never follow a redirect from https to plain http.
        .followSslRedirects(false)
        .build()

internal fun joinUrl(baseUrl: String, path: String): String =
    baseUrl.trimEnd('/') + path

internal fun Request.Builder.applyExtraHeaders(config: ProviderConfig): Request.Builder {
    config.extraHeaders.forEach { (k, v) -> header(k, v) }
    return this
}

/** Executes a request, mapping transport failures to ProviderException. */
internal fun OkHttpClient.executeOrThrow(request: Request): Response =
    try {
        newCall(request).execute()
    } catch (e: IOException) {
        throw ProviderException.Network("Network error: ${e.javaClass.simpleName}", e)
    }

/**
 * Reads one line of a streamed response. A dropped connection or read timeout in the middle of a
 * stream is a normal event on mobile networks, so it becomes a typed Network error (retryable)
 * instead of a raw IOException that would end the whole run.
 */
internal fun BufferedSource.readLineOrThrow(): String? =
    try {
        readUtf8Line()
    } catch (e: IOException) {
        throw ProviderException.Network("Connection lost while streaming: ${e.javaClass.simpleName}", e)
    }

/** Parses one streamed JSON event. Malformed data becomes a typed error instead of an unrelated exception. */
internal fun Json.parseEvent(text: String): JsonObject =
    try {
        parseToJsonElement(text).jsonObject
    } catch (e: IllegalArgumentException) {   // includes SerializationException
        throw ProviderException.Server("Malformed data from provider", 502)
    }

/** Body of an error response, or "" when it cannot be read. */
internal fun Response.readErrorBody(): String =
    try {
        body?.string().orEmpty()
    } catch (e: IOException) {
        ""
    }

/** Retry-After header in milliseconds (seconds form only), capped at 10 minutes. */
internal fun Response.retryAfterMillis(): Long? =
    header("Retry-After")?.trim()?.toLongOrNull()?.let { (it * 1000).coerceIn(0L, 10 * 60_000L) }

/** Builds the typed exception for a non-2xx response, including a Retry-After hint when present. */
internal fun Response.toProviderException(): ProviderException =
    mapHttpError(code, readErrorBody(), retryAfterMillis())

/** Maps HTTP error codes to typed exceptions. The body is truncated and never includes the key. */
internal fun mapHttpError(code: Int, body: String, retryAfterMs: Long? = null): ProviderException {
    val snippet = body.take(300)
    return when (code) {
        401, 403 -> ProviderException.Auth("Authentication failed ($code)")
        429 -> if (snippet.contains("quota", ignoreCase = true) || snippet.contains("billing", ignoreCase = true))
            ProviderException.Quota("Quota exceeded")
        else ProviderException.RateLimited("Rate limited", retryAfterMs)
        400, 404, 422 -> ProviderException.BadRequest("Request rejected ($code): $snippet")
        408, 425 -> ProviderException.Server("Provider timed out ($code)", code)
        in 500..599 -> ProviderException.Server("Provider server error ($code)", code)
        else -> ProviderException.Server("Unexpected HTTP $code", code)
    }
}

// ---------- Base URL rules ----------

private val IPV4 = Regex("^(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})$")

/** Host of a URL, lower-case and without IPv6 brackets, or null when the URL does not parse. */
internal fun hostOf(url: String): String? = try {
    URI(url.trim()).host?.removeSurrounding("[", "]")?.lowercase()
} catch (e: URISyntaxException) {
    null
}

/** True for localhost, loopback and private-LAN addresses (the phone itself, Termux, a PC on the same Wi-Fi). */
internal fun isLocalHost(host: String?): Boolean {
    if (host.isNullOrEmpty()) return false
    if (host == "localhost" || host.endsWith(".localhost") || host == "::1") return true
    val match = IPV4.matchEntire(host) ?: return false
    val o = match.groupValues.drop(1).map { it.toInt() }
    if (o.any { it > 255 }) return false
    return o[0] == 127 || o[0] == 10 || (o[0] == 192 && o[1] == 168) || (o[0] == 172 && o[1] in 16..31)
}

/** Plain http:// to this device or the local network, for example a llama-server or Ollama. */
internal fun isLocalNetworkUrl(baseUrl: String): Boolean {
    val url = baseUrl.trim()
    return url.startsWith("http://", ignoreCase = true) && isLocalHost(hostOf(url))
}

/** https:// anywhere, or http:// only to this device / the local network. */
internal fun isAllowedBaseUrl(baseUrl: String): Boolean {
    val url = baseUrl.trim()
    return url.startsWith("https://", ignoreCase = true) || isLocalNetworkUrl(url)
}

internal const val BASE_URL_RULE =
    "Base URL must start with https://, or http:// for localhost / a local network address (for example http://127.0.0.1:8080/v1)"

internal fun requireSafeBaseUrl(baseUrl: String) {
    require(isAllowedBaseUrl(baseUrl)) { BASE_URL_RULE }
}
