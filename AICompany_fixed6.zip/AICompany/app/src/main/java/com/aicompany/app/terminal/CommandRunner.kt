package com.aicompany.app.terminal

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import javax.inject.Inject
import javax.inject.Singleton

data class CommandResult(
    val exitCode: Int,
    val output: String,
    val outputTruncated: Boolean,
    val timedOut: Boolean,
)

/**
 * Runs a host process (proot) without a PTY, with a hard timeout and an output cap.
 * Output past the cap is drained and discarded so the child never blocks on a full pipe.
 */
@Singleton
class CommandRunner @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    suspend fun run(argv: List<String>, environment: Map<String, String>, timeoutMs: Long, maxChars: Int): CommandResult {
        require(argv.isNotEmpty()) { "Empty command" }
        require(timeoutMs in 1_000..300_000) { "Timeout out of range" }
        require(maxChars in 256..100_000) { "Output cap out of range" }

        return withContext(Dispatchers.IO) {
            val builder = ProcessBuilder(argv)
                .redirectErrorStream(true)
                .directory(context.filesDir)
            builder.environment().putAll(environment)
            val process = builder.start()
            val timedOut = AtomicBoolean(false)
            try {
                coroutineScope {
                    val watchdog = launch {
                        delay(timeoutMs)
                        timedOut.set(true)
                        process.destroyForcibly()
                    }
                    val sb = StringBuilder()
                    var truncated = false
                    val buf = CharArray(4096)
                    process.inputStream.reader(Charsets.UTF_8).use { reader ->
                        while (true) {
                            val n = reader.read(buf)
                            if (n < 0) break
                            val room = maxChars - sb.length
                            if (room > 0) {
                                val take = minOf(n, room)
                                sb.append(buf, 0, take)
                                if (take < n) truncated = true
                            } else {
                                truncated = true
                            }
                        }
                    }
                    val exit = process.waitFor()
                    watchdog.cancel()
                    CommandResult(exit, sb.toString(), truncated, timedOut.get())
                }
            } finally {
                if (process.isAlive) process.destroyForcibly()
            }
        }
    }
}
