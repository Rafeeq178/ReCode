package com.aicompany.app.local

/** Decides whether a GGUF model should load on this phone. The test device has 4 GB RAM. */
object RamGuard {
    /** Runtime overhead on top of the weights: KV cache at 2048 context, buffers, and the app itself. */
    const val OVERHEAD_BYTES = 350L * 1024 * 1024

    enum class Verdict { OK, TIGHT, TOO_LARGE }

    fun assess(modelBytes: Long, availableBytes: Long): Verdict {
        require(modelBytes >= 0) { "Model size is negative" }
        require(availableBytes >= 0) { "Available memory is negative" }
        val need = modelBytes + OVERHEAD_BYTES
        return when {
            need > availableBytes -> Verdict.TOO_LARGE
            need > (availableBytes * 0.8).toLong() -> Verdict.TIGHT
            else -> Verdict.OK
        }
    }
}
