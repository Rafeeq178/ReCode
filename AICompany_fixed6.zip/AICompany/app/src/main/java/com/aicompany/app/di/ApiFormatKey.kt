package com.aicompany.app.di

import com.aicompany.app.provider.ApiFormat
import dagger.MapKey

@MapKey
annotation class ApiFormatKey(val value: ApiFormat)
