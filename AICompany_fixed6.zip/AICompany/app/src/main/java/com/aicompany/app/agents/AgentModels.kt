package com.aicompany.app.agents

import com.aicompany.app.tools.ToolCall

enum class RunStatus { RUNNING, PAUSED, COMPLETED, FAILED, LOOP_DETECTED, STEP_LIMIT, TIMED_OUT, STOPPED }

/** Owner-editable limits. Values outside these ranges are rejected before a run starts. */
data class AgentConfig(
    val id: String,
    val name: String,
    val role: String,
    val allowedTools: Set<String>,
    val maxSteps: Int = 20,
    val timeoutMs: Long = 600_000,
    val maxTokens: Int = 1024,
    val temperature: Double = 0.2,
    val isCeo: Boolean = false,
    /** Owner instructions from the employee editor. Treated as data inside the task, never as system rules. */
    val extraInstructions: String = "",
    /** Skill ids the agent may load with load_skill. Only ids go into the prompt. */
    val skillIds: Set<String> = emptySet(),
) {
    init {
        require(id.isNotBlank() && id.length <= 64) { "Agent id is invalid" }
        require(name.isNotBlank() && name.length <= 60) { "Name must be 1-60 characters" }
        require(role.isNotBlank() && role.length <= 120) { "Role must be 1-120 characters" }
        require(maxSteps in 1..200) { "Max steps must be 1-200" }
        require(timeoutMs in 10_000..3_600_000) { "Timeout must be 10 s to 1 h" }
        require(maxTokens in 64..32_000) { "Max tokens must be 64-32000" }
        require(temperature in 0.0..2.0) { "Temperature must be 0-2" }
        require(allowedTools.size <= 64) { "Too many tools assigned" }
        require(extraInstructions.length <= 4_000) { "Instructions are too long" }
        require(skillIds.size <= 32) { "Too many skills assigned" }
    }
}

object AgentDefaults {
    fun assistant(): AgentConfig = AgentConfig(
        id = "assistant",
        name = "Assistant",
        role = "general assistant",
        allowedTools = setOf("get_time", "calculator", "read_file", "list_dir", "write_file", "web_fetch"),
        maxSteps = 10,
        timeoutMs = 300_000,
    )
}

sealed class AgentAction {
    data class Call(val call: ToolCall) : AgentAction()
    data class Done(val text: String) : AgentAction()
    data class Invalid(val reason: String) : AgentAction()
}

data class RunOutcome(val status: RunStatus, val reason: String, val steps: Int)
