package com.aicompany.app.drive

import com.aicompany.app.util.Redactor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.HttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

data class DriveFile(val id: String, val name: String, val mimeType: String, val modified: String)

/** Read-only Drive REST v3 calls. Tokens are attached here and never returned to callers. */
@Singleton
class DriveApi @Inject constructor(
    private val auth: DriveAuth,
    private val http: OkHttpClient,
    private val json: Json,
) {
    suspend fun search(term: String): List<DriveFile> {
        val clean = term.trim()
        require(clean.isNotEmpty() && clean.length <= MAX_TERM) { "Search term must be 1-$MAX_TERM characters" }
        val url = HttpUrl.Builder()
            .scheme("https")
            .host("www.googleapis.com")
            .addPathSegments("drive/v3/files")
            .addQueryParameter("q", "name contains '${escapeQuery(clean)}' and trashed = false")
            .addQueryParameter("pageSize", "10")
            .addQueryParameter("fields", "files(id,name,mimeType,modifiedTime)")
            .build()
        val root = json.parseToJsonElement(get(url)).jsonObject
        val files = root["files"] as? JsonArray ?: return emptyList()
        return files.map { el ->
            val o = el.jsonObject
            DriveFile(
                id = o.str("id"),
                name = o.str("name"),
                mimeType = o.str("mimeType"),
                modified = o.str("modifiedTime"),
            )
        }
    }

    suspend fun readText(fileId: String): String {
        require(FILE_ID.matches(fileId)) { "File id is not valid" }
        val meta = json.parseToJsonElement(
            get(fileUrl(fileId).addQueryParameter("fields", "mimeType,size").build())
        ).jsonObject
        val mime = meta.str("mimeType")
        val url = when {
            mime == GOOGLE_DOC -> fileUrl(fileId, "export").addQueryParameter("mimeType", "text/plain").build()
            mime.startsWith("text/") -> fileUrl(fileId).addQueryParameter("alt", "media").build()
            else -> throw IllegalArgumentException("Only text files and Google Docs can be read")
        }
        return get(url).take(MAX_READ_CHARS)
    }

    private fun fileUrl(fileId: String, suffix: String? = null): HttpUrl.Builder {
        val segments = mutableListOf("drive", "v3", "files", fileId)
        if (suffix != null) segments += suffix
        return HttpUrl.Builder().scheme("https").host("www.googleapis.com").addPathSegments(segments.joinToString("/"))
    }

    private suspend fun get(url: HttpUrl): String = withContext(Dispatchers.IO) {
        val token = auth.accessToken()
        val req = Request.Builder().url(url).header("Authorization", "Bearer $token").get().build()
        http.newBuilder().callTimeout(30, TimeUnit.SECONDS).build().newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IllegalStateException("Drive returned HTTP ${resp.code}")
            val source = resp.body?.source() ?: return@withContext ""
            source.request(MAX_BODY_BYTES)
            Redactor.redact(source.buffer.readUtf8(minOf(source.buffer.size, MAX_BODY_BYTES)))
        }
    }

    private fun JsonObject.str(key: String): String =
        (this[key] as? JsonPrimitive)?.contentOrNull.orEmpty()

    companion object {
        const val MAX_TERM = 100
        const val MAX_READ_CHARS = 8_000
        private const val MAX_BODY_BYTES = 256 * 1024L
        private const val GOOGLE_DOC = "application/vnd.google-apps.document"
        val FILE_ID = Regex("^[A-Za-z0-9_-]{10,100}$")

        /** Escapes a value for the Drive query language (backslash and single quote). */
        fun escapeQuery(term: String): String = term.replace("\\", "\\\\").replace("'", "\\'")
    }
}
