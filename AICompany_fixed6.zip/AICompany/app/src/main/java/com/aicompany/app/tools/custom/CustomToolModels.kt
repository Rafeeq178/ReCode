package com.aicompany.app.tools.custom

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonPrimitive

/**
 * A custom tool, no code needed. Type decides which fields are used:
 * SHELL -> command, HTTP -> method/url/headers/body, SCRIPT -> language/code,
 * PROMPT -> prompt, MCP -> serverUrl/remoteName.
 */
@Serializable
data class CustomToolDef(
    val name: String,
    val description: String,
    val type: String,
    val parameters: JsonObject,
    val approval: String = "ASK",
    val timeoutSeconds: Int = 60,
    val command: String? = null,
    val method: String? = null,
    val url: String? = null,
    val headers: Map<String, String> = emptyMap(),
    val body: String? = null,
    val language: String? = null,
    val code: String? = null,
    val prompt: String? = null,
    val serverUrl: String? = null,
    val remoteName: String? = null,
)

object CustomToolValidator {
    val NAME = Regex("^[a-z][a-z0-9_]{1,40}$")
    /** {param} is a placeholder. {{...}} is not (used for secrets). */
    val PLACEHOLDER = Regex("(?<!\\{)\\{([a-zA-Z_][a-zA-Z0-9_]*)\\}(?!\\})")
    val SECRET = Regex("\\{\\{secret:([A-Z][A-Z0-9_]{0,39})\\}\\}")
    val TYPES = setOf("SHELL", "HTTP", "SCRIPT", "PROMPT", "MCP")
    private val APPROVALS = setOf("AUTO", "ASK", "BLOCKED")
    private val METHODS = setOf("GET", "POST", "PUT", "DELETE")
    private val LANGUAGES = setOf("python", "node", "sh")

    fun validate(def: CustomToolDef, builtinNames: Set<String>): List<String> {
        val errors = mutableListOf<String>()
        if (!NAME.matches(def.name)) errors += "Tool name must be lowercase letters, digits or underscores (2-41 chars)"
        if (def.name in builtinNames) errors += "The name clashes with a built-in tool"
        if (def.description.isBlank() || def.description.length > 500) errors += "Description must be 1-500 characters"
        if (def.approval !in APPROVALS) errors += "Approval must be AUTO, ASK or BLOCKED"
        if (def.timeoutSeconds !in 1..300) errors += "Timeout must be 1-300 seconds"

        val props = def.parameters["properties"] as? JsonObject
        val isObject = (def.parameters["type"] as? JsonPrimitive)?.contentOrNull == "object"
        if (!isObject || props == null) errors += "Parameters must be an object schema with properties"
        val paramNames = props?.keys.orEmpty()
        fun checkPlaceholders(text: String, where: String) {
            PLACEHOLDER.findAll(text).forEach { m ->
                if (m.groupValues[1] !in paramNames) errors += "$where uses {${m.groupValues[1]}} which is not a parameter"
            }
        }

        if (def.type !in TYPES) errors += "Unknown tool type"
        when (def.type) {
            "SHELL" -> {
                val c = def.command
                if (c.isNullOrBlank() || c.length > 1_000) errors += "Command must be 1-1000 characters"
                else {
                    checkPlaceholders(c, "command")
                    if (SECRET.containsMatchIn(c)) errors += "Secrets cannot be used in shell commands"
                }
            }
            "HTTP" -> {
                val u = def.url
                if (u.isNullOrBlank() || !u.startsWith("https://") || u.length > 2_000) errors += "URL must start with https://"
                else checkPlaceholders(u, "url")
                if (def.method !in METHODS) errors += "Method must be GET, POST, PUT or DELETE"
                if (def.headers.size > 20) errors += "Too many headers (max 20)"
                def.body?.let { b ->
                    if (b.length > 8_000) errors += "Body is too long (max 8000)"
                    checkPlaceholders(b, "body")
                }
            }
            "SCRIPT" -> {
                if (def.language !in LANGUAGES) errors += "Language must be python, node or sh"
                val code = def.code
                if (code.isNullOrBlank() || code.length > 20_000) errors += "Script must be 1-20000 characters"
            }
            "PROMPT" -> {
                val p = def.prompt
                if (p.isNullOrBlank() || p.length > 4_000) errors += "Prompt must be 1-4000 characters"
                else checkPlaceholders(p, "prompt")
            }
            "MCP" -> {
                val s = def.serverUrl
                if (s.isNullOrBlank() || !s.startsWith("https://") || s.length > 300) errors += "MCP server URL must start with https://"
                if (def.remoteName.isNullOrBlank() || def.remoteName.length > 120) errors += "MCP tool name is missing"
            }
        }
        return errors
    }
}

/** Fills {param} placeholders. The caller chooses how each value is encoded for its context. */
object Template {
    fun fill(template: String, args: JsonObject, encode: (String) -> String): String =
        CustomToolValidator.PLACEHOLDER.replace(template) { m ->
            encode(valueText(args[m.groupValues[1]]))
        }

    fun valueText(v: JsonElement?): String = when (v) {
        null -> ""
        is JsonPrimitive -> v.contentOrNull ?: v.toString()
        else -> v.toString()
    }

    /** Single-quotes a value for sh, escaping embedded single quotes. */
    fun shellQuote(v: String): String = "'" + v.replace("'", "'\\''") + "'"

    /** Escapes a value so it can sit inside a JSON string. */
    fun jsonEscape(v: String): String = JsonPrimitive(v).toString().removeSurrounding("\"")
}
