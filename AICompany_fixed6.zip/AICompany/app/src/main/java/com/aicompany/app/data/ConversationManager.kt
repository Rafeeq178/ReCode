package com.aicompany.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Tracks which chat is open. The app starts on a fresh empty chat (the greeting screen);
 * older chats are listed under "Recents" in the drawer.
 */
@Singleton
class ConversationManager @Inject constructor(
    private val dao: MessageDao,
) {
    private val _currentId = MutableStateFlow(newId())
    val currentId: StateFlow<String> = _currentId.asStateFlow()

    val recents: Flow<List<ConversationRow>> = dao.conversations()

    fun newChat() {
        _currentId.value = newId()
    }

    fun open(id: String) {
        _currentId.value = id
    }

    suspend fun delete(id: String) {
        withContext(Dispatchers.IO) { dao.clear(id) }
        if (_currentId.value == id) newChat()
    }

    private fun newId(): String = UUID.randomUUID().toString()
}
