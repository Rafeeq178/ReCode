package com.aicompany.app.data

import com.aicompany.app.tools.ApprovalLevel
import com.aicompany.app.util.Redactor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AuditRepository @Inject constructor(private val dao: AuditDao) {

    suspend fun record(
        agentId: String,
        toolName: String,
        summary: String,
        level: ApprovalLevel,
        decision: String,
        outcome: String,
    ) = withContext(Dispatchers.IO) {
        dao.insert(
            AuditEntity(
                createdAt = System.currentTimeMillis(),
                agentId = agentId.take(64),
                toolName = toolName.take(64),
                summary = Redactor.redact(summary).take(500),
                approvalLevel = level.name,
                decision = decision.take(32),
                outcome = outcome.take(64),
            )
        )
    }

    fun observeRecent(limit: Int = 200): Flow<List<AuditEntity>> {
        require(limit in 1..1000) { "Limit out of range" }
        return dao.observeRecent(limit)
    }

    suspend fun pruneOlderThan(days: Long) = withContext(Dispatchers.IO) {
        require(days in 1..3650) { "Retention must be 1-3650 days" }
        dao.pruneBefore(System.currentTimeMillis() - days * 24 * 60 * 60 * 1000L)
    }
}
