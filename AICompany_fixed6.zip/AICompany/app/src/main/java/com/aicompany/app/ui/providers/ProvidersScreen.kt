package com.aicompany.app.ui.providers

import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import androidx.hilt.navigation.compose.hiltViewModel
import com.aicompany.app.data.ProviderDraft
import com.aicompany.app.local.ModelStore
import com.aicompany.app.provider.ApiFormat
import com.aicompany.app.provider.ProviderConfig
import com.aicompany.app.ui.components.AppTopBar
import com.aicompany.app.ui.components.ChipFlow
import com.aicompany.app.ui.components.IconBadge
import com.aicompany.app.ui.components.PillButton
import com.aicompany.app.ui.components.RowDivider
import com.aicompany.app.ui.components.SectionLabel
import com.aicompany.app.ui.components.SettingsGroup
import com.aicompany.app.ui.components.SettingsRow

@Composable
fun ProvidersScreen(
    onMenu: () -> Unit,
    viewModel: ProvidersViewModel = hiltViewModel(),
) {
    val providers by viewModel.providers.collectAsState()
    val status by viewModel.status.collectAsState()
    val localModels by viewModel.localModels.collectAsState()
    val importing by viewModel.importing.collectAsState()
    val importMessage by viewModel.importMessage.collectAsState()
    val pickedModel by viewModel.pickedModel.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    var editing by remember { mutableStateOf<ProviderConfig?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    // true: the top "Add model" button (also creates the provider); false: picked inside the editor dialog.
    var registerOnPick by remember { mutableStateOf(true) }
    val context = LocalContext.current

    // GGUF has no MIME type, so "*/*" is required. OpenDocument opens the phone's file picker
    // (Downloads, internal storage, SD card) and needs no storage permission.
    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val name = runCatching {
                context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
            }.getOrNull()
            viewModel.importModel(uri, name, registerOnPick)
        }
    }

    LaunchedEffect(status) {
        status?.let {
            snackbar.showSnackbar(it)
            viewModel.clearStatus()
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { AppTopBar("Models", Icons.Default.Menu, "Menu", onMenu) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    editing = null
                    registerOnPick = false
                    showEditor = true
                },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Add provider", fontWeight = FontWeight.Medium) },
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                SettingsGroup {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconBadge(Icons.Outlined.Memory)
                            Column(Modifier.padding(start = 14.dp)) {
                                Text("Run a model on this phone", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "Pick a .gguf file from your phone storage.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                        PillButton(
                            text = if (importing) "Copying..." else "Add model from phone",
                            icon = Icons.Outlined.FolderOpen,
                            enabled = !importing,
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                registerOnPick = true
                                modelPicker.launch(arrayOf("*/*"))
                            },
                        )
                        if (importing) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.size(10.dp))
                                Text(
                                    importMessage.orEmpty(),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        } else if (!importMessage.isNullOrBlank()) {
                            Text(
                                importMessage.orEmpty(),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }

            if (localModels.isNotEmpty()) {
                item { SectionLabel("On this phone") }
                item {
                    SettingsGroup {
                        localModels.forEachIndexed { i, m ->
                            if (i > 0) RowDivider()
                            SettingsRow(
                                title = m.name,
                                subtitle = "${m.sizeBytes / (1024 * 1024)} MB",
                                trailing = {
                                    IconButton(onClick = { viewModel.deleteModel(m.name) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete model")
                                    }
                                },
                            )
                        }
                    }
                }
            }

            item { SectionLabel("Providers") }
            if (providers.isEmpty()) {
                item {
                    Text(
                        "Abhi koi provider nahi hai. Upar se phone ka model add karein, ya neeche + Add provider dabayein.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 4.dp),
                    )
                }
            } else {
                items(providers, key = { it.id }) { p ->
                    SettingsGroup {
                        Column(Modifier.padding(start = 16.dp, end = 8.dp, top = 14.dp, bottom = 6.dp)) {
                            Text(p.name, style = MaterialTheme.typography.titleMedium)
                            Text(
                                "${p.format.name} · ${p.model}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            if (p.format != ApiFormat.LOCAL) {
                                Text(
                                    p.baseUrl,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                TextButton(onClick = { viewModel.test(p.id) }) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Text(" Test")
                                }
                                IconButton(onClick = {
                                    editing = p
                                    registerOnPick = false
                                    showEditor = true
                                }) { Icon(Icons.Default.Edit, contentDescription = "Edit") }
                                IconButton(onClick = { viewModel.delete(p.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEditor) {
        ProviderEditorDialog(
            initial = editing,
            localModels = localModels,
            importing = importing,
            importMessage = importMessage,
            pickedModel = pickedModel,
            onPickModel = {
                registerOnPick = false
                modelPicker.launch(arrayOf("*/*"))
            },
            onConsumePicked = viewModel::consumePickedModel,
            onDeleteModel = viewModel::deleteModel,
            onDismiss = { showEditor = false; viewModel.clearImportMessage() },
            onSave = { draft ->
                viewModel.save(draft) { showEditor = false }
            },
        )
    }
}

@Composable
private fun ProviderEditorDialog(
    initial: ProviderConfig?,
    localModels: List<ModelStore.LocalModelFile>,
    importing: Boolean,
    importMessage: String?,
    pickedModel: String?,
    onPickModel: () -> Unit,
    onConsumePicked: () -> Unit,
    onDeleteModel: (String) -> Unit,
    onDismiss: () -> Unit,
    onSave: (ProviderDraft) -> Unit,
) {
    var name by rememberSaveable { mutableStateOf(initial?.name ?: "") }
    var format by rememberSaveable { mutableStateOf(initial?.format ?: ApiFormat.OPENAI) }
    var baseUrl by rememberSaveable { mutableStateOf(initial?.baseUrl ?: "https://api.openai.com/v1") }
    var model by rememberSaveable { mutableStateOf(initial?.model ?: "") }
    var keys by rememberSaveable { mutableStateOf("") }      // never pre-filled: keys stay in the vault
    var maxTokens by rememberSaveable { mutableStateOf((initial?.maxTokens ?: 1024).toString()) }
    var temperature by rememberSaveable { mutableStateOf((initial?.temperature ?: 0.7).toString()) }
    var timeout by rememberSaveable { mutableStateOf((initial?.timeoutSeconds ?: 60).toString()) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }

    LaunchedEffect(pickedModel) {
        pickedModel?.let {
            model = it
            if (name.isBlank()) name = it.removeSuffix(".gguf")
            onConsumePicked()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth(0.94f),
        properties = DialogProperties(usePlatformDefaultWidth = false),
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text(if (initial == null) "New provider" else "Edit provider") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Text("API format", style = MaterialTheme.typography.labelLarge)
                ChipFlow {
                    ApiFormat.entries.forEach { f ->
                        FilterChip(
                            selected = format == f,
                            onClick = {
                                format = f
                                if (f == ApiFormat.LOCAL) {
                                    baseUrl = "local"
                                } else if (baseUrl == "local") {
                                    baseUrl = "https://api.openai.com/v1"
                                }
                            },
                            label = { Text(f.name) },
                        )
                    }
                }
                if (format == ApiFormat.LOCAL) {
                    Text("Model on this phone (.gguf)", style = MaterialTheme.typography.labelLarge)
                    PillButton(
                        text = if (importing) "Copying..." else "Choose file from phone",
                        icon = Icons.Outlined.FolderOpen,
                        enabled = !importing,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = onPickModel,
                    )
                    importMessage?.let {
                        Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (localModels.isEmpty()) {
                        Text("Abhi koi model add nahi hai.", style = MaterialTheme.typography.bodySmall)
                    } else {
                        localModels.forEach { m ->
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                FilterChip(
                                    selected = model == m.name,
                                    onClick = { model = m.name },
                                    label = { Text("${m.name} (${m.sizeBytes / (1024 * 1024)} MB)", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                    modifier = Modifier.weight(1f),
                                )
                                IconButton(onClick = {
                                    if (model == m.name) model = ""
                                    onDeleteModel(m.name)
                                }) { Icon(Icons.Default.Delete, contentDescription = "Delete model") }
                            }
                        }
                    }
                } else {
                    OutlinedTextField(baseUrl, { baseUrl = it }, label = { Text("Base URL (https, or http://127.0.0.1:8080/v1 for local)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(model, { model = it }, label = { Text("Model name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(
                        keys, { keys = it },
                        label = { Text(if (initial == null) "API key(s), one per line (empty is OK for a local http server)" else "New key(s) (leave empty to keep the old ones)") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 1,
                        maxLines = 4,
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(maxTokens, { maxTokens = it }, label = { Text("Max tokens") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(temperature, { temperature = it }, label = { Text("Temp") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(timeout, { timeout = it }, label = { Text("Timeout s") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            PillButton(text = "Save", onClick = {
                val parsed = runCatching {
                    ProviderDraft(
                        id = initial?.id,
                        name = name,
                        format = format,
                        baseUrl = baseUrl,
                        model = model,
                        keysText = keys,
                        maxTokens = maxTokens.toInt(),
                        temperature = temperature.toDouble(),
                        timeoutSeconds = timeout.toLong(),
                    )
                }
                parsed.onSuccess { error = null; onSave(it) }
                    .onFailure { error = "Numbers sahi format mein daalein" }
            })
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
