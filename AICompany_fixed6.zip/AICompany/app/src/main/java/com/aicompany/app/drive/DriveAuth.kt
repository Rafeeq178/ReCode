package com.aicompany.app.drive

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.aicompany.app.BuildConfig
import com.aicompany.app.security.KeyVault
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import net.openid.appauth.AuthState
import net.openid.appauth.AuthorizationException
import net.openid.appauth.AuthorizationRequest
import net.openid.appauth.AuthorizationResponse
import net.openid.appauth.AuthorizationService
import net.openid.appauth.AuthorizationServiceConfiguration
import net.openid.appauth.ClientAuthentication
import net.openid.appauth.NoClientAuthentication
import net.openid.appauth.ResponseTypeValues
import net.openid.appauth.TokenResponse
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Official Google OAuth (authorization code + PKCE) through AppAuth. Read-only Drive scope.
 * The refresh token lives in the Keystore-backed vault, never in Room or logs.
 */
@Singleton
class DriveAuth @Inject constructor(
    @ApplicationContext private val context: Context,
    private val vault: KeyVault,
) {
    private val config = AuthorizationServiceConfiguration(
        Uri.parse(AUTH_ENDPOINT),
        Uri.parse(TOKEN_ENDPOINT),
    )

    private val redirect: Uri
        get() = Uri.parse("${BuildConfig.GOOGLE_REDIRECT_SCHEME}:/oauth2redirect")

    fun isConfigured(): Boolean = BuildConfig.GOOGLE_CLIENT_ID.endsWith(".apps.googleusercontent.com")

    fun isConnected(): Boolean = vault.getBlob(STATE_NAME) != null

    fun buildSignInIntent(): Intent {
        check(isConfigured()) { "Google client ID is not set in this build" }
        val request = AuthorizationRequest.Builder(
            config,
            BuildConfig.GOOGLE_CLIENT_ID,
            ResponseTypeValues.CODE,
            redirect,
        )
            .setScopes(SCOPE)
            .setAdditionalParameters(mapOf("access_type" to "offline", "prompt" to "consent"))
            .build()
        val service = AuthorizationService(context)
        try {
            return service.getAuthorizationRequestIntent(request)
        } finally {
            service.dispose()
        }
    }

    /** Completes sign-in from the intent returned by the browser flow. */
    suspend fun completeSignIn(data: Intent): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val response = AuthorizationResponse.fromIntent(data)
                ?: throw IllegalStateException(
                    AuthorizationException.fromIntent(data)?.errorDescription ?: "Sign-in was cancelled"
                )
            val service = AuthorizationService(context)
            try {
                val tokens = exchangeCode(service, response)
                val state = AuthState(response, null)
                state.update(tokens, null)
                vault.saveBlob(STATE_NAME, state.jsonSerializeString())
            } finally {
                service.dispose()
            }
        }
    }

    /** Returns a valid access token, refreshing it when needed, and stores the updated state. */
    suspend fun accessToken(): String = withContext(Dispatchers.IO) {
        val json = vault.getBlob(STATE_NAME) ?: throw IllegalStateException("Google Drive is not connected")
        val state = AuthState.jsonDeserialize(json)
        val service = AuthorizationService(context)
        try {
            val token = suspendCancellableCoroutine<String> { cont ->
                state.performActionWithFreshTokens(service) { accessToken, _, ex ->
                    if (accessToken != null) cont.resume(accessToken)
                    else cont.resumeWithException(ex ?: IllegalStateException("Could not get a token"))
                }
            }
            vault.saveBlob(STATE_NAME, state.jsonSerializeString())
            token
        } finally {
            service.dispose()
        }
    }

    fun disconnect() {
        vault.deleteBlob(STATE_NAME)
    }

    private suspend fun exchangeCode(service: AuthorizationService, response: AuthorizationResponse): TokenResponse =
        suspendCancellableCoroutine { cont ->
            service.performTokenRequest(
                response.createTokenExchangeRequest(),
                NoClientAuthentication.INSTANCE as ClientAuthentication,
            ) { tokens, ex ->
                if (tokens != null) cont.resume(tokens)
                else cont.resumeWithException(ex ?: IllegalStateException("Token exchange failed"))
            }
        }

    companion object {
        const val SCOPE = "https://www.googleapis.com/auth/drive.readonly"
        private const val AUTH_ENDPOINT = "https://accounts.google.com/o/oauth2/v2/auth"
        private const val TOKEN_ENDPOINT = "https://oauth2.googleapis.com/token"
        private const val STATE_NAME = "DRIVE_AUTH_STATE"
    }
}
