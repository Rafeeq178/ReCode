package com.aicompany.app.approvals

enum class ApprovalDecision { APPROVED, ALLOW_ONE_HOUR, REJECTED, TIMEOUT }

/** Shown to the owner. The summary is already redacted before it gets here. */
data class ApprovalRequest(
    val id: String,
    val agentId: String,
    val toolName: String,
    val summary: String,
    val requestedAt: Long,
)

sealed class AuthOutcome {
    abstract val label: String

    data class Allowed(override val label: String) : AuthOutcome()
    data class Denied(override val label: String, val reason: String) : AuthOutcome()
}
