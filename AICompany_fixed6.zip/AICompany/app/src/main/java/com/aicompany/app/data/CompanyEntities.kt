package com.aicompany.app.data

import androidx.room.ColumnInfo
import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "employees")
data class EmployeeEntity(
    @PrimaryKey val id: String,
    val name: String,
    val role: String,
    val allowedTools: String,      // comma separated tool names
    val status: String,            // IDLE | PAUSED | WORKING | FIRED
    val createdAt: Long,
    @ColumnInfo(defaultValue = "") val systemPrompt: String = "",
    @ColumnInfo(defaultValue = "") val providerIds: String = "",     // comma separated, empty = all
    @ColumnInfo(defaultValue = "") val model: String = "",           // overrides the primary provider's model
    @ColumnInfo(defaultValue = "15") val maxSteps: Int = 15,
    @ColumnInfo(defaultValue = "600") val timeoutSeconds: Long = 600,
    @ColumnInfo(defaultValue = "1024") val maxTokens: Int = 1024,
    @ColumnInfo(defaultValue = "0.2") val temperature: Double = 0.2,
    @ColumnInfo(defaultValue = "ASK") val terminalPermission: String = "ASK",
    @ColumnInfo(defaultValue = "5") val localPriority: Int = 5,
    @ColumnInfo(defaultValue = "") val skillIds: String = "",       // comma separated
    @ColumnInfo(defaultValue = "0") val ceoCanModify: Boolean = false,
    @ColumnInfo(defaultValue = "#C9623F") val color: String = "#C9623F",
    @ColumnInfo(defaultValue = "1") val version: Int = 1,
) {
    fun toolSet(): Set<String> = splitCsv(allowedTools)
    fun skillSet(): Set<String> = splitCsv(skillIds)
    fun providerList(): List<String> = providerIds.split(',').map { it.trim() }.filter { it.isNotEmpty() }

    private fun splitCsv(v: String): Set<String> = v.split(',').map { it.trim() }.filter { it.isNotEmpty() }.toSet()
}

@Entity(tableName = "tasks", indices = [Index("assigneeId"), Index("status")])
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String,
    val assigneeId: String,
    val status: String,            // TODO | IN_PROGRESS | DONE | FAILED
    val result: String,
    val runId: Long,
    val createdAt: Long,
    val updatedAt: Long,
)

@Entity(tableName = "employee_versions", indices = [Index("employeeId")])
data class EmployeeVersionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: String,
    val version: Int,
    val createdAt: Long,
    val snapshot: String,          // JSON of EmployeeSnapshot
)

@Entity(tableName = "templates")
data class TemplateEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val snapshot: String,          // JSON of EmployeeSnapshot
    val createdAt: Long,
)

@Entity(tableName = "skills")
data class SkillEntity(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val instructions: String,
    val createdAt: Long,
)

@Dao
interface CompanyDao {
    @Query("SELECT * FROM employees ORDER BY createdAt ASC")
    fun observeEmployees(): Flow<List<EmployeeEntity>>

    @Query("SELECT * FROM employees WHERE id = :id LIMIT 1")
    suspend fun getEmployee(id: String): EmployeeEntity?

    @Query("SELECT COUNT(*) FROM employees WHERE status != 'FIRED'")
    suspend fun activeEmployeeCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveEmployee(entity: EmployeeEntity)

    @Insert
    suspend fun insertTask(entity: TaskEntity): Long

    @Query("UPDATE tasks SET status = :status, result = :result, runId = :runId, updatedAt = :now WHERE id = :id")
    suspend fun updateTask(id: Long, status: String, result: String, runId: Long, now: Long)

    @Query("SELECT * FROM tasks ORDER BY id DESC LIMIT 200")
    fun observeTasks(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE id = :id LIMIT 1")
    fun observeTask(id: Long): Flow<TaskEntity?>

    @Insert
    suspend fun insertVersion(entity: EmployeeVersionEntity)

    @Query("SELECT * FROM employee_versions WHERE employeeId = :employeeId ORDER BY version DESC")
    fun observeVersions(employeeId: String): Flow<List<EmployeeVersionEntity>>

    @Query("SELECT * FROM employee_versions WHERE employeeId = :employeeId AND version = :version LIMIT 1")
    suspend fun getVersion(employeeId: String, version: Int): EmployeeVersionEntity?

    @Insert
    suspend fun insertTemplate(entity: TemplateEntity): Long

    @Query("SELECT * FROM templates WHERE id = :id LIMIT 1")
    suspend fun getTemplate(id: Long): TemplateEntity?

    @Query("SELECT * FROM templates ORDER BY createdAt DESC")
    fun observeTemplates(): Flow<List<TemplateEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSkill(entity: SkillEntity)

    @Query("SELECT * FROM skills ORDER BY name ASC")
    fun observeSkills(): Flow<List<SkillEntity>>

    @Query("SELECT * FROM skills WHERE id = :id LIMIT 1")
    suspend fun getSkill(id: String): SkillEntity?

    @Query("SELECT id FROM skills")
    suspend fun skillIds(): List<String>
}
