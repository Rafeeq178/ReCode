package com.aicompany.app.tools

import java.io.File

/**
 * Confines file tools to one folder. Rejects absolute paths, "..", NUL bytes,
 * and any path whose canonical form (after symlink resolution) leaves the root.
 */
class WorkspaceSandbox(root: File) {
    val root: File = root.canonicalFile.also { it.mkdirs() }

    fun resolve(relative: String): File {
        require(relative.isNotBlank()) { "Path is empty" }
        require(relative.length <= MAX_PATH_LENGTH) { "Path is too long" }
        require(!relative.contains('\u0000')) { "Invalid path" }
        require(!relative.startsWith("/") && !relative.startsWith("\\")) { "Absolute paths are not allowed" }
        require(!WINDOWS_DRIVE.containsMatchIn(relative)) { "Absolute paths are not allowed" }
        require(relative.split('/', '\\').none { it == ".." }) { "Parent folder references are not allowed" }
        val target = File(root, relative).canonicalFile
        require(target.path == root.path || target.path.startsWith(root.path + File.separator)) {
            "Path escapes the workspace"
        }
        return target
    }

    companion object {
        const val MAX_PATH_LENGTH = 512
        private val WINDOWS_DRIVE = Regex("^[A-Za-z]:")
    }
}
