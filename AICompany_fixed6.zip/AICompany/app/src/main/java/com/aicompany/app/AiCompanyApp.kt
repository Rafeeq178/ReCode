package com.aicompany.app

import android.app.Application
import android.content.Context
import com.aicompany.app.local.MemoryMonitor
import com.aicompany.app.tools.custom.CustomToolCatalog
import com.aicompany.app.util.CrashReporter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class AiCompanyApp : Application() {

    @Inject lateinit var memory: MemoryMonitor

    // Lazy on purpose: building the tool catalog pulls in the whole tool graph (KeyVault, DB, ...).
    // Injecting it eagerly ran all of that on the main thread inside Application.onCreate, so any
    // failure there killed the app before the first screen.
    @Inject lateinit var customTools: dagger.Lazy<CustomToolCatalog>

    private val startupScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        CrashReporter.install(base)
    }

    override fun onCreate() {
        super.onCreate()
        startupScope.launch {
            runCatching { customTools.get().reload() }
                .onFailure { CrashReporter.record(this@AiCompanyApp, "Custom tool catalog failed to load", it) }
        }
    }

    /** Forwards system memory pressure so the local engine can unload when needed. */
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        memory.onTrim(level)
    }
}
