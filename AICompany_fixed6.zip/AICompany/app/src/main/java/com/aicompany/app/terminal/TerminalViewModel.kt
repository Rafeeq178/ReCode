package com.aicompany.app.terminal

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.termux.terminal.TerminalSession
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class TerminalViewModel @Inject constructor(
    val installer: RootfsInstaller,
    private val launcher: ShellLauncher,
) : ViewModel() {

    val installState: StateFlow<InstallState> = installer.state

    private val _session = MutableStateFlow<TerminalSession?>(null)
    val session: StateFlow<TerminalSession?> = _session.asStateFlow()

    private val _notice = MutableStateFlow<String?>(null)
    val notice: StateFlow<String?> = _notice.asStateFlow()

    fun install() {
        viewModelScope.launch { installer.install() }
    }

    /** Creates the owner's interactive shell once. Re-entering the screen reuses it. */
    fun ensureSession() {
        if (_session.value != null) return
        val reason = launcher.notReadyReason()
        if (reason != null) {
            _notice.value = reason
            return
        }
        _session.value = TermuxBridge.createSession(
            argv = launcher.interactiveArgv(),
            environment = launcher.environment(),
            cwd = launcher.hostCwd(),
            onFinished = { code -> _notice.value = "Shell exited with code $code" },
        )
    }

    fun restartSession() {
        _session.value?.finishIfRunning()
        _session.value = null
        _notice.value = null
        ensureSession()
    }

    override fun onCleared() {
        _session.value?.finishIfRunning()
        super.onCleared()
    }
}
