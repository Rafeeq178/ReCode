package com.aicompany.app.provider

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import javax.inject.Inject

/** Works with OpenAI, Groq, OpenRouter, DeepSeek, a local llama-server / Ollama and any OpenAI-compatible endpoint. */
class OpenAiCompatClient @Inject constructor(
    private val http: OkHttpClient,
    private val json: Json,
) : ProviderClient {

    /**
     * Which token-limit field and whether temperature goes into the body.
     * OpenAI's current models (o-series, GPT-5 family) reject `max_tokens` and any non-default
     * temperature; Groq, OpenRouter, DeepSeek and local servers expect the classic `max_tokens`.
     */
    internal data class BodyOptions(val useCompletionTokens: Boolean, val sendTemperature: Boolean)

    override fun chat(
        config: ProviderConfig,
        apiKey: String,
        messages: List<ChatMessage>,
        params: ChatParams,
    ): Flow<String> = flow {
        requireSafeBaseUrl(config.baseUrl)
        var options = initialOptions(config)
        var adaptations = 0
        while (true) {
            val request = buildRequest(config, apiKey, messages, params, options)
            val response = http.forProvider(config).executeOrThrow(request)
            val failure: ProviderException? = response.use { r ->
                if (r.isSuccessful) {
                    val source = r.body?.source() ?: throw ProviderException.Server("Empty response", 502)
                    while (true) {
                        val line = source.readLineOrThrow() ?: break
                        if (!line.startsWith("data:")) continue
                        val data = line.removePrefix("data:").trim()
                        if (data == "[DONE]") break
                        val obj = json.parseEvent(data)
                        if (obj["error"] != null) throw ProviderException.Server("Stream error from provider", 502)
                        val text = obj["choices"]
                            ?.jsonArray?.firstOrNull()?.jsonObject
                            ?.get("delta")?.jsonObject
                            ?.get("content")?.jsonPrimitive?.contentOrNull
                        if (!text.isNullOrEmpty()) emit(text)
                    }
                    null
                } else {
                    val text = r.readErrorBody()
                    val next = if (r.code == 400 && adaptations < MAX_ADAPTATIONS) adapt(options, text) else null
                    if (next != null) {
                        options = next
                        adaptations++
                        // Fall through to a retry with the adjusted parameters.
                        ADAPTED
                    } else {
                        mapHttpError(r.code, text, r.retryAfterMillis())
                    }
                }
            }
            if (failure == null) return@flow
            if (failure !== ADAPTED) throw failure
        }
    }.flowOn(Dispatchers.IO)

    private fun buildRequest(
        config: ProviderConfig,
        apiKey: String,
        messages: List<ChatMessage>,
        params: ChatParams,
        options: BodyOptions,
    ): Request {
        val body = buildJsonObject {
            put("model", config.model)
            put("stream", true)
            put(if (options.useCompletionTokens) "max_completion_tokens" else "max_tokens", params.maxTokens)
            if (options.sendTemperature) put("temperature", params.temperature)
            put("messages", buildJsonArray {
                messages.forEach { m ->
                    add(buildJsonObject {
                        put("role", m.role)
                        put("content", m.content)
                    })
                }
            })
        }
        return Request.Builder()
            .url(joinUrl(config.baseUrl, "/chat/completions"))
            .apply { if (apiKey != NO_API_KEY) header("Authorization", "Bearer $apiKey") }
            .header("Accept", "text/event-stream")
            .applyExtraHeaders(config)
            .post(body.toString().toRequestBody(JSON_MEDIA))
            .build()
    }

    internal companion object {
        private const val MAX_ADAPTATIONS = 2
        private val ADAPTED = ProviderException.BadRequest("adapted")
        private val REASONING_MODEL = Regex("^(o\\d|gpt-5)", RegexOption.IGNORE_CASE)

        /** api.openai.com always accepts max_completion_tokens; reasoning models also fix temperature. */
        fun initialOptions(config: ProviderConfig): BodyOptions {
            val official = hostOf(config.baseUrl) == "api.openai.com"
            val reasoning = official && REASONING_MODEL.containsMatchIn(config.model.substringAfterLast('/'))
            return BodyOptions(useCompletionTokens = official, sendTemperature = !reasoning)
        }

        /**
         * Reads a 400 body and, when the server names the field it rejected, returns adjusted options.
         * This covers future models and compatible servers without a hard-coded model list.
         */
        fun adapt(current: BodyOptions, errorBody: String): BodyOptions? {
            val lower = errorBody.lowercase()
            if (current.sendTemperature && lower.contains("temperature") &&
                (lower.contains("unsupported") || lower.contains("not support") || lower.contains("only the default"))
            ) {
                return current.copy(sendTemperature = false)
            }
            if (!current.useCompletionTokens && lower.contains("max_completion_tokens")) {
                return current.copy(useCompletionTokens = true)
            }
            if (current.useCompletionTokens && lower.contains("max_completion_tokens") &&
                (lower.contains("unsupported") || lower.contains("unknown") || lower.contains("unrecognized"))
            ) {
                return current.copy(useCompletionTokens = false)
            }
            return null
        }
    }
}
