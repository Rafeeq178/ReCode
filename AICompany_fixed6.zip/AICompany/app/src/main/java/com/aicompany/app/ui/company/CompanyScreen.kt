package com.aicompany.app.ui.company

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.aicompany.app.company.TaskStatus
import com.aicompany.app.data.TaskEntity
import com.aicompany.app.ui.components.AppTopBar
import com.aicompany.app.ui.components.PillButton
import com.aicompany.app.ui.components.PillOutlinedButton
import com.aicompany.app.ui.components.RowDivider
import com.aicompany.app.ui.components.SectionLabel
import com.aicompany.app.ui.components.SettingsGroup
import com.aicompany.app.ui.components.SettingsRow

@Composable
fun CompanyScreen(
    onMenu: () -> Unit,
    onOpenEmployee: (String) -> Unit,
    onNewEmployee: () -> Unit,
    viewModel: CompanyViewModel = hiltViewModel(),
) {
    val employees by viewModel.employees.collectAsState()
    val tasks by viewModel.tasks.collectAsState()
    val active by viewModel.active.collectAsState()
    val notice by viewModel.notice.collectAsState()
    var goal by rememberSaveable { mutableStateOf("") }
    var hireName by rememberSaveable { mutableStateOf("") }
    var hireRole by rememberSaveable { mutableStateOf("") }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(notice) {
        notice?.let {
            snackbar.showSnackbar(it)
            viewModel.clearNotice()
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { AppTopBar("Company", Icons.Default.Menu, "Menu", onMenu) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onNewEmployee,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("New worker", fontWeight = FontWeight.Medium) },
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            SettingsGroup {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Goal for the CEO", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(
                        value = goal,
                        onValueChange = { if (it.length <= 4000) goal = it },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2,
                        maxLines = 5,
                        placeholder = { Text("Goal likhein, CEO plan banayega") },
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        PillButton(
                            text = "Send to CEO",
                            onClick = {
                                viewModel.runCeo(goal)
                                goal = ""
                            },
                            enabled = goal.isNotBlank(),
                        )
                        PillOutlinedButton(
                            text = "Stop all",
                            onClick = viewModel::stopAll,
                            icon = Icons.Default.Warning,
                            danger = true,
                        )
                    }
                    Text(
                        "Active runs: $active",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            SectionLabel("Employees (${employees.size})")
            if (employees.isEmpty()) {
                Text(
                    "Abhi koi employee nahi. Neeche New worker ya Quick hire use karein.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 4.dp),
                )
            } else {
                SettingsGroup {
                    employees.forEachIndexed { i, e ->
                        if (i > 0) RowDivider()
                        SettingsRow(
                            title = e.name,
                            subtitle = "${e.role} · ${e.status}",
                            onClick = { onOpenEmployee(e.id) },
                            trailing = {
                                if (e.status != "FIRED") {
                                    TextButton(onClick = { viewModel.fire(e.id) }) {
                                        Text("Fire", color = MaterialTheme.colorScheme.error)
                                    }
                                }
                            },
                        )
                    }
                }
            }

            SectionLabel("Quick hire")
            SettingsGroup {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(hireName, { hireName = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(hireRole, { hireRole = it }, label = { Text("Role") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    PillButton(
                        text = "Hire (default tools)",
                        onClick = {
                            viewModel.hire(hireName, hireRole)
                            hireName = ""
                            hireRole = ""
                        },
                        enabled = hireName.isNotBlank() && hireRole.isNotBlank(),
                    )
                }
            }

            SectionLabel("Task board")
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                TaskStatus.entries.forEach { status ->
                    BoardColumn(status, tasks.filter { it.status == status.name })
                }
            }
        }
    }
}

@Composable
private fun BoardColumn(status: TaskStatus, items: List<TaskEntity>) {
    Column(
        modifier = Modifier.width(220.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(
            "${status.name} (${items.size})",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        items.forEach { t ->
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(t.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                    if (t.result.isNotEmpty()) {
                        Text(
                            t.result.take(200),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 4,
                        )
                    }
                }
            }
        }
        if (items.isEmpty()) {
            Spacer(Modifier.height(4.dp))
        }
    }
}
