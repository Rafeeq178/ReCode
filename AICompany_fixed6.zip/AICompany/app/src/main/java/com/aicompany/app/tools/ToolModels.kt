package com.aicompany.app.tools

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

enum class ApprovalLevel { AUTO, ASK, BLOCKED }

data class ToolSpec(
    val name: String,
    val description: String,
    val schema: JsonObject,
    val approval: ApprovalLevel,
    val timeoutMs: Long = 20_000,
    val maxOutputChars: Int = 8_000,
) {
    init {
        require(Regex("^[a-z][a-z0-9_]{1,40}$").matches(name)) { "Invalid tool name: $name" }
        require(description.isNotBlank() && description.length <= 500) { "Description required (max 500)" }
        require(timeoutMs in 1_000..300_000) { "Timeout out of range for $name" }
        require(maxOutputChars in 256..100_000) { "Output cap out of range for $name" }
    }
}

data class ToolCall(val name: String, val arguments: JsonObject)

data class ToolContext(
    val agentId: String,
    val workspace: com.aicompany.app.tools.WorkspaceSandbox,
    val skills: Set<String> = emptySet(),
)

sealed class ToolResult {
    abstract val kind: String

    data class Ok(val output: String) : ToolResult() {
        override val kind: String = "ok"
    }

    data class Error(val code: String, val message: String) : ToolResult() {
        override val kind: String get() = "error:$code"
    }
}

interface Tool {
    val spec: ToolSpec
    suspend fun execute(args: JsonObject, ctx: ToolContext): ToolResult
}

/** Small helpers so every tool declares a strict schema the same way. */
object Schema {
    fun obj(properties: Map<String, JsonElement>, required: List<String> = emptyList()): JsonObject =
        buildJsonObject {
            put("type", "object")
            put("properties", JsonObject(properties))
            put("required", JsonArray(required.map { JsonPrimitive(it) }))
            put("additionalProperties", false)
        }

    fun str(description: String, maxLength: Int = 1000): JsonObject = buildJsonObject {
        put("type", "string")
        put("description", description)
        put("maxLength", maxLength)
    }

    fun enumStr(description: String, values: List<String>): JsonObject = buildJsonObject {
        put("type", "string")
        put("description", description)
        put("enum", JsonArray(values.map { JsonPrimitive(it) }))
    }

    fun arrayStr(description: String, maxItems: Int): JsonObject = buildJsonObject {
        put("type", "array")
        put("description", description)
        put("maxItems", maxItems)
        put("items", buildJsonObject {
            put("type", "string")
            put("maxLength", 64)
        })
    }

    fun int(description: String, min: Long, max: Long): JsonObject = buildJsonObject {
        put("type", "integer")
        put("description", description)
        put("minimum", min)
        put("maximum", max)
    }
}
