package com.aicompany.app.ui.drive

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.Cloud
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.aicompany.app.ui.components.AppTopBar
import com.aicompany.app.ui.components.IconBadge
import com.aicompany.app.ui.components.PillButton
import com.aicompany.app.ui.components.PillOutlinedButton
import com.aicompany.app.ui.components.SettingsGroup

@Composable
fun DriveConnectScreen(
    onBack: () -> Unit,
    viewModel: DriveConnectViewModel = hiltViewModel(),
) {
    val status by viewModel.status.collectAsState()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        viewModel.onSignInResult(result.data)
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { AppTopBar("Google Drive", Icons.AutoMirrored.Filled.ArrowBack, "Back", onBack) },
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            SettingsGroup {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBadge(Icons.Outlined.Cloud)
                        Text(
                            status,
                            modifier = Modifier.padding(start = 14.dp),
                            style = MaterialTheme.typography.titleMedium,
                        )
                    }
                    Text(
                        "Sign in with your own Google account. The app asks only for read-only Drive access. " +
                            "Your password is typed on Google's page, never in this app.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        PillButton(text = "Connect Google Drive", onClick = {
                            viewModel.signInIntent()?.let { launcher.launch(it) }
                        })
                        PillOutlinedButton(text = "Disconnect", onClick = viewModel::disconnect)
                    }
                }
            }
        }
    }
}
