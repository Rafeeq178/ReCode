package com.aicompany.app.provider

import kotlinx.coroutines.flow.Flow

/** Streams text tokens. Cancelling the collector cancels the HTTP call. */
interface ProviderClient {
    fun chat(
        config: ProviderConfig,
        apiKey: String,
        messages: List<ChatMessage>,
        params: ChatParams,
    ): Flow<String>
}
