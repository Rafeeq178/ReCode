package com.aicompany.app.company

enum class TaskStatus { TODO, IN_PROGRESS, DONE, FAILED }

/** WORKING and FIRED are set by the company itself. The owner can only choose IDLE or PAUSED in the editor. */
enum class EmployeeStatus { IDLE, PAUSED, WORKING, FIRED }

object CompanyRules {
    const val CEO_ID = "ceo"
    const val MAX_WORKERS = 20
    const val MAX_NAME = 40
    const val MAX_ROLE = 80
    const val MAX_TITLE = 120
    const val MAX_DESCRIPTION = 4_000
    const val MAX_TOOLS_PER_WORKER = 20
    const val MAX_WAIT_SECONDS = 120L
    const val MAX_SKILLS_PER_WORKER = 32
    const val SKILL_LOAD_TOOL = "load_skill"

    /** Tools only the CEO may use. Workers can never be given these. */
    val CEO_ONLY_TOOLS = setOf(
        "hire_worker", "fire_worker", "assign_task", "check_task", "ask_owner", "final_report", "edit_worker",
    )

    /** Tools a newly hired worker gets by default. */
    val DEFAULT_WORKER_TOOLS = setOf("read_file", "write_file", "list_dir", "calculator", "get_time", "web_fetch")
}
