package com.aicompany.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ProviderDao {
    @Query("SELECT * FROM providers ORDER BY createdAt ASC")
    fun observeAll(): Flow<List<ProviderEntity>>

    @Query("SELECT * FROM providers WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): ProviderEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: ProviderEntity)

    @Query("DELETE FROM providers WHERE id = :id")
    suspend fun delete(id: String)
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY id ASC")
    fun observe(conversationId: String): Flow<List<MessageEntity>>

    @Insert
    suspend fun insert(entity: MessageEntity): Long

    @Query("UPDATE messages SET content = :content WHERE id = :id")
    suspend fun updateContent(id: Long, content: String)

    @Query("DELETE FROM messages WHERE conversationId = :conversationId")
    suspend fun clear(conversationId: String)

    /** One row per chat, newest first; the title is the first thing the owner wrote. */
    @Query(
        "SELECT m.conversationId AS conversationId, " +
            "(SELECT u.content FROM messages u WHERE u.conversationId = m.conversationId AND u.role = 'user' ORDER BY u.id ASC LIMIT 1) AS title, " +
            "MAX(m.createdAt) AS lastAt " +
            "FROM messages m GROUP BY m.conversationId ORDER BY lastAt DESC LIMIT 30"
    )
    fun conversations(): Flow<List<ConversationRow>>
}

/** Query result for the drawer's "Recents" list (not a table). */
data class ConversationRow(
    val conversationId: String,
    val title: String?,
    val lastAt: Long,
)
