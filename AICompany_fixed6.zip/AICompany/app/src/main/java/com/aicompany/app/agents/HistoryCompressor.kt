package com.aicompany.app.agents

import com.aicompany.app.provider.ChatMessage

/**
 * Keeps memory bounded on a 4 GB phone. Index 0 (system prompt) and 1 (goal) are never removed.
 * The oldest middle messages are dropped and replaced by one marker line.
 */
object HistoryCompressor {
    private const val KEEP_TAIL = 4

    fun compact(history: MutableList<ChatMessage>, maxChars: Int) {
        require(maxChars >= 1_000) { "Context budget too small" }
        if (history.size < 2) return
        var total = history.sumOf { it.content.length }
        if (total <= maxChars) return

        var dropped = 0
        while (total > maxChars && history.size > 2 + KEEP_TAIL) {
            val removed = history.removeAt(2)
            total -= removed.content.length
            dropped++
        }
        if (dropped > 0) {
            history.add(2, ChatMessage("user", "[$dropped earlier messages were removed to save memory]"))
        }
    }
}
