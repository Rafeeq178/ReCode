package com.aicompany.app.ui.nav

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.ListAlt
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aicompany.app.data.ConversationRow
import com.aicompany.app.ui.components.PillButton

private data class DrawerItem(val route: String, val label: String, val icon: ImageVector)

private val ITEMS = listOf(
    DrawerItem(Routes.CHAT, "Chats", Icons.Outlined.ChatBubbleOutline),
    DrawerItem(Routes.COMPANY, "Company", Icons.Outlined.Groups),
    DrawerItem(Routes.LOGS, "Live logs", Icons.Outlined.ListAlt),
    DrawerItem(Routes.TERMINAL, "Terminal", Icons.Outlined.Code),
    DrawerItem(Routes.PROVIDERS, "Models", Icons.Outlined.Memory),
    DrawerItem(Routes.SETTINGS, "Settings", Icons.Outlined.Settings),
)

@Composable
fun AppDrawerContent(
    currentRoute: String?,
    recents: List<ConversationRow>,
    currentChatId: String,
    userName: String,
    onNavigate: (String) -> Unit,
    onOpenChat: (String) -> Unit,
    onNewChat: () -> Unit,
) {
    ModalDrawerSheet(
        modifier = Modifier.fillMaxWidth(0.86f),
        drawerContainerColor = MaterialTheme.colorScheme.surfaceVariant,
        drawerContentColor = MaterialTheme.colorScheme.onSurface,
        drawerShape = RoundedCornerShape(topEnd = 0.dp, bottomEnd = 0.dp),
        windowInsets = androidx.compose.foundation.layout.WindowInsets(0, 0, 0, 0),
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Text(
                "AI Company",
                modifier = Modifier.padding(start = 24.dp, top = 20.dp, bottom = 12.dp),
                fontFamily = FontFamily.Serif,
                fontSize = 28.sp,
                fontWeight = FontWeight.Medium,
            )

            ITEMS.forEach { item ->
                DrawerRow(
                    icon = item.icon,
                    label = item.label,
                    selected = currentRoute == item.route,
                    onClick = { onNavigate(item.route) },
                )
            }

            HorizontalDivider(
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                color = MaterialTheme.colorScheme.outline,
            )

            Text(
                "Recents",
                modifier = Modifier.padding(start = 28.dp, bottom = 6.dp),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            if (recents.isEmpty()) {
                Text(
                    "Abhi koi chat nahi. Neeche New chat dabayein.",
                    modifier = Modifier.padding(horizontal = 28.dp, vertical = 8.dp).weight(1f),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                LazyColumn(Modifier.weight(1f)) {
                    items(recents, key = { it.conversationId }) { row ->
                        RecentRow(
                            title = row.title?.lineSequence()?.firstOrNull()?.trim().orEmpty().ifBlank { "New chat" },
                            selected = currentRoute == Routes.CHAT && row.conversationId == currentChatId,
                            onClick = { onOpenChat(row.conversationId) },
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.tertiary)
                        .clickable { onNavigate(Routes.SETTINGS) },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        userName.trim().firstOrNull()?.uppercase() ?: "A",
                        color = MaterialTheme.colorScheme.onTertiary,
                        fontWeight = FontWeight.Bold,
                    )
                }
                PillButton(text = "New chat", onClick = onNewChat, icon = Icons.Filled.Add)
            }
        }
    }
}

@Composable
private fun DrawerRow(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    val bg = if (selected) MaterialTheme.colorScheme.outlineVariant else androidx.compose.ui.graphics.Color.Transparent
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp)
            .height(52.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(16.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun RecentRow(title: String, selected: Boolean, onClick: () -> Unit) {
    val bg = if (selected) MaterialTheme.colorScheme.outlineVariant else androidx.compose.ui.graphics.Color.Transparent
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp)
            .height(44.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            Icons.Outlined.ChatBubbleOutline,
            contentDescription = null,
            modifier = Modifier.size(16.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.width(14.dp))
        Text(title, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
