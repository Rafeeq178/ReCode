package com.aicompany.app.terminal

import android.content.Context
import com.aicompany.app.util.Logger
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.nio.file.FileVisitResult
import java.nio.file.Files
import java.nio.file.LinkOption
import java.nio.file.Path
import java.nio.file.Paths
import java.nio.file.SimpleFileVisitor
import java.nio.file.StandardCopyOption
import java.nio.file.attribute.BasicFileAttributes
import java.security.MessageDigest
import java.util.zip.GZIPInputStream
import javax.inject.Inject
import javax.inject.Singleton

sealed class InstallState {
    object Idle : InstallState()
    data class Downloading(val progress: Float) : InstallState()
    object Verifying : InstallState()
    object Extracting : InstallState()
    object Done : InstallState()
    data class Failed(val message: String) : InstallState()
}

/**
 * Downloads the Alpine minirootfs over HTTPS, resumes partial downloads, verifies SHA-256
 * against the published .sha256 file, and extracts with path-traversal protection.
 */
@Singleton
class RootfsInstaller @Inject constructor(
    @ApplicationContext private val context: Context,
    private val http: OkHttpClient,
) {
    val rootfsDir = File(context.filesDir, "alpine")
    private val cacheDir = File(context.filesDir, "cache").apply { mkdirs() }
    private val partFile = File(cacheDir, "alpine.tar.gz.part")
    private val archiveFile = File(cacheDir, "alpine.tar.gz")
    private val marker = File(rootfsDir, ".installed")
    private val lock = Mutex()

    private val _state = MutableStateFlow<InstallState>(
        if (isInstalled()) InstallState.Done else InstallState.Idle
    )
    val state: StateFlow<InstallState> = _state.asStateFlow()

    fun isInstalled(): Boolean = marker.exists() && hasShell(rootfsDir)

    /**
     * Alpine's /bin/sh is a symlink with an ABSOLUTE target (/bin/busybox). On the Android host that
     * target does not exist, so File.exists() on the link is false even though the rootfs is fine
     * (it resolves correctly inside proot). So: check busybox itself, and treat the link as present
     * if the link entry exists.
     */
    private fun hasShell(root: File): Boolean {
        val sh = File(root, "bin/sh")
        val busybox = File(root, "bin/busybox")
        return busybox.isFile && (Files.isSymbolicLink(sh.toPath()) || sh.exists())
    }

    suspend fun install(): Result<Unit> = lock.withLock {
        withContext(Dispatchers.IO) {
            runCatching { doInstall() }.onFailure { e ->
                Logger.e("Rootfs", "Install failed: ${e.javaClass.simpleName}")
                _state.value = InstallState.Failed(e.message ?: "Install failed")
            }
        }
    }

    private fun doInstall() {
        if (isInstalled()) {
            _state.value = InstallState.Done
            return
        }
        ensureDir(cacheDir)
        ensureDir(rootfsDir.parentFile ?: context.filesDir)
        val expected = fetchExpectedSha256()
        download()
        _state.value = InstallState.Verifying
        val actual = sha256(archiveFile)
        if (actual != expected) {
            archiveFile.delete()
            partFile.delete()
            throw IOException("Checksum mismatch. Download discarded.")
        }
        _state.value = InstallState.Extracting
        val staging = File(context.filesDir, "alpine-staging")
        RootfsExtractor.deleteTree(staging)
        ensureDir(staging)
        RootfsExtractor.extract(archiveFile, staging)
        if (!hasShell(staging)) {
            RootfsExtractor.deleteTree(staging)
            throw IOException("Rootfs is missing /bin/sh after extraction")
        }
        RootfsExtractor.deleteTree(rootfsDir)
        if (!staging.renameTo(rootfsDir)) {
            RootfsExtractor.deleteTree(staging)
            throw IOException("Could not move rootfs into place")
        }
        marker.writeText(ROOTFS_URL)
        _state.value = InstallState.Done
    }

    /** Creates [dir] (and parents) or fails with its path, instead of a later "No such file" in the middle of extraction. */
    private fun ensureDir(dir: File) {
        if (!dir.isDirectory && !dir.mkdirs() && !dir.isDirectory) {
            throw IOException("Could not create folder ${dir.absolutePath}")
        }
    }

    private fun fetchExpectedSha256(): String {
        val req = Request.Builder().url("$ROOTFS_URL.sha256").get().build()
        http.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("Could not fetch checksum (HTTP ${resp.code})")
            val text = resp.body?.string().orEmpty()
            val hash = text.trim().split(Regex("\\s+")).firstOrNull().orEmpty().lowercase()
            require(SHA256_REGEX.matches(hash)) { "Checksum file is malformed" }
            return hash
        }
    }

    private fun download() {
        _state.value = InstallState.Downloading(0f)
        val resume = if (partFile.exists()) partFile.length() else 0L
        val req = Request.Builder()
            .url(ROOTFS_URL)
            .apply { if (resume > 0) header("Range", "bytes=$resume-") }
            .get()
            .build()
        http.newCall(req).execute().use { resp ->
            if (resp.code != 200 && resp.code != 206) throw IOException("Download failed (HTTP ${resp.code})")
            val appending = resp.code == 206 && resume > 0
            if (!appending) partFile.delete()
            val body = resp.body ?: throw IOException("Empty download")
            val startOffset = if (appending) resume else 0L
            val total = if (body.contentLength() > 0) body.contentLength() + startOffset else -1L
            if (total > MAX_ARCHIVE_BYTES) throw IOException("Archive is larger than the allowed limit")

            var written = startOffset
            FileOutputStream(partFile, appending).use { out ->
                body.byteStream().use { input ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        written += n
                        if (written > MAX_ARCHIVE_BYTES) throw IOException("Archive exceeded the size limit")
                        out.write(buf, 0, n)
                        if (total > 0) _state.value = InstallState.Downloading((written.toFloat() / total).coerceIn(0f, 1f))
                    }
                }
            }
        }
        archiveFile.delete()
        if (!partFile.renameTo(archiveFile)) throw IOException("Could not finalise download")
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                digest.update(buf, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    companion object {
        /** Official Alpine minirootfs, aarch64. Update this URL when moving to a new Alpine release. */
        const val ROOTFS_URL =
            "https://dl-cdn.alpinelinux.org/alpine/v3.22/releases/aarch64/alpine-minirootfs-3.22.2-aarch64.tar.gz"
        private const val MAX_ARCHIVE_BYTES = 80L * 1024 * 1024
        private val SHA256_REGEX = Regex("^[0-9a-f]{64}$")
    }
}
