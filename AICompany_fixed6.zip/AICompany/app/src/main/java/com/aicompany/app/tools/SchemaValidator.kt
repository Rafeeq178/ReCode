package com.aicompany.app.tools

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import kotlinx.serialization.json.contentOrNull

/**
 * Validates tool arguments against a JSON-schema subset in code (the model cannot bypass it).
 * Supports: type (object, array, string, integer, number, boolean), properties, required,
 * additionalProperties, items, maxItems, minLength, maxLength, minimum, maximum, enum.
 * Error messages are English and are returned to the model so it can fix its call.
 */
object SchemaValidator {
    private const val MAX_DEPTH = 8

    fun validate(schema: JsonObject, value: JsonElement): List<String> {
        val errors = mutableListOf<String>()
        check(schema, value, "args", errors, 0)
        return errors
    }

    private fun check(schema: JsonObject, value: JsonElement, path: String, errors: MutableList<String>, depth: Int) {
        if (depth > MAX_DEPTH) {
            errors += "$path is nested too deeply"
            return
        }
        when (schema["type"]?.jsonPrimitive?.contentOrNull) {
            "object" -> checkObject(schema, value, path, errors, depth)
            "array" -> checkArray(schema, value, path, errors, depth)
            "string" -> checkString(schema, value, path, errors)
            "integer" -> checkNumber(schema, value, path, errors, integer = true)
            "number" -> checkNumber(schema, value, path, errors, integer = false)
            "boolean" -> if (!isBoolean(value)) errors += "$path must be true or false"
            null -> Unit
            else -> errors += "$path uses an unsupported schema type"
        }
        schema["enum"]?.jsonArray?.let { allowed ->
            if (allowed.none { it == value }) errors += "$path must be one of the allowed values"
        }
    }

    private fun checkObject(schema: JsonObject, value: JsonElement, path: String, errors: MutableList<String>, depth: Int) {
        val obj = value as? JsonObject ?: run {
            errors += "$path must be an object"
            return
        }
        val props = schema["properties"] as? JsonObject ?: JsonObject(emptyMap())
        schema["required"]?.jsonArray?.forEach { req ->
            val key = req.jsonPrimitive.content
            if (!obj.containsKey(key)) errors += "$path.$key is required"
        }
        val allowExtra = schema["additionalProperties"]?.jsonPrimitive?.booleanOrNull ?: true
        obj.forEach { (key, v) ->
            val sub = props[key] as? JsonObject
            if (sub == null) {
                if (!allowExtra) errors += "$path.$key is not an allowed argument"
            } else {
                check(sub, v, "$path.$key", errors, depth + 1)
            }
        }
    }

    private fun checkArray(schema: JsonObject, value: JsonElement, path: String, errors: MutableList<String>, depth: Int) {
        val arr = value as? JsonArray ?: run {
            errors += "$path must be an array"
            return
        }
        schema["maxItems"]?.jsonPrimitive?.intOrNull?.let { max ->
            if (arr.size > max) errors += "$path has too many items (max $max)"
        }
        val itemSchema = schema["items"] as? JsonObject
        if (itemSchema != null) {
            arr.forEachIndexed { i, v -> check(itemSchema, v, "$path[$i]", errors, depth + 1) }
        }
    }

    private fun checkString(schema: JsonObject, value: JsonElement, path: String, errors: MutableList<String>) {
        val prim = value as? JsonPrimitive
        if (prim == null || !prim.isString) {
            errors += "$path must be a string"
            return
        }
        val len = prim.content.length
        schema["minLength"]?.jsonPrimitive?.intOrNull?.let { if (len < it) errors += "$path must be at least $it characters" }
        schema["maxLength"]?.jsonPrimitive?.intOrNull?.let { if (len > it) errors += "$path must be at most $it characters" }
    }

    private fun checkNumber(schema: JsonObject, value: JsonElement, path: String, errors: MutableList<String>, integer: Boolean) {
        val prim = value as? JsonPrimitive
        if (prim == null || prim.isString) {
            errors += "$path must be a ${if (integer) "integer" else "number"}"
            return
        }
        if (integer && prim.longOrNull == null) {
            errors += "$path must be an integer"
            return
        }
        val d = prim.doubleOrNull
        if (d == null) {
            errors += "$path must be a ${if (integer) "integer" else "number"}"
            return
        }
        schema["minimum"]?.jsonPrimitive?.doubleOrNull?.let { if (d < it) errors += "$path must be >= $it" }
        schema["maximum"]?.jsonPrimitive?.doubleOrNull?.let { if (d > it) errors += "$path must be <= $it" }
    }

    private fun isBoolean(value: JsonElement): Boolean =
        value is JsonPrimitive && !value.isString && (value.content == "true" || value.content == "false")
}
