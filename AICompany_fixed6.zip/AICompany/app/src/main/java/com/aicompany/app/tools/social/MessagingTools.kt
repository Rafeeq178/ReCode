package com.aicompany.app.tools.social

import com.aicompany.app.data.AuditDao
import com.aicompany.app.provider.JSON_MEDIA
import com.aicompany.app.security.KeyVault
import com.aicompany.app.tools.ApprovalLevel
import com.aicompany.app.tools.Schema
import com.aicompany.app.tools.Tool
import com.aicompany.app.tools.ToolContext
import com.aicompany.app.tools.ToolResult
import com.aicompany.app.tools.ToolSpec
import com.aicompany.app.tools.builtin.stringArgument
import com.aicompany.app.util.Redactor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.Calendar
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.random.Random

/** Input rules and limits for messaging tools. Pure values, so they are easy to test. */
object MessagingRules {
    val CHAT = Regex("^(-?[0-9]{1,20}|@[A-Za-z][A-Za-z0-9_]{4,31})$")
    val PHONE = Regex("^[0-9]{8,15}$")
    const val MAX_TEXT = 4_000
    const val DAILY_LIMIT = 20
    const val MIN_DELAY_MS = 1_500L
    const val MAX_DELAY_MS = 4_000L
    const val TELEGRAM_TOOL = "telegram_send"
    const val WHATSAPP_TOOL = "whatsapp_send"
    const val TELEGRAM_TOKEN = "TELEGRAM_BOT_TOKEN"
    const val WHATSAPP_TOKEN = "WHATSAPP_TOKEN"
    const val WHATSAPP_PHONE_ID = "WHATSAPP_PHONE_ID"
}

/** Counts successful sends today from the audit log, so the limit survives restarts. */
@Singleton
class DailyLimiter @Inject constructor(private val audit: AuditDao) {
    suspend fun ensureUnderLimit(tool: String) {
        val used = audit.countOk(tool, startOfToday())
        require(used < MessagingRules.DAILY_LIMIT) { "Daily limit of ${MessagingRules.DAILY_LIMIT} messages reached" }
    }

    private fun startOfToday(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis
}

class TelegramSendTool @Inject constructor(
    private val vault: KeyVault,
    private val http: OkHttpClient,
    private val limiter: DailyLimiter,
) : Tool {
    override val spec = ToolSpec(
        name = MessagingRules.TELEGRAM_TOOL,
        description = "Send a text message with the owner's Telegram bot (official Bot API). Needs owner approval.",
        schema = Schema.obj(
            mapOf(
                "chat_id" to Schema.str("Chat id or @channel name", 40),
                "text" to Schema.str("Message text", MessagingRules.MAX_TEXT),
            ),
            listOf("chat_id", "text"),
        ),
        approval = ApprovalLevel.ASK,
        timeoutMs = 60_000,
    )

    override suspend fun execute(args: JsonObject, ctx: ToolContext): ToolResult = withContext(Dispatchers.IO) {
        val chat = stringArgument(args, "chat_id", 40)
        require(MessagingRules.CHAT.matches(chat)) { "chat_id is not valid" }
        val text = stringArgument(args, "text", MessagingRules.MAX_TEXT)
        val token = vault.getSecret(MessagingRules.TELEGRAM_TOKEN)
            ?: return@withContext ToolResult.Error("secret_missing", "The owner must save ${MessagingRules.TELEGRAM_TOKEN} first")
        limiter.ensureUnderLimit(MessagingRules.TELEGRAM_TOOL)
        delay(Random.nextLong(MessagingRules.MIN_DELAY_MS, MessagingRules.MAX_DELAY_MS))

        val body = buildJsonObject {
            put("chat_id", chat)
            put("text", text)
        }
        val req = Request.Builder()
            .url("https://api.telegram.org/bot$token/sendMessage")
            .post(body.toString().toRequestBody(JSON_MEDIA))
            .build()
        http.newBuilder().callTimeout(30, TimeUnit.SECONDS).build().newCall(req).execute().use { resp ->
            if (resp.isSuccessful) ToolResult.Ok("Message sent")
            else ToolResult.Error("http_${resp.code}", Redactor.redact("Telegram refused the message (HTTP ${resp.code})"))
        }
    }
}

class WhatsAppSendTool @Inject constructor(
    private val vault: KeyVault,
    private val http: OkHttpClient,
    private val limiter: DailyLimiter,
) : Tool {
    override val spec = ToolSpec(
        name = MessagingRules.WHATSAPP_TOOL,
        description = "Send a text message with the WhatsApp Business Cloud API. Recipient is a phone number with country code. Needs owner approval.",
        schema = Schema.obj(
            mapOf(
                "to" to Schema.str("Recipient phone number with country code, digits only", 15),
                "text" to Schema.str("Message text", MessagingRules.MAX_TEXT),
            ),
            listOf("to", "text"),
        ),
        approval = ApprovalLevel.ASK,
        timeoutMs = 60_000,
    )

    override suspend fun execute(args: JsonObject, ctx: ToolContext): ToolResult = withContext(Dispatchers.IO) {
        val to = stringArgument(args, "to", 15)
        require(MessagingRules.PHONE.matches(to)) { "Phone number must be digits with country code" }
        val text = stringArgument(args, "text", MessagingRules.MAX_TEXT)
        val token = vault.getSecret(MessagingRules.WHATSAPP_TOKEN)
            ?: return@withContext ToolResult.Error("secret_missing", "The owner must save ${MessagingRules.WHATSAPP_TOKEN} first")
        val phoneId = vault.getSecret(MessagingRules.WHATSAPP_PHONE_ID)
            ?: return@withContext ToolResult.Error("secret_missing", "The owner must save ${MessagingRules.WHATSAPP_PHONE_ID} first")
        limiter.ensureUnderLimit(MessagingRules.WHATSAPP_TOOL)
        delay(Random.nextLong(MessagingRules.MIN_DELAY_MS, MessagingRules.MAX_DELAY_MS))

        val body = buildJsonObject {
            put("messaging_product", "whatsapp")
            put("to", to)
            put("type", "text")
            put("text", buildJsonObject { put("body", text) })
        }
        val req = Request.Builder()
            .url("https://graph.facebook.com/v20.0/$phoneId/messages")
            .header("Authorization", "Bearer $token")
            .post(body.toString().toRequestBody(JSON_MEDIA))
            .build()
        http.newBuilder().callTimeout(30, TimeUnit.SECONDS).build().newCall(req).execute().use { resp ->
            if (resp.isSuccessful) ToolResult.Ok("Message sent")
            else ToolResult.Error("http_${resp.code}", "WhatsApp refused the message (HTTP ${resp.code})")
        }
    }
}
