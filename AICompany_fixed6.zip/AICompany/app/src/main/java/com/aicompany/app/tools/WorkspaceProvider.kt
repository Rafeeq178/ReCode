package com.aicompany.app.tools

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class WorkspaceProvider @Inject constructor(@ApplicationContext context: Context) {
    val sandbox: WorkspaceSandbox = WorkspaceSandbox(File(context.filesDir, "workspace"))
}
