package com.aicompany.app.approvals

import com.aicompany.app.tools.ApprovalLevel
import com.aicompany.app.tools.ToolSpec
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Enforcement lives in code, not in prompts. Models cannot bypass it.
 * AUTO: run. ASK: wait for the owner (never auto-approved). BLOCKED: never run.
 */
@Singleton
class ApprovalPolicy @Inject constructor(
    private val queue: ApprovalQueue,
) {
    private val grants = ConcurrentHashMap<String, Long>()

    suspend fun authorize(agentId: String, spec: ToolSpec, summary: String): AuthOutcome =
        when (spec.approval) {
            ApprovalLevel.AUTO -> AuthOutcome.Allowed("AUTO")
            ApprovalLevel.BLOCKED ->
                AuthOutcome.Denied("BLOCKED", "This action is blocked by owner policy and cannot be run.")
            ApprovalLevel.ASK -> askOwner(agentId, spec, summary)
        }

    private suspend fun askOwner(agentId: String, spec: ToolSpec, summary: String): AuthOutcome {
        val key = "$agentId|${spec.name}"
        val now = System.currentTimeMillis()
        if ((grants[key] ?: 0L) > now) return AuthOutcome.Allowed("GRANTED_1H")

        val request = ApprovalRequest(
            id = UUID.randomUUID().toString(),
            agentId = agentId,
            toolName = spec.name,
            summary = summary,
            requestedAt = now,
        )
        return when (queue.await(request, APPROVAL_TIMEOUT_MS)) {
            ApprovalDecision.APPROVED -> AuthOutcome.Allowed("APPROVED")
            ApprovalDecision.ALLOW_ONE_HOUR -> {
                grants[key] = System.currentTimeMillis() + ONE_HOUR_MS
                AuthOutcome.Allowed("APPROVED_1H")
            }
            ApprovalDecision.REJECTED -> AuthOutcome.Denied("REJECTED", "The owner rejected this action.")
            ApprovalDecision.TIMEOUT -> AuthOutcome.Denied("TIMEOUT", "Approval timed out. The action was cancelled.")
        }
    }

    companion object {
        const val APPROVAL_TIMEOUT_MS = 5 * 60 * 1000L
        const val ONE_HOUR_MS = 60 * 60 * 1000L
    }
}
