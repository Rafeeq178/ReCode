package com.aicompany.app.approvals

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

/** Holds pending approvals. The calling agent suspends until the owner answers or the timeout hits. */
@Singleton
class ApprovalQueue @Inject constructor() {

    private val _pending = MutableStateFlow<List<ApprovalRequest>>(emptyList())
    val pending: StateFlow<List<ApprovalRequest>> = _pending.asStateFlow()

    private val waiters = ConcurrentHashMap<String, CompletableDeferred<ApprovalDecision>>()

    suspend fun await(request: ApprovalRequest, timeoutMs: Long): ApprovalDecision {
        require(timeoutMs in 1_000..3_600_000) { "Approval timeout out of range" }
        val deferred = CompletableDeferred<ApprovalDecision>()
        waiters[request.id] = deferred
        _pending.update { it + request }
        return try {
            withTimeoutOrNull(timeoutMs) { deferred.await() } ?: ApprovalDecision.TIMEOUT
        } finally {
            waiters.remove(request.id)
            _pending.update { list -> list.filterNot { it.id == request.id } }
        }
    }

    /** Called from UI or a notification action. Returns false if the request is no longer pending. */
    fun resolve(requestId: String, decision: ApprovalDecision): Boolean =
        waiters[requestId]?.complete(decision) ?: false
}
