package com.aicompany.app.terminal

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import com.aicompany.app.ui.components.AppTopBar
import com.aicompany.app.ui.components.IconBadge
import com.aicompany.app.ui.components.PillButton
import com.aicompany.app.ui.components.SettingsGroup

@Composable
fun TerminalScreen(
    onMenu: () -> Unit,
    viewModel: TerminalViewModel = hiltViewModel(),
) {
    val install by viewModel.installState.collectAsState()
    val session by viewModel.session.collectAsState()
    val notice by viewModel.notice.collectAsState()

    LaunchedEffect(install) {
        if (install is InstallState.Done) viewModel.ensureSession()
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            AppTopBar(
                title = "Terminal",
                navIcon = Icons.Default.Menu,
                navDescription = "Menu",
                onNav = onMenu,
                actions = {
                    IconButton(onClick = viewModel::restartSession) {
                        Icon(Icons.Default.Refresh, contentDescription = "Restart shell")
                    }
                },
            )
        },
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            if (install !is InstallState.Done) {
                InstallPanel(install, onInstall = viewModel::install)
            }
            notice?.let {
                Text(
                    it,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
                )
            }
            val s = session
            if (install is InstallState.Done && s != null) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx -> TermuxBridge.createView(ctx).also { it.attachSession(s) } },
                    update = { view -> view.attachSession(s) },
                )
            }
        }
    }
}

@Composable
private fun InstallPanel(state: InstallState, onInstall: () -> Unit) {
    SettingsGroup(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBadge(Icons.Outlined.Code)
                Column(Modifier.padding(start = 14.dp)) {
                    Text("Linux terminal", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Alpine Linux, runs inside the app.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            when (state) {
                InstallState.Idle -> {
                    Text("Linux environment abhi install nahi hai (Alpine, ~few MB). Internet chahiye.")
                    PillButton(text = "Install Alpine", onClick = onInstall, modifier = Modifier.fillMaxWidth())
                }
                is InstallState.Downloading -> {
                    Text("Download ho raha hai: ${(state.progress * 100).toInt()}%")
                    LinearProgressIndicator(progress = { state.progress }, modifier = Modifier.fillMaxWidth())
                }
                InstallState.Verifying -> Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    Text("  Checksum verify ho raha hai")
                }
                InstallState.Extracting -> Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    Text("  Extract ho raha hai")
                }
                InstallState.Done -> Text("Alpine tayyar hai.")
                is InstallState.Failed -> {
                    Text(state.message, color = MaterialTheme.colorScheme.error)
                    PillButton(text = "Retry", onClick = onInstall, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}
