package com.aicompany.app.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.outlined.Cloud
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.ListAlt
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.VpnKey
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.aicompany.app.BuildConfig
import com.aicompany.app.prefs.UiPrefs
import com.aicompany.app.ui.components.AppTopBar
import com.aicompany.app.ui.components.RowDivider
import com.aicompany.app.ui.components.SettingsGroup
import com.aicompany.app.ui.components.SettingsRow

@Composable
fun SettingsScreen(
    onMenu: () -> Unit,
    onOpenProviders: () -> Unit,
    onOpenCompany: () -> Unit,
    onOpenLogs: () -> Unit,
    onOpenTerminal: () -> Unit,
    onOpenDrive: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel(),
) {
    val providers by viewModel.providers.collectAsState()
    val userName by viewModel.userName.collectAsState()
    val themeMode by viewModel.themeMode.collectAsState()
    var showName by remember { mutableStateOf(false) }
    var showTheme by remember { mutableStateOf(false) }
    var showReset by remember { mutableStateOf(false) }
    var resetResult by remember { mutableStateOf<String?>(null) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { AppTopBar("Settings", Icons.Default.Menu, "Menu", onMenu) },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            SettingsGroup {
                SettingsRow(
                    title = userName.ifBlank { "Set your name" },
                    subtitle = "Name used in the greeting",
                    icon = Icons.Outlined.Person,
                    chevron = true,
                    onClick = { showName = true },
                )
            }

            SettingsGroup {
                SettingsRow(
                    title = "Providers & keys",
                    subtitle = if (providers.isEmpty()) "None yet" else "${providers.size} configured",
                    icon = Icons.Outlined.VpnKey,
                    chevron = true,
                    onClick = onOpenProviders,
                )
                RowDivider(54.dp)
                SettingsRow(
                    title = "Local models",
                    subtitle = "${viewModel.localModelCount()} on this phone",
                    icon = Icons.Outlined.Memory,
                    chevron = true,
                    onClick = onOpenProviders,
                )
                RowDivider(54.dp)
                SettingsRow(title = "Google Drive", icon = Icons.Outlined.Cloud, chevron = true, onClick = onOpenDrive)
            }

            SettingsGroup {
                SettingsRow(title = "Company", subtitle = "Employees and tasks", icon = Icons.Outlined.Groups, chevron = true, onClick = onOpenCompany)
                RowDivider(54.dp)
                SettingsRow(title = "Live logs", subtitle = "Agent runs", icon = Icons.Outlined.ListAlt, chevron = true, onClick = onOpenLogs)
                RowDivider(54.dp)
                SettingsRow(title = "Terminal", subtitle = "Alpine Linux shell", icon = Icons.Outlined.Code, chevron = true, onClick = onOpenTerminal)
            }

            SettingsGroup {
                SettingsRow(
                    title = "Theme",
                    subtitle = themeLabel(themeMode),
                    icon = Icons.Outlined.Palette,
                    chevron = true,
                    onClick = { showTheme = true },
                )
                RowDivider(54.dp)
                SettingsRow(
                    title = "Reset secure storage",
                    subtitle = resetResult ?: "Use only if API keys cannot be saved or read",
                    icon = Icons.Outlined.VpnKey,
                    chevron = true,
                    onClick = { showReset = true },
                )
                RowDivider(54.dp)
                SettingsRow(title = "Version", subtitle = BuildConfig.VERSION_NAME, icon = Icons.Outlined.Info)
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showName) {
        var draft by remember { mutableStateOf(userName) }
        AlertDialog(
            onDismissRequest = { showName = false },
            containerColor = MaterialTheme.colorScheme.surface,
            title = { Text("Your name") },
            text = {
                OutlinedTextField(
                    value = draft,
                    onValueChange = { if (it.length <= 40) draft = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            },
            confirmButton = {
                TextButton(onClick = { viewModel.setUserName(draft); showName = false }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showName = false }) { Text("Cancel") } },
        )
    }

    if (showReset) {
        AlertDialog(
            onDismissRequest = { showReset = false },
            containerColor = MaterialTheme.colorScheme.surface,
            title = { Text("Reset secure storage?") },
            text = { Text("This deletes ALL saved API keys and secrets from this phone. Providers stay, but you must enter their keys again.") },
            confirmButton = {
                TextButton(onClick = {
                    showReset = false
                    resetResult = if (viewModel.resetSecureStorage()) "Reset done. Add your API keys again." else "Reset failed. Restart the app."
                }) { Text("Delete keys") }
            },
            dismissButton = { TextButton(onClick = { showReset = false }) { Text("Cancel") } },
        )
    }

    if (showTheme) {
        AlertDialog(
            onDismissRequest = { showTheme = false },
            containerColor = MaterialTheme.colorScheme.surface,
            title = { Text("Theme") },
            text = {
                Column {
                    listOf(UiPrefs.THEME_SYSTEM, UiPrefs.THEME_LIGHT, UiPrefs.THEME_DARK).forEach { mode ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.setThemeMode(mode); showTheme = false }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RadioButton(selected = themeMode == mode, onClick = { viewModel.setThemeMode(mode); showTheme = false })
                            Text(themeLabel(mode))
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showTheme = false }) { Text("Close") } },
        )
    }
}

private fun themeLabel(mode: String): String = when (mode) {
    UiPrefs.THEME_LIGHT -> "Light"
    UiPrefs.THEME_DARK -> "Dark"
    else -> "Follow system"
}
