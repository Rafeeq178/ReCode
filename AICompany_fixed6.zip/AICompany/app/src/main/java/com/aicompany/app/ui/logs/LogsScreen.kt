package com.aicompany.app.ui.logs

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.aicompany.app.data.AgentLogEntity
import com.aicompany.app.data.AgentRunEntity
import com.aicompany.app.ui.components.AppTopBar
import com.aicompany.app.ui.components.ChipFlow
import com.aicompany.app.ui.components.PillButton
import com.aicompany.app.ui.components.PillOutlinedButton

private val FILTERS = listOf("all", "model", "tool", "error")

@Composable
fun LogsScreen(
    onMenu: () -> Unit,
    viewModel: AgentsViewModel = hiltViewModel(),
) {
    val runs by viewModel.runs.collectAsState()
    val selected by viewModel.selected.collectAsState()
    val filter by viewModel.filter.collectAsState()
    val logs by viewModel.logs.collectAsState()
    val notice by viewModel.notice.collectAsState()
    var goal by rememberSaveable { mutableStateOf("") }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(notice) {
        notice?.let {
            snackbar.showSnackbar(it)
            viewModel.clearNotice()
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { AppTopBar("Live logs", Icons.Default.Menu, "Menu", onMenu) },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            OutlinedTextField(
                value = goal,
                onValueChange = { if (it.length <= 4000) goal = it },
                label = { Text("Goal for the Assistant") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2,
                maxLines = 4,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                PillButton(
                    text = "Run",
                    onClick = {
                        viewModel.start(goal)
                        goal = ""
                    },
                    enabled = goal.isNotBlank(),
                )
                PillOutlinedButton(
                    text = "Kill switch",
                    onClick = viewModel::killSwitch,
                    icon = Icons.Default.Warning,
                    danger = true,
                )
            }

            if (runs.isNotEmpty()) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(runs, key = { it.id }) { run ->
                        RunCard(
                            run = run,
                            selected = run.id == selected,
                            onSelect = { viewModel.select(run.id) },
                            onPause = { viewModel.pause(run.id) },
                            onResume = { viewModel.resume(run.id) },
                            onStop = { viewModel.stop(run.id) },
                        )
                    }
                }
            }

            ChipFlow {
                FILTERS.forEach { f ->
                    FilterChip(
                        selected = filter == f,
                        onClick = { viewModel.setFilter(f) },
                        label = { Text(f) },
                    )
                }
            }

            Surface(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            ) {
                if (logs.isEmpty()) {
                    Text(
                        "Abhi koi log nahi. Upar goal likh kar Run dabayein.",
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    LazyColumn(
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        items(logs, key = { it.id }) { log -> LogLine(log) }
                    }
                }
            }
        }
    }
}

@Composable
private fun RunCard(
    run: AgentRunEntity,
    selected: Boolean,
    onSelect: () -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onStop: () -> Unit,
) {
    val active = run.status == "RUNNING" || run.status == "PAUSED"
    Surface(
        modifier = Modifier.width(230.dp).clickable(onClick = onSelect),
        shape = MaterialTheme.shapes.medium,
        color = if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(run.agentName, fontWeight = FontWeight.SemiBold)
            Text(run.status, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.tertiary)
            Text(run.goal, maxLines = 2, style = MaterialTheme.typography.bodySmall)
            Text("steps: ${run.steps}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (run.reason.isNotEmpty() && !active) {
                Text(run.reason, style = MaterialTheme.typography.labelSmall, maxLines = 2, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (active) {
                Row {
                    if (run.status == "PAUSED") {
                        IconButton(onClick = onResume) { Icon(Icons.Default.PlayArrow, contentDescription = "Resume") }
                    } else {
                        IconButton(onClick = onPause) { Icon(Icons.Default.Pause, contentDescription = "Pause") }
                    }
                    IconButton(onClick = onStop) { Icon(Icons.Default.Stop, contentDescription = "Stop") }
                }
            }
        }
    }
}

@Composable
private fun LogLine(log: AgentLogEntity) {
    Text(
        text = "#${log.step} [${log.kind}] ${log.text}",
        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
        modifier = Modifier.fillMaxWidth(),
    )
}
