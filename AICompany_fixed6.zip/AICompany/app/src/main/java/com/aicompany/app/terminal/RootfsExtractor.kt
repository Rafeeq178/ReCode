package com.aicompany.app.terminal

import com.aicompany.app.util.Logger
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.nio.file.FileVisitResult
import java.nio.file.Files
import java.nio.file.LinkOption
import java.nio.file.Path
import java.nio.file.Paths
import java.nio.file.SimpleFileVisitor
import java.nio.file.StandardCopyOption
import java.nio.file.attribute.BasicFileAttributes
import java.util.zip.GZIPInputStream

/** Symlink-safe tar.gz extraction and deletion for the Alpine rootfs. */
object RootfsExtractor {
    /**
     * Extracts without ever following a symlink. Alpine's rootfs is full of symlinks with ABSOLUTE targets
     * (/bin/busybox, /run, /proc/mounts) that only make sense inside proot; on the Android host they point
     * at nothing or at system folders, so resolving them (canonicalFile, File.exists, FileOutputStream)
     * either fails or writes outside the rootfs. Everything here works on the link itself.
     * A failure names the archive entry, so the message shown in the terminal screen is actionable.
     */
    fun extract(archive: File, dest: File) {
        // The target folder may not exist (first run, cleared app data): create it, or say exactly why not.
        Files.createDirectories(dest.toPath())
        val root: Path = dest.canonicalFile.toPath()
        val hardLinks = mutableListOf<Pair<Path, String>>()
        TarArchiveInputStream(GZIPInputStream(BufferedInputStream(FileInputStream(archive)))).use { tar ->
            while (true) {
                val entry = tar.nextTarEntry ?: break
                val name = entry.name.removePrefix("./").trimEnd('/')
                if (name.isEmpty() || name == ".") continue
                ArchivePathGuard.check(name)?.let { throw IOException("Unsafe archive entry '$name' ($it)") }
                try {
                    extractEntry(tar, entry, name, root, hardLinks)
                } catch (e: Exception) {
                    throw IOException("Extract failed at '$name': ${e.javaClass.simpleName}: ${e.message}", e)
                }
            }
        }
        // Hard links are copied once every regular file exists.
        for ((target, linkName) in hardLinks) {
            val source = root.resolve(linkName.removePrefix("./")).normalize()
            if (!source.startsWith(root)) throw IOException("Hard link '$linkName' escapes the rootfs")
            if (Files.isRegularFile(source, LinkOption.NOFOLLOW_LINKS)) {
                Files.copy(source, target, StandardCopyOption.REPLACE_EXISTING)
            }
        }
    }

    private fun extractEntry(
        tar: TarArchiveInputStream,
        entry: org.apache.commons.compress.archivers.tar.TarArchiveEntry,
        name: String,
        root: Path,
        hardLinks: MutableList<Pair<Path, String>>,
    ) {
        val target = root.resolve(name).normalize()
        require(target.startsWith(root)) { "entry escapes the rootfs" }
        val parent = target.parent ?: return
        if (passesThroughSymlink(root, parent)) {
            Logger.w("Rootfs", "Skipped entry below a symlink: $name")
            return
        }
        when {
            entry.isDirectory -> {
                if (!Files.isSymbolicLink(target)) Files.createDirectories(target)
            }
            entry.isSymbolicLink -> {
                require(entry.linkName.length <= ArchivePathGuard.MAX_LINK) { "link target too long" }
                Files.createDirectories(parent)
                deleteLeaf(target)
                // Absolute targets are correct inside the chroot, so they are allowed.
                Files.createSymbolicLink(target, Paths.get(entry.linkName))
            }
            entry.isLink -> {
                Files.createDirectories(parent)
                hardLinks += target to entry.linkName
            }
            entry.isFile -> {
                Files.createDirectories(parent)
                deleteLeaf(target)   // never write through an existing symlink
                Files.copy(tar, target, StandardCopyOption.REPLACE_EXISTING)
                val file = target.toFile()
                file.setReadable(true, false)
                if (entry.mode and 0b001_000_000 != 0) file.setExecutable(true, false)
            }
            else -> Logger.w("Rootfs", "Skipped special file: $name")   // devices, fifos: proot binds /dev anyway
        }
    }

    /** True when any existing folder between the rootfs root and [dir] is a symlink. */
    private fun passesThroughSymlink(root: Path, dir: Path): Boolean {
        var current: Path = root
        for (part in root.relativize(dir)) {
            current = current.resolve(part)
            if (Files.isSymbolicLink(current)) return true
        }
        return false
    }

    /** Removes a file or symlink without following it. A real directory is left alone. */
    private fun deleteLeaf(path: Path) {
        if (Files.isSymbolicLink(path) || Files.isRegularFile(path, LinkOption.NOFOLLOW_LINKS)) Files.deleteIfExists(path)
    }

    /** Recursive delete that never follows symlinks (Kotlin's deleteRecursively does follow them). */
    fun deleteTree(dir: File) {
        val path = dir.toPath()
        if (!Files.exists(path, LinkOption.NOFOLLOW_LINKS)) return
        Files.walkFileTree(path, object : SimpleFileVisitor<Path>() {
            override fun visitFile(file: Path, attrs: BasicFileAttributes): FileVisitResult {
                Files.deleteIfExists(file)
                return FileVisitResult.CONTINUE
            }

            override fun postVisitDirectory(d: Path, exc: IOException?): FileVisitResult {
                Files.deleteIfExists(d)
                return FileVisitResult.CONTINUE
            }
        })
    }
}
