package com.aicompany.app.provider

enum class ApiFormat { OPENAI, ANTHROPIC, GEMINI, LOCAL }

/** role is one of: system, user, assistant */
data class ChatMessage(val role: String, val content: String)

data class ProviderConfig(
    val id: String,
    val name: String,
    val format: ApiFormat,
    val baseUrl: String,
    val model: String,
    val timeoutSeconds: Long = 60,
    val maxTokens: Int = 1024,
    val temperature: Double = 0.7,
    val extraHeaders: Map<String, String> = emptyMap(),
)

data class ChatParams(
    val maxTokens: Int,
    val temperature: Double,
    /** GBNF grammar, used only by local models. Cloud clients ignore it. */
    val grammar: String? = null,
    val grammarRoot: String = "root",
    /**
     * Queue priority on the local model, 0-9, lower runs first. The owner's chat and the CEO use
     * [PRIORITY_OWNER]; workers use [PRIORITY_WORKER]. Cloud clients ignore it.
     */
    val priority: Int = PRIORITY_WORKER,
    /**
     * How many leading messages must never be dropped when a local prompt has to be trimmed to fit
     * the context window (for an agent: the system prompt and the goal). Leading system messages
     * are always kept. Cloud clients ignore it.
     */
    val keepHead: Int = 0,
) {
    companion object {
        const val PRIORITY_OWNER = 0
        const val PRIORITY_WORKER = 5
    }
}

/** Sentinel "key" for endpoints that need none, such as a local llama-server or Ollama. */
const val NO_API_KEY = "no-key"

sealed class ProviderException(
    message: String,
    val retryable: Boolean,
    cause: Throwable? = null,
) : Exception(message, cause) {
    /** [retryAfterMs] comes from the provider's Retry-After header when it sent one. */
    class RateLimited(message: String, val retryAfterMs: Long? = null) : ProviderException(message, retryable = true)
    class Quota(message: String) : ProviderException(message, retryable = true)
    class Auth(message: String) : ProviderException(message, retryable = false)
    class BadRequest(message: String) : ProviderException(message, retryable = false)
    class Server(message: String, val code: Int) : ProviderException(message, retryable = true)
    class Network(message: String, cause: Throwable?) : ProviderException(message, retryable = true, cause = cause)

    /** The call ran out of time. Retrying the same provider would only wait again, so the chain moves on. */
    class Timeout(message: String) : ProviderException(message, retryable = false)

    /** The answer was cut off (context full or max tokens with a grammar), so it is incomplete. */
    class OutputTruncated(message: String) : ProviderException(message, retryable = false)

    /** Anything unexpected inside a client. Keeps the real message and lets the chain continue. */
    class Unexpected(message: String, cause: Throwable?) : ProviderException(message, retryable = false, cause = cause)
}
