package com.aicompany.app.tools

import com.aicompany.app.approvals.ApprovalPolicy
import com.aicompany.app.approvals.AuthOutcome
import com.aicompany.app.data.AuditRepository
import com.aicompany.app.tools.builtin.Calc
import com.aicompany.app.util.Redactor
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Single entry point for every tool call. Order of checks:
 * name -> assignment -> schema -> approval -> timeout-bounded execution -> output cap -> audit.
 * The model only ever sees ToolResult values, never secrets or raw exceptions.
 */
@Singleton
class ToolRegistry @Inject constructor(
    tools: Set<@JvmSuppressWildcards Tool>,
    private val approvals: ApprovalPolicy,
    private val audit: AuditRepository,
    private val workspace: WorkspaceProvider,
    private val custom: com.aicompany.app.tools.custom.CustomToolCatalog,
) {
    private val byName: Map<String, Tool> = tools.associateBy { it.spec.name }

    init {
        require(tools.size == byName.size) { "Duplicate tool names are not allowed" }
    }

    fun allNames(): Set<String> = byName.keys + custom.names()

    fun specsFor(allowed: Set<String>): List<ToolSpec> =
        (byName.values.map { it.spec } + custom.specs()).filter { it.name in allowed }

    suspend fun execute(
        agentId: String,
        call: ToolCall,
        allowed: Set<String>,
        skills: Set<String> = emptySet(),
    ): ToolResult {
        val tool = byName[call.name] ?: custom.get(call.name)
            ?: return ToolResult.Error("unknown_tool", "Tool '${call.name}' does not exist. Use only your assigned tools.")
        if (call.name !in allowed) {
            return ToolResult.Error("not_assigned", "Tool '${call.name}' is not assigned to you.")
        }

        val errors = SchemaValidator.validate(tool.spec.schema, call.arguments)
        if (errors.isNotEmpty()) {
            return ToolResult.Error("invalid_args", errors.joinToString("; "))
        }

        val summary = Redactor.redact("${call.name} ${call.arguments}").take(SUMMARY_MAX)
        val auth = approvals.authorize(agentId, tool.spec, summary)
        if (auth is AuthOutcome.Denied) {
            audit.record(agentId, call.name, summary, tool.spec.approval, auth.label, "error:denied")
            return ToolResult.Error("denied", auth.reason)
        }

        val raw: ToolResult = try {
            withTimeout(tool.spec.timeoutMs) {
                tool.execute(call.arguments, ToolContext(agentId, workspace.sandbox, skills))
            }
        } catch (e: TimeoutCancellationException) {
            ToolResult.Error("timeout", "Tool timed out after ${tool.spec.timeoutMs} ms")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            ToolResult.Error("tool_failed", Redactor.redact(e.message ?: "Tool failed").take(300))
        }

        val final = when (raw) {
            is ToolResult.Ok -> ToolResult.Ok(capOutput(Redactor.redact(raw.output), tool.spec.maxOutputChars))
            is ToolResult.Error -> raw
        }
        audit.record(agentId, call.name, summary, tool.spec.approval, auth.label, final.kind)
        return final
    }

    private fun capOutput(text: String, max: Int): String =
        if (text.length <= max) text else text.take(max) + "\n[output truncated at $max characters]"

    private companion object {
        const val SUMMARY_MAX = 500
    }
}
