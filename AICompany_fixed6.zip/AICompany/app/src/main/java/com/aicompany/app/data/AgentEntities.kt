package com.aicompany.app.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "agent_runs")
data class AgentRunEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val agentName: String,
    val goal: String,
    val status: String,
    val reason: String,
    val startedAt: Long,
    val endedAt: Long,
    val steps: Int,
)

@Entity(tableName = "agent_logs", indices = [Index("runId")])
data class AgentLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val runId: Long,
    val step: Int,
    val kind: String,
    val text: String,
    val createdAt: Long,
)

@Dao
interface AgentDao {
    @Insert
    suspend fun insertRun(entity: AgentRunEntity): Long

    @Query("UPDATE agent_runs SET status = :status WHERE id = :id")
    suspend fun updateStatus(id: Long, status: String)

    @Query("UPDATE agent_runs SET status = :status, reason = :reason, endedAt = :endedAt, steps = :steps WHERE id = :id")
    suspend fun finish(id: Long, status: String, reason: String, endedAt: Long, steps: Int)

    @Insert
    suspend fun insertLog(entity: AgentLogEntity)

    @Query("SELECT * FROM agent_runs ORDER BY id DESC LIMIT :limit")
    fun observeRuns(limit: Int): Flow<List<AgentRunEntity>>

    @Query("SELECT * FROM agent_logs WHERE runId = :runId ORDER BY id ASC")
    fun observeLogs(runId: Long): Flow<List<AgentLogEntity>>
}
