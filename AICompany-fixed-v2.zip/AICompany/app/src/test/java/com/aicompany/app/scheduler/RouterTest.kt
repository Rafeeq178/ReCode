package com.aicompany.app.scheduler

import org.junit.Assert.assertEquals
import org.junit.Test

class RouterTest {
    @Test fun codingWorkIsHeavy() {
        assertEquals(Router.Kind.HEAVY, Router.classify("Implement a login screen"))
    }

    @Test fun summaryWorkIsLight() {
        assertEquals(Router.Kind.LIGHT, Router.classify("Summarize these notes"))
    }

    @Test fun heavyAlwaysRoutesToApi() {
        assertEquals(Router.Route.API, Router.route(Router.Kind.HEAVY, localAvailable = true))
    }

    @Test fun lightUsesLocalWhenAvailable() {
        assertEquals(Router.Route.LOCAL, Router.route(Router.Kind.LIGHT, localAvailable = true))
        assertEquals(Router.Route.API, Router.route(Router.Kind.LIGHT, localAvailable = false))
    }
}
