// JNI bridge between LlamaNative (Kotlin) and llama.cpp.
// One model per handle. The Kotlin side serialises calls (LocalScheduler), so a handle
// is never used by two generations at once; the mutex is a second safety net.
#include <jni.h>
#include <android/log.h>
#include <atomic>
#include <cstring>
#include <mutex>
#include <string>
#include <vector>
#include <algorithm>
#include <mutex>
#include "llama.h"

#define LOG_TAG "AICompanyLLM"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {

constexpr int kStatusOk = 0;
constexpr int kStatusCancelled = 1;
constexpr int kStatusContextFull = 2;
constexpr int kErrDecode = -1;
constexpr int kErrTokenize = -2;
constexpr int kErrHandle = -3;
constexpr int kErrSampler = -4;

constexpr int kMinCtx = 256;
constexpr int kMaxCtx = 8192;
constexpr int kMaxThreads = 16;

struct Engine {
    llama_model * model = nullptr;
    llama_context * ctx = nullptr;
    const llama_vocab * vocab = nullptr;
    int n_ctx = 0;
    std::mutex run_lock;
    std::atomic<bool> cancel{false};
};

std::once_flag backend_once;

// Returns how many leading bytes form complete UTF-8 characters, so a multi-byte
// character split across tokens is never passed to NewStringUTF.
size_t complete_utf8_prefix(const std::string & s) {
    const size_t n = s.size();
    for (size_t back = 1; back <= 3 && back <= n; ++back) {
        const unsigned char c = static_cast<unsigned char>(s[n - back]);
        if ((c & 0xC0) == 0x80) continue;  // continuation byte, keep looking for the lead
        size_t need = 1;
        if ((c & 0xE0) == 0xC0) need = 2;
        else if ((c & 0xF0) == 0xE0) need = 3;
        else if ((c & 0xF8) == 0xF0) need = 4;
        return need > back ? n - back : n;
    }
    return n;
}

}  // namespace

extern "C" JNIEXPORT jlong JNICALL
Java_com_aicompany_app_llama_LlamaNative_nativeLoad(
        JNIEnv * env, jclass, jstring jpath, jint n_ctx, jint n_threads, jboolean use_mmap) {
    std::call_once(backend_once, [] { llama_backend_init(); });
    if (jpath == nullptr || n_ctx < kMinCtx || n_ctx > kMaxCtx || n_threads < 1 || n_threads > kMaxThreads) {
        return 0;
    }
    const char * path = env->GetStringUTFChars(jpath, nullptr);
    if (path == nullptr) return 0;

    llama_model_params mparams = llama_model_default_params();
    mparams.use_mmap = use_mmap == JNI_TRUE;
    mparams.n_gpu_layers = 0;
    llama_model * model = llama_model_load_from_file(path, mparams);
    env->ReleaseStringUTFChars(jpath, path);
    if (model == nullptr) {
        LOGE("model load failed");
        return 0;
    }

    llama_context_params cparams = llama_context_default_params();
    cparams.n_ctx = static_cast<uint32_t>(n_ctx);
    cparams.n_batch = static_cast<uint32_t>(n_ctx);
    cparams.n_threads = n_threads;
    cparams.n_threads_batch = n_threads;
    llama_context * ctx = llama_init_from_model(model, cparams);
    if (ctx == nullptr) {
        LOGE("context creation failed");
        llama_model_free(model);
        return 0;
    }

    auto * engine = new Engine();
    engine->model = model;
    engine->ctx = ctx;
    engine->vocab = llama_model_get_vocab(model);
    engine->n_ctx = n_ctx;
    return reinterpret_cast<jlong>(engine);
}

extern "C" JNIEXPORT void JNICALL
Java_com_aicompany_app_llama_LlamaNative_nativeFree(JNIEnv *, jclass, jlong handle) {
    auto * engine = reinterpret_cast<Engine *>(handle);
    if (engine == nullptr) return;
    std::lock_guard<std::mutex> guard(engine->run_lock);
    llama_free(engine->ctx);
    llama_model_free(engine->model);
    engine->ctx = nullptr;
    engine->model = nullptr;
    // Deleting while a waiter holds the mutex would be undefined behaviour; the Kotlin side
    // unloads only between requests, so no waiter can exist here.
    delete engine;
}

extern "C" JNIEXPORT void JNICALL
Java_com_aicompany_app_llama_LlamaNative_nativeCancel(JNIEnv *, jclass, jlong handle) {
    auto * engine = reinterpret_cast<Engine *>(handle);
    if (engine != nullptr) engine->cancel.store(true);
}

extern "C" JNIEXPORT jint JNICALL
Java_com_aicompany_app_llama_LlamaNative_nativeGenerate(
        JNIEnv * env, jclass, jlong handle, jstring jprompt, jint max_tokens, jfloat temperature,
        jlong seed, jstring jgrammar, jstring jgrammar_root, jobject sink) {
    auto * engine = reinterpret_cast<Engine *>(handle);
    if (engine == nullptr || jprompt == nullptr || sink == nullptr) return kErrHandle;
    std::lock_guard<std::mutex> guard(engine->run_lock);
    engine->cancel.store(false);

    // Callback target: TokenSink.onToken(String): Boolean
    jclass sink_class = env->GetObjectClass(sink);
    jmethodID on_token = env->GetMethodID(sink_class, "onToken", "(Ljava/lang/String;)Z");
    if (on_token == nullptr) {
        env->ExceptionClear();
        return kErrHandle;
    }

    // Each generation starts from an empty KV cache.
    llama_memory_clear(llama_get_memory(engine->ctx), true);

    const char * prompt = env->GetStringUTFChars(jprompt, nullptr);
    if (prompt == nullptr) return kErrHandle;
    const int32_t prompt_len = static_cast<int32_t>(std::strlen(prompt));
    std::vector<llama_token> tokens(static_cast<size_t>(prompt_len) + 16);
    int32_t n_tokens = llama_tokenize(engine->vocab, prompt, prompt_len,
                                      tokens.data(), static_cast<int32_t>(tokens.size()), true, true);
    if (n_tokens < 0) {
        tokens.resize(static_cast<size_t>(-n_tokens));
        n_tokens = llama_tokenize(engine->vocab, prompt, prompt_len,
                                  tokens.data(), static_cast<int32_t>(tokens.size()), true, true);
    }
    env->ReleaseStringUTFChars(jprompt, prompt);
    if (n_tokens <= 0) return kErrTokenize;
    tokens.resize(static_cast<size_t>(n_tokens));

    const int budget = engine->n_ctx - n_tokens;
    if (budget <= 0) return kStatusContextFull;
    const int limit = std::min<int>(max_tokens, budget);

    if (llama_decode(engine->ctx, llama_batch_get_one(tokens.data(), n_tokens)) != 0) {
        LOGE("prompt decode failed");
        return kErrDecode;
    }

    // Sampler chain. Grammar (if any) must come first so it filters every candidate.
    llama_sampler * smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    if (smpl == nullptr) return kErrSampler;
    if (jgrammar != nullptr && jgrammar_root != nullptr) {
        const char * grammar = env->GetStringUTFChars(jgrammar, nullptr);
        const char * root = env->GetStringUTFChars(jgrammar_root, nullptr);
        llama_sampler * gs = llama_sampler_init_grammar(engine->vocab, grammar, root);
        env->ReleaseStringUTFChars(jgrammar, grammar);
        env->ReleaseStringUTFChars(jgrammar_root, root);
        if (gs == nullptr) {
            llama_sampler_free(smpl);
            return kErrSampler;
        }
        llama_sampler_chain_add(smpl, gs);
    }
    if (temperature <= 0.0f) {
        llama_sampler_chain_add(smpl, llama_sampler_init_greedy());
    } else {
        llama_sampler_chain_add(smpl, llama_sampler_init_top_k(40));
        llama_sampler_chain_add(smpl, llama_sampler_init_top_p(0.95f, 1));
        llama_sampler_chain_add(smpl, llama_sampler_init_temp(temperature));
        llama_sampler_chain_add(smpl, llama_sampler_init_dist(static_cast<uint32_t>(seed)));
    }

    int status = kStatusOk;
    std::string pending;  // bytes not yet emitted (incomplete UTF-8 tail)
    char piece[256];
    for (int produced = 0; produced < limit; ++produced) {
        if (engine->cancel.load()) {
            status = kStatusCancelled;
            break;
        }
        const llama_token tok = llama_sampler_sample(smpl, engine->ctx, -1);
        if (llama_vocab_is_eog(engine->vocab, tok)) break;

        const int len = llama_token_to_piece(engine->vocab, tok, piece, sizeof(piece), 0, false);
        if (len > 0) {
            pending.append(piece, static_cast<size_t>(len));
            const size_t emit_len = complete_utf8_prefix(pending);
            if (emit_len > 0) {
                jstring text = env->NewStringUTF(std::string(pending.data(), emit_len).c_str());
                pending.erase(0, emit_len);
                const jboolean keep_going = env->CallBooleanMethod(sink, on_token, text);
                env->DeleteLocalRef(text);
                if (env->ExceptionCheck()) {
                    env->ExceptionClear();
                    status = kErrHandle;
                    break;
                }
                if (keep_going == JNI_FALSE) {
                    status = kStatusCancelled;
                    break;
                }
            }
        }

        if (llama_decode(engine->ctx, llama_batch_get_one(const_cast<llama_token *>(&tok), 1)) != 0) {
            status = kErrDecode;
            break;
        }
    }
    llama_sampler_free(smpl);
    return status;
}
