package com.aicompany.app.ui.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aicompany.app.data.ChatMessageUi
import com.aicompany.app.data.ChatRepository
import com.aicompany.app.data.ProviderRepository
import com.aicompany.app.provider.ChatGateway
import com.aicompany.app.provider.ChatMessage
import com.aicompany.app.provider.ChatParams
import com.aicompany.app.provider.ProviderConfig
import com.aicompany.app.provider.ProviderException
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

private const val CONVERSATION_ID = "default"
private const val MAX_HISTORY_MESSAGES = 30
private const val MAX_INPUT_CHARS = 8000

@HiltViewModel
class ChatViewModel @Inject constructor(
    private val chatRepo: ChatRepository,
    private val providerRepo: ProviderRepository,
    private val gateway: ChatGateway,
) : ViewModel() {

    val messages: StateFlow<List<ChatMessageUi>> = chatRepo.observe(CONVERSATION_ID)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val providers: StateFlow<List<ProviderConfig>> = providerRepo.observe()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _streaming = MutableStateFlow<String?>(null)
    val streaming: StateFlow<String?> = _streaming.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private var job: Job? = null

    fun send(raw: String) {
        val text = raw.trim()
        if (text.isEmpty() || _busy.value) return
        if (text.length > MAX_INPUT_CHARS) {
            _error.value = "Message is too long (max $MAX_INPUT_CHARS characters)"
            return
        }
        job = viewModelScope.launch {
            _busy.value = true
            _error.value = null
            val chain = providers.value
            if (chain.isEmpty()) {
                _error.value = "Pehle Providers screen mein koi provider add karein"
                _busy.value = false
                return@launch
            }
            chatRepo.append(CONVERSATION_ID, "user", text, null)

            val history = (messages.value + ChatMessageUi(-1, "user", text, null))
                .takeLast(MAX_HISTORY_MESSAGES)
                .map { ChatMessage(it.role, it.content) }

            val primary = chain.first()
            val params = ChatParams(maxTokens = primary.maxTokens, temperature = primary.temperature)
            val answer = StringBuilder()
            _streaming.value = ""
            try {
                gateway.stream(chain, history, params).collect { token ->
                    answer.append(token)
                    _streaming.value = answer.toString()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: ProviderException) {
                _error.value = e.message ?: "Provider error"
            } catch (e: Exception) {
                _error.value = "Unexpected error: ${e.javaClass.simpleName}"
            } finally {
                // Keep partial answers even when the owner pressed Stop.
                withContext(NonCancellable) {
                    if (answer.isNotEmpty()) {
                        chatRepo.append(CONVERSATION_ID, "assistant", answer.toString(), null)
                    }
                    _streaming.value = null
                    _busy.value = false
                }
            }
        }
    }

    fun stop() {
        job?.cancel()
    }

    fun clearError() {
        _error.value = null
    }

    fun clearChat() {
        if (_busy.value) return
        viewModelScope.launch { chatRepo.clear(CONVERSATION_ID) }
    }
}
