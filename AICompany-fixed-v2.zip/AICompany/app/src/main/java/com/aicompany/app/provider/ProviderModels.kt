package com.aicompany.app.provider

enum class ApiFormat { OPENAI, ANTHROPIC, GEMINI, LOCAL }

/** role is one of: system, user, assistant */
data class ChatMessage(val role: String, val content: String)

data class ProviderConfig(
    val id: String,
    val name: String,
    val format: ApiFormat,
    val baseUrl: String,
    val model: String,
    val timeoutSeconds: Long = 60,
    val maxTokens: Int = 1024,
    val temperature: Double = 0.7,
    val extraHeaders: Map<String, String> = emptyMap(),
)

data class ChatParams(
    val maxTokens: Int,
    val temperature: Double,
    /** GBNF grammar, used only by local models. Cloud clients ignore it. */
    val grammar: String? = null,
    val grammarRoot: String = "root",
)

sealed class ProviderException(
    message: String,
    val retryable: Boolean,
    cause: Throwable? = null,
) : Exception(message, cause) {
    class RateLimited(message: String) : ProviderException(message, retryable = true)
    class Quota(message: String) : ProviderException(message, retryable = true)
    class Auth(message: String) : ProviderException(message, retryable = false)
    class BadRequest(message: String) : ProviderException(message, retryable = false)
    class Server(message: String, val code: Int) : ProviderException(message, retryable = true)
    class Network(message: String, cause: Throwable?) : ProviderException(message, retryable = true, cause = cause)
}
