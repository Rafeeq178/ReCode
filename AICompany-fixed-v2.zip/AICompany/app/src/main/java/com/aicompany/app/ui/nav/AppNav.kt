package com.aicompany.app.ui.nav

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.aicompany.app.terminal.TerminalScreen
import com.aicompany.app.ui.chat.ChatScreen
import com.aicompany.app.ui.company.CompanyScreen
import com.aicompany.app.ui.drive.DriveConnectScreen
import com.aicompany.app.ui.company.EmployeeEditorScreen
import com.aicompany.app.ui.company.NEW_EMPLOYEE_ID
import com.aicompany.app.ui.logs.LogsScreen
import com.aicompany.app.ui.providers.ProvidersScreen

object Routes {
    const val CHAT = "chat"
    const val PROVIDERS = "providers"
    const val LOGS = "logs"
    const val TERMINAL = "terminal"
    const val COMPANY = "company"
    const val EMPLOYEE = "employee/{employeeId}"
    const val DRIVE = "drive"
}

@Composable
fun AppNav() {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = Routes.CHAT) {
        composable(Routes.CHAT) {
            ChatScreen(
                onOpenProviders = { nav.navigate(Routes.PROVIDERS) },
                onOpenLogs = { nav.navigate(Routes.LOGS) },
                onOpenTerminal = { nav.navigate(Routes.TERMINAL) },
                onOpenCompany = { nav.navigate(Routes.COMPANY) },
            )
        }
        composable(Routes.PROVIDERS) {
            ProvidersScreen(onBack = { nav.popBackStack() })
        }
        composable(Routes.LOGS) {
            LogsScreen(onBack = { nav.popBackStack() })
        }
        composable(Routes.TERMINAL) {
            TerminalScreen(onBack = { nav.popBackStack() })
        }
        composable(Routes.COMPANY) {
            CompanyScreen(
                onBack = { nav.popBackStack() },
                onOpenEmployee = { id -> nav.navigate("employee/$id") },
                onNewEmployee = { nav.navigate("employee/$NEW_EMPLOYEE_ID") },
                onOpenDrive = { nav.navigate(Routes.DRIVE) },
            )
        }
        composable(Routes.DRIVE) {
            DriveConnectScreen(onBack = { nav.popBackStack() })
        }
        composable(Routes.EMPLOYEE) {
            EmployeeEditorScreen(onBack = { nav.popBackStack() })
        }
    }
}
