package com.aicompany.app.ui.company

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.aicompany.app.company.EmployeeRules
import com.aicompany.app.company.EmployeeSnapshot
import com.aicompany.app.company.EmployeeStatus
import com.aicompany.app.data.EmployeeVersionEntity
import com.aicompany.app.data.SkillEntity
import com.aicompany.app.provider.ProviderConfig

/** Form state for one snapshot. Recreated whenever the loaded snapshot changes (for example after rollback). */
private class EditorState(s: EmployeeSnapshot) {
    var name by mutableStateOf(s.name)
    var role by mutableStateOf(s.role)
    var prompt by mutableStateOf(s.systemPrompt)
    var model by mutableStateOf(s.model)
    var maxSteps by mutableStateOf(s.maxSteps.toString())
    var timeout by mutableStateOf(s.timeoutSeconds.toString())
    var maxTokens by mutableStateOf(s.maxTokens.toString())
    var temperature by mutableStateOf(s.temperature.toString())
    var priority by mutableStateOf(s.localPriority.toString())
    var permission by mutableStateOf(s.terminalPermission)
    var ceoCanModify by mutableStateOf(s.ceoCanModify)
    var paused by mutableStateOf(s.status == EmployeeStatus.PAUSED.name)
    var tools by mutableStateOf(s.tools.toSet())
    var providerIds by mutableStateOf(s.providerIds.toSet())
    var skillIds by mutableStateOf(s.skillIds.toSet())

    /** Builds the snapshot or returns the first problem in plain English. */
    fun build(providerOrder: List<String>): Result<EmployeeSnapshot> = runCatching {
        EmployeeSnapshot(
            name = name.trim(),
            role = role.trim(),
            systemPrompt = prompt,
            tools = tools.sorted(),
            skillIds = skillIds.sorted(),
            providerIds = providerOrder.filter { it in providerIds },
            model = model.trim(),
            maxSteps = maxSteps.trim().toInt(),
            timeoutSeconds = timeout.trim().toLong(),
            maxTokens = maxTokens.trim().toInt(),
            temperature = temperature.trim().toDouble(),
            terminalPermission = permission,
            localPriority = priority.trim().toInt(),
            ceoCanModify = ceoCanModify,
            color = "#C9623F",
            status = if (paused) EmployeeStatus.PAUSED.name else EmployeeStatus.IDLE.name,
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmployeeEditorScreen(
    onBack: () -> Unit,
    viewModel: EmployeeEditorViewModel = hiltViewModel(),
) {
    val snapshot by viewModel.snapshot.collectAsState()
    val providers by viewModel.providerList.collectAsState()
    val skills by viewModel.skills.collectAsState()
    val versions by viewModel.versions.collectAsState()
    val notice by viewModel.notice.collectAsState()
    val created by viewModel.created.collectAsState()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(notice) {
        notice?.let {
            snackbar.showSnackbar(it)
            viewModel.clearNotice()
        }
    }
    LaunchedEffect(created) {
        if (created != null) {
            viewModel.clearCreated()
            onBack()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (viewModel.isNew) "New worker" else "Edit worker", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        val current = snapshot
        if (current == null) {
            Text("Loading...", modifier = Modifier.padding(padding).padding(16.dp))
        } else {
            EditorForm(
                modifier = Modifier.fillMaxSize().padding(padding),
                snapshot = current,
                isNew = viewModel.isNew,
                providers = providers,
                toolNames = viewModel.toolNames,
                skills = skills,
                versions = versions,
                onSave = { s, report -> viewModel.save(s) },
                onReport = viewModel::report,
                onRollback = viewModel::rollback,
                onFire = viewModel::fire,
                onSaveTemplate = viewModel::saveTemplate,
                onAddSkill = viewModel::addSkill,
            )
        }
    }
}

@Composable
private fun EditorForm(
    modifier: Modifier,
    snapshot: EmployeeSnapshot,
    isNew: Boolean,
    providers: List<ProviderConfig>,
    toolNames: List<String>,
    skills: List<SkillEntity>,
    versions: List<EmployeeVersionEntity>,
    onSave: (EmployeeSnapshot, String) -> Unit,
    onReport: (String) -> Unit,
    onRollback: (Int) -> Unit,
    onFire: () -> Unit,
    onSaveTemplate: (String) -> Unit,
    onAddSkill: (String, String, String) -> Unit,
) {
    val state = remember(snapshot) { EditorState(snapshot) }
    var templateName by remember { mutableStateOf("") }
    var skillName by remember { mutableStateOf("") }
    var skillDescription by remember { mutableStateOf("") }
    var skillText by remember { mutableStateOf("") }
    val providerOrder = providers.map { it.id }

    Column(
        modifier = modifier.verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Section("Identity") {
            OutlinedTextField(state.name, { state.name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(state.role, { state.role = it }, label = { Text("Role") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(
                state.prompt,
                { if (it.length <= EmployeeRules.MAX_PROMPT) state.prompt = it },
                label = { Text("Extra instructions (optional)") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                maxLines = 8,
            )
            OutlinedButton(onClick = { state.prompt = "" }) { Text("Reset to default") }
        }

        Section("Model and providers") {
            OutlinedTextField(state.model, { state.model = it }, label = { Text("Model override (primary provider, optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Text("Providers (order follows the Providers screen):", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                providers.forEach { p ->
                    FilterChip(
                        selected = p.id in state.providerIds,
                        onClick = {
                            state.providerIds = if (p.id in state.providerIds) state.providerIds - p.id else state.providerIds + p.id
                        },
                        label = { Text(p.name) },
                    )
                }
            }
            Text("No provider selected means all providers, in order.", style = MaterialTheme.typography.bodySmall)
        }

        Section("Limits") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(state.maxSteps, { state.maxSteps = it }, label = { Text("Max steps") }, singleLine = true, modifier = Modifier.weight(1f))
                OutlinedTextField(state.timeout, { state.timeout = it }, label = { Text("Timeout s") }, singleLine = true, modifier = Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(state.maxTokens, { state.maxTokens = it }, label = { Text("Max tokens") }, singleLine = true, modifier = Modifier.weight(1f))
                OutlinedTextField(state.temperature, { state.temperature = it }, label = { Text("Temperature") }, singleLine = true, modifier = Modifier.weight(1f))
            }
            OutlinedTextField(state.priority, { state.priority = it }, label = { Text("Local queue priority (0 high, 9 low)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }

        Section("Terminal permission") {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                EmployeeRules.PERMISSIONS.sorted().forEach { p ->
                    FilterChip(selected = state.permission == p, onClick = { state.permission = p }, label = { Text(p) })
                }
            }
            Text("Terminal commands always ask the owner in this version.", style = MaterialTheme.typography.bodySmall)
        }

        Section("Tools") {
            toolNames.chunked(3).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    row.forEach { t ->
                        FilterChip(
                            selected = t in state.tools,
                            onClick = { state.tools = if (t in state.tools) state.tools - t else state.tools + t },
                            label = { Text(t) },
                        )
                    }
                }
            }
        }

        Section("Skills") {
            if (skills.isEmpty()) Text("No skills yet. Create one below.", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                skills.forEach { s ->
                    FilterChip(
                        selected = s.id in state.skillIds,
                        onClick = { state.skillIds = if (s.id in state.skillIds) state.skillIds - s.id else state.skillIds + s.id },
                        label = { Text(s.name) },
                    )
                }
            }
            OutlinedTextField(skillName, { skillName = it }, label = { Text("New skill name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(skillDescription, { skillDescription = it }, label = { Text("Description") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(skillText, { skillText = it }, label = { Text("Instructions") }, minLines = 3, modifier = Modifier.fillMaxWidth())
            OutlinedButton(
                onClick = {
                    onAddSkill(skillName, skillDescription, skillText)
                    skillName = ""
                    skillDescription = ""
                    skillText = ""
                },
                enabled = skillName.isNotBlank() && skillText.isNotBlank(),
            ) { Text("Save skill") }
        }

        Section("Behaviour") {
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text("Paused", modifier = Modifier.weight(1f))
                Switch(checked = state.paused, onCheckedChange = { state.paused = it })
            }
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text("CEO may modify this worker", modifier = Modifier.weight(1f))
                Switch(checked = state.ceoCanModify, onCheckedChange = { state.ceoCanModify = it })
            }
        }

        Button(
            onClick = {
                state.build(providerOrder)
                    .onSuccess { onSave(it, "") }
                    .onFailure { onReport(it.message ?: "Please check the fields") }
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text(if (isNew) "Hire worker" else "Save changes") }

        if (!isNew) {
            Section("Version history") {
                if (versions.isEmpty()) Text("No versions yet.", style = MaterialTheme.typography.bodySmall)
                versions.take(20).forEach { v ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(10.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Text("Version ${v.version}", modifier = Modifier.weight(1f))
                            OutlinedButton(onClick = { onRollback(v.version) }) { Text("Rollback") }
                        }
                    }
                }
            }

            Section("Save as template") {
                OutlinedTextField(templateName, { templateName = it }, label = { Text("Template name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedButton(onClick = { onSaveTemplate(templateName); templateName = "" }, enabled = templateName.isNotBlank()) {
                    Text("Save template")
                }
            }

            OutlinedButton(onClick = onFire, modifier = Modifier.fillMaxWidth()) { Text("Fire this worker") }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            content()
        }
    }
}
