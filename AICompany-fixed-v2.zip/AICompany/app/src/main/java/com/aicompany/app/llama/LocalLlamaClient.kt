package com.aicompany.app.llama

import com.aicompany.app.local.LocalScheduler
import com.aicompany.app.local.ModelStore
import com.aicompany.app.provider.ChatMessage
import com.aicompany.app.provider.ChatParams
import com.aicompany.app.provider.ProviderClient
import com.aicompany.app.provider.ProviderConfig
import com.aicompany.app.provider.ProviderException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import javax.inject.Inject

/**
 * Runs a GGUF model from ModelStore on device. The config.model is the file name.
 * Owner and CEO requests get priority 0; workers get 5 (see LocalScheduler).
 */
class LocalLlamaClient @Inject constructor(
    private val engine: LlamaEngine,
    private val scheduler: LocalScheduler,
    private val models: ModelStore,
) : ProviderClient {

    override fun chat(
        config: ProviderConfig,
        apiKey: String,
        messages: List<ChatMessage>,
        params: ChatParams,
    ): Flow<String> = channelFlow {
        val file = models.file(config.model)
        val prompt = ChatTemplate.chatMl(messages)
        val priority = if (config.id == "ceo") PRIORITY_OWNER else PRIORITY_WORKER
        scheduler.submit(priority, config.timeoutSeconds * 1000) {
            engine.ensureLoaded(file).getOrElse { throw ProviderException.BadRequest(it.message ?: "Model load failed") }
            val status = engine.generate(
                prompt = prompt,
                maxTokens = params.maxTokens,
                temperature = params.temperature,
                seed = System.nanoTime(),
                grammar = params.grammar,
                grammarRoot = params.grammarRoot,
                onToken = { text -> trySend(text).isSuccess },
            )
            if (status < 0) throw ProviderException.Server("Local model failed (code $status)", 500)
        }
    }

    companion object {
        const val PRIORITY_OWNER = 0
        const val PRIORITY_WORKER = 5
    }
}
