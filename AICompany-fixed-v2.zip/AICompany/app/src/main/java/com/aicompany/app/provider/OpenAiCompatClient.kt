package com.aicompany.app.provider

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import javax.inject.Inject

/** Works with OpenAI, Groq, OpenRouter and any OpenAI-compatible endpoint. */
class OpenAiCompatClient @Inject constructor(
    private val http: OkHttpClient,
    private val json: Json,
) : ProviderClient {

    override fun chat(
        config: ProviderConfig,
        apiKey: String,
        messages: List<ChatMessage>,
        params: ChatParams,
    ): Flow<String> = flow {
        requireHttps(config.baseUrl)
        val body = buildJsonObject {
            put("model", config.model)
            put("stream", true)
            put("max_tokens", params.maxTokens)
            put("temperature", params.temperature)
            put("messages", buildJsonArray {
                messages.forEach { m ->
                    add(buildJsonObject {
                        put("role", m.role)
                        put("content", m.content)
                    })
                }
            })
        }
        val request = Request.Builder()
            .url(joinUrl(config.baseUrl, "/chat/completions"))
            .header("Authorization", "Bearer $apiKey")
            .header("Accept", "text/event-stream")
            .applyExtraHeaders(config)
            .post(body.toString().toRequestBody(JSON_MEDIA))
            .build()

        http.forProvider(config).executeOrThrow(request).use { response ->
            if (!response.isSuccessful) {
                throw mapHttpError(response.code, response.body?.string().orEmpty())
            }
            val source = response.body?.source()
                ?: throw ProviderException.Server("Empty response", 502)
            while (true) {
                val line = source.readUtf8Line() ?: break
                if (!line.startsWith("data:")) continue
                val data = line.removePrefix("data:").trim()
                if (data == "[DONE]") break
                val text = json.parseToJsonElement(data).jsonObject["choices"]
                    ?.jsonArray?.firstOrNull()?.jsonObject
                    ?.get("delta")?.jsonObject
                    ?.get("content")?.jsonPrimitive?.contentOrNull
                if (!text.isNullOrEmpty()) emit(text)
            }
        }
    }.flowOn(Dispatchers.IO)
}
