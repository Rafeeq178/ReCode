package com.aicompany.app.agents

import com.aicompany.app.data.AgentRunRepository
import com.aicompany.app.data.ProviderRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Owns every running agent. Runs live in an app-level scope, not in a screen,
 * so leaving the Logs screen does not stop work. Pause, resume, stop and kill switch live here.
 */
@Singleton
class AgentRunner @Inject constructor(
    private val loop: AgentLoop,
    private val runs: AgentRunRepository,
    private val providers: ProviderRepository,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val jobs = ConcurrentHashMap<Long, Job>()
    private val paused = MutableStateFlow<Set<Long>>(emptySet())

    suspend fun start(config: AgentConfig, goal: String): Long {
        val cleanGoal = goal.trim()
        require(cleanGoal.isNotEmpty()) { "Goal is empty" }
        require(cleanGoal.length <= AgentRunRepository.MAX_GOAL_CHARS) { "Goal is too long" }
        val chain = providers.observe().first()
        require(chain.isNotEmpty()) { "Add a provider first" }

        val runId = runs.createRun(config.name, cleanGoal)
        val job = scope.launch {
            var outcome = RunOutcome(RunStatus.FAILED, "Run ended unexpectedly", 0)
            try {
                outcome = withTimeoutOrNull(config.timeoutMs) {
                    loop.run(runId, config, cleanGoal, chain) { awaitResume(runId) }
                } ?: RunOutcome(RunStatus.TIMED_OUT, "Time limit reached", 0)
            } catch (e: CancellationException) {
                outcome = RunOutcome(RunStatus.STOPPED, "Stopped by owner", outcome.steps)
                throw e
            } catch (e: Exception) {
                outcome = RunOutcome(RunStatus.FAILED, "Unexpected error: ${e.javaClass.simpleName}", outcome.steps)
            } finally {
                withContext(NonCancellable) {
                    runs.finish(runId, outcome.status, outcome.reason, outcome.steps)
                }
                jobs.remove(runId)
                paused.update { it - runId }
            }
        }
        jobs[runId] = job
        if (job.isCompleted) jobs.remove(runId)
        return runId
    }

    suspend fun pause(runId: Long) {
        if (!jobs.containsKey(runId)) return
        paused.update { it + runId }
        runs.setStatus(runId, RunStatus.PAUSED)
    }

    suspend fun resume(runId: Long) {
        if (!paused.value.contains(runId)) return
        paused.update { it - runId }
        runs.setStatus(runId, RunStatus.RUNNING)
    }

    fun stop(runId: Long) {
        paused.update { it - runId }
        jobs[runId]?.cancel()
    }

    /** Kill switch: cancels every running agent immediately. */
    fun stopAll() {
        paused.value = emptySet()
        jobs.values.toList().forEach { it.cancel() }
    }

    fun isRunning(runId: Long): Boolean = jobs.containsKey(runId)

    private suspend fun awaitResume(runId: Long) {
        paused.first { runId !in it }
    }
}
