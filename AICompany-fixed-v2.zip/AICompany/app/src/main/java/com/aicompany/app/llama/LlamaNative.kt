package com.aicompany.app.llama

/**
 * JNI entry points. The C++ side lives in app/src/main/cpp/aicompany_llm.cpp.
 * If the native library is missing (for example a build without llama.cpp),
 * [available] is false and the local provider reports a clear error instead of crashing.
 */
object LlamaNative {
    val available: Boolean = try {
        System.loadLibrary("aicompany_llm")
        true
    } catch (e: UnsatisfiedLinkError) {
        false
    }

    external fun nativeLoad(path: String, nCtx: Int, nThreads: Int, useMmap: Boolean): Long
    external fun nativeFree(handle: Long)
    external fun nativeCancel(handle: Long)
    external fun nativeGenerate(
        handle: Long,
        prompt: String,
        maxTokens: Int,
        temperature: Float,
        seed: Long,
        grammar: String?,
        grammarRoot: String?,
        sink: TokenSink,
    ): Int
}

/** Receives tokens from native code. Native code calls [onToken]; return false to stop. */
class TokenSink(private val consumer: (String) -> Boolean) {
    fun onToken(text: String): Boolean = consumer(text)
}
