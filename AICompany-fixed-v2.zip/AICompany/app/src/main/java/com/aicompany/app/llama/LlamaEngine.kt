package com.aicompany.app.llama

import com.aicompany.app.local.MemoryMonitor
import com.aicompany.app.local.RamGuard
import com.aicompany.app.util.Logger
import dagger.hilt.android.qualifiers.ApplicationContext
import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Owns the single loaded local model. Only one model is ever loaded.
 * Unloads automatically under system memory pressure. Not thread-safe by itself:
 * callers go through LocalScheduler, which runs one request at a time.
 */
@Singleton
class LlamaEngine @Inject constructor(
    @ApplicationContext private val context: Context,
    private val memory: MemoryMonitor,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var handle: Long = 0L
    private var loadedName: String? = null

    init {
        scope.launch {
            memory.trimLevel.collect { level ->
                if (memory.shouldUnloadModel(level)) unload()
            }
        }
    }

    val isLoaded: Boolean get() = handle != 0L

    /** Loads a GGUF file unless the same one is already loaded. Checks RAM before loading. */
    fun ensureLoaded(file: File, nCtx: Int = DEFAULT_CTX, threads: Int = DEFAULT_THREADS): Result<Unit> = runCatching {
        check(LlamaNative.available) { "Local engine is not included in this build" }
        require(file.isFile) { "Model file is missing" }
        if (handle != 0L && loadedName == file.name) return@runCatching
        val verdict = RamGuard.assess(file.length(), memory.availableBytes())
        check(verdict != RamGuard.Verdict.TOO_LARGE) { "This model is too large for the free memory on this phone" }
        if (verdict == RamGuard.Verdict.TIGHT) Logger.w("Llama", "Model is close to the memory limit")
        unload()
        val h = LlamaNative.nativeLoad(file.absolutePath, nCtx, threads, true)
        check(h != 0L) { "The model could not be loaded" }
        handle = h
        loadedName = file.name
    }

    /**
     * Generates text. Tokens are delivered to [onToken] as they are produced. Returns the native status code.
     * Status 0 = finished, 1 = cancelled or consumer stopped, 2 = context full, negative = error.
     */
    fun generate(
        prompt: String,
        maxTokens: Int,
        temperature: Double,
        seed: Long,
        grammar: String?,
        grammarRoot: String,
        onToken: (String) -> Boolean,
    ): Int {
        check(handle != 0L) { "No model is loaded" }
        return LlamaNative.nativeGenerate(
            handle, prompt, maxTokens, temperature.toFloat(), seed, grammar, grammarRoot,
            TokenSink(onToken),
        )
    }

    fun cancel() {
        if (handle != 0L) LlamaNative.nativeCancel(handle)
    }

    fun unload() {
        if (handle != 0L) {
            LlamaNative.nativeFree(handle)
            handle = 0L
            loadedName = null
        }
    }

    companion object {
        const val DEFAULT_CTX = 2048
        const val DEFAULT_THREADS = 4
    }
}
