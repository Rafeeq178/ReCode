package com.aicompany.app.local

import android.app.ActivityManager
import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/** Reports free RAM and the latest system trim level. The local engine unloads on high trim levels. */
@Singleton
class MemoryMonitor @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val am = context.getSystemService(ActivityManager::class.java)

    private val _trimLevel = MutableStateFlow(0)
    val trimLevel: StateFlow<Int> = _trimLevel.asStateFlow()

    fun availableBytes(): Long {
        val info = ActivityManager.MemoryInfo()
        am?.getMemoryInfo(info)
        return info.availMem
    }

    fun isLowMemory(): Boolean {
        val info = ActivityManager.MemoryInfo()
        am?.getMemoryInfo(info)
        return info.lowMemory
    }

    /** Called from Application.onTrimMemory. */
    fun onTrim(level: Int) {
        _trimLevel.value = level
    }

    /** True when the system asks apps to release memory (TRIM_MEMORY_RUNNING_CRITICAL and above). */
    fun shouldUnloadModel(level: Int): Boolean = level >= RUNNING_CRITICAL

    companion object {
        const val RUNNING_CRITICAL = 15
    }
}
