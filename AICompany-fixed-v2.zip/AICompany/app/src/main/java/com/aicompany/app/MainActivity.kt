package com.aicompany.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.aicompany.app.ui.nav.AppNav
import com.aicompany.app.ui.theme.AICompanyTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AICompanyTheme {
                Surface(modifier = Modifier, color = androidx.compose.material3.MaterialTheme.colorScheme.background) {
                    AppNav()
                }
            }
        }
    }
}
