package com.aicompany.app

import android.app.Application
import com.aicompany.app.local.MemoryMonitor
import com.aicompany.app.tools.custom.CustomToolCatalog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class AiCompanyApp : Application() {

    @Inject lateinit var memory: MemoryMonitor
    @Inject lateinit var customTools: CustomToolCatalog

    private val startupScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        startupScope.launch { customTools.reload() }
    }

    /** Forwards system memory pressure so the local engine can unload when needed. */
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        memory.onTrim(level)
    }
}
