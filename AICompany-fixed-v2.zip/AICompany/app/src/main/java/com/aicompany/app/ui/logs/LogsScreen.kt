package com.aicompany.app.ui.logs

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.aicompany.app.data.AgentLogEntity
import com.aicompany.app.data.AgentRunEntity

private val FILTERS = listOf("all", "model", "tool", "error")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LogsScreen(
    onBack: () -> Unit,
    viewModel: AgentsViewModel = hiltViewModel(),
) {
    val runs by viewModel.runs.collectAsState()
    val selected by viewModel.selected.collectAsState()
    val filter by viewModel.filter.collectAsState()
    val logs by viewModel.logs.collectAsState()
    val notice by viewModel.notice.collectAsState()
    var goal by rememberSaveable { mutableStateOf("") }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(notice) {
        notice?.let {
            snackbar.showSnackbar(it)
            viewModel.clearNotice()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Live Logs", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            OutlinedTextField(
                value = goal,
                onValueChange = { if (it.length <= 4000) goal = it },
                label = { Text("Goal for the Assistant") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 4,
                keyboardOptions = KeyboardOptions.Default,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        viewModel.start(goal)
                        goal = ""
                    },
                    enabled = goal.isNotBlank(),
                ) { Text("Run") }
                OutlinedButton(onClick = viewModel::killSwitch) {
                    Icon(Icons.Default.Warning, contentDescription = null)
                    Text(" Kill switch")
                }
            }

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(runs, key = { it.id }) { run ->
                    RunCard(
                        run = run,
                        selected = run.id == selected,
                        onSelect = { viewModel.select(run.id) },
                        onPause = { viewModel.pause(run.id) },
                        onResume = { viewModel.resume(run.id) },
                        onStop = { viewModel.stop(run.id) },
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FILTERS.forEach { f ->
                    FilterChip(
                        selected = filter == f,
                        onClick = { viewModel.setFilter(f) },
                        label = { Text(f) },
                    )
                }
            }

            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(logs, key = { it.id }) { log -> LogLine(log) }
            }
        }
    }
}

@Composable
private fun RunCard(
    run: AgentRunEntity,
    selected: Boolean,
    onSelect: () -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onStop: () -> Unit,
) {
    val active = run.status == "RUNNING" || run.status == "PAUSED"
    Card(
        onClick = onSelect,
        modifier = Modifier.width(220.dp),
        colors = androidx.compose.material3.CardDefaults.cardColors(
            containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surface,
        ),
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(run.agentName, fontWeight = FontWeight.Bold)
            Text(run.status, style = MaterialTheme.typography.labelMedium)
            Text(run.goal, maxLines = 2, style = MaterialTheme.typography.bodySmall)
            Text("steps: ${run.steps}", style = MaterialTheme.typography.labelSmall)
            if (run.reason.isNotEmpty() && !active) {
                Text(run.reason, style = MaterialTheme.typography.labelSmall, maxLines = 2)
            }
            if (active) {
                Row {
                    if (run.status == "PAUSED") {
                        IconButton(onClick = onResume) { Icon(Icons.Default.PlayArrow, contentDescription = "Resume") }
                    } else {
                        IconButton(onClick = onPause) { Icon(Icons.Default.Pause, contentDescription = "Pause") }
                    }
                    IconButton(onClick = onStop) { Icon(Icons.Default.Stop, contentDescription = "Stop") }
                }
            }
        }
    }
}

@Composable
private fun LogLine(log: AgentLogEntity) {
    Text(
        text = "#${log.step} [${log.kind}] ${log.text}",
        style = MaterialTheme.typography.bodySmall,
        modifier = Modifier.fillMaxWidth(),
    )
}
