package com.aicompany.app.security

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Stores API keys and named secrets in Android Keystore-backed encrypted preferences.
 * Provider keys are keyed by provider id; secrets are keyed by "secret:NAME".
 * Nothing here is written to Room, logs, or prompts.
 */
@Singleton
class KeyVault @Inject constructor(@ApplicationContext context: Context) {

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "ai_company_keys",
        MasterKey.Builder(context).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
    )

    fun keysFor(providerId: String): List<String> =
        prefs.getString(providerId, null)
            ?.split('\n')
            ?.map { it.trim() }
            ?.filter { it.isNotEmpty() }
            ?: emptyList()

    fun saveKeys(providerId: String, keys: List<String>) {
        val cleaned = keys.map { it.trim() }.filter { it.isNotEmpty() }
        require(cleaned.all { it.length <= MAX_KEY_LENGTH && !it.contains('\n') }) { "Invalid key format" }
        prefs.edit().putString(providerId, cleaned.joinToString("\n")).apply()
    }

    fun deleteKeys(providerId: String) {
        prefs.edit().remove(providerId).apply()
    }

    fun saveSecret(name: String, value: String) {
        require(SECRET_NAME.matches(name)) { "Secret name must be UPPER_CASE letters, digits or underscores" }
        require(value.isNotEmpty() && value.length <= MAX_SECRET_LENGTH) { "Secret value must be 1-2048 characters" }
        prefs.edit().putString("$SECRET_PREFIX$name", value).apply()
    }

    /** Returns the secret value. Callers must never show it to a model or log it. */
    fun getSecret(name: String): String? {
        if (!SECRET_NAME.matches(name)) return null
        return prefs.getString("$SECRET_PREFIX$name", null)
    }

    fun deleteSecret(name: String) {
        prefs.edit().remove("$SECRET_PREFIX$name").apply()
    }

    /** Stores a larger encrypted value, for example an OAuth state. Never shown to models. */
    fun saveBlob(name: String, value: String) {
        require(SECRET_NAME.matches(name)) { "Blob name is invalid" }
        require(value.isNotEmpty() && value.length <= MAX_BLOB_LENGTH) { "Value is too large" }
        prefs.edit().putString("$BLOB_PREFIX$name", value).apply()
    }

    fun getBlob(name: String): String? {
        if (!SECRET_NAME.matches(name)) return null
        return prefs.getString("$BLOB_PREFIX$name", null)
    }

    fun deleteBlob(name: String) {
        prefs.edit().remove("$BLOB_PREFIX$name").apply()
    }

    companion object {
        const val MAX_KEY_LENGTH = 512
        const val MAX_BLOB_LENGTH = 16_384
        private const val BLOB_PREFIX = "blob:"
        const val MAX_SECRET_LENGTH = 2048
        private const val SECRET_PREFIX = "secret:"
        private val SECRET_NAME = Regex("^[A-Z][A-Z0-9_]{0,39}$")
    }
}
