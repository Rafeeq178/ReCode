package com.aicompany.app.provider

import com.aicompany.app.security.KeyVault
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject
import javax.inject.Singleton

/** A provider with its key source resolved, ready to call. */
data class RoutedProvider(val config: ProviderConfig)

/**
 * Sends a chat through an ordered fallback chain of providers.
 * - Rotates keys on rate limit / quota.
 * - Retries transient errors with exponential backoff.
 * - Moves to the next provider on failure, but only before any token was shown,
 *   so the owner never sees a half answer glued to a different model's answer.
 */
@Singleton
class ChatGateway @Inject constructor(
    private val clients: Map<ApiFormat, @JvmSuppressWildcards ProviderClient>,
    private val vault: KeyVault,
    private val rotator: KeyRotator,
) {
    fun stream(
        chain: List<ProviderConfig>,
        messages: List<ChatMessage>,
        params: ChatParams,
    ): Flow<String> = flow {
        require(chain.isNotEmpty()) { "No provider configured" }
        var lastError: Throwable? = null

        for (config in chain) {
            val keys = if (config.format == ApiFormat.LOCAL) listOf(LOCAL_KEY) else vault.keysFor(config.id)
            if (keys.isEmpty()) {
                lastError = ProviderException.Auth("No API key for ${config.name}")
                continue
            }
            val client = clients[config.format]
                ?: throw IllegalStateException("No client for ${config.format}")

            var attempt = 0
            var emittedAny = false
            providerLoop@ while (attempt < MAX_ATTEMPTS_PER_PROVIDER) {
                attempt++
                val key = rotator.nextKey(config.id, keys) ?: break@providerLoop
                try {
                    client.chat(config, key, messages, params).collect { token ->
                        emittedAny = true
                        emit(token)
                    }
                    return@flow
                } catch (e: ProviderException) {
                    lastError = e
                    if (emittedAny) throw e
                    when (e) {
                        is ProviderException.RateLimited, is ProviderException.Quota -> {
                            rotator.markCooling(config.id, key)
                            continue@providerLoop
                        }
                        is ProviderException.Server, is ProviderException.Network -> {
                            delay(backoffMillis(attempt))
                            continue@providerLoop
                        }
                        else -> break@providerLoop
                    }
                }
            }
        }
        throw lastError ?: ProviderException.Server("All providers failed", 503)
    }

    private fun backoffMillis(attempt: Int): Long = (500L shl (attempt - 1).coerceAtMost(4))

    companion object {
        private const val MAX_ATTEMPTS_PER_PROVIDER = 3
        private const val LOCAL_KEY = "local-no-key"
    }
}
