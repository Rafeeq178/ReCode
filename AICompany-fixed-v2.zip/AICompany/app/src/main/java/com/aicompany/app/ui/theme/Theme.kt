package com.aicompany.app.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

// Palette taken from the Vethos reference (style.css :root, light + night).
private val LightColors = lightColorScheme(
    primary = Color(0xFFC9623F),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFFBEDE6),
    onPrimaryContainer = Color(0xFFB4512F),
    background = Color(0xFFFAF9F5),
    onBackground = Color(0xFF1F1A17),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1F1A17),
    surfaceVariant = Color(0xFFF3EFE8),
    onSurfaceVariant = Color(0xFF5B534D),
    outline = Color(0xFFE8E4DA),
    error = Color(0xFFF0221B),
    errorContainer = Color(0xFFFFE9E8),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFDB7A58),
    onPrimary = Color(0xFF14110F),
    primaryContainer = Color(0xFF4A2A1E),
    onPrimaryContainer = Color(0xFFF1D2C4),
    background = Color(0xFF14110F),
    onBackground = Color(0xFFE8E6E3),
    surface = Color(0xFF1E1F24),
    onSurface = Color(0xFFE8E6E3),
    surfaceVariant = Color(0xFF2B2D33),
    onSurfaceVariant = Color(0xFF9AA0A6),
    outline = Color(0xFF3A3D45),
    error = Color(0xFFFF6B66),
    errorContainer = Color(0xFF5C1E1C),
)

@Composable
fun AICompanyTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val context = LocalContext.current
    val colors = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        darkTheme -> DarkColors
        else -> LightColors
    }
    MaterialTheme(colorScheme = colors, content = content)
}
