package com.aicompany.app.ui.company

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.aicompany.app.company.TaskStatus
import com.aicompany.app.data.TaskEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CompanyScreen(
    onBack: () -> Unit,
    onOpenEmployee: (String) -> Unit,
    onNewEmployee: () -> Unit,
    onOpenDrive: () -> Unit,
    viewModel: CompanyViewModel = hiltViewModel(),
) {
    val employees by viewModel.employees.collectAsState()
    val tasks by viewModel.tasks.collectAsState()
    val active by viewModel.active.collectAsState()
    val notice by viewModel.notice.collectAsState()
    var goal by rememberSaveable { mutableStateOf("") }
    var hireName by rememberSaveable { mutableStateOf("") }
    var hireRole by rememberSaveable { mutableStateOf("") }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(notice) {
        notice?.let {
            snackbar.showSnackbar(it)
            viewModel.clearNotice()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Company", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(12.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Goal for the CEO", style = MaterialTheme.typography.titleSmall)
            OutlinedTextField(
                value = goal,
                onValueChange = { if (it.length <= 4000) goal = it },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 4,
                placeholder = { Text("Goal likhein, CEO plan banayega") },
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        viewModel.runCeo(goal)
                        goal = ""
                    },
                    enabled = goal.isNotBlank(),
                ) { Text("Send to CEO") }
                OutlinedButton(onClick = viewModel::stopAll) {
                    Icon(Icons.Default.Warning, contentDescription = null)
                    Text(" Stop all")
                }
            }
            Text("Active: $active", style = MaterialTheme.typography.labelLarge)

            Text("Employees", style = MaterialTheme.typography.titleSmall)
            OutlinedButton(onClick = onOpenDrive) { Text("Google Drive connection") }
            OutlinedButton(onClick = onNewEmployee) { Text("New worker (full editor)") }
            employees.forEach { e ->
                Card(modifier = Modifier.fillMaxWidth(), onClick = { onOpenEmployee(e.id) }) {
                    Row(Modifier.padding(12.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(e.name, fontWeight = FontWeight.Bold)
                            Text("${e.role} · ${e.status}", style = MaterialTheme.typography.bodySmall)
                        }
                        if (e.status != "FIRED") {
                            OutlinedButton(onClick = { viewModel.fire(e.id) }) { Text("Fire") }
                        }
                    }
                }
            }

            Text("Hire a worker", style = MaterialTheme.typography.titleSmall)
            OutlinedTextField(hireName, { hireName = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(hireRole, { hireRole = it }, label = { Text("Role") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Button(
                onClick = {
                    viewModel.hire(hireName, hireRole)
                    hireName = ""
                    hireRole = ""
                },
                enabled = hireName.isNotBlank() && hireRole.isNotBlank(),
            ) { Text("Hire (default tools)") }

            Text("Task board", style = MaterialTheme.typography.titleSmall)
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                TaskStatus.entries.forEach { status ->
                    BoardColumn(status, tasks.filter { it.status == status.name })
                }
            }
        }
    }
}

@Composable
private fun BoardColumn(status: TaskStatus, items: List<TaskEntity>) {
    Column(
        modifier = Modifier.width(200.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text("${status.name} (${items.size})", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
        items.forEach { t ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp)) {
                    Text(t.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                    if (t.result.isNotEmpty()) {
                        Text(t.result.take(200), style = MaterialTheme.typography.bodySmall, maxLines = 4)
                    }
                }
            }
        }
    }
}
