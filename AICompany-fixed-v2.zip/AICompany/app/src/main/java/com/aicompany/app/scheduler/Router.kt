package com.aicompany.app.scheduler

/**
 * Heavy work (code, planning, research) goes to API models.
 * Light, private work goes to the local model when one is available (local model arrives in Step 6).
 */
object Router {
    enum class Kind { HEAVY, LIGHT }
    enum class Route { API, LOCAL }

    private val HEAVY_HINTS = listOf(
        "code", "implement", "debug", "plan", "research", "analy", "build", "design", "refactor", "test",
    )

    fun classify(text: String): Kind {
        val lower = text.lowercase()
        return if (HEAVY_HINTS.any { lower.contains(it) }) Kind.HEAVY else Kind.LIGHT
    }

    fun route(kind: Kind, localAvailable: Boolean): Route = when {
        kind == Kind.HEAVY -> Route.API
        localAvailable -> Route.LOCAL
        else -> Route.API
    }
}
