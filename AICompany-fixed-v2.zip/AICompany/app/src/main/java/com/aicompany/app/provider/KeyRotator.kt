package com.aicompany.app.provider

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Round-robins over a provider's keys and puts keys that hit rate limits or quota
 * on cooldown, so the next request uses a different key automatically.
 */
@Singleton
class KeyRotator @Inject constructor() {

    private val cooldownUntil = ConcurrentHashMap<String, Long>()
    private val cursor = ConcurrentHashMap<String, AtomicInteger>()

    /** Returns the next usable key, or null when there are no keys. */
    fun nextKey(providerId: String, keys: List<String>): String? {
        if (keys.isEmpty()) return null
        val now = System.currentTimeMillis()
        val start = cursor.getOrPut(providerId) { AtomicInteger(0) }.getAndIncrement()
        for (offset in keys.indices) {
            val key = keys[Math.floorMod(start + offset, keys.size)]
            if ((cooldownUntil[cooldownKey(providerId, key)] ?: 0L) <= now) return key
        }
        // Every key is cooling down: use the one that becomes available first.
        return keys.minByOrNull { cooldownUntil[cooldownKey(providerId, it)] ?: 0L }
    }

    fun markCooling(providerId: String, key: String, millis: Long = DEFAULT_COOLDOWN_MS) {
        cooldownUntil[cooldownKey(providerId, key)] = System.currentTimeMillis() + millis
    }

    private fun cooldownKey(providerId: String, key: String) = "$providerId|${key.hashCode()}"

    companion object {
        const val DEFAULT_COOLDOWN_MS = 60_000L
    }
}
