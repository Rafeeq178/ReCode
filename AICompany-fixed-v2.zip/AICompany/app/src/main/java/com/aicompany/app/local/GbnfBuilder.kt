package com.aicompany.app.local

/**
 * Builds a GBNF grammar that forces the local model to output exactly one JSON object:
 * {"tool": <one of the allowed names>, "arguments": {...}} or {"done": "..."}.
 * Tool names are validated here, so a grammar never contains an unexpected token.
 */
object GbnfBuilder {
    private val NAME = Regex("^[a-z][a-z0-9_]{1,40}$")
    private const val MAX_TOOLS = 64

    private const val HEAD = """root ::= ws "{" ws ( toolpart | donepart ) ws "}"
toolpart ::= "\"tool\"" ws ":" ws toolname ws "," ws "\"arguments\"" ws ":" ws object
donepart ::= "\"done\"" ws ":" ws string
"""

    private const val TAIL = """object ::= "{" ws ( pair ( ws "," ws pair )* )? ws "}"
pair ::= string ws ":" ws value
value ::= string | number | "true" | "false" | "null" | object | array
array ::= "[" ws ( value ( ws "," ws value )* )? ws "]"
string ::= "\"" ( [^"\\] | "\\" [\"\\/bfnrt] | "\\u" [0-9a-fA-F] [0-9a-fA-F] [0-9a-fA-F] [0-9a-fA-F] )* "\""
number ::= "-"? [0-9]+ ("." [0-9]+)? ([eE] [-+]? [0-9]+)?
ws ::= [ \t\n\r]*
"""

    fun toolCallGrammar(toolNames: Collection<String>): String {
        require(toolNames.isNotEmpty()) { "At least one tool is required" }
        require(toolNames.size <= MAX_TOOLS) { "Too many tools for one grammar" }
        require(toolNames.all { NAME.matches(it) }) { "Tool names must be lowercase letters, digits or underscores" }
        val alternatives = toolNames.distinct().sorted().joinToString(" | ") { "\"\\\"$it\\\"\"" }
        return buildString {
            append(HEAD)
            append("toolname ::= ").append(alternatives).append('\n')
            append(TAIL)
        }
    }
}
