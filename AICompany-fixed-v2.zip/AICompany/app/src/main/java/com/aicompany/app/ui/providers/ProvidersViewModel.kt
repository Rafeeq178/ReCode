package com.aicompany.app.ui.providers

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aicompany.app.data.ProviderDraft
import com.aicompany.app.data.ProviderRepository
import com.aicompany.app.provider.ChatGateway
import com.aicompany.app.provider.ChatMessage
import com.aicompany.app.provider.ChatParams
import com.aicompany.app.provider.ProviderConfig
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ProvidersViewModel @Inject constructor(
    private val repo: ProviderRepository,
    private val gateway: ChatGateway,
) : ViewModel() {

    val providers: StateFlow<List<ProviderConfig>> = repo.observe()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _status = MutableStateFlow<String?>(null)
    val status: StateFlow<String?> = _status.asStateFlow()

    fun save(draft: ProviderDraft, onSaved: () -> Unit) {
        viewModelScope.launch {
            runCatching { repo.save(draft) }
                .onSuccess {
                    _status.value = "Saved. Connection test ke liye 'Test' dabayein."
                    onSaved()
                }
                .onFailure { _status.value = it.message ?: "Save failed" }
        }
    }

    fun delete(id: String) {
        viewModelScope.launch { repo.delete(id) }
    }

    fun test(id: String) {
        viewModelScope.launch {
            _status.value = "Testing..."
            val config = repo.get(id)
            if (config == null) {
                _status.value = "Provider nahi mila"
                return@launch
            }
            val result = runCatching {
                gateway.stream(
                    chain = listOf(config),
                    messages = listOf(ChatMessage("user", "Reply with the single word OK.")),
                    params = ChatParams(maxTokens = 16, temperature = 0.0),
                ).toList()
            }
            _status.value = result.fold(
                onSuccess = { tokens -> if (tokens.isEmpty()) "Provider ne koi jawab nahi diya" else "Connection OK: ${config.name}" },
                onFailure = { it.message ?: "Test failed" },
            )
        }
    }

    fun clearStatus() {
        _status.value = null
    }
}
