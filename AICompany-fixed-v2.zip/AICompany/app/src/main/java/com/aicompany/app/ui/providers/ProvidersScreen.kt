package com.aicompany.app.ui.providers

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.aicompany.app.data.ProviderDraft
import com.aicompany.app.provider.ApiFormat
import com.aicompany.app.provider.ProviderConfig

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProvidersScreen(
    onBack: () -> Unit,
    viewModel: ProvidersViewModel = hiltViewModel(),
) {
    val providers by viewModel.providers.collectAsState()
    val status by viewModel.status.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    var editing by remember { mutableStateOf<ProviderConfig?>(null) }
    var showEditor by remember { mutableStateOf(false) }

    LaunchedEffect(status) {
        status?.let {
            snackbar.showSnackbar(it)
            viewModel.clearStatus()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Providers & Keys", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = {
                editing = null
                showEditor = true
            }) {
                Icon(Icons.Default.Add, contentDescription = "Add provider")
            }
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        if (providers.isEmpty()) {
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("Abhi koi provider nahi hai. + dabakar add karein.")
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(providers, key = { it.id }) { p ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text(p.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text(
                                "${p.format.name} · ${p.model}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Text(
                                p.baseUrl,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                                TextButton(onClick = { viewModel.test(p.id) }) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                                    Text(" Test")
                                }
                                IconButton(onClick = {
                                    editing = p
                                    showEditor = true
                                }) { Icon(Icons.Default.Edit, contentDescription = "Edit") }
                                IconButton(onClick = { viewModel.delete(p.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEditor) {
        ProviderEditorDialog(
            initial = editing,
            onDismiss = { showEditor = false },
            onSave = { draft ->
                viewModel.save(draft) { showEditor = false }
            },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProviderEditorDialog(
    initial: ProviderConfig?,
    onDismiss: () -> Unit,
    onSave: (ProviderDraft) -> Unit,
) {
    var name by rememberSaveable { mutableStateOf(initial?.name ?: "") }
    var format by rememberSaveable { mutableStateOf(initial?.format ?: ApiFormat.OPENAI) }
    var baseUrl by rememberSaveable { mutableStateOf(initial?.baseUrl ?: "https://api.openai.com/v1") }
    var model by rememberSaveable { mutableStateOf(initial?.model ?: "") }
    var keys by rememberSaveable { mutableStateOf("") }      // never pre-filled: keys stay in the vault
    var maxTokens by rememberSaveable { mutableStateOf((initial?.maxTokens ?: 1024).toString()) }
    var temperature by rememberSaveable { mutableStateOf((initial?.temperature ?: 0.7).toString()) }
    var timeout by rememberSaveable { mutableStateOf((initial?.timeoutSeconds ?: 60).toString()) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Naya provider" else "Provider edit karein") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OutlinedTextField(name, { name = it }, label = { Text("Naam") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Text("API format", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ApiFormat.entries.forEach { f ->
                        FilterChip(selected = format == f, onClick = { format = f }, label = { Text(f.name) })
                    }
                }
                OutlinedTextField(baseUrl, { baseUrl = it }, label = { Text("Base URL (https)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(model, { model = it }, label = { Text("Model name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    keys, { keys = it },
                    label = { Text(if (initial == null) "API key(s), har line mein ek" else "Nayi key(s) (khali chhodein to purani rahegi)") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 1,
                    maxLines = 4,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(maxTokens, { maxTokens = it }, label = { Text("Max tokens") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(temperature, { temperature = it }, label = { Text("Temp") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(timeout, { timeout = it }, label = { Text("Timeout s") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            Button(onClick = {
                val parsed = runCatching {
                    ProviderDraft(
                        id = initial?.id,
                        name = name,
                        format = format,
                        baseUrl = baseUrl,
                        model = model,
                        keysText = keys,
                        maxTokens = maxTokens.toInt(),
                        temperature = temperature.toDouble(),
                        timeoutSeconds = timeout.toLong(),
                    )
                }
                parsed.onSuccess { error = null; onSave(it) }
                    .onFailure { error = "Numbers sahi format mein daalein" }
            }) { Text("Save") }
        },
        dismissButton = { OutlinedButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
