package com.aicompany.app.provider

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import javax.inject.Inject

class GeminiClient @Inject constructor(
    private val http: OkHttpClient,
    private val json: Json,
) : ProviderClient {

    override fun chat(
        config: ProviderConfig,
        apiKey: String,
        messages: List<ChatMessage>,
        params: ChatParams,
    ): Flow<String> = flow {
        requireHttps(config.baseUrl)
        require(config.model.matches(Regex("^[A-Za-z0-9._-]+$"))) { "Invalid model name" }
        val system = messages.filter { it.role == "system" }.joinToString("\n") { it.content }
        val turns = messages.filter { it.role != "system" }
        val body = buildJsonObject {
            if (system.isNotBlank()) {
                put("systemInstruction", buildJsonObject {
                    put("parts", buildJsonArray { add(buildJsonObject { put("text", system) }) })
                })
            }
            put("contents", buildJsonArray {
                turns.forEach { m ->
                    add(buildJsonObject {
                        put("role", if (m.role == "assistant") "model" else "user")
                        put("parts", buildJsonArray { add(buildJsonObject { put("text", m.content) }) })
                    })
                }
            })
            put("generationConfig", buildJsonObject {
                put("maxOutputTokens", params.maxTokens)
                put("temperature", params.temperature)
            })
        }
        val url = joinUrl(config.baseUrl, "/v1beta/models/${config.model}:streamGenerateContent?alt=sse")
        val request = Request.Builder()
            .url(url)
            .header("x-goog-api-key", apiKey)
            .header("Accept", "text/event-stream")
            .applyExtraHeaders(config)
            .post(body.toString().toRequestBody(JSON_MEDIA))
            .build()

        http.forProvider(config).executeOrThrow(request).use { response ->
            if (!response.isSuccessful) {
                throw mapHttpError(response.code, response.body?.string().orEmpty())
            }
            val source = response.body?.source()
                ?: throw ProviderException.Server("Empty response", 502)
            while (true) {
                val line = source.readUtf8Line() ?: break
                if (!line.startsWith("data:")) continue
                val obj = json.parseToJsonElement(line.removePrefix("data:").trim()).jsonObject
                val parts = obj["candidates"]?.jsonArray?.firstOrNull()?.jsonObject
                    ?.get("content")?.jsonObject?.get("parts")?.jsonArray
                parts?.forEach { part ->
                    part.jsonObject["text"]?.jsonPrimitive?.contentOrNull?.let { if (it.isNotEmpty()) emit(it) }
                }
            }
        }
    }.flowOn(Dispatchers.IO)
}
