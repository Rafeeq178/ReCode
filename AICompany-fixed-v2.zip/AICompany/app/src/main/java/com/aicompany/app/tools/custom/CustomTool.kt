package com.aicompany.app.tools.custom

import com.aicompany.app.provider.ChatGateway
import com.aicompany.app.provider.ChatMessage
import com.aicompany.app.provider.ChatParams
import com.aicompany.app.provider.ProviderRepository
import com.aicompany.app.security.KeyVault
import com.aicompany.app.terminal.CommandRunner
import com.aicompany.app.terminal.ShellLauncher
import com.aicompany.app.tools.ApprovalLevel
import com.aicompany.app.tools.Tool
import com.aicompany.app.tools.ToolContext
import com.aicompany.app.tools.ToolResult
import com.aicompany.app.tools.ToolSpec
import com.aicompany.app.tools.WorkspaceProvider
import com.aicompany.app.util.Redactor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.net.URLEncoder
import java.util.UUID
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

private const val MAX_OUTPUT = 8_000
private const val MAX_HTTP_BODY = 64 * 1024L

/** A dynamically defined tool. Its spec comes from the definition; execution goes through the runner. */
class CustomTool(
    val def: CustomToolDef,
    private val runner: CustomToolRunner,
) : Tool {
    override val spec = ToolSpec(
        name = def.name,
        description = def.description,
        schema = def.parameters,
        approval = ApprovalLevel.valueOf(def.approval),
        timeoutMs = def.timeoutSeconds * 1_000L,
        maxOutputChars = MAX_OUTPUT,
    )

    override suspend fun execute(args: JsonObject, ctx: ToolContext): ToolResult = runner.run(def, args)
}

/** Runs custom tools. Secrets are resolved here, and only the response reaches the model. */
@Singleton
class CustomToolRunner @Inject constructor(
    private val shell: ShellLauncher,
    private val commands: CommandRunner,
    private val workspace: WorkspaceProvider,
    private val http: OkHttpClient,
    private val vault: KeyVault,
    private val gateway: ChatGateway,
    private val providers: ProviderRepository,
    private val mcp: McpClient,
) {
    suspend fun run(def: CustomToolDef, args: JsonObject): ToolResult = try {
        when (def.type) {
            "SHELL" -> shellTool(def, args)
            "HTTP" -> httpTool(def, args)
            "SCRIPT" -> scriptTool(def, args)
            "PROMPT" -> promptTool(def, args)
            "MCP" -> mcpTool(def, args)
            else -> ToolResult.Error("unknown_type", "Unknown tool type")
        }
    } catch (e: IllegalArgumentException) {
        ToolResult.Error("invalid_args", Redactor.redact(e.message ?: "Invalid input").take(300))
    } catch (e: IllegalStateException) {
        ToolResult.Error("tool_failed", Redactor.redact(e.message ?: "Tool failed").take(300))
    }

    private suspend fun shellTool(def: CustomToolDef, args: JsonObject): ToolResult {
        val command = Template.fill(def.command.orEmpty(), args) { Template.shellQuote(it) }
        return runInAlpine(command, def.timeoutSeconds)
    }

    private suspend fun scriptTool(def: CustomToolDef, args: JsonObject): ToolResult {
        val ext = when (def.language) { "python" -> "py"; "node" -> "js"; else -> "sh" }
        val interpreter = when (def.language) { "python" -> "python3"; "node" -> "node"; else -> "sh" }
        val id = UUID.randomUUID().toString()
        val dir = workspace.sandbox.resolve(".tmp").apply { mkdirs() }
        val script = File(dir, "tool_$id.$ext")
        val argsFile = File(dir, "args_$id.json")
        try {
            script.writeText(def.code.orEmpty(), Charsets.UTF_8)
            argsFile.writeText(args.toString(), Charsets.UTF_8)
            return runInAlpine("$interpreter /workspace/.tmp/tool_$id.$ext /workspace/.tmp/args_$id.json", def.timeoutSeconds)
        } finally {
            script.delete()
            argsFile.delete()
        }
    }

    private suspend fun httpTool(def: CustomToolDef, args: JsonObject): ToolResult {
        val url = Template.fill(def.url.orEmpty(), args) { URLEncoder.encode(it, "UTF-8") }
        val parsed = url.toHttpUrlOrNull() ?: throw IllegalArgumentException("URL is not valid")
        require(parsed.scheme == "https") { "Only https URLs are allowed" }
        val body = def.body?.let { Template.fill(it, args) { v -> Template.jsonEscape(v) } }
        val headers = def.headers.mapValues { (_, v) -> resolveSecrets(v) }

        val builder = Request.Builder().url(parsed)
        headers.forEach { (k, v) -> builder.header(k, v) }
        val mediaBody = (body ?: "").toRequestBody(com.aicompany.app.provider.JSON_MEDIA)
        when (def.method) {
            "GET" -> builder.get()
            "DELETE" -> builder.delete()
            "POST" -> builder.post(mediaBody)
            "PUT" -> builder.put(mediaBody)
            else -> throw IllegalArgumentException("Unsupported method")
        }
        return withContext(Dispatchers.IO) {
            val client = http.newBuilder().callTimeout(def.timeoutSeconds.toLong(), TimeUnit.SECONDS).build()
            client.newCall(builder.build()).execute().use { resp ->
                val source = resp.body?.source()
                val text = if (source == null) "" else {
                    source.request(MAX_HTTP_BODY)
                    source.buffer.readUtf8(minOf(source.buffer.size, MAX_HTTP_BODY))
                }
                if (!resp.isSuccessful) ToolResult.Error("http_${resp.code}", "HTTP ${resp.code}")
                else ToolResult.Ok("[UNTRUSTED HTTP RESPONSE ${resp.code}]\n$text")
            }
        }
    }

    private suspend fun promptTool(def: CustomToolDef, args: JsonObject): ToolResult {
        val text = Template.fill(def.prompt.orEmpty(), args) { it }
        val chain = providers.observe().first()
        require(chain.isNotEmpty()) { "Add a provider first" }
        val answer = StringBuilder()
        gateway.stream(chain, listOf(ChatMessage("user", text)), ChatParams(maxTokens = 1024, temperature = 0.2))
            .collect { token -> if (answer.length < MAX_OUTPUT) answer.append(token) }
        return ToolResult.Ok("[SUB-AGENT ANSWER, untrusted data]\n$answer")
    }

    private suspend fun mcpTool(def: CustomToolDef, args: JsonObject): ToolResult {
        val output = mcp.callTool(def.serverUrl.orEmpty(), def.remoteName.orEmpty(), args)
        return ToolResult.Ok("[UNTRUSTED MCP RESPONSE]\n${output.take(MAX_OUTPUT)}")
    }

    /** {{secret:NAME}} is replaced with the stored value. Missing secrets fail loudly. */
    private fun resolveSecrets(value: String): String =
        CustomToolValidator.SECRET.replace(value) { m ->
            vault.getSecret(m.groupValues[1]) ?: throw IllegalArgumentException("Secret ${m.groupValues[1]} is not set")
        }

    private suspend fun runInAlpine(command: String, timeoutSeconds: Int): ToolResult {
        shell.notReadyReason()?.let { return ToolResult.Error("terminal_not_ready", it) }
        val result = commands.run(
            shell.commandArgv(command),
            shell.environment(),
            timeoutSeconds * 1_000L,
            MAX_OUTPUT,
        )
        val header = if (result.timedOut) "[timed out]" else "[exit ${result.exitCode}]"
        return ToolResult.Ok("$header\n${result.output}")
    }
}
