package com.aicompany.app.llama

import com.aicompany.app.provider.ChatMessage

/**
 * ChatML formatting used by Qwen2.5 instruct models (the default local model).
 * Roles are restricted to system, user and assistant so user text cannot inject a new role.
 */
object ChatTemplate {
    private val ROLES = setOf("system", "user", "assistant")
    private const val MAX_CHARS = 24_000

    fun chatMl(messages: List<ChatMessage>): String {
        val body = buildString {
            messages.forEach { m ->
                require(m.role in ROLES) { "Unsupported role" }
                append("<|im_start|>").append(m.role).append('\n')
                append(m.content.replace("<|im_start|>", "").replace("<|im_end|>", ""))
                append("<|im_end|>\n")
            }
            append("<|im_start|>assistant\n")
        }
        require(body.length <= MAX_CHARS) { "Prompt is too long for the local model" }
        return body
    }
}
