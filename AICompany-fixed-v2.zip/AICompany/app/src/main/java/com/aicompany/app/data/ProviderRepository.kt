package com.aicompany.app.data

import com.aicompany.app.provider.ApiFormat
import com.aicompany.app.provider.ProviderConfig
import com.aicompany.app.security.KeyVault
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

data class ProviderDraft(
    val id: String? = null,
    val name: String,
    val format: ApiFormat,
    val baseUrl: String,
    val model: String,
    val keysText: String,           // newline separated; blank on edit means "keep existing"
    val maxTokens: Int = 1024,
    val temperature: Double = 0.7,
    val timeoutSeconds: Long = 60,
)

@Singleton
class ProviderRepository @Inject constructor(
    private val dao: ProviderDao,
    private val vault: KeyVault,
) {
    fun observe(): Flow<List<ProviderConfig>> =
        dao.observeAll().map { rows -> rows.map { it.toConfig() } }

    suspend fun get(id: String): ProviderConfig? = withContext(Dispatchers.IO) {
        dao.getById(id)?.toConfig()
    }

    fun hasKeys(id: String): Boolean = vault.keysFor(id).isNotEmpty()

    /** Validates the draft, stores keys in the vault and metadata in Room. Returns the saved id. */
    suspend fun save(draft: ProviderDraft): String = withContext(Dispatchers.IO) {
        require(draft.name.isNotBlank() && draft.name.length <= 60) { "Name must be 1-60 characters" }
        if (draft.format == ApiFormat.LOCAL) {
            require(draft.baseUrl.trim() == "local") { "Local models use the base URL 'local'" }
        } else {
            require(draft.baseUrl.startsWith("https://")) { "Base URL must start with https://" }
        }
        require(draft.baseUrl.length <= 300) { "Base URL too long" }
        require(draft.model.isNotBlank() && draft.model.length <= 120) { "Model name is required" }
        require(draft.maxTokens in 1..200_000) { "Max tokens out of range" }
        require(draft.temperature in 0.0..2.0) { "Temperature must be between 0 and 2" }
        require(draft.timeoutSeconds in 5..600) { "Timeout must be 5-600 seconds" }

        val id = draft.id ?: UUID.randomUUID().toString()
        val newKeys = draft.keysText.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (newKeys.isNotEmpty()) {
            vault.saveKeys(id, newKeys)
        } else if (draft.format != ApiFormat.LOCAL) {
            require(draft.id != null && vault.keysFor(id).isNotEmpty()) { "At least one API key is required" }
        }

        val existing = draft.id?.let { dao.getById(it) }
        dao.upsert(
            ProviderEntity(
                id = id,
                name = draft.name.trim(),
                format = draft.format.name,
                baseUrl = draft.baseUrl.trim().trimEnd('/'),
                model = draft.model.trim(),
                timeoutSeconds = draft.timeoutSeconds,
                maxTokens = draft.maxTokens,
                temperature = draft.temperature,
                extraHeaders = existing?.extraHeaders.orEmpty(),
                createdAt = existing?.createdAt ?: System.currentTimeMillis(),
            )
        )
        id
    }

    suspend fun delete(id: String) = withContext(Dispatchers.IO) {
        dao.delete(id)
        vault.deleteKeys(id)
    }

    private fun ProviderEntity.toConfig() = ProviderConfig(
        id = id,
        name = name,
        format = ApiFormat.valueOf(format),
        baseUrl = baseUrl,
        model = model,
        timeoutSeconds = timeoutSeconds,
        maxTokens = maxTokens,
        temperature = temperature,
        extraHeaders = extraHeaders.lines()
            .mapNotNull { line -> line.split(":", limit = 2).takeIf { it.size == 2 } }
            .associate { it[0].trim() to it[1].trim() },
    )
}
