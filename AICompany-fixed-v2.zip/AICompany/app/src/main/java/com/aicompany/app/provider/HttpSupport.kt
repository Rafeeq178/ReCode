package com.aicompany.app.provider

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.util.concurrent.TimeUnit

internal val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()

internal fun OkHttpClient.forProvider(config: ProviderConfig): OkHttpClient =
    newBuilder()
        .connectTimeout(config.timeoutSeconds, TimeUnit.SECONDS)
        .readTimeout(config.timeoutSeconds, TimeUnit.SECONDS)
        .callTimeout(config.timeoutSeconds * 4, TimeUnit.SECONDS)
        .build()

internal fun joinUrl(baseUrl: String, path: String): String =
    baseUrl.trimEnd('/') + path

internal fun Request.Builder.applyExtraHeaders(config: ProviderConfig): Request.Builder {
    config.extraHeaders.forEach { (k, v) -> header(k, v) }
    return this
}

/** Executes a request, mapping transport failures to ProviderException. */
internal fun OkHttpClient.executeOrThrow(request: Request): Response =
    try {
        newCall(request).execute()
    } catch (e: IOException) {
        throw ProviderException.Network("Network error: ${e.javaClass.simpleName}", e)
    }

/** Maps HTTP error codes to typed exceptions. The body is truncated and never includes the key. */
internal fun mapHttpError(code: Int, body: String): ProviderException {
    val snippet = body.take(300)
    return when (code) {
        401, 403 -> ProviderException.Auth("Authentication failed ($code)")
        429 -> if (snippet.contains("quota", ignoreCase = true) || snippet.contains("billing", ignoreCase = true))
            ProviderException.Quota("Quota exceeded")
        else ProviderException.RateLimited("Rate limited")
        400, 404, 422 -> ProviderException.BadRequest("Request rejected ($code): $snippet")
        in 500..599 -> ProviderException.Server("Provider server error ($code)", code)
        else -> ProviderException.Server("Unexpected HTTP $code", code)
    }
}

internal fun requireHttps(baseUrl: String) {
    require(baseUrl.startsWith("https://")) { "Base URL must use HTTPS" }
}
