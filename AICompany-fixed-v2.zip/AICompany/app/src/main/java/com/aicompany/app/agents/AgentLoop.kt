package com.aicompany.app.agents

import com.aicompany.app.data.AgentRunRepository
import com.aicompany.app.provider.ChatGateway
import com.aicompany.app.provider.ChatMessage
import com.aicompany.app.provider.ChatParams
import com.aicompany.app.provider.ProviderConfig
import com.aicompany.app.provider.ProviderException
import com.aicompany.app.local.GbnfBuilder
import com.aicompany.app.tools.ToolRegistry
import com.aicompany.app.tools.ToolResult
import kotlinx.coroutines.flow.collect
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import javax.inject.Inject
import javax.inject.Singleton

/**
 * One agent run: prompt -> model -> parse -> validate/approve/execute -> feed result back.
 * Every step is logged to Room so the owner can follow it live and after a restart.
 */
@Singleton
class AgentLoop @Inject constructor(
    private val gateway: ChatGateway,
    private val registry: ToolRegistry,
    private val runs: AgentRunRepository,
) {
    suspend fun run(
        runId: Long,
        config: AgentConfig,
        goal: String,
        providers: List<ProviderConfig>,
        awaitResume: suspend () -> Unit,
    ): RunOutcome {
        val specs = registry.specsFor(config.allowedTools)
        val history = mutableListOf(
            ChatMessage("system", AgentPrompt.build(config, specs)),
            ChatMessage("user", "Goal: $goal"),
        )
        val loopDetector = LoopDetector()
        val grammar = if (config.allowedTools.isEmpty()) null
        else GbnfBuilder.toolCallGrammar(config.allowedTools)
        val params = ChatParams(config.maxTokens, config.temperature, grammar = grammar)
        var invalidStreak = 0
        var toolErrorStreak = 0

        for (step in 1..config.maxSteps) {
            awaitResume()
            HistoryCompressor.compact(history, MAX_CONTEXT_CHARS)

            val raw = try {
                collect(providers, history.toList(), params)
            } catch (e: ProviderException) {
                runs.log(runId, step, "error", "Model call failed: ${e.message}")
                return RunOutcome(RunStatus.FAILED, "Model call failed: ${e.message}", step)
            }
            runs.log(runId, step, "model", raw)
            history += ChatMessage("assistant", raw)

            when (val action = ToolCallParser.parse(raw)) {
                is AgentAction.Invalid -> {
                    invalidStreak++
                    runs.log(runId, step, "error", action.reason)
                    if (invalidStreak > MAX_RETRIES) {
                        return RunOutcome(RunStatus.FAILED, "Model kept returning invalid output", step)
                    }
                    history += ChatMessage(
                        "user",
                        "ERROR: ${action.reason}. Reply with one JSON tool call or {\"done\": \"...\"}.",
                    )
                }

                is AgentAction.Done -> return RunOutcome(RunStatus.COMPLETED, action.text, step)

                is AgentAction.Call -> {
                    invalidStreak = 0
                    if (loopDetector.record(action.call)) {
                        runs.log(runId, step, "error", "Loop detected: ${action.call.name} repeated")
                        return RunOutcome(
                            RunStatus.LOOP_DETECTED,
                            "Same tool call repeated ${LoopDetector.THRESHOLD} times",
                            step,
                        )
                    }
                    val result = registry.execute(runId.toString(), action.call, config.allowedTools, config.skillIds)
                    runs.log(runId, step, "tool", "${action.call.name} -> ${result.kind}")
                    if (action.call.name == FINAL_REPORT_TOOL && result is ToolResult.Ok) {
                        return RunOutcome(RunStatus.COMPLETED, result.output, step)
                    }

                    val validationFailed = result is ToolResult.Error && result.code == "invalid_args"
                    toolErrorStreak = if (validationFailed) toolErrorStreak + 1 else 0
                    if (toolErrorStreak > MAX_RETRIES) {
                        return RunOutcome(RunStatus.FAILED, "Tool arguments kept failing validation", step)
                    }
                    history += ChatMessage("user", "TOOL_RESULT ${action.call.name}: ${resultJson(result)}")
                }
            }
        }
        return RunOutcome(RunStatus.STEP_LIMIT, "Step limit of ${config.maxSteps} reached", config.maxSteps)
    }

    private suspend fun collect(
        providers: List<ProviderConfig>,
        messages: List<ChatMessage>,
        params: ChatParams,
    ): String {
        val sb = StringBuilder()
        gateway.stream(providers, messages, params).collect { token ->
            if (sb.length < MAX_MODEL_OUTPUT) sb.append(token)
        }
        return sb.toString()
    }

    private fun resultJson(result: ToolResult): String = when (result) {
        is ToolResult.Ok -> buildJsonObject {
            put("status", "ok")
            put("output", result.output)
        }.toString()
        is ToolResult.Error -> buildJsonObject {
            put("status", "error")
            put("code", result.code)
            put("message", result.message)
        }.toString()
    }

    companion object {
        const val MAX_CONTEXT_CHARS = 12_000
        const val MAX_MODEL_OUTPUT = 20_000
        const val MAX_RETRIES = 2
        const val FINAL_REPORT_TOOL = "final_report"
    }
}
