# AICompany APK build instructions

The GitHub Actions workflow is `.github/workflows/build.yml`.

## Required repository variable
The workflow downloads the ARM64 Termux `proot` Debian package to bundle its native files. Add a repository variable named `PROOT_DEB_URL`:

GitHub repository → Settings → Secrets and variables → Actions → Variables → New repository variable.

Set the value to a direct HTTPS download URL of a compatible ARM64 Termux proot `.deb` package. It must contain:
- `usr/bin/proot`
- `usr/libexec/proot/loader`

Then use Actions → Build AICompany APK → Run workflow. The APK and SHA-256 file will be available in the run's Artifacts section if the build succeeds.

This workflow has not been run on GitHub Actions in this editing session; a successful build is not guaranteed until CI completes.
