/* ReCode - the only place that talks to the Android side (window.Android, see Bridge.kt). */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var U = RC.u;
  var pend = {}, llmH = {};

  var N = RC.native = {
    get has() { return !!window.Android; },
    /** events pushed by Kotlin */
    emit: function (ev) {
      if (!ev) return;
      if (ev.t === 'llm') { var h = llmH[ev.id]; if (h) h(ev); }
      else if (ev.t === 'res') { var p = pend[ev.id]; if (p) { delete pend[ev.id]; ev.ok ? p.res(ev.d) : p.rej(new Error(String(ev.d))); } }
      else if (ev.t === 'dl') { N.dl = ev.list || []; RC.bus.emit('dl', N.dl); }
    },
    dl: [],
    onLlm: function (id, fn) { llmH[id] = fn; return function () { delete llmH[id]; }; },
    /** call a bridge method that answers later: first argument is the request id */
    req: function (method) {
      var args = Array.prototype.slice.call(arguments, 1), id = U.uid('r');
      return new Promise(function (res, rej) {
        if (!window.Android || !window.Android[method]) return rej(new Error('This needs the ReCode Android app'));
        pend[id] = { res: res, rej: rej };
        try { window.Android[method].apply(window.Android, [id].concat(args)); } catch (e) { delete pend[id]; rej(e); }
      });
    },
    /** call a bridge method that answers at once */
    call: function (method) {
      var args = Array.prototype.slice.call(arguments, 1);
      try { if (window.Android && window.Android[method]) return window.Android[method].apply(window.Android, args); } catch (e) { console.error(method, e); }
      return undefined;
    },
    json: function (method, fallback) {
      try { var s = N.call(method); return s ? JSON.parse(s) : fallback; } catch (e) { return fallback; }
    },
    info: function () { return N.json('info', {}); },
    models: function () { return N.json('models', []); },
    online: function () { var o = N.call('online'); return o === undefined ? navigator.onLine : !!o; },
    toast: function (m) { if (RC.ui && RC.ui.toast) RC.ui.toast(m); },
    copy: function (t) {
      if (window.Android && window.Android.copy) { N.call('copy', String(t)); return Promise.resolve(); }
      try { return navigator.clipboard.writeText(t); } catch (e) { return Promise.reject(e); }
    },
    search: function (q, n) { return N.req('webSearch', q, n || 5); },
    read: function (url, max) { return N.req('webRead', url, max || 3000); },
    pickDocs: function () { return N.req('pickDocs'); },
    /** save bytes (Uint8Array | string) through the system "Save as" screen */
    save: function (name, data, mime) {
      var u8 = typeof data === 'string' ? U.utf8(data) : data;
      return N.req('saveFile', name, mime || U.mime(name), U.toB64(u8));
    },
    keepAwake: function (on) { N.call('keepAwake', !!on); },
    open: function (url) { N.call('openExternal', url); }
  };
})();
