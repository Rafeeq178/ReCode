// Phase 1 tests: tool registry, parser, agent loop (mock model, in-memory store). Run: node tests/phase1.test.js
const fs = require('fs'), path = require('path'), vm = require('vm');
const WWW = path.join(__dirname, '../ReCode/app/src/main/assets/www/js/');
const win = { RC: {}, addEventListener() {}, matchMedia: null };
global.window = win; global.document = { createElement() { return { style: {}, setAttribute() {}, remove() {} }; }, createTextNode: t => t, body: {}, querySelector() {} };
global.navigator = { onLine: true }; global.localStorage = { getItem() { return null; }, setItem() {} };
global.AbortController = AbortController;
const RC = win.RC;
function load(f) { vm.runInThisContext(fs.readFileSync(WWW + f, 'utf8'), { filename: f }); }
load('util.js');
// in-memory store, same surface as RC.store
const files = {};
RC.store = { files, cur: { id: 'p', name: 't' }, fileList: () => Object.keys(files).sort(),
  putFile: async (p, c) => { files[p] = c; }, delFile: async p => { delete files[p]; }, touch() {} };
RC.bus = { emit() {}, on() {} };
RC.saveSettings = () => {}; RC.set = (k, v) => { RC.settings[k] = v; };
RC.native = { call() {}, online: () => true, keepAwake() {} };
RC.settings = { maxIter: 6, ctxChars: 4000, agents: {}, provider: 'local', keepAwake: false, permMode: 'auto', perms: { global: {}, files: [], confirmDelete: true, confirmOverwrite: true, dangerous: 'deny' }, hooks: { format: true, syntax: true, overwrite: true, backup: true, structure: true, errors: true, autoTest: false, maxFiles: 60, custom: [] } };
RC.agentCfg = id => ({ on: true, max: 800, prompt: RC.agents.def[id].system });
RC.run = { entry: f => f['index.html'] ? 'index.html' : null, check: async () => ({ issues: [], fixes: [], ran: true }), probe: async () => ({ errors: [], logs: [] }) };
let script = [], prompts = [];
RC.llm = { AbortErr() { const e = new Error('Stopped'); e.name = 'AbortError'; return e; },
  run: async o => { prompts.push(o); if (!script.length) throw new Error('script exhausted'); const r = script.shift(); return typeof r === 'function' ? r(o) : r; } };
load('agents.js'); load('tools.js'); load('hooks.js'); load('perms.js'); load('pipeline.js'); load('loop.js');
const T = RC.tools;
let pass = 0, fail = 0;
function ok(c, m) { if (c) pass++; else { fail++; console.log('FAIL', m); } }
async function ex(name, args) { return T.exec({ name, args }, { touch() {} }); }
(async () => {
  // ---- registry completeness
  for (const n of ['read_file','write_file','edit_file','delete_file','list_files','search_files','search_text','create_directory','rename_file','move_file','get_file_info','run_command','check_syntax','run_tests'])
    ok(T.registry[n] && T.registry[n].description && T.registry[n].params && T.registry[n].perm && T.registry[n].run, 'tool ' + n);

  // ---- parser
  let p = T.parse('Let me look.\nTOOL: list_files\nTOOL: read_file | index.html');
  ok(p.calls.length === 2 && p.calls[1].args.path === 'index.html', 'text calls');
  p = T.parse('TOOL: write_file | style.css\n```css\nbody{margin:0}\n```\nTOOL: read_file | a.js');
  ok(p.calls.length === 2 && p.calls[0].args.content === 'body{margin:0}', 'write_file block: ' + JSON.stringify(p.calls[0]));
  p = T.parse('TOOL: edit_file | s.js\n```\n<<<<<<< SEARCH\nlet a=1;\n=======\nlet a=2;\n>>>>>>> REPLACE\n```');
  ok(p.calls[0].args.old_text === 'let a=1;' && p.calls[0].args.new_text === 'let a=2;', 'edit block');
  p = T.parse('{"tool":"read_file","args":{"path":"x.js"}}');
  ok(p.calls[0].name === 'read_file' && p.calls[0].args.path === 'x.js', 'json call');
  p = T.parse('<tool_call>{"name":"list_files","arguments":{}}</tool_call>');
  ok(p.calls[0].name === 'list_files', 'tool_call tag');
  p = T.parse('{"tool_calls":[{"function":{"name":"read_file","arguments":"{\\"path\\":\\"a.js\\"}"}}]}');
  ok(p.calls[0] && p.calls[0].args.path === 'a.js', 'openai shape');
  p = T.parse('TOOL: hack_system | rm -rf');
  ok(!p.calls.length && p.errors.length, 'unknown tool rejected');
  p = T.parse('All done, the page works.');
  ok(!p.calls.length && !p.errors.length, 'plain answer');
  p = T.parse('TOOL: search_text | foo | *.js');
  ok(p.calls[0].args.pattern === 'foo' && p.calls[0].args.path === '*.js', 'search_text args');

  // ---- tools + sandbox
  let r = await ex('write_file', { path: 'index.html', content: '<!DOCTYPE html><html><body><div id="a"></div><script src="s.js"></script></body></html>' });
  ok(r.ok && files['index.html'], 'write_file ' + r.out);
  await ex('write_file', { path: 'src/s.js', content: 'function f(){\n  return 1;\n}\n// TODO x\n' });
  r = await ex('write_file', { path: '../evil.js', content: 'x' }); ok(!r.ok && /outside/.test(r.out), 'traversal blocked');
  r = await ex('write_file', { path: '/etc/passwd.txt', content: 'x' }); ok(!r.ok, 'absolute blocked');
  r = await ex('read_file', { path: 'C:/x.js' }); ok(!r.ok, 'drive path blocked');
  r = await ex('read_file', { path: 'src/s.js', start_line: 1, end_line: 2 }); ok(/1: function f/.test(r.out) && !/TODO/.test(r.out), 'read range');
  r = await ex('read_file', { path: 'nope.js' }); ok(!r.ok && /No such file/.test(r.out), 'missing file');
  r = await ex('edit_file', { path: 'src/s.js', old_text: 'return 1;', new_text: 'return 2;' }); ok(r.ok && /return 2/.test(files['src/s.js']), 'edit');
  r = await ex('edit_file', { path: 'src/s.js', old_text: 'zzz', new_text: 'q' }); ok(!r.ok, 'edit miss');
  r = await ex('edit_file', { path: 'src/s.js', old_text: '  return 2;', new_text: '  return 3;' }); ok(r.ok, 'edit ws');
  files['d.js'] = 'a\na\n'; r = await ex('edit_file', { path: 'd.js', old_text: 'a', new_text: 'b' }); ok(!r.ok && /2 times/.test(r.out), 'ambiguous edit');
  r = await ex('edit_file', { path: 'd.js', old_text: 'a', new_text: 'b', replace_all: true }); ok(r.ok && files['d.js'] === 'b\nb\n', 'replace_all');
  r = await ex('search_text', { pattern: 'TODO' }); ok(/src\/s.js:4/.test(r.out), 'search_text');
  r = await ex('search_files', { pattern: '*.js' }); ok(/src\/s.js/.test(r.out), 'search_files glob');
  r = await ex('list_files', {}); ok(/index.html/.test(r.out), 'list');
  r = await ex('get_file_info', { path: 'index.html' }); ok(/lines: [12]/.test(r.out), 'info');
  r = await ex('create_directory', { path: 'assets' }); ok(r.ok && files['assets/.gitkeep'] !== undefined, 'mkdir');
  r = await ex('rename_file', { from: 'd.js', to: 'e.js' }); ok(r.ok && files['e.js'] && !files['d.js'], 'rename');
  r = await ex('move_file', { from: 'e.js', to: 'assets/' }); ok(r.ok && files['assets/e.js'], 'move');
  r = await ex('move_file', { from: 'assets/e.js', to: 'index.html' }); ok(!r.ok && /exists/.test(r.out), 'move no overwrite');
  r = await ex('delete_file', { path: 'assets/e.js' }); ok(!r.ok && r.blocked && files['assets/e.js'], 'delete DENY by default');
  RC.perms.setRule('delete_file', 'allow', 'global'); RC.perms.requester = async () => 'once'; r = await ex('delete_file', { path: 'assets/e.js' }); ok(r.ok && !files['assets/e.js'], 'delete when allowed+confirmed ' + r.out); RC.perms.requester = null; delete RC.settings.perms.global.delete_file;
  files['bad.js'] = 'function ('; files['ok.json'] = '{"a":1}'; files['bad.css'] = 'a{color:red'; files['bad.html'] = '<div><span></div>';
  r = await ex('check_syntax', { path: 'bad.js' }); ok(/problem/.test(r.out), 'js syntax ' + r.out);
  r = await ex('check_syntax', { path: 'ok.json' }); ok(/OK/.test(r.out), 'json ok');
  r = await ex('check_syntax', { path: 'bad.css' }); ok(/problem/.test(r.out), 'css syntax');
  r = await ex('check_syntax', { path: 'bad.html' }); ok(/problem/.test(r.out), 'html syntax');
  r = await ex('check_syntax', { path: 'index.html' }); ok(/OK/.test(r.out), 'html ok ' + r.out);
  r = await ex('run_command', { command: 'npm install' }); ok(!r.ok && /no shell/i.test(r.out), 'no shell'); r = await ex('run_command', { command: 'rm -rf /' }); ok(r.blocked, 'dangerous blocked');
  r = await ex('run_command', { command: 'ls' }); ok(r.ok, 'run ls');
  r = await ex('run_tests', {}); ok(/PASSED/.test(r.out), 'run_tests ' + r.out);
  r = await T.exec({ name: 'write_file', args: { path: 'x.js', content: 'a' } }, { mode: 'plan', touch() {} }); ok(r.blocked, 'plan mode blocks writes');
  r = await T.exec({ name: 'nope', args: {} }, {}); ok(!r.ok, 'unknown tool exec');

  // ---- agent loop
  for (const k of Object.keys(files)) delete files[k];
  function run(text, mode) { script = script.slice(); const r = RC.pipe.start(text, mode || 'agent'); return r.done; }
  // 1) multi-turn: list -> write -> check -> final
  script = [
    'I will start.\nTOOL: list_files',
    'TOOL: write_file | index.html\n```html\n<!DOCTYPE html><html><body><h1>Hi</h1></body></html>\n```',
    'TOOL: check_syntax',
    'Created index.html with a heading. Syntax checked.'
  ];
  let rr = await run('make a hello page');
  ok(rr.status === 'done' && /Created index.html/.test(rr.final) && files['index.html'], 'loop completes: ' + rr.final + rr.status);
  ok(rr.files.indexOf('index.html') >= 0, 'run.files tracks writes');
  ok(rr.steps.filter(s => s.kind === 'tool').length === 3, 'tool steps recorded');
  ok(prompts[prompts.length - 1].prompt.indexOf('check_syntax') >= 0 || /Progress so far/.test(prompts[prompts.length - 1].prompt), 'results fed back');
  // 2) unverified change -> nudge before accepting final
  prompts = [];
  script = ['TOOL: write_file | a.js\n```js\nvar a=1;\n```', 'Done!', 'TOOL: check_syntax | a.js', 'Wrote and checked a.js.'];
  rr = await run('add a.js');
  ok(/checked/.test(rr.final) && prompts.length === 4, 'verification nudge, turns=' + prompts.length);
  // 3) invalid tool calls limit
  script = ['TOOL: bogus | x', 'TOOL: bogus | y', 'TOOL: bogus | z'];
  rr = await run('do it');
  ok(/could not produce a valid tool call/.test(rr.final), 'invalid limit: ' + rr.final);
  // 4) max iterations
  RC.settings.maxIter = 3; script = ['TOOL: list_files', 'TOOL: read_file | a.js', 'TOOL: get_file_info | a.js', 'TOOL: list_files'];
  rr = await run('loop forever');
  ok(/iteration limit/.test(rr.final) && prompts.length >= 3, 'max iterations');
  // 5) cancel
  RC.settings.maxIter = 6; script = [async () => { RC.pipe.stop(); return 'TOOL: list_files'; }, 'TOOL: list_files'];
  RC.llm.run = async o => { const r = script.shift(); const v = typeof r === 'function' ? await r(o) : r; if (o.signal.aborted) throw RC.llm.AbortErr(); return v; };
  rr = await run('cancel me');
  ok(rr.status === 'stopped', 'cancel -> ' + rr.status);
  // 6) blocked delete is reported to the model, loop continues
  RC.llm.run = async o => { prompts.push(o); const r = script.shift(); return r; };
  files['z.js'] = 'var z=1;'; script = ['TOOL: delete_file | z.js', 'Could not delete: not permitted.'];
  rr = await run('delete z.js');
  ok(files['z.js'] && /not permitted/.test(rr.final) && /BLOCKED/.test(prompts[prompts.length - 1].prompt), 'blocked delete fed back');
  // 7) repeated identical call detection
  RC.settings.maxIter = 8; script = ['TOOL: list_files', 'TOOL: list_files', 'TOOL: list_files', 'TOOL: list_files', 'Finished.'];
  rr = await run('repeat');
  ok(prompts.some(x => /same result|already ran/.test(x.prompt)), 'repeat detected');
  // 8) small-context budget respected
  RC.settings.ctxChars = 3000; RC.settings.maxIter = 4; prompts = [];
  files['big.js'] = 'var x = 1;\n'.repeat(2000);
  script = ['TOOL: read_file | big.js', 'TOOL: read_file | big.js | 5', 'Summary.'];
  await run('read big');
  ok(prompts.every(x => (x.system + x.prompt).length <= 3000 + 600), 'budget: ' + prompts.map(x => (x.system + x.prompt).length));
  // 9) classic modes untouched
  RC.settings.autoAgent = false; ok(RC.pipe.detectMode('build a game', 'auto') === 'build' && RC.pipe.detectMode('hi', 'auto') === 'chat', 'auto mode unchanged');
  RC.settings.autoAgent = true; ok(RC.pipe.detectMode('build a game', 'auto') === 'agent', 'autoAgent switch');
  console.log(pass + ' passed, ' + fail + ' failed'); process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
