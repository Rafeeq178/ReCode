plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    // llama.cpp loads its CPU backends (.so) from nativeLibraryDir, so they must be extracted on install
    packaging { jniLibs { useLegacyPackaging = true } }
    namespace = "com.recode.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.recode.app"
        minSdk = 29          // Android 10+ (lib is patched down from 33 by CI / setup.sh)
        targetSdk = 35
        versionCode = 17
        versionName = "17.0.0"
        ndk { abiFilters += listOf("arm64-v8a") }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(project(":lib"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    // serves the offline UI (assets/www) from a proper https origin inside the WebView
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    // reads the text of PDF files (offline) for the knowledge base
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
    // readable text of web pages and search results
    implementation("org.jsoup:jsoup:1.17.2")
    // Real local Git repository operations; no external git binary is required.
    implementation("org.eclipse.jgit:org.eclipse.jgit:6.10.0.202406032230-r")
    implementation("com.google.code.gson:gson:2.11.0")
    // Optional Shizuku bridge. Privileged actions remain opt-in and require Shizuku approval.
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
