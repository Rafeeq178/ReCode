/* ReCode - Phase 1: tool registry, tool parser and tool executor.
   Tools only ever touch the open project (RC.store.files). There is no disk access, so nothing can leave the project.
   Every tool declares: name, description, params, perm (read|write|delete|exec), run(args, ctx) -> string, and is
   executed through T.exec() which validates, checks the policy gate, runs, and never throws. */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var U = RC.u;

  // Default policy until the Phase 2 permission manager replaces RC.tools.gate.
  // allow | ask | deny. "ask" is treated as deny here because there is no dialog yet.
  var policy = { read: 'allow', write: 'allow', delete: 'deny', exec: 'allow' };

  function St() { return RC.store; }
  function files() { return St().files; }
  function fail(m) { var e = new Error(m); e.tool = true; return e; }

  /** project-relative, validated path. Throws if it could leave the project or is malformed. */
  function path(p, opts) {
    var raw = String(p == null ? '' : p).trim().replace(/^["'`]|["'`]$/g, '');
    if (!raw) throw fail('Missing path.');
    if (/^([a-z]:|\/|~)/i.test(raw) || /(^|[\\/])\.\.([\\/]|$)/.test(raw)) throw fail('Path "' + raw + '" is outside the project. Use a simple relative path like src/app.js.');
    var n = U.normPath(raw);
    if (!n) throw fail('Missing path.');
    if (!(opts && opts.dir) && !U.validPath(n)) throw fail('Invalid file name "' + n + '". Use letters, digits, - _ . and / with a file extension.');
    return n;
  }
  function must(p) {
    var n = path(p);
    if (files()[n] === undefined) {
      var near = Object.keys(files()).filter(function (x) { return U.base(x).toLowerCase() === U.base(n).toLowerCase(); });
      throw fail('No such file: ' + n + (near.length ? '. Did you mean ' + near[0] + '?' : '. Use list_files to see the files.'));
    }
    return n;
  }
  function num(v, d) { v = parseInt(v, 10); return isNaN(v) ? d : v; }
  function lineCount(s) { return s === '' ? 0 : s.split('\n').length; }
  function globRe(g) {
    var s = String(g).replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*\*/g, '\u0000').replace(/\*/g, '[^/]*').replace(/\?/g, '[^/]').replace(/\u0000/g, '.*');
    return new RegExp('^' + s + '$', 'i');
  }

  // ------------------------------------------------------------------ syntax checkers (no dependencies)
  function balance(code, pairs) {
    // strip strings/comments crudely, then compare bracket depth
    var s = code.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/[^\n]*/g, '').replace(/"(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*'|`(?:\\.|[^`\\])*`/g, '""');
    var st = [], line = 1, close = { ')': '(', ']': '[', '}': '{' };
    for (var i = 0; i < s.length; i++) {
      var c = s[i];
      if (c === '\n') line++;
      else if (c === '(' || c === '[' || c === '{') st.push({ c: c, line: line });
      else if (close[c]) { var t = st.pop(); if (!t || t.c !== close[c]) return 'Unexpected "' + c + '" near line ' + line; }
    }
    return st.length ? 'Unclosed "' + st[st.length - 1].c + '" opened near line ' + st[st.length - 1].line : '';
  }
  function checkOne(p, code) {
    var e = U.ext(p), msg = '';
    if (e === 'js' || e === 'mjs') {
      try { new Function(code); } catch (x) {
        if (/import|export|await/.test(String(x.message)) && /^\s*(import|export)\b/m.test(code)) { try { new Function('return async()=>{' + code.replace(/^\s*(import|export)[^\n]*\n?/gm, '') + '}'); } catch (y) { msg = y.message; } }
        else msg = x.message;
      }
    } else if (e === 'json') {
      try { JSON.parse(code); } catch (x) { msg = x.message; }
    } else if (e === 'css') {
      msg = balance(code);
      var o = (code.match(/\/\*/g) || []).length, c = (code.match(/\*\//g) || []).length;
      if (!msg && o !== c) msg = 'Unclosed comment';
    } else if (e === 'html' || e === 'htm') {
      var voidT = /^(area|base|br|col|embed|hr|img|input|link|meta|param|source|track|wbr|!doctype)$/i, st = [], re = /<(\/?)([a-z][a-z0-9-]*|!doctype)\b[^>]*?(\/?)>/gi, m;
      var body = code.replace(/<!--[\s\S]*?-->/g, '').replace(/<(script|style)\b[^>]*>[\s\S]*?<\/\1>/gi, function (x, t) { return '<' + t + '></' + t + '>'; });
      while ((m = re.exec(body))) {
        var tag = m[2].toLowerCase();
        if (voidT.test(tag) || m[3]) continue;
        if (m[1]) { var top = st.pop(); if (top !== tag) { msg = 'Closing </' + tag + '> does not match ' + (top ? '<' + top + '>' : 'any open tag'); break; } }
        else st.push(tag);
      }
      if (!msg && st.length && !/^(html|body|head|p|li)$/.test(st[st.length - 1])) msg = 'Unclosed <' + st[st.length - 1] + '>';
      if (!msg) {
        var scripts = code.match(/<script\b(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/gi) || [];
        for (var i = 0; i < scripts.length && !msg; i++) {
          var inner = scripts[i].replace(/^<script[^>]*>|<\/script>$/gi, '');
          if (inner.trim()) { try { new Function(inner); } catch (x) { msg = 'Inline <script> ' + x.message; } }
        }
      }
    } else if (e === 'py') {
      msg = balance(code.replace(/#[^\n]*/g, ''));
      if (!msg && /^\t+ +| +\t+/m.test(code)) msg = 'Mixed tabs and spaces in indentation';
    } else return null; // unknown type: not checked
    return msg;
  }

  // ------------------------------------------------------------------ test harness (runs *.test.js / test*.js in the sandbox)
  var HARNESS = '(function(){var p=0,f=0;window.assert=function(c,m){if(!c)throw new Error(m||"assertion failed")};' +
    'window.assertEqual=function(a,b,m){if(JSON.stringify(a)!==JSON.stringify(b))throw new Error((m||"not equal")+": got "+JSON.stringify(a)+", expected "+JSON.stringify(b))};' +
    'window.test=function(n,fn){try{fn();p++;console.log("T:PASS "+n)}catch(e){f++;console.log("T:FAIL "+n+": "+(e&&e.message||e))}};' +
    'window.addEventListener("load",function(){setTimeout(function(){console.log("T:DONE "+p+" "+f)},50)})})();';
  function testFiles() { return Object.keys(files()).filter(function (n) { return /(^|\/)(test[\w.-]*|[\w.-]+\.test|[\w.-]+_test)\.m?js$/i.test(n); }); }

  // ------------------------------------------------------------------ the tools
  var reg = {};
  function def(t) { reg[t.name] = t; }

  // Repository reconnaissance inspired by Harness's repo-map workflow. This is read-only and
  // operates only on the currently open ReCode project (never on the phone filesystem).
  def({
    name: 'project_map', perm: 'read', params: '[focus]',
    description: 'Create a compact repository map: folders, entry points, manifests, tests and likely build files. Optional focus filters paths.',
    run: function (a) {
      var all = St().fileList(), focus = String(a.focus || '').trim().toLowerCase();
      var picked = focus ? all.filter(function (p) { return p.toLowerCase().indexOf(focus) >= 0; }) : all;
      var dirs = {}, ext = {}, manifests = [], tests = [], entries = [], large = [];
      picked.forEach(function (p) {
        var parts = p.split('/');
        for (var i = 1; i < parts.length; i++) dirs[parts.slice(0, i).join('/') + '/'] = 1;
        var e = U.ext(p) || '(no extension)'; ext[e] = (ext[e] || 0) + 1;
        if (/(^|\/)(package\.json|build\.gradle(\.kts)?|settings\.gradle(\.kts)?|pom\.xml|pyproject\.toml|Cargo\.toml|go\.mod|AndroidManifest\.xml)$/i.test(p)) manifests.push(p);
        if (/(^|\/)(test[^/]*|[^/]+\.test|[^/]+_test)\.[^.]+$/i.test(p)) tests.push(p);
        if (/(^|\/)(index\.html|main\.[^.]+|app\.[^.]+|MainActivity\.kt|App\.[^.]+)$/i.test(p)) entries.push(p);
        if (String(files()[p] || '').length > 12000) large.push(p + ' (' + lineCount(files()[p]) + ' lines)');
      });
      return 'PROJECT MAP (' + picked.length + '/' + all.length + ' files)' + (focus ? ' · focus: ' + focus : '') + '\nFolders: ' + (Object.keys(dirs).sort().slice(0, 45).join(', ') || '(root only)') + '\nFile types: ' + Object.keys(ext).sort().map(function (k) { return k + ': ' + ext[k]; }).join(', ') + '\nBuild/manifests: ' + (manifests.join(', ') || 'not found') + '\nLikely entry points: ' + (entries.join(', ') || 'not found') + '\nTests: ' + (tests.join(', ') || 'not found') + '\nLarge files: ' + (large.join(', ') || 'none') + '\nNext: inspect the relevant manifest and entry point before editing.';
    }
  });

  def({
    name: 'read_file', perm: 'read', params: 'path, [start_line], [end_line]',
    description: 'Read a file (large files: give a line range).',
    run: function (a) {
      var p = must(a.path), c = files()[p], lines = c.split('\n'), s = Math.max(1, num(a.start_line, 1)), e = num(a.end_line, 0);
      if (!e && c.length > 3500 && !a.start_line) e = Math.min(lines.length, 120);
      if (!e) return '--- ' + p + ' (' + lines.length + ' lines) ---\n' + c;
      e = Math.min(lines.length, e);
      return '--- ' + p + ' lines ' + s + '-' + e + ' of ' + lines.length + (e < lines.length ? ' (use start_line/end_line for more)' : '') + ' ---\n' +
        lines.slice(s - 1, e).map(function (l, i) { return (s + i) + ': ' + l; }).join('\n');
    }
  });
  def({
    name: 'write_file', perm: 'write', params: 'path, content',
    description: 'Create a file or replace it completely with content.',
    run: function (a, ctx) {
      var p = path(a.path), content = a.content;
      if (content == null || (!String(content).trim() && !a.allow_empty)) throw fail('No content given for ' + p + '. Put the full file in a code block after the TOOL line.');
      if (RC.assets && RC.assets.isBinary(p)) {
        var alt = RC.assets.fixPath(p);
        if (alt && RC.assets.isImage(p)) { var svg = RC.assets.make(alt, { name: (RC.store && RC.store.cur && RC.store.cur.name) || 'Brand', type: 'generic' }); return St().putFile(alt, svg).then(function () { ctx.touch(alt); return p + ' is a binary image and cannot be written as text, so ReCode created ' + alt + ' (SVG) instead. Use ' + alt + ' in the HTML/CSS.'; }); }
        throw fail(p + ' is a binary file type. Only text files can be written. Use an SVG for pictures.');
      }
      if (RC.assets && RC.assets.degenerate(String(content))) throw fail('The content for ' + p + ' is an endless repeat of the same characters. Write the real file.');
      var existed = files()[p] !== undefined;
      return St().putFile(p, String(content)).then(function () {
        ctx.touch(p);
        return (existed ? 'Replaced ' : 'Created ') + p + ' (' + lineCount(String(content)) + ' lines, ' + U.bytes(String(content).length) + ').';
      });
    }
  });
  def({
    name: 'edit_file', perm: 'write', params: 'path, old_text, new_text, [replace_all]',
    description: 'Replace exact text in a file. old_text must match exactly and be unique (or set replace_all).',
    run: function (a, ctx) {
      var p = must(a.path), c = files()[p], o = a.old_text == null ? a.search : a.old_text, n = a.new_text == null ? (a.replace == null ? '' : a.replace) : a.new_text;
      if (o == null || o === '') throw fail('old_text is empty. Give the exact existing text to replace.');
      o = String(o); n = String(n);
      var idx = c.indexOf(o);
      if (idx < 0) { // tolerate whitespace differences at line ends / indentation
        var re = new RegExp(o.split('\n').map(function (l) { return l.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\s+/g, '\\s+'); }).filter(Boolean).join('\\s*\\n\\s*'));
        var mm = o.trim() ? re.exec(c) : null;
        if (!mm) throw fail('old_text was not found in ' + p + '. Use read_file to copy the exact text.');
        o = mm[0]; idx = mm.index;
      }
      var count = c.split(o).length - 1;
      if (count > 1 && !(a.replace_all === true || /^(true|yes|1|all)$/i.test(String(a.replace_all)))) throw fail('old_text appears ' + count + ' times in ' + p + '. Add more surrounding lines to make it unique, or set replace_all.');
      var out = count > 1 ? c.split(o).join(n) : c.slice(0, idx) + n + c.slice(idx + o.length);
      return St().putFile(p, out).then(function () { ctx.touch(p); return 'Edited ' + p + ' (' + count + ' replacement' + (count > 1 ? 's' : '') + ', now ' + lineCount(out) + ' lines).'; });
    }
  });
  def({
    name: 'delete_file', perm: 'delete', params: 'path',
    description: 'Delete a file (or every file under a folder path ending in /).',
    run: function (a, ctx) {
      var raw = String(a.path || '').trim();
      if (/\/$/.test(raw)) {
        var d = path(raw, { dir: true }) + '/', list = Object.keys(files()).filter(function (x) { return x.indexOf(d) === 0; });
        if (!list.length) throw fail('Folder is empty or does not exist: ' + d);
        return Promise.all(list.map(function (x) { return St().delFile(x); })).then(function () { list.forEach(ctx.touch); return 'Deleted ' + list.length + ' file(s) in ' + d; });
      }
      var p = must(raw);
      return St().delFile(p).then(function () { ctx.touch(p); return 'Deleted ' + p + '.'; });
    }
  });
  def({
    name: 'list_files', perm: 'read', params: '[folder]',
    description: 'List project files with sizes.',
    run: function (a) {
      var pre = a.folder || a.path ? path(a.folder || a.path, { dir: true }).replace(/\/?$/, '/') : '';
      var l = St().fileList().filter(function (x) { return x.indexOf(pre) === 0; });
      if (!l.length) return pre ? 'No files in ' + pre : 'The project is empty.';
      return l.length + ' file(s):\n' + l.map(function (x) { return x + '  (' + lineCount(files()[x]) + ' lines, ' + U.bytes(files()[x].length) + ')'; }).join('\n');
    }
  });
  def({
    name: 'search_files', perm: 'read', params: 'pattern',
    description: 'Find files by name (substring or glob like *.css, src/**).',
    run: function (a) {
      var q = String(a.pattern || a.query || a.name || '').trim();
      if (!q) throw fail('Missing pattern.');
      var re = /[*?]/.test(q) ? globRe(q.indexOf('/') < 0 ? '**' + q : q) : null, ql = q.toLowerCase();
      var l = St().fileList().filter(function (x) { return re ? re.test(x) : x.toLowerCase().indexOf(ql) >= 0; });
      return l.length ? l.length + ' match(es):\n' + l.join('\n') : 'No file name matches "' + q + '".';
    }
  });
  def({
    name: 'search_text', perm: 'read', params: 'pattern, [path]',
    description: 'Search file contents (regex or plain text), shows file:line: text.',
    run: function (a) {
      var q = String(a.pattern || a.query || a.text || ''), g = a.path || a.glob || a.include || '';
      if (!q) throw fail('Missing pattern.');
      var re; try { re = new RegExp(q, 'i'); } catch (e) { re = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i'); }
      var gre = g ? globRe(/[*?]/.test(g) ? (g.indexOf('/') < 0 ? '**' + g : g) : U.normPath(g)) : null, out = [], total = 0;
      St().fileList().forEach(function (f) {
        if (gre && !gre.test(f)) return;
        files()[f].split('\n').forEach(function (l, i) { if (re.test(l)) { total++; if (out.length < 25) out.push(f + ':' + (i + 1) + ': ' + U.clip(l.trim(), 140, '…')); } });
      });
      return total ? total + ' match(es)' + (total > out.length ? ' (showing ' + out.length + ')' : '') + ':\n' + out.join('\n') : 'No matches for "' + q + '".';
    }
  });
  def({
    name: 'create_directory', perm: 'read', params: 'path',
    description: 'Not needed: write_file creates folders itself.',
    run: function (a) {
      var d = path(a.path, { dir: true });
      if (/\.[a-z0-9]{1,8}$/i.test(U.base(d))) throw fail('"' + d + '" looks like a file name, not a folder.');
      return 'OK - folder ' + d + '/ exists as soon as you write a file into it (write_file ' + d + '/index.html). Do not call create_directory again; write the files now.';
    }
  });
  def({
    name: 'scaffold', perm: 'write', params: 'name',
    description: 'Write a tested starter project: calculator, snake or todo.',
    run: function (a, ctx) {
      var n = String(a.name || a.template || '').toLowerCase().trim(), R = RC.recipes, rec = R && R.get(n);
      if (!rec) throw fail('Unknown template "' + n + '". Available: ' + (R ? R.names().join(', ') : 'none') + '.');
      var names = Object.keys(rec.files);
      return names.reduce(function (pr, f) { return pr.then(function () { return St().putFile(f, rec.files[f]); }).then(function () { ctx.touch(f); }); }, Promise.resolve())
        .then(function () { return 'Wrote the tested "' + rec.title + '" template: ' + names.join(', ') + '. It already works. Next: run_tests, then edit_file only what the user asked, then give the final answer.'; });
    }
  });
  function move(a, ctx, verb) {
    var from = must(a.from || a.path || a.src), to = a.to || a.dest || a.new_path || a.new_name;
    if (!to) throw fail('Missing destination.');
    var tp = String(to).trim();
    if (/\/$/.test(tp)) tp = tp + U.base(from);
    tp = path(tp);
    if (tp === from) throw fail('Source and destination are the same.');
    if (files()[tp] !== undefined) throw fail('Destination ' + tp + ' already exists. Delete it first or choose another name.');
    var c = files()[from];
    return St().putFile(tp, c).then(function () { return St().delFile(from); }).then(function () { ctx.touch(from); ctx.touch(tp); return verb + ' ' + from + ' -> ' + tp + '.'; });
  }
  def({ name: 'rename_file', perm: 'write', params: 'from, to', description: 'Rename a file (same folder or new name).', run: function (a, c) { return move(a, c, 'Renamed'); } });
  def({ name: 'move_file', perm: 'write', params: 'from, to', description: 'Move a file to another path or folder (to ending in / keeps the name).', run: function (a, c) { return move(a, c, 'Moved'); } });
  def({
    name: 'get_file_info', perm: 'read', params: 'path',
    description: 'Size, line count, type and a structure digest of a file.',
    run: function (a) {
      var p = must(a.path), c = files()[p];
      return p + '\ntype: ' + (U.ext(p) || 'none') + '\nsize: ' + U.bytes(c.length) + ' (' + c.length + ' chars, ~' + U.tok(c) + ' tokens)\nlines: ' + lineCount(c) +
        '\n' + RC.agents.digest(p, c) + (RC.run && RC.run.entry(files()) === p ? '\n(this is the entry page)' : '');
    }
  });
  def({
    name: 'check_syntax', perm: 'read', params: '[path]',
    description: 'Check syntax of one file (or all files): js, json, css, html, py.',
    run: function (a) {
      var names = a.path ? [must(a.path)] : St().fileList(), bad = [], ok = 0, skipped = 0;
      names.forEach(function (p) {
        var m = checkOne(p, files()[p]);
        if (m === null) skipped++; else if (m) bad.push(p + ': ' + m); else ok++;
      });
      if (!bad.length) return 'Syntax OK for ' + ok + ' file(s)' + (skipped ? ' (' + skipped + ' not checkable)' : '') + '.';
      return bad.length + ' syntax problem(s):\n' + bad.join('\n') + (ok ? '\n' + ok + ' other file(s) OK.' : '');
    }
  });
  def({
    name: 'run_command', perm: 'exec', params: 'command',
    description: 'Run a built-in command. ReCode has no shell. Supported: run (load the page in the sandbox and report errors), check, ls [folder], cat <file>, grep <text> [glob], wc <file>.',
    run: function (a, ctx) {
      var cmd = String(a.command || a.cmd || '').trim();
      if (!cmd) throw fail('Missing command.');
      var parts = cmd.match(/"[^"]*"|'[^']*'|\S+/g).map(function (x) { return x.replace(/^["']|["']$/g, ''); }), c = parts[0].toLowerCase(), rest = parts.slice(1);
      if (c === 'ls') return reg.list_files.run({ folder: rest[0] }, ctx);
      if (c === 'cat') return reg.read_file.run({ path: rest[0] }, ctx);
      if (c === 'grep') return reg.search_text.run({ pattern: rest[0], path: rest[1] }, ctx);
      if (c === 'wc') { var p = must(rest[0]); return lineCount(files()[p]) + ' lines ' + files()[p].length + ' chars ' + p; }
      if (c === 'check') return reg.run_tests.run({ only: 'page' }, ctx);
      if (c === 'run' || c === 'preview' || c === 'start') return reg.run_tests.run({ only: 'page' }, ctx);
      throw fail('Unknown command "' + c + '". ReCode has no shell. Supported: run, check, ls, cat, grep, wc.');
    }
  });
  // V13 native integrations. All native execution is scoped to the private ReCode workspace.
  def({ name: 'multi_agent_code', perm: 'exec', params: 'task', description: 'Run a coordinated specialist team: planner, explorer, architect and security inspect in parallel; coder implements; tester verifies; reviewer audits serially to avoid conflicting edits.', run: async function (a, ctx) { if (!RC.engine || !RC.engine.runTeam) throw fail('V13 multi-agent engine unavailable.'); return await RC.engine.runTeam(String(a.task || ''), ctx.run); }});
  def({ name: 'sync_native_workspace', perm: 'write', params: '', description: 'Copy every file in the currently open ReCode project to the app-private native workspace so Git, shell and Gradle can operate on a real directory.', run: async function () {
    if (!RC.native || !RC.native.has) throw fail('Native workspace requires the installed Android app.');
    var names = St().fileList(), count = 0;
    for (var i = 0; i < names.length; i++) { await RC.native.workspaceWrite(names[i], files()[names[i]]); count++; }
    return 'Synced ' + count + ' project files to ' + RC.native.workspace();
  }});
  def({ name: 'native_shell', perm: 'exec', params: 'command', description: 'Run a real Android /system/bin/sh command in ReCode private workspace. Commands may change files; avoid destructive operations. Timeout is capped at 120 seconds.', run: async function (a) { return await RC.native.shell(String(a.command || ''), 60); }});
  def({ name: 'git_status', perm: 'read', params: '', description: 'Read actual Git status from the ReCode native workspace using JGit.', run: async function () { return await RC.native.git('status'); }});
  def({ name: 'git_init', perm: 'exec', params: '', description: 'Initialize a real Git repository in the ReCode native workspace.', run: async function () { return await RC.native.git('init'); }});
  def({ name: 'git_commit', perm: 'exec', params: '[message]', description: 'Stage all files and create a real Git commit in the ReCode native workspace.', run: async function (a) { return await RC.native.git('commit', String(a.message || 'ReCode update')); }});
  def({ name: 'mcp_request', perm: 'exec', params: 'endpoint, method, [params]', description: 'Send a JSON-RPC request to a user-configured MCP HTTP endpoint. HTTPS required except localhost. Supports methods such as initialize, tools/list and tools/call.', run: async function (a) { var p = a.params || {}; if (typeof p === 'string') { try { p = JSON.parse(p); } catch (_) { p = {}; } } return await RC.native.mcp(String(a.endpoint || ''), String(a.method || 'tools/list'), p); }});
  def({ name: 'shizuku_status', perm: 'read', params: '', description: 'Check whether Shizuku is connected and whether ReCode has permission. Does not execute privileged commands.', run: function () { return RC.native.shizukuStatus(); }});
  def({ name: 'shizuku_shell', perm: 'exec', params: 'command', description: 'Run a real Shizuku shell command with the user-granted shell/root identity, in the ReCode private workspace. Requires Shizuku API 11–13 and explicit permission.', run: async function (a) { return await RC.native.shizukuShell(String(a.command || ''), 45); }});
  def({ name: 'shizuku_request_permission', perm: 'exec', params: '', description: 'Ask Shizuku to display its permission prompt. The user must approve it in Shizuku.', run: function () { return RC.native.shizukuRequest(); }});
  def({ name: 'browser_automate', perm: 'exec', params: 'url, script', description: 'Load an HTTPS page in an isolated Android WebView and execute a short JavaScript async function body against its DOM. Example script: return {title:document.title, links:[...document.links].slice(0,10).map(a=>a.href)};', run: async function (a) { return await RC.native.browser(String(a.url || ''), String(a.script || 'return document.title;')); }});
  def({ name: 'android_build', perm: 'exec', params: '[task]', description: 'Attempt a real Gradle build in the synced native workspace. Supported tasks: assembleDebug, assembleRelease, test, lint, tasks. Requires a working on-device Java/Gradle/Android SDK toolchain.', run: async function (a) { return await RC.native.androidBuild(String(a.task || 'assembleDebug')); }});

  // V14: automated bug triage, scoped parallel coding and independent code review.
  def({ name: 'detect_bugs', perm: 'read', params: '[focus]', description: 'Scan the open project for supported syntax errors, suspicious empty files, unresolved local references and runtime/test failures. Read-only; reports evidence and affected paths.', run: async function (a, ctx) {
    var all = St().fileList(), focus = String(a.focus || '').trim().toLowerCase(), findings = [], checked = 0;
    all.forEach(function (p) {
      if (focus && p.toLowerCase().indexOf(focus) < 0) return;
      var c = String(files()[p] || ''), issue = checkOne(p, c);
      if (issue) { checked++; findings.push({ severity: 'high', path: p, message: issue }); }
      if (!c.trim()) findings.push({ severity: 'medium', path: p, message: 'File is empty.' });
      if (/\.(html?|css|js|mjs)$/i.test(p)) {
        var refs = [], re = /(?:src|href)\s*=\s*["']([^"']+)["']/gi, m;
        while ((m = re.exec(c))) { var ref = m[1].split(/[?#]/)[0]; if (!/^(?:https?:|data:|#|\/|javascript:)/i.test(ref) && /\.(?:js|css|html?)$/i.test(ref)) { var base = p.indexOf('/') >= 0 ? p.slice(0, p.lastIndexOf('/') + 1) : ''; var rel = U.normPath(base + ref); if (files()[rel] === undefined && files()[ref] === undefined) refs.push(ref); } }
        if (refs.length) findings.push({ severity: 'medium', path: p, message: 'Missing local references: ' + refs.join(', ') });
      }
    });
    var tests = 'Not run';
    if (a.run_tests === true && RC.run) { var tr = await reg.run_tests.run({}, ctx); tests = tr; if (/FAILED|PROBLEM|TEST FAILED|TEST ERROR/.test(tr)) findings.push({ severity: 'high', path: '(test suite)', message: U.clip(tr, 900, '…') }); }
    return 'BUG SCAN: ' + all.length + ' files inspected; ' + checked + ' syntax-checked.\n' + (findings.length ? findings.map(function (x) { return '[' + x.severity.toUpperCase() + '] ' + x.path + ' — ' + x.message; }).join('\n') : 'No supported static issues detected.') + '\nTests: ' + tests + '\nNote: static heuristics can miss bugs; review findings before applying changes.';
  }});
  def({ name: 'automatic_bug_repair', perm: 'exec', params: 'task', description: 'Run bug detection, ask the debugger to establish root cause, let the fixer apply minimal evidence-based changes, then rerun tests. Never claims repair unless verification passes.', run: async function (a, ctx) {
    if (!RC.subagents) throw fail('Subagent runtime unavailable.');
    var task = String(a.task || 'Find and repair reproducible bugs in the open project.').trim();
    var scan = await reg.detect_bugs.run({ run_tests: true }, ctx);
    var diagnosis = await RC.subagents.run('debugger', 'Investigate these bug scan results and the user task. Do not edit files. Identify only reproducible/root-cause issues and exact file-level fixes.\nTASK: ' + task + '\nSCAN:\n' + scan, { run: ctx.run, goal: task, depth: 0 });
    if (!diagnosis.ok) return 'Bug scan completed, but diagnosis failed. No automatic repair applied.\n' + scan + '\n' + diagnosis.text;
    var fix = await RC.subagents.run('fixer', 'Apply the smallest safe fixes for confirmed issues only. If evidence is insufficient, do not guess. Run tests after changes.\nTASK: ' + task + '\nDIAGNOSIS:\n' + diagnosis.text, { run: ctx.run, goal: task, depth: 0 });
    var verify = await reg.run_tests.run({}, ctx);
    return 'AUTOMATIC BUG REPAIR\n' + scan + '\nDIAGNOSIS:\n' + diagnosis.text + '\nFIXER:\n' + fix.text + '\nFINAL VERIFICATION:\n' + verify + '\n' + (/^PASSED/.test(verify) ? 'Verification passed.' : 'Verification did not pass; remaining failures require investigation.');
  }});
  def({ name: 'parallel_coding_workers', perm: 'exec', params: 'workers (JSON array: [{task,files:[...]}])', description: 'Run up to three coding workers concurrently on explicitly disjoint file scopes. Each worker is technically restricted to its assigned paths; overlapping scopes are rejected. Tests/review follow after all workers finish.', run: async function (a, ctx) {
    if (!RC.subagents) throw fail('Subagent runtime unavailable.');
    var ws = a.workers; if (typeof ws === 'string') { try { ws = JSON.parse(ws); } catch (_) { throw fail('workers must be a JSON array.'); } }
    if (!Array.isArray(ws) || ws.length < 2 || ws.length > 3) throw fail('Provide 2 or 3 workers, each with task and files array.');
    var seen = {}, normalized = ws.map(function (w, i) { if (!w || !String(w.task || '').trim() || !Array.isArray(w.files) || !w.files.length) throw fail('Worker ' + (i + 1) + ' needs a task and at least one owned file.'); var scope = w.files.map(function (f) { var n = path(f); if (seen[n]) throw fail('Overlapping file ownership: ' + n + '. Split work into disjoint files.'); seen[n] = 1; return n; }); return { task: String(w.task), files: scope }; });
    var results = await Promise.all(normalized.map(function (w, i) { return RC.subagents.run('coder', 'You are worker ' + (i + 1) + ' of ' + normalized.length + '. Implement only your assigned subtask. Do not touch other files.\nTASK: ' + w.task + '\nOWNED FILES: ' + w.files.join(', '), { run: ctx.run, goal: w.task, depth: 0, fileScope: w.files }); }));
    var report = results.map(function (r) { return '[' + r.name + ' ' + (r.ok ? 'OK' : 'FAILED') + ']\n' + r.text; }).join('\n\n');
    var verify = await reg.run_tests.run({}, ctx);
    return 'PARALLEL CODING WORKERS (' + results.filter(function (r) { return r.ok; }).length + '/' + results.length + ' completed)\n' + report + '\nPOST-WORK VERIFICATION:\n' + verify;
  }});
  def({ name: 'automatic_code_review', perm: 'read', params: '[focus]', description: 'Run independent reviewer and security reviewers in parallel against the current project. Read-only; prioritizes correctness, regressions, security and maintainability.', run: async function (a, ctx) {
    if (!RC.subagents) throw fail('Subagent runtime unavailable.');
    var focus = String(a.focus || 'Review the current project and recent changes.');
    var rs = await Promise.all(['reviewer','security'].map(function (name) { return RC.subagents.run(name, 'Perform a read-only review. Focus: ' + focus + '. Inspect relevant files and report findings with severity, file and line, impact, and a concrete recommendation. Do not edit files.', { run: ctx.run, goal: focus, depth: 0 }); }));
    return 'AUTOMATIC CODE REVIEW\n' + rs.map(function (r) { return '## ' + r.name + ' (' + (r.ok ? 'complete' : 'failed') + ')\n' + r.text; }).join('\n\n') + '\nReview is advisory; verify each finding before changing code.';
  }});

  def({
    name: 'run_tests', perm: 'exec', params: '[only]',
    description: 'Run project checks: file/reference lint, a real run of the page in the sandbox (runtime errors), and test files (test*.js, *.test.js using test(name, fn) and assert()).',
    run: async function (a) {
      if (!RC.run) throw fail('The runner is not available.');
      var lines = [], bad = 0;
      var r = await RC.run.check();
      r.fixes.forEach(function (m) { lines.push('auto-fix: ' + m); });
      r.issues.forEach(function (m) { bad++; lines.push('PROBLEM ' + m.file + ': ' + m.msg); });
      lines.push(r.ran ? (r.issues.length ? 'Page ran with problems.' : 'Page ran without errors.') : 'No page to run (static checks only).');
      var tf = a.only === 'page' ? [] : testFiles();
      if (tf.length) {
        var copy = Object.assign({}, files()), entry = RC.run.entry(copy);
        copy['__harness.js'] = HARNESS;
        var tags = ['__harness.js'].concat(tf).map(function (x) { return '<script src="' + x + '"></script>'; }).join('');
        var linked = function (h) { return tf.every(function (x) { return h.indexOf(x) >= 0; }); };
        if (entry) {
          var h = copy[entry];
          if (!linked(h)) copy[entry] = /<\/body>/i.test(h) ? h.replace(/<\/body>/i, tags + '</body>') : h + tags;
          else copy[entry] = h.replace(/<head(\s[^>]*)?>/i, function (x) { return x + '<script src="__harness.js"></script>'; });
        } else {
          copy['index.html'] = '<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>' + Object.keys(files()).filter(function (x) { return /\.m?js$/i.test(x) && tf.indexOf(x) < 0; }).map(function (x) { return '<script src="' + x + '"></script>'; }).join('').replace(/^/, '<script src="__harness.js"></script>') + tf.map(function (x) { return '<script src="' + x + '"></script>'; }).join('') + '</body></html>';
        }
        var pr = await RC.run.probe(copy, 1500), pass = 0, fl = 0;
        pr.logs.forEach(function (l) {
          var m = /T:(PASS|FAIL) (.*)/.exec(l);
          if (m) { if (m[1] === 'PASS') pass++; else { fl++; bad++; lines.push('TEST FAILED ' + m[2]); } }
        });
        pr.errors.forEach(function (e) { if (!/^console\.error: T:/.test(e.msg)) { bad++; lines.push('TEST ERROR ' + (e.file ? e.file + (e.line ? ':' + e.line : '') + ' ' : '') + e.msg); } });
        lines.push('Tests: ' + pass + ' passed, ' + fl + ' failed (' + tf.join(', ') + ').');
      } else if (a.only !== 'page') lines.push('No test files found (name them test*.js or *.test.js).');
      return (bad ? 'FAILED - ' + bad + ' problem(s)\n' : 'PASSED\n') + lines.join('\n');
    }
  });

  def({
    name: 'delegate', perm: 'read', params: 'agent, task',
    description: 'Hand a focused sub-task to a specialist agent (planner, explorer, frontend, backend, database, coder, debugger, fixer, tester, reviewer, security, optimizer, documentation, researcher, architect). It works on its own and returns a short report.',
    run: async function (a, ctx) {
      if (!RC.subagents) throw fail('Subagents are not available.');
      if ((ctx.depth || 0) >= 1) throw fail('Subagents cannot delegate further. Do the work yourself.');
      var name = String(a.agent || a.name || '').trim(), task = a.task || a.prompt || a.request;
      if (!name || !RC.subagents.get(name)) throw fail('No agent named "' + name + '". Available: ' + RC.subagents.names().join(', '));
      var r = await RC.subagents.run(name, task, { run: ctx.run, goal: ctx.goal, depth: ctx.depth || 0 });
      if (!r.ok) throw fail(r.text);
      return '[' + r.name + ' report]\n' + r.text;
    }
  });
  def({
    name: 'search_knowledge', perm: 'read', params: 'query',
    description: 'Search the knowledge base (your documents and project files) with BM25 and return the best passages.',
    run: function (a) {
      var q = String(a.query || a.pattern || '').trim();
      if (!q) throw fail('Missing query.');
      if (!RC.rag || !RC.rag.corpus().length) return 'The knowledge base is empty.';
      var hits = RC.rag.search(q, { k: 3 });
      return hits.length ? RC.rag.format(hits, 1800) : 'Nothing relevant found for "' + q + '".';
    }
  });
  def({
    name: 'web_search', perm: 'read', params: 'query',
    description: 'Search the web (needs internet and "Internet research" enabled). Returns titles, links and snippets.',
    run: async function (a) {
      var q = String(a.query || '').trim();
      if (!q) throw fail('Missing query.');
      if (RC.settings.autoResearch === false) throw fail('Web access is switched off in Settings (Internet research).');
      if (!RC.native.online()) throw fail('No internet connection. Work offline.');
      var h = await RC.native.search(q, 5);
      return h.length ? h.map(function (x, i) { return (i + 1) + '. ' + x.title + ' - ' + x.url + (x.snippet ? '\n   ' + U.clip(x.snippet, 160, '…') : ''); }).join('\n') : 'No results.';
    }
  });
  def({
    name: 'web_read', perm: 'read', params: 'url',
    description: 'Read a web page returned by web_search (text only).',
    run: async function (a) {
      var u = String(a.url || '').trim();
      if (!/^https?:\/\//i.test(u)) throw fail('Give a full http(s) URL.');
      if (RC.settings.autoResearch === false) throw fail('Web access is switched off in Settings (Internet research).');
      if (!RC.native.online()) throw fail('No internet connection. Work offline.');
      var d = await RC.native.read(u, 2500);
      return (d.title ? d.title + '\n' : '') + U.clip(d.text, 2500, '…');
    }
  });

  // V11: repository intelligence tools (read-only; operate only on the open project).
  def({
    name: 'dependency_audit', perm: 'read', params: '[path]',
    description: 'Inspect package.json and Gradle manifests for declared dependencies, scripts, versions and risky wildcard/latest pins. Does not install anything.',
    run: function (a) {
      var wanted = String(a.path || '').trim(), names = St().fileList().filter(function (p) {
        return /(^|\/)(package\.json|build\.gradle(\.kts)?|settings\.gradle(\.kts)?|gradle\.libs\.versions\.toml)$/i.test(p) && (!wanted || p.indexOf(wanted) === 0);
      });
      if (!names.length) return 'No package or Gradle dependency manifests found in the open project.';
      var out = [];
      names.forEach(function (p) {
        var c = files()[p] || '';
        if (/package\.json$/i.test(p)) {
          try { var j = JSON.parse(c); out.push(p + ': name=' + (j.name || '(unnamed)') + ', version=' + (j.version || '(unspecified)'));
            ['dependencies','devDependencies','peerDependencies','optionalDependencies'].forEach(function (k) { var d=j[k]||{}, ks=Object.keys(d); if(ks.length) out.push('  '+k+': '+ks.sort().map(function(x){return x+'@'+d[x]+((/\*|latest|\^0?\.0?\.0/i.test(d[x]))?' [review pin]':'');}).join(', ')); });
            if(j.scripts) out.push('  scripts: '+Object.keys(j.scripts).sort().join(', '));
          } catch(e) { out.push(p+': INVALID JSON - '+e.message); }
        } else {
          var lines=c.split('\n'), hits=[];
          lines.forEach(function(l,i){ if(/\b(implementation|api|compileOnly|runtimeOnly|testImplementation|classpath|plugins|alias)\s*\(?/.test(l) || /^(\s*\w[\w.-]*\s*=\s*["']?[^"']+["']?\s*)$/.test(l) && /libs\.versions\.toml/i.test(p)) hits.push((i+1)+': '+l.trim()); });
          out.push(p+': '+(hits.length?hits.slice(0,100).join('\n  '):'No simple dependency declarations detected.'));
        }
      });
      return 'DEPENDENCY AUDIT (static manifest inspection only)\n'+out.join('\n');
    }
  });
  def({
    name: 'secret_scan', perm: 'read', params: '[path]',
    description: 'Scan project text for likely hard-coded credentials and private keys. Reports locations only and never prints matched secret values.',
    run: function (a) {
      var focus=String(a.path||'').trim(), patterns=[
        {n:'private key header',r:/-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/},
        {n:'API token / secret assignment',r:/\b(?:api[_-]?key|access[_-]?token|client[_-]?secret|password|passwd)\b\s*[:=]\s*["'][^"'\s]{8,}["']/i},
        {n:'AWS access key shape',r:/\bAKIA[0-9A-Z]{16}\b/},
        {n:'GitHub token shape',r:/\bgh[pousr]_[A-Za-z0-9]{20,}\b/},
        {n:'Bearer token literal',r:/\bBearer\s+[A-Za-z0-9._~+\/-]{20,}/i}
      ], out=[], scanned=0;
      St().fileList().forEach(function(p){ if(focus && p.indexOf(focus)!==0)return; var c=String(files()[p]||''); if(c.length>300000)return; scanned++; c.split('\n').forEach(function(line,i){ patterns.forEach(function(x){ if(x.r.test(line)) out.push(p+':'+(i+1)+' — '+x.n+' (value hidden)'); x.r.lastIndex=0; }); }); });
      return 'SECRET SCAN: '+scanned+' text files scanned.\n'+(out.length?'Potential exposures ('+out.length+'):\n'+out.slice(0,80).join('\n'):'No obvious credential patterns found. This heuristic scan cannot guarantee secrets are absent.');
    }
  });
  def({
    name: 'change_impact', perm: 'read', params: 'path',
    description: 'Find imports, script/style references and textual references to a project file before editing or renaming it.',
    run: function (a) {
      var target=must(a.path), base=U.base(target), stem=base.replace(/\.[^.]+$/,''), out=[];
      St().fileList().forEach(function(p){ if(p===target)return; var c=String(files()[p]||''), lines=c.split('\n'), hits=[];
        lines.forEach(function(l,i){ if(l.indexOf(target)>=0 || l.indexOf(base)>=0 || (stem.length>2 && new RegExp('(^|[^\\w$])'+stem.replace(/[.*+?^${}()|[\\]\\\\]/g,'\\$&')+'([^\\w$]|$)','i').test(l))) hits.push((i+1)+': '+U.clip(l.trim(),150,'…')); });
        if(hits.length) out.push(p+'\n  '+hits.slice(0,12).join('\n  '));
      });
      return 'CHANGE IMPACT for '+target+'\n'+(out.length?out.slice(0,60).join('\n'):'No direct textual references found. Dynamic references may not be detected.')+'\nReview results before renaming or deleting.';
    }
  });
  def({
    name: 'project_diagnostics', perm: 'read', params: '',
    description: 'Run a read-only project health inventory: entry point, manifests, tests, empty files, large files, and supported static syntax checks.',
    run: function () {
      var all=St().fileList(), empty=[], large=[], manifests=[], tests=[], entry=RC.run&&RC.run.entry?RC.run.entry(files()):null, checked=0, issues=[];
      all.forEach(function(p){var c=String(files()[p]||''); if(!c.trim())empty.push(p); if(c.length>50000)large.push(p+' ('+c.length+' chars)'); if(/(^|\/)(package\.json|build\.gradle(\.kts)?|settings\.gradle(\.kts)?|AndroidManifest\.xml|pyproject\.toml|Cargo\.toml)$/i.test(p))manifests.push(p); if(/(^|\/)(test[^/]*|[^/]+\.test|[^/]+_test)\.[^.]+$/i.test(p))tests.push(p); if(RC.tools&&RC.tools.checkOne){var e=RC.tools.checkOne(p,c); if(e){checked++;issues.push(p+': '+e);}} });
      return 'PROJECT DIAGNOSTICS\nFiles: '+all.length+'\nEntry: '+(entry||'not detected')+'\nManifests: '+(manifests.join(', ')||'none')+'\nTests: '+(tests.join(', ')||'none detected')+'\nEmpty files: '+(empty.join(', ')||'none')+'\nLarge files (>50 KB): '+(large.join(', ')||'none')+'\nStatic syntax issues: '+(issues.length?issues.slice(0,40).join('\n'):'none detected')+'\nNote: this is static inspection, not a native build or device test.';
    }
  });

  // ------------------------------------------------------------------ parser
  var NAMES_ALIAS = { fix_bugs: 'automatic_bug_repair', bug_scan: 'detect_bugs', review_code: 'automatic_code_review', parallel_workers: 'parallel_coding_workers', audit: 'dependency_audit', deps: 'dependency_audit', secrets: 'secret_scan', security_scan: 'secret_scan', impact: 'change_impact', diagnose: 'project_diagnostics', doctor: 'project_diagnostics', map: 'project_map', repo_map: 'project_map', inspect_project: 'project_map', ask_agent: 'delegate', subagent: 'delegate', agent: 'delegate', knowledge: 'search_knowledge', web: 'web_search', fetch: 'web_read', browse: 'web_read', read: 'read_file', write: 'write_file', edit: 'edit_file', delete: 'delete_file', remove: 'delete_file', ls: 'list_files', list: 'list_files', find: 'search_files', grep: 'search_text', search: 'search_text', mkdir: 'create_directory', rename: 'rename_file', mv: 'move_file', move: 'move_file', info: 'get_file_info', stat: 'get_file_info', run: 'run_command', exec: 'run_command', shell: 'native_shell', git: 'git_status', build_apk: 'android_build', syntax: 'check_syntax', test: 'run_tests', tests: 'run_tests', create_file: 'write_file', create: 'write_file', cat: 'read_file', read_files: 'read_file', create_folder: 'create_directory', todos: 'todo', tasks: 'todo', task: 'todo', note: 'remember', notes: 'remember', memory: 'remember', memorize: 'remember', save_note: 'remember' };
  function canon(n) {
    n = String(n || '').trim().toLowerCase().replace(/[^a-z_]/g, '');
    return reg[n] ? n : (NAMES_ALIAS[n] && reg[NAMES_ALIAS[n]] ? NAMES_ALIAS[n] : '');
  }
  function paramNames(t) { return t.params.replace(/[\[\]]/g, '').split(',').map(function (x) { return x.trim(); }).filter(Boolean); }
  function fence(text, from) {
    // first fenced block that starts after `from`; returns {code, end} or null
    var re = /(^|\n)[ \t]*(`{3,}|~{3,})[^\n]*\n/g, m;
    re.lastIndex = from;
    m = re.exec(text);
    if (!m) return null;
    var open = m.index + m[0].length, tick = m[2], close = text.indexOf('\n' + tick, open);
    var code, end;
    if (close < 0) { code = text.slice(open); end = text.length; }
    else { code = text.slice(open, close); var nl = text.indexOf('\n', close + 1); end = nl < 0 ? text.length : nl; }
    return { code: code.replace(/\n$/, ''), end: end, start: m.index };
  }
  function parseEdit(body) {
    var m = /<{3,}\s*(?:SEARCH|OLD)[^\n]*\n([\s\S]*?)\n={3,}[^\n]*\n([\s\S]*?)\n?>{3,}\s*(?:REPLACE|NEW)?/i.exec(body);
    return m ? { old_text: m[1], new_text: m[2] } : null;
  }

  // V12 readiness diagnostics. These inspect only files in the open project;
  // they do not claim to execute Git, MCP, browser automation, or native shell.
  function hasAny(list) { return list.some(function (p) { return files()[p] !== undefined; }); }
  function namesLike(re) { return Object.keys(files()).filter(function (p) { return re.test(p); }); }
  def({
    name: 'environment_doctor', perm: 'read', params: '[focus]',
    description: 'Run a read-only environment doctor on the open project: detect app/build manifests, SDK configuration, source roots, tests, and missing expected project files.',
    run: function () {
      var all = Object.keys(files()), checks = [];
      function check(label, ok, detail) { checks.push({ label: label, ok: !!ok, detail: detail }); }
      check('Gradle settings', hasAny(['settings.gradle', 'settings.gradle.kts']), 'Root Gradle settings file');
      check('Root build script', hasAny(['build.gradle', 'build.gradle.kts']), 'Root build configuration');
      check('Android app module', hasAny(['app/build.gradle', 'app/build.gradle.kts']), 'App module Gradle configuration');
      check('Android manifest', hasAny(['app/src/main/AndroidManifest.xml', 'src/main/AndroidManifest.xml']), 'Application manifest');
      check('Kotlin or Java source', namesLike(/\.(kt|java)$/i).length > 0, 'Kotlin/Java source files');
      check('Tests present', namesLike(/(^|\/)(test|androidTest)(\/|$)|\.(test|spec)\./i).length > 0, 'Unit, instrumentation, or spec tests');
      check('Gradle wrapper', hasAny(['gradlew', 'gradlew.bat', 'gradle/wrapper/gradle-wrapper.properties']), 'Wrapper scripts/configuration');
      var ok = checks.filter(function (x) { return x.ok; }).length;
      return 'ENVIRONMENT DOCTOR: ' + ok + '/' + checks.length + ' checks present\n' + checks.map(function (x) { return (x.ok ? '[OK] ' : '[MISSING] ') + x.label + ' — ' + x.detail; }).join('\n') + '\nFiles inspected: ' + all.length + '. This is a project-file inventory, not a device or SDK execution test.';
    }
  });
  def({
    name: 'mcp_config_audit', perm: 'read', params: '[focus]',
    description: 'Audit MCP-related configuration files and report likely server declarations without connecting to any MCP server.',
    run: function () {
      var hits = namesLike(/(^|\/)(mcp\.json|\.mcp\.json|mcp\.config\.(json|js|ts)|claude_desktop_config\.json)$/i)
        .concat(namesLike(/(^|\/)(\.cursor|\.vscode)\/.*mcp.*\.(json|jsonc)$/i));
      var manifests = namesLike(/(^|\/)(package\.json|pyproject\.toml|Cargo\.toml)$/i);
      var details = hits.map(function (p) { var c = String(files()[p] || ''); return p + ' (' + c.length + ' chars; ' + (/"(mcpServers|servers)"\s*:/.test(c) ? 'server declaration marker found' : 'review format manually') + ')'; });
      return 'MCP CONFIG AUDIT\nConfig candidates: ' + hits.length + '\n' + (details.join('\n') || 'No recognized MCP config file found.') + '\nPackage manifests: ' + (manifests.join(', ') || 'none') + '\nNo network connection was attempted; ReCode V12 does not include a live MCP transport.';
    }
  });
  def({
    name: 'browser_readiness_audit', perm: 'read', params: '[focus]',
    description: 'Inspect project browser/test configuration and web entry points; does not control a browser or visit websites.',
    run: function () {
      var configs = namesLike(/(^|\/)(playwright\.config\.[jt]s|cypress\.config\.[jt]s|wdio\.conf\.[jt]s|puppeteer\.config\.[jt]s)$/i);
      var tests = namesLike(/(e2e|browser|playwright|cypress|\.spec\.)/i);
      var entries = namesLike(/(^|\/)(index\.html|vite\.config\.[jt]s|next\.config\.[jt]s|webpack\.config\.[jt]s)$/i);
      return 'BROWSER READINESS AUDIT\nBrowser automation configs: ' + (configs.join(', ') || 'none') + '\nBrowser/e2e test candidates: ' + (tests.join(', ') || 'none') + '\nWeb entry/build files: ' + (entries.join(', ') || 'none') + '\nThis checks repository readiness only; no browser automation is available in this build.';
    }
  });
  def({
    name: 'git_readiness_audit', perm: 'read', params: '[focus]',
    description: 'Inspect Git-related project metadata and ignore rules; does not run Git commands or modify repository history.',
    run: function () {
      var meta = namesLike(/(^|\/)(\.gitignore|\.gitattributes|\.gitmodules|\.gitkeep)$/i);
      var workflows = namesLike(/(^|\/)\.github\/workflows\/.*\.ya?ml$/i);
      var pkg = namesLike(/(^|\/)(package\.json|build\.gradle(\.kts)?|settings\.gradle(\.kts)?)$/i);
      return 'GIT READINESS AUDIT\nGit metadata files: ' + (meta.join(', ') || 'none') + '\nCI workflows: ' + (workflows.join(', ') || 'none') + '\nBuild/package manifests: ' + (pkg.join(', ') || 'none') + '\nNo .git directory inspection, git status, commit, push, or branch operation was performed; real Git integration is not enabled.';
    }
  });
  def({
    name: 'release_readiness_audit', perm: 'read', params: '[focus]',
    description: 'Review Android release metadata, manifest, signing declarations, and CI build workflow for obvious gaps.',
    run: function () {
      var gradle = files()['app/build.gradle'] || files()['app/build.gradle.kts'] || '';
      var manifest = files()['app/src/main/AndroidManifest.xml'] || files()['src/main/AndroidManifest.xml'] || '';
      var ci = namesLike(/(^|\/)\.github\/workflows\/.*\.ya?ml$/i);
      var checks = [
        ['Application ID', /applicationId\s*[=(]\s*["']/.test(gradle)],
        ['Version metadata', /version(Code|Name)\s*[=(]/.test(gradle)],
        ['Release build type', /buildTypes[\s\S]*?release/.test(gradle)],
        ['Manifest application', /<application\b/.test(manifest)],
        ['CI workflow', ci.length > 0]
      ];
      return 'ANDROID RELEASE READINESS\n' + checks.map(function (x) { return (x[1] ? '[PRESENT] ' : '[REVIEW] ') + x[0]; }).join('\n') + '\nThis is a static checklist only. Signing validity, dependency resolution, APK assembly, and device installation remain unverified.';
    }
  });

  var T = RC.tools = {
    registry: reg,
    policy: policy,
    names: function () { return Object.keys(reg); },
    /** compact tool list for prompts: small models get short lines */
    prompt: function (names, compact) {
      return (names || T.names()).filter(function (n) { return reg[n]; }).map(function (n) { var t = reg[n]; return compact ? 'TOOL: ' + n + ' | ' + t.params.replace(/[\[\]]/g, '').split(',').join(' |').replace(/\s+\|/g, ' |') : '- ' + n + '(' + t.params + '): ' + t.description; }).join('\n');
    },
    /**
     * Parse model output into tool calls.
     * Supports: "TOOL: name | arg | arg" (+ following code block as content / edit block),
     * JSON {"tool":"x","args":{}} / {"name":"x","arguments":{}} / OpenAI tool_calls, <tool_call>{json}</tool_call>.
     * -> {calls:[{name,args,raw}], errors:[string], text:"model text without tool lines"}
     */
    parse: function (text) {
      text = String(text || '');
      var calls = [], errors = [], used = [];
      function addJson(obj, raw) {
        if (!obj || typeof obj !== 'object') return;
        if (Array.isArray(obj)) { obj.forEach(function (o) { addJson(o, raw); }); return; }
        if (obj.tool_calls) return addJson(obj.tool_calls, raw);
        var fn = obj.function || obj, n = fn.name || fn.tool || obj.tool || obj.name, args = fn.arguments || fn.args || fn.parameters || obj.args || obj.arguments || obj.input || obj.parameters;
        if (typeof args === 'string') { try { args = JSON.parse(args); } catch (e) { args = { path: args }; } }
        var c = canon(n);
        if (!c) { if (n) errors.push('Unknown tool "' + n + '". Available: ' + T.names().join(', ')); return; }
        calls.push({ name: c, args: args && typeof args === 'object' ? args : {}, raw: raw });
      }
      // 1. structured JSON (tags or fenced json, or a bare object that has a tool key)
      text.replace(/<tool_call>\s*([\s\S]*?)\s*<\/tool_call>/gi, function (all, j) {
        used.push(all); try { addJson(JSON.parse(j), j); } catch (e) { errors.push('Invalid JSON in <tool_call>.'); } return all;
      });
      text.replace(/(`{3,})json\s*\n([\s\S]*?)\n\1/gi, function (all, t, j) {
        if (!/"(tool|name|tool_calls|function)"\s*:/.test(j) || used.some(function (u) { return u.indexOf(j) >= 0; })) return all;
        try { addJson(JSON.parse(j), j); used.push(all); } catch (e) { /* normal json example, ignore */ }
        return all;
      });
      if (!calls.length && !used.length) {
        var t = text.trim();
        if (/^[\[{]/.test(t) && /"(tool|tool_calls|function)"\s*:/.test(t)) { try { addJson(JSON.parse(t), t); } catch (e) { errors.push('Invalid JSON tool call.'); } }
      }
      // 2. text protocol
      var re = /(^|\n)[ \t]*(?:[-*]\s*)?TOOL:[ \t]*([^\n]*)/gi, m, cursor = 0, lineHits = [];
      while ((m = re.exec(text))) lineHits.push({ idx: m.index + m[1].length, end: m.index + m[0].length, body: m[2] });
      for (var i = 0; i < lineHits.length; i++) {
        var h = lineHits[i];
        if (h.idx < cursor) continue;
        var segs = h.body.split(/\s+\|\s+|\s*\|\s*/).map(function (x) { return x.trim(); });
        var name = canon(segs[0].replace(/\(.*$/, ''));
        if (!name) { errors.push('Unknown tool "' + segs[0] + '". Available: ' + T.names().join(', ')); cursor = h.end; continue; }
        var t2 = reg[name], pn = paramNames(t2), args = {};
        var vals = segs.slice(1);
        var next = i + 1 < lineHits.length ? lineHits[i + 1].idx : text.length;
        var block = null, tail = text.slice(h.end, next);
        if (name === 'write_file' || name === 'edit_file') {
          var f = fence(text, h.end);
          if (f && f.start < next) { block = f; cursor = f.end; }
          else if (name === 'write_file' && vals.length > 1) { /* content inline after path */ }
          else if (tail.trim()) { block = { code: tail.replace(/^\n/, '').replace(/\s+$/, ''), end: next }; cursor = next; }
        } else cursor = h.end;
        if (name === 'write_file') {
          args.path = vals[0];
          if (block) args.content = block.code; else if (vals.length > 1) args.content = vals.slice(1).join(' | ');
        } else if (name === 'edit_file') {
          args.path = vals[0];
          var ed = block && parseEdit(block.code);
          if (!ed && block === null && /<{3,}\s*SEARCH/i.test(tail)) ed = parseEdit(tail);
          if (ed) { args.old_text = ed.old_text; args.new_text = ed.new_text; }
          else if (vals.length >= 3) { args.old_text = vals[1]; args.new_text = vals.slice(2).join(' | '); }
          else errors.push('edit_file needs a block:\n<<<<<<< SEARCH\nold text\n=======\nnew text\n>>>>>>> REPLACE');
        } else {
          pn.forEach(function (k, ix) { if (vals[ix] !== undefined && vals[ix] !== '') args[k] = vals[ix]; });
          if (name === 'search_text' && vals.length > 2) args.pattern = vals.slice(0, vals.length - 1).join(' | '), args.path = vals[vals.length - 1];
          if (name === 'run_command' && vals.length > 1) args.command = vals.join(' | ');
          if (name === 'delegate' && vals.length > 2) args.task = vals.slice(1).join(' | ');
          if (name === 'todo' && vals.length > 2) args.text = vals.slice(1).join(' | ');
          if (name === 'remember' && vals.length > 1) args.text = vals.join(' | ');
          if (name === 'delegate' && vals.length === 1 && /^@?[a-z-]+\s*:/i.test(vals[0])) { var dm = /^@?([a-z-]+)\s*:\s*([\s\S]*)$/i.exec(vals[0]); args.agent = dm[1]; args.task = dm[2]; }
        }
        calls.push({ name: name, args: args, raw: text.slice(h.idx, Math.min(next, h.end + 300)) });
      }
      var clean = text;
      used.forEach(function (u) { clean = clean.replace(u, ''); });
      clean = clean.replace(/(^|\n)[ \t]*(?:[-*]\s*)?TOOL:[^\n]*/gi, '$1').trim();
      return { calls: calls, errors: errors, text: clean };
    },
    /** decide allow|ask|deny for a call. Phase 2 replaces this with the permission manager. */
    gate: function (call, ctx) {
      var t = reg[call.name], lvl = policy[t.perm] || 'deny';
      if (ctx && ctx.mode === 'plan' && t.perm !== 'read') return { ok: false, why: 'Plan mode is read-only. Only reading tools can be used until the plan is approved.' };
      if (lvl === 'allow') return { ok: true };
      return { ok: false, why: t.perm === 'delete' ? 'Deleting files is not allowed by the current permissions.' : 'This action needs permission that is not granted.' };
    },
    /**
     * Execute one call. Never throws (except AbortError). -> {ok, out, blocked}
     */
    exec: async function (call, ctx) {
      ctx = ctx || {};
      var t = reg[call.name], HK = !ctx.skipHooks && RC.hooks, feedback = [];
      if (!t) return { ok: false, out: 'Unknown tool "' + call.name + '". Available: ' + T.names().join(', ') };
      if (!ctx.touch) ctx.touch = function () { };
      if (ctx.allowed && ctx.allowed.indexOf(call.name) < 0) return { ok: false, blocked: true, out: 'BLOCKED: tool "' + call.name + '" is not available to this agent. Available: ' + ctx.allowed.join(', ') };
      call = { name: call.name, args: Object.assign({}, call.args || {}), raw: call.raw };
      // V14: parallel coding workers receive an explicit, enforced file ownership scope.
      if (ctx.fileScope && ['write_file','edit_file','delete_file','rename_file','move_file','create_directory'].indexOf(call.name) >= 0) {
        var owned = ctx.fileScope.map(function (x) { return U.normPath(String(x)); });
        var targets = [];
        if (call.args.path) targets.push(call.args.path);
        if (call.args.from) targets.push(call.args.from);
        if (call.args.to) targets.push(call.args.to);
        if (!targets.length || targets.some(function (x) { var n = U.normPath(String(x)).replace(/\/$/, ''); return call.name === 'create_directory' ? !owned.some(function (f) { return f.indexOf(n + '/') === 0; }) : owned.indexOf(n) < 0; }))
          return { ok: false, blocked: true, out: 'BLOCKED: this worker may only modify its assigned files: ' + owned.join(', ') };
      }
      // 1. PreToolUse hooks may block or rewrite the arguments
      if (HK) {
        var pre = await HK.run('PreToolUse', { tool: call.name, args: call.args }, ctx);
        if (pre.blocked) return { ok: false, blocked: true, out: 'BLOCKED: ' + pre.reason };
        if (pre.input && pre.input.args) call.args = pre.input.args;
        feedback = feedback.concat(pre.feedback);
      }
      // 2. permission manager (DENY > ASK > ALLOW, plan/ask/auto mode)
      var g = (ctx.gate || T.gate)(call, ctx);
      if (g && typeof g.then === 'function') g = await g;
      if (!g || !g.ok) return { ok: false, blocked: true, out: 'BLOCKED: ' + ((g && g.why) || 'not permitted') };
      if (ctx.signal && ctx.signal.aborted) throw RC.llm.AbortErr();
      // 3. run
      var res;
      try {
        var out = await t.run(call.args || {}, ctx);
        res = { ok: true, out: String(out == null ? 'OK' : out) };
      } catch (e) {
        if (e && e.name === 'AbortError') throw e;
        res = { ok: false, out: 'ERROR: ' + (e && e.message || e) + (e && e.tool ? '' : ' (tool crashed)') };
      }
      // 4. PostToolUse hooks add feedback for the model
      if (HK) {
        try {
          var post = await HK.run('PostToolUse', { tool: call.name, args: call.args, result: res }, ctx);
          feedback = feedback.concat(post.feedback);
        } catch (e) { if (e && e.name === 'AbortError') throw e; }
        if (feedback.length) res.out += '\n' + feedback.join('\n');
      }
      return res;
    },
    // exposed for tests and later phases
    path: path, checkOne: checkOne
  };
})();
