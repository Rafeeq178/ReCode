/* ReCode - Phase 2: event hooks. Deterministic JavaScript that runs at fixed points of a run.
   Events: SessionStart, SessionEnd, UserPromptSubmit, PreToolUse, PostToolUse, Stop, PreCompact.
   PreCompact fires from loop.js (Phase 4) before old steps are folded into a summary: payload {entries, chars, reason, state, todos};
   {block:true} skips the compaction, {feedback} text is kept in the summary.
   A hook is fn(payload, ctx) and may return:
     {block: true, reason}  stop the operation (PreToolUse, UserPromptSubmit, Stop)
     {feedback: 'text'}     text shown to the model (appended to the tool result / next turn)
     {input: {...}}         replacement tool arguments (PreToolUse) or prompt text {text} (UserPromptSubmit)
   A hook that throws never crashes a run: the error is logged and reported as feedback. A hook marked
   critical fails CLOSED (its failure blocks the operation); all others fail open. */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var U = RC.u;

  var EVENTS = ['SessionStart', 'SessionEnd', 'UserPromptSubmit', 'PreToolUse', 'PostToolUse', 'Stop', 'PreCompact'];
  var WRITES = ['write_file', 'edit_file'];
  var MUTATING = ['write_file', 'edit_file', 'delete_file', 'rename_file', 'move_file', 'create_directory'];
  var list = [], log = [], backups = [];

  function cfg() { return (RC.settings && RC.settings.hooks) || {}; }
  function on(key) { return cfg()[key] !== false; }
  function files() { return RC.store.files; }
  function paths(call) { var a = call.args || {}; return [a.path, a.from, a.to].filter(Boolean).map(function (p) { try { return RC.tools.path(p); } catch (e) { return ''; } }).filter(Boolean); }

  var H = RC.hooks = {
    events: EVENTS, log: log, backups: backups,
    list: function () { return list.map(function (h) { return { name: h.name, event: h.event, builtin: !!h.builtin, critical: !!h.critical, tools: h.tools }; }); },
    /** register(event, fn, {name, tools:[...], critical, builtin}) -> unregister fn */
    register: function (event, fn, o) {
      if (EVENTS.indexOf(event) < 0) throw new Error('Unknown hook event ' + event);
      o = o || {};
      var h = { event: event, fn: fn, name: o.name || 'hook' + (list.length + 1), tools: o.tools || null, critical: !!o.critical, builtin: !!o.builtin, key: o.key || '' };
      list.push(h);
      return function () { var i = list.indexOf(h); if (i >= 0) list.splice(i, 1); };
    },
    /**
     * run(event, payload, ctx) -> {blocked, reason, feedback:[string], input}
     * payload for tool events: {tool, args, result?}
     */
    run: async function (event, payload, ctx) {
      var res = { blocked: false, reason: '', feedback: [], input: null };
      payload = payload || {};
      for (var i = 0; i < list.length; i++) {
        var h = list[i];
        if (h.event !== event) continue;
        if (h.tools && payload.tool && h.tools.indexOf(payload.tool) < 0) continue;
        if (h.key && !on(h.key)) continue;
        try {
          var out = h.fn(res.input && res.input.args ? Object.assign({}, payload, { args: res.input.args }) : payload, ctx || {});
          if (out && typeof out.then === 'function') out = await out;
          if (!out) continue;
          if (out.feedback) res.feedback.push('[' + h.name + '] ' + out.feedback);
          if (out.input) res.input = out.input.args ? out.input : { args: out.input, text: out.input.text };
          if (out.block) { res.blocked = true; res.reason = '[' + h.name + '] ' + (out.reason || 'blocked'); log.push({ t: Date.now(), event: event, hook: h.name, blocked: true, why: res.reason }); break; }
        } catch (e) {
          if (e && e.name === 'AbortError') throw e;
          var msg = 'hook "' + h.name + '" failed: ' + (e && e.message || e);
          log.push({ t: Date.now(), event: event, hook: h.name, error: msg });
          if (h.critical) { res.blocked = true; res.reason = '[' + h.name + '] safety hook failed, operation not allowed (' + (e && e.message || e) + ')'; break; }
          res.feedback.push('[' + h.name + '] ' + msg);
        }
      }
      return res;
    },
    /** load user-written hooks from settings.hooks.custom: [{event, tools, name, code, on}] (code is the function body of (payload, ctx)) */
    loadCustom: function () {
      for (var i = list.length - 1; i >= 0; i--) if (list[i].custom) list.splice(i, 1);
      ((cfg().custom) || []).forEach(function (c) {
        if (!c || c.on === false || EVENTS.indexOf(c.event) < 0 || !c.code) return;
        try {
          var fn = new Function('payload', 'ctx', 'RC', String(c.code));
          var u = H.register(c.event, function (p, x) { return fn(p, x, RC); }, { name: c.name || 'custom', tools: c.tools && c.tools.length ? c.tools : null });
          list[list.length - 1].custom = true;
        } catch (e) { log.push({ t: Date.now(), event: c.event, hook: c.name, error: 'cannot compile: ' + e.message }); }
      });
    },
    /** latest saved copy of a file from before the agent changed it (Phase 6 adds real checkpoints) */
    backupOf: function (path) { for (var i = backups.length - 1; i >= 0; i--) if (backups[i].path === path) return backups[i]; return null; },
    restoreBackup: function (path) {
      var b = H.backupOf(path);
      if (!b) return Promise.reject(new Error('No backup of ' + path));
      return b.content === null ? RC.store.delFile(path) : RC.store.putFile(path, b.content);
    },
    attach: function (ctx, run) { ctx.hooks = H; ctx.run = run; }
  };

  // ------------------------------------------------------------------ built-in hooks
  // 1. dangerous command prevention (critical: if it breaks, run_command is not allowed)
  H.register('PreToolUse', function (p) {
    var cmd = String((p.args && (p.args.command || p.args.cmd)) || '');
    var why = RC.perms && RC.perms.isDangerous(cmd);
    return why ? { block: true, reason: 'Dangerous command blocked (' + why + ').' } : null;
  }, { name: 'dangerous-command', tools: ['run_command'], critical: true, builtin: true });

  // 2. file overwrite protection: a write_file that would wipe most of an existing file must use edit_file or force
  H.register('PreToolUse', function (p) {
    var a = p.args || {}, path; try { path = RC.tools.path(a.path); } catch (e) { return null; }
    var old = files()[path], neu = a.content == null ? '' : String(a.content);
    if (old === undefined || a.force === true || /^(true|yes)$/i.test(String(a.force))) return null;
    if (old.length > 400 && neu.length < old.length * 0.3) return { block: true, reason: path + ' has ' + old.length + ' chars and the new content only ' + neu.length + '. This would erase most of the file. Use edit_file for a small change, or write the COMPLETE file.' };
    return null;
  }, { name: 'overwrite-protection', tools: ['write_file'], key: 'overwrite', builtin: true, critical: true });

  // 3. project structure validation (before)
  H.register('PreToolUse', function (p) {
    if (['write_file', 'create_directory', 'move_file', 'rename_file'].indexOf(p.tool) < 0) return null;
    var max = +cfg().maxFiles || 60, n = Object.keys(files()).length, a = p.args || {}, tgt = a.path || a.to || '';
    if (p.tool === 'write_file' && n >= max && files()[U.normPath(tgt)] === undefined) return { block: true, reason: 'Project already has ' + n + ' files (limit ' + max + '). Reuse existing files.' };
    if (U.normPath(tgt).split('/').length > 5) return { block: true, reason: 'Folder nesting is too deep (max 5 levels): ' + tgt };
    return null;
  }, { name: 'project-structure', key: 'structure', builtin: true });

  // 4. backup before modification (in-memory ring, last 60)
  H.register('PreToolUse', function (p) {
    if (MUTATING.indexOf(p.tool) < 0) return null;
    paths(p).forEach(function (path) {
      var c = files()[path];
      backups.push({ path: path, content: c === undefined ? null : c, t: Date.now(), tool: p.tool });
    });
    while (backups.length > 60) backups.shift();
    return null;
  }, { name: 'backup', key: 'backup', builtin: true });

  // 5. automatic formatting after writes (whitespace only: never changes meaning)
  H.register('PostToolUse', function (p) {
    if (!p.result || !p.result.ok || WRITES.indexOf(p.tool) < 0) return null;
    var path = RC.tools.path(p.args.path), c = files()[path];
    if (c === undefined || !/^(js|mjs|css|html?|json|py|txt)$/.test(U.ext(path))) return null;
    var f = c.replace(/\r\n?/g, '\n').replace(/[ \t]+$/gm, '').replace(/\n{4,}/g, '\n\n\n');
    if (f.length && !/\n$/.test(f)) f += '\n';
    if (f === c) return null;
    return RC.store.putFile(path, f).then(function () { return null; });
  }, { name: 'format', key: 'format', builtin: true });

  // 6. syntax validation after writes
  H.register('PostToolUse', function (p) {
    if (!p.result || !p.result.ok || WRITES.indexOf(p.tool) < 0) return null;
    var path = RC.tools.path(p.args.path), m = RC.tools.checkOne(path, files()[path] || '');
    return m ? { feedback: 'SYNTAX ERROR in ' + path + ': ' + m + '. Fix it before continuing.' } : null;
  }, { name: 'syntax-check', key: 'syntax', builtin: true });

  // 7. structure validation after writes: html must not point to files that do not exist (warn only)
  H.register('PostToolUse', function (p) {
    if (!p.result || !p.result.ok || WRITES.indexOf(p.tool) < 0) return null;
    var path = RC.tools.path(p.args.path);
    if (!/\.html?$/i.test(path)) return null;
    var miss = [], c = files()[path] || '', dir = path.indexOf('/') >= 0 ? path.replace(/[^\/]*$/, '') : '';
    c.replace(/(?:href|src)\s*=\s*["']([^"'#?]+\.(?:css|m?js))["']/gi, function (_, ref) {
      if (/^([a-z]+:|\/\/)/i.test(ref)) { miss.push(ref + ' (external, will not load offline)'); return; }
      var t = U.normPath(ref.charAt(0) === '/' ? ref : dir + ref);
      if (files()[t] === undefined) miss.push(t + ' (not created yet)');
    });
    return miss.length ? { feedback: 'Note: ' + path + ' references ' + miss.join(', ') + '.' } : null;
  }, { name: 'structure-check', key: 'structure', builtin: true });

  // 8. error reporting: classify failed tool calls and add a hint
  H.register('PostToolUse', function (p, ctx) {
    if (!p.result || p.result.ok) return null;
    var o = p.result.out || '', kind = /BLOCKED/.test(o) ? 'permission' : /No such file/.test(o) ? 'missing-file' : /not found in|appears \d+ times/.test(o) ? 'edit-mismatch' : /outside the project|Invalid file name/.test(o) ? 'bad-path' : 'tool-error';
    if (ctx && ctx.run) (ctx.run.toolErrors = ctx.run.toolErrors || []).push({ tool: p.tool, kind: kind, msg: U.clip(o, 160, '…'), t: Date.now() });
    var hint = ({ 'missing-file': 'Run list_files to see real file names.', 'edit-mismatch': 'Run read_file on the file and copy the exact text.', 'bad-path': 'Use a short relative path such as src/app.js.', permission: 'Do not retry this; use another approach or explain it in your final answer.' })[kind];
    return hint ? { feedback: 'Hint: ' + hint } : null;
  }, { name: 'error-report', key: 'errors', builtin: true });

  // 9. automatic testing / verification at Stop: do not let the agent finish with broken files
  H.register('Stop', async function (p, ctx) {
    var st = p.state || {}, bad = [];
    (st.modified || []).forEach(function (f) {
      if (files()[f] === undefined) return;
      var m = RC.tools.checkOne(f, files()[f]);
      if (m) bad.push(f + ': ' + m);
    });
    if (bad.length) return { block: true, reason: 'These files still have syntax errors: ' + bad.join('; ') + '. Fix them first.' };
    if (cfg().autoTest !== false && (st.modified || []).some(function (f) { return /\.(html?|js|css)$/i.test(f); }) && RC.run) {
      var r = await RC.tools.exec({ name: 'run_tests', args: { only: 'page' } }, Object.assign({}, ctx, { skipHooks: true }));
      if (!r.ok || /^FAILED/.test(r.out)) return { block: true, reason: 'Automatic tests failed:\n' + U.clip(r.out, 700, '…') };
      st.verified = true;
    }
    return null;
  }, { name: 'auto-verify', key: 'syntax', builtin: true });
})();
(function () {
  var RC = window.RC;
  RC.hooks.loadCustom();
  if (RC.bus) RC.bus.on('settings', function () { RC.hooks.loadCustom(); });
})();
