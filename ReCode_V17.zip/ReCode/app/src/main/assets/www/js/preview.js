/* ReCode - Run tab: offline runner for the project (HTML/CSS/JS) in a sandboxed frame + console.
   v6: fullscreen mode (with real system fullscreen on Android), console never hides under the bottom pill,
   console Clear/Copy, and an on-screen arrow pad so games can be played on a phone. */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var U = RC.u, h = U.h, UI = RC.ui, St = RC.store, N = RC.native, Run = RC.run;
  var root = U.$('#v-run');
  var sid = U.uid('pv'), frame = null, temp = null, device = 'auto', showCon = false, consoleLines = [], errCount = 0, stale = true, fs = false, padOn = false;
  var box = h('div#pvbox'), con = h('div#console'), banner = h('div#banner'), bar = h('div.toolbar'), wrapEl = h('div#pvwrap', banner, box, con);
  var fsbar = h('div#fsbar'), pad = h('div#pad');
  root.appendChild(bar); root.appendChild(wrapEl); root.appendChild(fsbar);
  document.body.appendChild(pad);

  function files() { return temp || St.files; }

  // ---------------------------------------------------------------- toolbar (normal + fullscreen)
  function paintBar() {
    U.clear(bar);
    bar.appendChild(UI.btn('Reload', 'refresh', 'sm', function () { load(true); }));
    bar.appendChild(h('button.chip', { onclick: function () { setFs(true); } }, h('span', { html: RC.i('expand', 14) }), 'Full'));
    var d = h('button.chip', { onclick: function () { device = device === 'auto' ? 'phone' : device === 'phone' ? 'tablet' : 'auto'; box.className = device === 'auto' ? '' : device; paintBar(); } }, h('span', { html: RC.i('cpu', 14) }), device === 'auto' ? 'Fit' : device === 'phone' ? 'Phone' : 'Tablet');
    bar.appendChild(d);
    bar.appendChild(h('button.chip' + (showCon ? '.on' : ''), { onclick: function () { showCon = !showCon; paintCon(); paintBar(); } }, h('span', { html: RC.i('terminal', 14) }), 'Console' + (errCount ? ' (' + errCount + ')' : '')));
    bar.appendChild(h('button.chip' + (padOn ? '.on' : ''), { onclick: function () { padOn = !padOn; paintPad(); paintBar(); } }, h('span', { html: RC.i('play', 14) }), 'Pad'));
    bar.appendChild(h('button.chip', { onclick: exportHtml }, h('span', { html: RC.i('download', 14) }), '.html'));
    paintFsBar();
  }
  function fsBtn(label, icon, on, fn) {
    var b = h('button' + (on ? '.on' : ''), { 'aria-label': label, onclick: fn });
    if (icon) b.innerHTML = RC.i(icon, 18); else b.textContent = label;
    return b;
  }
  var fsOpen = false, fsTimer = 0;
  function fsMenu(open) {
    fsOpen = open; clearTimeout(fsTimer);
    if (open) fsTimer = setTimeout(function () { fsOpen = false; paintFsBar(); }, 5000);
    paintFsBar();
  }
  // fullscreen controls: one small dot (so the page stays clear); tap it to see Reload / Pad / Console / Exit
  function paintFsBar() {
    U.clear(fsbar);
    if (!fsOpen) { var m = fsBtn('Menu', null, false, function () { fsMenu(true); }); m.textContent = '⋯'; m.className = 'mini'; fsbar.appendChild(m); return; }
    fsbar.appendChild(fsBtn('Reload', 'refresh', false, function () { load(true); fsMenu(true); }));
    fsbar.appendChild(fsBtn('Pad', null, padOn, function () { padOn = !padOn; paintPad(); paintBar(); fsMenu(true); }));
    fsbar.appendChild(fsBtn('Console', 'terminal', showCon, function () { showCon = !showCon; paintCon(); paintBar(); fsMenu(true); }));
    fsbar.appendChild(fsBtn('Exit fullscreen', 'x', false, function () { setFs(false); }));
  }

  // ---------------------------------------------------------------- console
  function paintCon() {
    con.style.display = showCon ? 'block' : 'none';
    U.clear(con);
    if (!showCon) return;
    con.appendChild(h('div#conbar', h('span.grow', 'Console' + (consoleLines.length ? ' · ' + consoleLines.length : '')),
      h('button', { onclick: function () { consoleLines = []; errCount = 0; paintCon(); paintBar(); } }, 'Clear'),
      h('button', { onclick: function () { N.copy(consoleLines.map(function (l) { return l[0] + ': ' + l[1]; }).join('\n')).then(function () { UI.toast('Copied'); }, function () { }); } }, 'Copy')));
    if (!consoleLines.length) con.appendChild(h('div', { style: { color: 'var(--codeMuted)' } }, 'Console is empty.'));
    consoleLines.slice(-200).forEach(function (l) { con.appendChild(h('div.' + l[0], l[1])); });
    con.scrollTop = con.scrollHeight;
  }

  // ---------------------------------------------------------------- fullscreen
  function setFs(on) {
    on = !!on;
    if (fs === on) return;
    fs = on; fsOpen = false;
    root.classList.toggle('fs', fs);
    document.body.classList.toggle('pvfs', fs);
    N.immersive(fs);
    paintPad(); paintBar();
    // tell the page its size changed (canvas games re-measure on resize)
    setTimeout(function () { try { if (frame && frame.contentWindow) frame.contentWindow.dispatchEvent(new Event('resize')); } catch (e) { } }, 250);
  }

  // ---------------------------------------------------------------- arrow pad -> keyboard events inside the page
  function sendKey(type, key) {
    if (!frame || !frame.contentWindow) return;
    try { frame.contentWindow.postMessage({ rc: 1, k: 'key', type: type, key: key }, '*'); } catch (e) { }
  }
  function padBtn(cls, label, key) {
    var b = h('button.' + cls, { 'aria-label': key }, label), down = false;
    function dn(e) { e.preventDefault(); if (down) return; down = true; sendKey('keydown', key); }
    function up(e) { e.preventDefault(); if (!down) return; down = false; sendKey('keyup', key); }
    b.addEventListener('touchstart', dn, { passive: false }); b.addEventListener('touchend', up, { passive: false }); b.addEventListener('touchcancel', up, { passive: false });
    b.addEventListener('mousedown', dn); b.addEventListener('mouseup', up); b.addEventListener('mouseleave', up);
    return b;
  }
  function paintPad() {
    U.clear(pad);
    var show = padOn && fs;
    pad.classList.toggle('on', show);
    if (!show) return;
    pad.appendChild(h('div.dp', padBtn('u', '▲', 'ArrowUp'), padBtn('l', '◀', 'ArrowLeft'), padBtn('r', '▶', 'ArrowRight'), padBtn('d', '▼', 'ArrowDown')));
    pad.appendChild(h('div.ab', padBtn('a', 'Space', ' '), padBtn('b', 'Enter', 'Enter')));
  }

  function exportHtml() {
    var b = Run.bundle(files()); if (!b) return UI.toast('Nothing to export');
    N.save(U.slug(St.cur.name) + '.html', b.html, 'text/html').then(function () { UI.toast('Saved'); }, function (e) { if (e.message !== 'cancelled') UI.toast(e.message); });
  }
  function onMsg(ev) {
    var d = ev.data;
    if (!frame || ev.source !== frame.contentWindow || !d || d.rc !== 1 || d.sid !== sid) return;
    if (d.k === 'console') { consoleLines.push([d.lvl, d.text]); if (d.lvl === 'error') errCount++; }
    else if (d.k === 'error') { consoleLines.push(['error', d.msg + (d.line ? ' (line ' + d.line + ')' : '')]); errCount++; }
    else if (d.k === 'ls') { if (!temp) St.setLS(d.data); }
    else return;
    paintCon(); paintBar();
    if (d.k === 'error' && !showCon) UI.toast('The page has an error - open Console');
  }
  window.addEventListener('message', onMsg);

  function load(force) {
    stale = false;
    U.clear(box); consoleLines = []; errCount = 0;
    U.clear(banner);
    if (temp) banner.appendChild(h('div.card', { style: { marginBottom: '8px', display: 'flex', gap: '10px', alignItems: 'center' } }, h('div.grow.t2', 'Snippet preview - not part of the project.'),
      UI.btn('Save to project', null, 'sm', function () { var f = temp; temp = null; Object.keys(f).forEach(function (p) { St.putFile(p === 'index.html' && St.files['index.html'] ? 'snippet.html' : p, f[p]); }); UI.toast('Saved'); load(true); }),
      UI.btn('Close', null, 'sm ghost', function () { temp = null; load(true); })));
    sid = U.uid('pv');
    var b = Run.frame(files(), sid);
    if (!b) { box.appendChild(h('div.empty', { style: { alignSelf: 'center' } }, 'Nothing to run yet. Build something first - HTML, CSS and JS files run here, fully offline.')); frame = null; paintBar(); paintCon(); return; }
    frame = h('iframe', { sandbox: Run.SANDBOX, title: 'preview', allow: 'fullscreen; autoplay; accelerometer; gyroscope' });
    frame.setAttribute('allowfullscreen', '');
    frame.srcdoc = b.srcdoc;
    box.appendChild(frame);
    paintBar(); paintCon();
  }
  UI.runSnippet = function (code, lang) {
    lang = (lang || '').toLowerCase(); var f = {};
    if (/^(js|javascript)$/.test(lang)) f['index.html'] = '<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head><body><script>\n' + code + '\n<\/script></body></html>';
    else if (lang === 'svg') f['index.html'] = '<!DOCTYPE html><html><body style="margin:0">' + code + '</body></html>';
    else f['index.html'] = code;
    temp = f; UI.go('run'); load(true);
  };
  var refresh = U.debounce(function () { if (RC.settings.autoPreview && !temp && root.classList.contains('on')) load(); else stale = true; }, 500);
  RC.bus.on('files', refresh);
  RC.bus.on('project', function () { temp = null; stale = true; if (fs) setFs(false); if (root.classList.contains('on')) load(); });
  RC.bus.on('settings', function () { if (root.classList.contains('on') && frame) { /* netPreview change applies on reload */ } });
  UI.mods.run = {
    show: function () { if (stale || !frame || temp) load(); else { paintBar(); paintCon(); } },
    // back button: leave fullscreen first, then close a snippet preview
    back: function () { if (fs) { setFs(false); return true; } if (temp) { temp = null; load(true); return true; } return false; }
  };
  // leaving the Run tab (any way) must also leave fullscreen
  try { new MutationObserver(function () { if (fs && !root.classList.contains('on')) setFs(false); }).observe(root, { attributes: true, attributeFilter: ['class'] }); } catch (e) { }
  paintBar(); paintCon();
})();
