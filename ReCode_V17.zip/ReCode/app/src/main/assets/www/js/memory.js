/* ReCode - Phase 4: memory and context.
   1. todo     - a small task list the agent keeps up to date (stored in the project, survives "continue").
   2. remember - appends a lasting fact to RECODE.md (a normal project file the user can read and edit).
                 RECODE.md is read at the start of every agent run and put at the top of the prompt.
   3. compaction - when the transcript of an agent run gets long, the oldest steps are folded into a short
                 summary (files read / changed, checks, problems) instead of being dropped. Deterministic and instant,
                 so it costs no extra model call on the phone. The PreCompact hook fires before it happens.
   The tools register themselves in RC.tools.registry, so they go through hooks, permissions and the parser like every other tool. */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var U = RC.u;

  var NOTES = 'RECODE.md', NOTES_CAP = 3000, MAX_TODO = 12, MAX_ITEM = 90;
  function St() { return RC.store; }
  function files() { return St().files; }
  function fail(m) { var e = new Error(m); e.tool = true; return e; }
  function one(s, n) { return U.clip(String(s || '').split('\n')[0].trim(), n, '…'); }

  // ------------------------------------------------------------------ todo list
  var MARK = { todo: '[ ]', doing: '[~]', done: '[x]' };
  var ACTIONS = {
    add: 'add', new: 'add', create: 'add', append: 'add',
    set: 'set', plan: 'set', replace: 'set', write: 'set',
    start: 'start', doing: 'start', progress: 'start', begin: 'start', wip: 'start',
    done: 'done', complete: 'done', completed: 'done', finish: 'done', finished: 'done', check: 'done', x: 'done',
    remove: 'remove', delete: 'remove', rm: 'remove', drop: 'remove',
    list: 'list', show: 'list', view: 'list', read: 'list',
    clear: 'clear', reset: 'clear'
  };
  function items() {
    var p = St().cur;
    if (!p) return [];
    if (!Array.isArray(p.todos)) p.todos = [];
    return p.todos;
  }
  function saved() { if (St().touch) St().touch(); if (RC.bus) RC.bus.emit('todos'); }
  function render(list) { return list.map(function (t, i) { return MARK[t.status] + ' ' + (i + 1) + '. ' + t.text; }).join('\n'); }
  function split(text) {
    return String(text == null ? '' : text).split(/\s*(?:;|\n)\s*/).map(function (x) {
      return x.replace(/^\s*(?:[-*•]|\d+[.)])\s*/, '').replace(/^\[[ xX~]\]\s*/, '').trim();
    }).filter(Boolean).map(function (x) { return U.clip(x, MAX_ITEM, '…'); });
  }
  /** "2", "1,3", "all" or a piece of the item text -> array of indexes */
  function refs(arg, list) {
    var s = String(arg == null ? '' : arg).trim().toLowerCase();
    if (!s) return [];
    if (s === 'all') return list.map(function (_, i) { return i; });
    var nums = s.match(/\d+/g);
    if (nums && /^[\d\s,#.\-and]+$/.test(s)) {
      return nums.map(function (n) { return parseInt(n, 10) - 1; }).filter(function (i, k, a) { return i >= 0 && i < list.length && a.indexOf(i) === k; });
    }
    for (var i = 0; i < list.length; i++) if (list[i].text.toLowerCase().indexOf(s) >= 0) return [i];
    return [];
  }
  function listOut(list, head) {
    return (head ? head + '\n' : '') + (list.length ? 'TODO:\n' + render(list) : 'The todo list is empty.');
  }

  var Todo = {
    items: items,
    text: function () { return render(items()); },
    open: function () { return items().filter(function (t) { return t.status !== 'done'; }); },
    /** a new request starts: finished lists are dropped, unfinished ones only survive a "continue" */
    startRun: function (keep) {
      var l = items();
      if (!l.length) return;
      if (!keep || !Todo.open().length) { l.length = 0; saved(); }
    },
    apply: function (a, ctx) {
      if (ctx && ctx.depth) throw fail('Specialists do not manage the todo list. Report back to the main agent instead.');
      var list = items(), act = String(a.action == null ? '' : a.action).trim().toLowerCase().replace(/[^a-z]/g, ''), text = a.text == null ? a.items == null ? '' : a.items : a.text;
      if (Array.isArray(text)) text = text.join(';');
      if (!act) act = 'list';
      else if (!ACTIONS[act]) { text = (a.action + (text ? ' ' + text : '')).trim(); act = 'add'; } // "TOOL: todo | Write index.html"
      else act = ACTIONS[act];
      var arg = text;
      if (act === 'list') return listOut(list);
      if (act === 'clear') { var n = list.length; list.length = 0; saved(); return 'Todo list cleared (' + n + ' item(s)).'; }
      if (act === 'add' || act === 'set') {
        var add = split(text);
        if (!add.length) throw fail('Give the item text, e.g. TOOL: todo | add | write style.css (separate several items with ;).');
        var base = act === 'set' ? [] : list.slice();
        if (base.length + add.length > MAX_TODO) throw fail('The todo list can hold ' + MAX_TODO + ' items (now ' + base.length + '). Finish or remove some first, or use fewer, bigger items.');
        list.length = 0;
        base.concat(add.map(function (t) { return typeof t === 'string' ? { text: t, status: 'todo' } : t; })).forEach(function (t) { list.push(t); });
        saved();
        return listOut(list, (act === 'set' ? 'Todo list set' : 'Added') + ' (' + add.length + ' item(s)).');
      }
      var idx = refs(arg, list);
      if (!idx.length) throw fail('No such item "' + String(arg).trim() + '". ' + (list.length ? 'Use the number from the list.\n' + render(list) : 'The todo list is empty.'));
      if (act === 'remove') {
        var gone = idx.length;
        idx.sort(function (x, y) { return y - x; }).forEach(function (i) { list.splice(i, 1); });
        saved();
        return listOut(list, 'Removed ' + gone + ' item(s).');
      }
      idx.forEach(function (i) { list[i].status = act === 'start' ? 'doing' : 'done'; });
      saved();
      var left = Todo.open().length;
      return listOut(list, (act === 'start' ? 'Started' : 'Done') + ': ' + idx.map(function (i) { return i + 1; }).join(', ') + '.') +
        (act === 'done' && !left ? '\nAll items are done. Verify the work (check_syntax / run_tests), then give the final answer.' : '');
    }
  };

  // ------------------------------------------------------------------ RECODE.md project notes
  function noteName() {
    if (files()[NOTES] !== undefined) return NOTES;
    var k = Object.keys(files()).filter(function (x) { return x.toLowerCase() === 'recode.md'; })[0];
    return k || '';
  }
  var HEAD = '# Project notes\n<!-- Short facts every ReCode session reads first: stack, conventions, decisions. Keep it brief. -->\n\n';
  var Notes = {
    name: NOTES, cap: NOTES_CAP,
    exists: function () { return !!noteName(); },
    /** make sure the notes file exists (empty template, no placeholder text that would reach the prompt) -> Promise<path> */
    ensure: function () {
      var n = noteName();
      return n ? Promise.resolve(n) : St().putFile(NOTES, HEAD).then(function () { return NOTES; });
    },
    /** the notes without heading and comments, shortened to max chars (the newest lines at the end are kept) */
    text: function (max) {
      var n = noteName();
      if (!n) return '';
      var t = String(files()[n] || '').replace(/<!--[\s\S]*?-->/g, '').replace(/^\s*#{1,6}\s[^\n]*\n?/gm, '').replace(/\n{3,}/g, '\n\n').trim();
      if (!t) return '';
      return max && t.length > max ? U.clipMid(t, max) : t;
    },
    add: function (text) {
      var t = String(text == null ? '' : text).replace(/\s+/g, ' ').trim().replace(/^[-*•]\s*/, '');
      if (!t) throw fail('Nothing to remember. Give one short fact, e.g. TOOL: remember | uses tabs, no frameworks.');
      t = U.clip(t, 240, '…');
      var name = noteName() || NOTES, cur = files()[name], line = '- ' + t;
      if (cur !== undefined && cur.split('\n').some(function (l) { return l.trim().toLowerCase() === line.toLowerCase(); })) return Promise.resolve('Already in ' + name + '.');
      var next = cur === undefined ? HEAD + line + '\n' : cur.replace(/\s*$/, '\n') + line + '\n';
      if (next.length > NOTES_CAP) throw fail(name + ' is full (' + (cur || '').length + ' of ' + NOTES_CAP + ' chars). Shorten it first with edit_file (merge or delete old lines), then remember again.');
      return St().putFile(name, next).then(function () { return 'Saved to ' + name + ': ' + t; });
    }
  };

  // ------------------------------------------------------------------ compaction
  var READ = { read_file: 1, get_file_info: 1 };
  var CHANGE = { write_file: 'write', edit_file: 'edit', delete_file: 'delete', rename_file: 'rename', move_file: 'move', create_directory: 'mkdir' };
  var VERIFY = { check_syntax: 1, run_tests: 1, run_command: 1 };
  function addU(arr, v, max) { var i = arr.indexOf(v); if (i >= 0) arr.splice(i, 1); arr.push(v); while (arr.length > max) arr.shift(); }

  var Compact = {
    fresh: function () { return { n: 0, runs: 0, read: [], changed: [], checks: [], fails: [], delegated: [], said: [], kept: [] }; },
    /** fold transcript entries ({role:'tool'|'model'|'note', ...}) into the summary state */
    fold: function (cs, entries) {
      entries.forEach(function (e) {
        cs.n++;
        if (e.role === 'model') { if (e.text) addU(cs.said, one(e.text, 110), 2); return; }
        if (e.role !== 'tool') return;
        var label = String(e.label || ''), sp = label.indexOf(' '), name = sp < 0 ? label : label.slice(0, sp), arg = sp < 0 ? '' : label.slice(sp + 1), out = String(e.out || '');
        if (!e.ok) { addU(cs.fails, label + ': ' + one(out.replace(/^(ERROR|BLOCKED):\s*/, ''), 90), 3); return; }
        if (READ[name]) addU(cs.read, arg, 10);
        else if (CHANGE[name]) addU(cs.changed, CHANGE[name] + ' ' + arg, 12);
        else if (VERIFY[name]) addU(cs.checks, name + ': ' + one(out, 80), 3);
        else if (name === 'delegate') {
          var m = /^\[([\w-]+) report\]\s*([\s\S]*)/.exec(out);
          addU(cs.delegated, (m ? m[1] + ': ' + one(m[2], 80) : one(out, 90)), 4);
        }
      });
      return cs;
    },
    keep: function (cs, text) { if (text) addU(cs.kept, U.clip(String(text).replace(/\s+/g, ' '), 120, '…'), 3); },
    /** most valuable lines first, so a tight cap cuts the least useful ones (what was read, what was said) */
    render: function (cs, max) {
      if (!cs || !cs.n) return '';
      var L = ['Earlier (' + cs.n + ' older step(s) compacted):'];
      if (cs.changed.length) L.push('- Changed: ' + cs.changed.join(', '));
      if (cs.checks.length) L.push('- Checks: ' + cs.checks.join(' | '));
      if (cs.fails.length) L.push('- Problems seen (may be fixed since): ' + cs.fails.join(' | '));
      if (cs.delegated.length) L.push('- Specialists: ' + cs.delegated.join(' | '));
      if (cs.kept.length) L.push('- Kept by hooks: ' + cs.kept.join(' | '));
      if (cs.read.length) L.push('- Read: ' + cs.read.join(', '));
      if (cs.said.length) L.push('- You said: ' + cs.said.join(' / '));
      return U.clip(L.join('\n'), max || 900, '…');
    }
  };

  RC.mem = { todo: Todo, notes: function (max) { return Notes.text(max); }, notesFile: Notes, compact: Compact, NOTES: NOTES };

  // ------------------------------------------------------------------ tools
  var reg = RC.tools && RC.tools.registry;
  if (reg) {
    reg.todo = {
      name: 'todo', perm: 'read', params: 'action, [text]',
      description: 'Task list: set a; b | add | start N | done N | remove N | list',
      run: function (a, ctx) { return Todo.apply(a || {}, ctx); }
    };
    reg.remember = {
      name: 'remember', perm: 'write', params: 'text',
      description: 'Save a lasting project fact to RECODE.md',
      run: function (a) { return Notes.add(a.text == null ? (a.note == null ? a.fact : a.note) : a.text); }
    };
  }
})();
