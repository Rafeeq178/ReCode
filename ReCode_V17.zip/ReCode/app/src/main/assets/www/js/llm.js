/* ReCode - one entry point for every model call, local (GGUF) or online (OpenAI compatible API).
   Every call is an isolated "agent turn": its own system prompt, no memory of earlier calls. */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var U = RC.u, N = RC.native;
  var chain = Promise.resolve();
  var curId = null;

  function AbortErr() { var e = new Error('Stopped'); e.name = 'AbortError'; return e; }

  var L = RC.llm = {
    AbortErr: AbortErr,
    /** {ok, why} - is a model available right now? */
    ready: function () {
      var s = RC.settings;
      if (!N.has) return { ok: false, why: 'Open ReCode on your phone to run a model.' };
      if (s.provider === 'api') {
        if (!s.api.base || !s.api.model) return { ok: false, why: 'Fill the online API address and model in Library.' };
        if (!N.online()) return { ok: false, why: 'The online API needs internet.' };
        return { ok: true };
      }
      if (!s.model) return { ok: false, why: 'Choose or download a model in Library first.' };
      var list = N.models();
      if (!list.some(function (m) { return m.name === s.model; })) return { ok: false, why: 'The selected model file is missing. Pick one in Library.' };
      return { ok: true };
    },
    label: function () {
      var s = RC.settings;
      return s.provider === 'api' ? (s.api.model + ' (online)') : (s.model ? s.model.replace(/\.gguf$/i, '') : 'No model');
    },
    /**
     * run({agent, system, prompt, maxTokens, signal, onPhase(p), onToken(text)}) -> Promise<string>
     * Calls are queued, so only one model call runs at a time.
     */
    run: function (o) {
      var p = chain.then(function () { return one(o); });
      chain = p.catch(function () { });
      return p;
    },
    stop: function () { N.call('llmStop'); }
  };

  function one(o) {
    return new Promise(function (resolve, reject) {
      if (o.signal && o.signal.aborted) return reject(AbortErr());
      var rdy = L.ready();
      if (!rdy.ok) return reject(new Error(rdy.why));
      var id = U.uid('l'), text = '', settled = false, looped = false, lastChk = 0, s = RC.settings, off, killT;
      curId = id;
      function done(err) {
        if (settled) return; settled = true;
        clearTimeout(killT); off && off();
        if (o.signal) o.signal.removeEventListener('abort', onAbort);
        curId = null;
        if (looped && (!err || err.name === 'AbortError') && !(o.signal && o.signal.aborted)) { text = RC.assets.trimLoop(text); o.looped = true; return resolve(text); }
        err ? reject(err) : resolve(text);
      }
      function onAbort() {
        L.stop();
        killT = setTimeout(function () { done(AbortErr()); }, 2500); // never hang if the phone does not answer
      }
      if (o.signal) o.signal.addEventListener('abort', onAbort);
      off = N.onLlm(id, function (ev) {
        if (ev.k === 'loading') o.onPhase && o.onPhase('loading');
        else if (ev.k === 'loaded') o.onPhase && o.onPhase('thinking');
        else if (ev.k === 'tok') {
          if (!text) o.onPhase && o.onPhase('writing');
          text += ev.v; o.onToken && o.onToken(text);
          // v8: a small model can fall into an endless repeat ("Xu9995777333Xu99957..."): stop it early and keep the good part
          if (!looped && RC.assets && text.length - lastChk >= 64) { lastChk = text.length; if (RC.assets.degenerate(text)) { looped = true; L.stop(); killT = setTimeout(function () { done(); }, 2500); } }
        }
        else if (ev.k === 'done') done();
        else if (ev.k === 'stopped') done(AbortErr());
        else if (ev.k === 'err') done(new Error(ev.v || 'The model failed'));
      });
      var max = Math.max(32, Math.min(o.maxTokens || 800, 8192));
      try {
        if (s.provider === 'api') N.call('apiRun', id, s.api.base, s.api.key || '', s.api.model, o.system || '', o.prompt || '', max, +s.api.temp || 0.3);
        else N.call('llmRun', id, s.model, o.system || '', o.prompt || '', max);
      } catch (e) { done(e); }
    });
  }
})();
