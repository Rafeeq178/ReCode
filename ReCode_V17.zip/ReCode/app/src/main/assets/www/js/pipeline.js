/* ReCode - the orchestrator. Runs the agent team step by step. Every LLM step reloads the model with that agent's
   own system prompt and receives only the hand-over the orchestrator builds for it (isolated memory). */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var U = RC.u, N = RC.native, St = RC.store;

  var BUILD_RE = /\b(build|create|make|generate|write|develop|design|code|implement|fix|debug|add|change|update|edit|modify|refactor|convert|zip|app|website|page|game|calculator|landing|todo|form|dashboard|bana|banao|bnao|bna|likh|likho|likhna)\b/i;

  function AbortErr() { return RC.llm.AbortErr(); }

  var P = RC.pipe = {
    current: null,
    detectMode: function (text, mode) {
      if (mode && mode !== 'auto') return mode;
      if (RC.subagents && RC.subagents.manual(text)) return 'agent';
      if (RC.settings.autoAgent && BUILD_RE.test(text)) return 'agent';
      return BUILD_RE.test(text) ? 'build' : 'chat';
    },
    /** starts a run; returns the run object (its .done promise settles when finished) */
    start: function (text, mode) {
      var run = {
        id: U.uid('run'), mode: P.detectMode(text, mode), status: 'running', title: U.clip(text.replace(/\s+/g, ' '), 60, '…'),
        t0: Date.now(), t1: 0, steps: [], files: [], sources: [], final: '', zip: null, ctl: new AbortController()
      };
      P.current = run;
      var bb = { text: text, plan: null, notes: '', rag: '', contract: '', web: '' };
      if (RC.settings.keepAwake) N.keepAwake(true);
      run.done = (async function () {
        try {
          if (RC.hooks) {
            await RC.hooks.run('SessionStart', { run: run }, { run: run });
            var up = await RC.hooks.run('UserPromptSubmit', { text: bb.text }, { run: run });
            if (up.blocked) { run.final = 'Request not started: ' + up.reason; run.status = 'done'; throw Object.assign(new Error('hook'), { name: 'HookBlock' }); }
            if (up.input && up.input.text) bb.text = String(up.input.text);
          }
          if (run.mode === 'agent') await runAgent(run, bb);
          else if (run.mode === 'build') await runBuild(run, bb);
          else await runChat(run, bb);
          run.status = 'done';
        } catch (e) {
          if (e && e.name === 'HookBlock') { /* blocked by a UserPromptSubmit hook: final text already set */ }
          else if (e && e.name === 'AbortError') {
            run.status = 'stopped';
            run.steps.forEach(function (s) { if (s.status === 'running') { s.status = 'stopped'; s.t1 = Date.now(); } });
            run.final = run.final || 'Stopped.';
          } else {
            run.status = 'error'; run.error = e && e.message || String(e);
            run.final = run.final || ('Something went wrong: ' + run.error);
            run.steps.forEach(function (s) { if (s.status === 'running') { s.status = 'error'; s.t1 = Date.now(); s.note = run.error; } });
          }
        }
        run.t1 = Date.now(); P.current = null;
        if (RC.hooks) { try { await RC.hooks.run('SessionEnd', { run: run }, { run: run }); } catch (e) { } }
        N.keepAwake(false);
        emit(run, true);
        return run;
      })();
      emit(run, true);
      return run;
    },
    stop: function () { if (P.current) { P.current.ctl.abort(); } },
    zipBytes: function () {
      var files = St.fileList().map(function (p) { return { name: p, data: St.files[p] }; });
      return U.zip(files);
    },
    zipName: function () { return U.slug(St.cur ? St.cur.name : 'project') + '.zip'; }
  };

  var pending = false;
  function emit(run, now) {
    if (now) { pending = false; RC.bus.emit('run', run); return; }
    if (pending) return; pending = true;
    setTimeout(function () { if (pending) { pending = false; RC.bus.emit('run', run); } }, 90);
  }
  function check(run) { if (run.ctl.signal.aborted) throw AbortErr(); }

  function step(run, agent, title, kind) {
    var s = { id: U.uid('s'), agent: agent, title: title, kind: kind || 'llm', status: 'running', phase: '', t0: Date.now(), t1: 0, ctx: null, out: '', log: [], note: '' };
    run.steps.push(s); emit(run, true); return s;
  }
  function finish(run, s, status, note) { s.status = status || 'done'; s.t1 = Date.now(); if (note) s.note = note; s.phase = ''; emit(run, true); }

  /** one isolated model turn */
  async function llmStep(run, s, system, prompt, max) {
    check(run);
    s.ctx = { system: system, prompt: prompt };
    s.phase = 'loading'; emit(run, true);
    try {
      var o = {
        agent: s.agent, system: system, prompt: prompt, maxTokens: max, signal: run.ctl.signal,
        onPhase: function (p) { s.phase = p; emit(run, true); },
        onToken: function (t) { s.out = t.length > 40000 ? t.slice(-40000) : t; emit(run); }
      };
      var out = await RC.llm.run(o);
      s.out = out; finish(run, s, 'done', o.looped ? 'stopped an endless repeat, kept the good part' : '');
      s.looped = !!o.looped;
      return RC.agents.stripThink(out);
    } catch (e) {
      finish(run, s, e.name === 'AbortError' ? 'stopped' : 'error', e.message);
      throw e;
    }
  }
  async function toolStep(run, agent, title, fn) {
    check(run);
    var s = step(run, agent, title, 'tool');
    try { var r = await fn(s); if (s.status === 'running') finish(run, s, 'done'); return r; }
    catch (e) { finish(run, s, e.name === 'AbortError' ? 'stopped' : 'error', e.message); throw e; }
  }
  function budget() { return Math.max(2500, +RC.settings.ctxChars || 7000); }
  function maxOf(id, fallback) { var c = RC.agentCfg(id); return c.max || fallback; }
  function host(u) { try { return new URL(u).hostname.replace(/^www\./, ''); } catch (e) { return u; } }
  function skip(run, agent, title, why) { var s = step(run, agent, title, 'tool'); s.log.push(why); finish(run, s, 'skipped', why); }

  // ------------------------------------------------------------------ web research (tool steps only)
  var BLOCKED = /(^|\.)(behance\.net|dribbble\.com|pinterest\.[a-z.]+|instagram\.com|facebook\.com|twitter\.com|x\.com|linkedin\.com|tiktok\.com|youtube\.com|youtu\.be|quora\.com|reddit\.com|shutterstock\.com|adobe\.com|canva\.com)$/i;
  function okHost(u) { try { return !BLOCKED.test(new URL(u).hostname); } catch (e) { return false; } }
  /** v8: ask search engines for readable sources (docs, tutorials) and exclude sites that block apps */
  function betterQuery(q, n) {
    q = U.clip(String(q).replace(/\s+/g, ' '), 80, '');
    var ex = ' -site:behance.net -site:dribbble.com -site:pinterest.com -site:instagram.com -site:facebook.com';
    return n === 0 ? q + ex : q + ' tutorial OR documentation OR guide' + ex;
  }
  async function webResearch(run, queries, bb) {
    var hits = [];
    if (RC.skills && RC.skills.enabled() && queries.length === 1) queries = [queries[0], queries[0]];
    for (var q = 0; q < queries.length; q++) {
      var r = await toolStep(run, 'notes', 'Searching the web: ' + U.clip(queries[q], 50, '…'), async function (s) {
        var h = (await N.search(betterQuery(queries[q], q), 8)).filter(function (x) { return okHost(x.url); });
        h.forEach(function (x) { s.log.push(x.title + ' - ' + x.url); });
        return h;
      }).catch(function (e) { if (e.name === 'AbortError') throw e; return []; });
      r.forEach(function (x) { if (!hits.some(function (y) { return y.url === x.url; })) hits.push(x); });
    }
    var pages = [];
    for (var i = 0; i < hits.length && i < 8 && pages.length < 2; i++) {
      var pg = await toolStep(run, 'notes', 'Reading ' + host(hits[i].url), async function (s) {
        var d = await N.read(hits[i].url, 2200);
        s.log.push(U.clip(d.text, 600, '…'));
        return d;
      }).catch(function (e) { if (e.name === 'AbortError') throw e; return null; });
      if (pg) { pages.push({ n: pages.length + 1, url: hits[i].url, title: pg.title || hits[i].title, text: pg.text }); }
      else if (hits[i].snippet) pages.push({ n: pages.length + 1, url: hits[i].url, title: hits[i].title, text: hits[i].snippet });
    }
    pages.forEach(function (p) { run.sources.push({ n: p.n, title: p.title, url: p.url }); });
    return pages;
  }

  function pagesText(pages, max) {
    var per = Math.floor(max / Math.max(1, pages.length));
    return pages.map(function (p) { return '[' + p.n + '] ' + p.title + ' (' + p.url + ')\n' + U.clip(p.text, per, '…'); }).join('\n\n');
  }

  async function ragStep(run, bb, query) {
    var S = RC.settings;
    if (!S.useRag || !RC.rag.corpus().length) return '';
    return await toolStep(run, 'coder', 'Searching your knowledge', async function (s) {
      var hits = RC.rag.search(query, { k: S.ragK });
      hits.forEach(function (h) { s.log.push(h.name + ' (line ' + h.line + ') score ' + h.score.toFixed(1)); });
      if (!hits.length) { s.log.push('Nothing relevant found.'); return ''; }
      return RC.rag.format(hits, 1800);
    }).catch(function (e) { if (e.name === 'AbortError') throw e; return ''; });
  }

  // ------------------------------------------------------------------ v8: skills + site kit
  function skillBlock(text, role, chars) { try { return RC.skills ? RC.skills.prompt(text, role, chars) : ''; } catch (e) { return ''; } }
  function siteFor(text) {
    var S = RC.settings;
    return (S.useSiteKit !== false && RC.sitekit && !realFiles().length && !templateFor(text) && RC.sitekit.isSite(text)) ? RC.sitekit.detectType(text) : '';
  }
  var COPY_SYS = 'You are ReCode Copywriter. Write the text for a website. Reply with ONLY one JSON object, no markdown, no explanation:\n' +
    '{"name":"brand name","tagline":"one sentence under 90 characters","about":"2 sentences","features":[{"title":"","text":""},{"title":"","text":""},{"title":"","text":""}],"items":[{"name":"","desc":"under 70 characters","price":"$0.00"}]}\n' +
    'Rules: real, specific content for this exact business; exactly 3 features; 6 items (menu items, products, services or projects); prices where it makes sense; English; no placeholder text.';
  async function buildSite(run, bb, type) {
    var S = RC.settings, copy = null, text = bb.text.replace(/\(ReCode already wrote[\s\S]*$/, '');
    if (S.siteCopy !== false && RC.llm.ready().ok) {
      var cs = step(run, 'planner', 'Writing the website text (' + type + ')');
      try {
        var out = await llmStep(run, cs, COPY_SYS + (skillBlock(text, 'planner', 400) ? '\n' + skillBlock(text, 'planner', 400) : ''), 'Website request: ' + U.clip(text, 600), 700);
        copy = RC.sitekit.parseCopy(out);
        cs.note = copy ? 'text ready' : 'using tested default text';
      } catch (e) { if (e.name === 'AbortError') throw e; cs.note = 'using tested default text'; }
    }
    var spec = RC.sitekit.spec(text, copy), files;
    await toolStep(run, 'coder', 'Building the website: ' + spec.name, async function (s) {
      files = RC.sitekit.files(spec);
      var names = Object.keys(files);
      for (var i = 0; i < names.length; i++) { await St.putFile(names[i], files[names[i]]); if (run.files.indexOf(names[i]) < 0) run.files.push(names[i]); s.log.push(names[i] + ' - ' + U.bytes(files[names[i]].length)); }
      s.note = names.length + ' files';
    });
    run.title = U.clip(spec.name + ' website', 70, '…');
    return spec;
  }
  async function runSite(run, bb, type) {
    var spec = await buildSite(run, bb, type);
    var res = await toolStep(run, 'fixer', 'Running checks', async function (cs) {
      var x = await RC.run.check();
      x.fixes.forEach(function (m) { cs.log.push('auto-fix: ' + m); });
      x.issues.forEach(function (m) { cs.log.push('problem in ' + m.file + ': ' + m.msg); });
      if (!x.issues.length) cs.log.push(x.ran ? 'Page ran without errors; every section has content.' : 'No page to run; static checks passed.');
      cs.note = x.issues.length ? x.issues.length + ' problem(s)' : 'all good';
      return x;
    });
    if (/\bzip\b|archive/i.test(bb.text)) {
      await toolStep(run, 'coder', 'Packaging ZIP', async function (zs) {
        var bytes = P.zipBytes(), n = St.fileList().length;
        run.zip = { name: P.zipName(), size: bytes.length, count: n };
        zs.log.push(run.zip.name + ' - ' + n + ' files, ' + U.bytes(bytes.length));
      });
    }
    run.final = 'Done - **' + spec.name + '** ' + spec.type + ' website is ready' + (res.issues.length ? ' (' + res.issues.length + ' problem(s) - open Activity).' : ', checks passed.') +
      (run.zip ? ' Your ZIP is ready.' : '') + '\n\n' + run.files.map(function (p) { return '- `' + p + '`'; }).join('\n') +
      '\n\nLogo, hero picture and favicon are SVG files made by ReCode (works offline, never broken). Phone, email and address are sample text - tell me the real ones, new colors or more sections and I will edit it. Open the Run tab to see it.';
  }

  // ------------------------------------------------------------------ AGENT (Phase 1: model-driven tool loop, see loop.js)
  P.H = { step: step, finish: finish, llmStep: llmStep, toolStep: toolStep, check: check, emit: emit, budget: budget, maxOf: maxOf, summary: agentSummary };
  function agentSummary(run, state, why) {
    return (why ? why + '\n\n' : '') + (state.modified.filter(function (p) { return !/\.gitkeep$/.test(p); }).length ? 'Changed files:\n' + state.modified.filter(function (p) { return !/\.gitkeep$/.test(p); }).map(function (p) { return '- `' + p + '`'; }).join('\n') + (state.verified ? '' : '\n\nThese changes were not verified.') : 'No files were changed.');
  }
  async function runAgent(run, bb) {
    run.title = U.clip(bb.text.replace(/\s+/g, ' '), 70, '…');
    if (!RC.agentLoop) throw new Error('The agent loop is not loaded.');
    // "@frontend make the button blue" talks to that specialist directly (manual selection)
    var man = RC.subagents && RC.subagents.manual(bb.text);
    if (man) {
      bb.text = man.task; run.manualAgent = man.name; run.title = U.clip('@' + man.name + ' ' + man.task, 70, '…');
      await RC.agentLoop(run, bb, P.H, Object.assign(RC.subagents.loopOpts(man.name), { sub: false, maxIter: Math.max(RC.subagents.get(man.name).max_turns, +RC.settings.maxIter || 12) }));
      return;
    }
    var tpl = templateFor(bb.text);
    if (tpl && !(RC.perms && RC.perms.mode() === 'plan')) {
      var rec = await seedTemplate(run, tpl);
      bb.text += '\n\n(ReCode already wrote the tested "' + rec.title + '" template into the project: ' + Object.keys(rec.files).join(', ') + '. It works. Do NOT rewrite it. Run run_tests, change only what the request above asks for with edit_file, then answer in one or two sentences.)';
    }
    var site = (!tpl && !(RC.perms && RC.perms.mode() === 'plan')) ? siteFor(bb.text) : '';
    if (site) {
      var sp = await buildSite(run, bb, site);
      bb.text += '\n\n(ReCode already built a complete tested ' + sp.type + ' website in the project: ' + Object.keys(St.files).join(', ') + '. Logo/hero/favicon are SVG files. It works. Do NOT rewrite it. Run run_tests, change only what the request above asks for with edit_file, then answer in one or two sentences.)';
    }
    bb.skills = skillBlock(bb.text, 'agent', 600);
    bb.goal = bb.text;
    await RC.agentLoop(run, bb, P.H);
  }

  // ------------------------------------------------------------------ TEMPLATES (v6)
  function realFiles() { return St.fileList().filter(function (p) { return !/(^|\/)\.gitkeep$/.test(p); }); }
  function templateFor(text) {
    var S = RC.settings;
    return (S.useTemplates !== false && RC.recipes && !realFiles().length) ? RC.recipes.match(text) : '';
  }
  async function seedTemplate(run, name) {
    var rec = RC.recipes.get(name);
    await toolStep(run, 'coder', 'Loading tested template: ' + rec.title, async function (s) {
      var names = Object.keys(rec.files);
      for (var i = 0; i < names.length; i++) { await St.putFile(names[i], rec.files[names[i]]); if (run.files.indexOf(names[i]) < 0) run.files.push(names[i]); s.log.push(names[i] + ' - ' + U.bytes(rec.files[names[i]].length)); }
      s.note = names.length + ' files';
      return names.length;
    });
    return rec;
  }
  async function runTemplate(run, bb, name) {
    var rec = await seedTemplate(run, name);
    run.title = rec.title;
    var res = await toolStep(run, 'fixer', 'Running checks', async function (cs) {
      var x = await RC.run.check();
      x.issues.forEach(function (m) { cs.log.push('problem in ' + m.file + ': ' + m.msg); });
      if (!x.issues.length) cs.log.push(x.ran ? 'Page ran and every button was clicked without errors.' : 'No page to run.');
      cs.note = x.issues.length ? x.issues.length + ' problem(s)' : 'all good';
      return x;
    });
    if (/\bzip\b|archive/i.test(bb.text)) {
      await toolStep(run, 'coder', 'Packaging ZIP', async function (zs) {
        var bytes = P.zipBytes(), n = St.fileList().length;
        run.zip = { name: P.zipName(), size: bytes.length, count: n };
        zs.log.push(run.zip.name + ' - ' + n + ' files, ' + U.bytes(bytes.length));
      });
    }
    run.final = 'Done - started from the tested **' + rec.title + '** template (' + rec.desc + ')' + (res.issues.length ? '. ' + res.issues.length + ' problem(s) found - open Activity.' : ', checks passed.') +
      (run.zip ? ' Your ZIP is ready.' : '') + '\n\n' + run.files.map(function (p) { return '- `' + p + '`'; }).join('\n') +
      '\n\nTell me what to change (colors, buttons, features) and I will edit it. Open the Run tab to try it.';
  }

  // ------------------------------------------------------------------ BUILD
  async function runBuild(run, bb) {
    var S = RC.settings, A = RC.agents, text = bb.text, existing = St.fileList(), B = budget();
    var tpl = templateFor(text);
    if (tpl) return await runTemplate(run, bb, tpl);
    var siteType = siteFor(text);
    if (siteType) return await runSite(run, bb, siteType);
    var plan;
    // 1. Planner
    var pc = RC.agentCfg('planner');
    var s = step(run, 'planner', 'Planning the project');
    try {
      var pr = A.fit(B - pc.prompt.length, [
        { t: 'Request: ' + U.clip(text, 1800), p: 9, min: 300 },
        { t: skillBlock(text, 'planner', 500), p: 4, min: 150 },
        { t: existing.length ? 'Existing project files (edit mode): ' + existing.map(function (p) { return p + ' (' + St.files[p].length + ' chars)'; }).join(', ') : 'Existing project files: none (new project)', p: 5, min: 100 }
      ]);
      var out = await llmStep(run, s, pc.prompt, pr, maxOf('planner', 450));
      plan = A.parsePlan(out, text, existing);
    } catch (e) {
      if (e.name === 'AbortError' || /model|API|internet|phone/i.test(e.message || '') && !run.steps.some(function (x) { return x.status === 'done'; })) throw e;
      plan = A.parsePlan('', text, existing);
    }
    bb.plan = plan; run.title = U.clip(plan.summary, 70, '…');
    s.note = plan.files.length + ' file(s)' + (plan.research ? ' · research' : '');
    s.log.push('Files: ' + plan.files.map(function (f) { return f.path; }).join(', '));

    // 2. Research
    if (plan.research && S.autoResearch && RC.agentCfg('notes').on) {
      if (!N.online()) skip(run, 'notes', 'Web research', 'No internet connection - continuing offline');
      else {
        var pages = await webResearch(run, plan.queries, bb);
        if (pages.length) {
          var nc = RC.agentCfg('notes'), ns = step(run, 'notes', 'Writing research notes');
          var np = A.fit(B - nc.prompt.length, [{ t: 'Task: ' + plan.summary, p: 9, min: 100 }, { t: pagesText(pages, B), p: 3, min: 600 }]);
          try { bb.notes = await llmStep(run, ns, nc.prompt, np, maxOf('notes', 500)); }
          catch (e) { if (e.name === 'AbortError') throw e; }
        } else skip(run, 'notes', 'Web research', 'No usable pages found');
      }
    }

    // 3. Knowledge (RAG)
    bb.rag = await ragStep(run, bb, plan.summary + ' ' + plan.files.map(function (f) { return f.purpose; }).join(' '));

    // 4. Architect
    var ac = RC.agentCfg('architect');
    if (plan.files.length > 1 && S.architect && ac.on) {
      var as = step(run, 'architect', 'Designing the file contract');
      var ap = A.fit(B - ac.prompt.length, [
        { t: 'Project: ' + plan.summary, p: 9, min: 100 },
        { t: 'Original request: ' + U.clip(text, 600), p: 4, min: 100 },
        { t: 'Files:\n' + plan.files.map(function (f) { return '- ' + f.path + ': ' + f.purpose; }).join('\n'), p: 9, min: 200 },
        { t: bb.notes && 'Research notes:\n' + bb.notes, p: 3, min: 150 },
        { t: skillBlock(text + ' ' + plan.summary, 'architect', 600), p: 4, min: 150 },
        { t: bb.rag && 'Knowledge:\n' + bb.rag, p: 2, min: 150 }
      ]);
      try { bb.contract = await llmStep(run, as, ac.prompt, ap, maxOf('architect', 500)); }
      catch (e) { if (e.name === 'AbortError') throw e; }
    }

    // 5. Coder, one file at a time (fresh model load for every file)
    var cc = RC.agentCfg('coder');
    for (var i = 0; i < plan.files.length; i++) {
      var f = plan.files[i], isEdit = St.files[f.path] !== undefined;
      var code;
      if (RC.assets && (RC.assets.isBinary(f.path) || (U.ext(f.path) === 'svg' && RC.assets.isGenerated(f.path)))) {
        var gs = step(run, 'coder', 'Creating ' + f.path + ' (SVG picture)', 'tool');
        code = RC.assets.make(RC.assets.fixPath(f.path) || f.path, { name: (RC.sitekit && RC.sitekit.detectName(text)) || plan.summary.split(/[\s,.]+/).slice(0, 2).join(' ') || 'Brand', type: RC.sitekit ? RC.sitekit.detectType(text) : 'generic' });
        gs.log.push('Generated by code, not by the model (no binary files).'); finish(run, gs, 'done', U.bytes(code.length));
      } else code = await writeFile(run, bb, f, isEdit, cc, B);
      run.files.push(f.path);
      await St.putFile(f.path, code);
      emit(run, true);
    }

    // 6. Checks + fixes
    var fc = RC.agentCfg('fixer');
    if (S.review && fc.on && Object.keys(St.files).length) {
      var rounds = Math.max(0, +S.fixLoops || 0);
      for (var r = 0; r <= rounds; r++) {
        var res = await toolStep(run, 'fixer', r === 0 ? 'Running checks' : 'Re-running checks', async function (cs) {
          var x = await RC.run.check();
          x.fixes.forEach(function (m) { cs.log.push('auto-fix: ' + m); });
          x.issues.forEach(function (m) { cs.log.push('problem in ' + m.file + ': ' + m.msg); });
          if (!x.issues.length) cs.log.push(x.ran ? 'Page ran without errors.' : 'No page to run; static checks passed.');
          cs.note = x.issues.length ? x.issues.length + ' problem(s)' : 'all good';
          return x;
        });
        if (res.fixes.length) emit(run, true);
        if (!res.issues.length) { bb.clean = true; break; }
        bb.left = res.issues;
        if (r === rounds) break;
        var byFile = {};
        res.issues.forEach(function (m) { (byFile[m.file] = byFile[m.file] || []).push(m.msg); });
        var names = Object.keys(byFile);
        for (var k = 0; k < names.length; k++) {
          var fs = step(run, 'fixer', 'Fixing ' + names[k]);
          var cur = St.files[names[k]] || '';
          var fp = A.fit(B - fc.prompt.length, [
            { t: 'File: ' + names[k] + '\nProblems:\n- ' + byFile[names[k]].join('\n- '), p: 9, min: 300 },
            { t: skillBlock(names[k] + ' ' + byFile[names[k]].join(' '), 'fixer', 400), p: 4, min: 100 },
            { t: 'Project files: ' + St.fileList().join(', ') + (bb.contract ? '\nContract:\n' + bb.contract : ''), p: 3, min: 150 },
            { t: 'Current content:\n```\n' + cur + '\n```', p: 8, min: 1200 }
          ]);
          try {
            var fo = await llmStep(run, fs, fc.prompt, fp, maxOf('fixer', 1800));
            var ex = A.extractCode(fo);
            if (ex.code.trim().length > 20 && !ex.weak) { await St.putFile(names[k], ex.code); fs.note = 'rewritten'; }
            else fs.note = 'no usable code returned';
          } catch (e) { if (e.name === 'AbortError') throw e; }
        }
      }
    }

    // 7. Package
    if (plan.zip) {
      await toolStep(run, 'coder', 'Packaging ZIP', async function (zs) {
        var bytes = P.zipBytes(), n = St.fileList().length;
        run.zip = { name: P.zipName(), size: bytes.length, count: n };
        zs.log.push(run.zip.name + ' - ' + n + ' files, ' + U.bytes(bytes.length));
      });
    }
    var list = St.fileList();
    run.final = 'Done - **' + run.files.length + ' file' + (run.files.length === 1 ? '' : 's') + '** written' +
      (bb.clean ? ', checks passed.' : (bb.left && bb.left.length ? '. ' + bb.left.length + ' problem(s) remain - open Activity to see them, or ask me to fix.' : '.')) +
      (run.zip ? ' Your ZIP is ready.' : '') + '\n\n' + run.files.map(function (p) { return '- `' + p + '`'; }).join('\n') +
      (list.length > run.files.length ? '\n\nProject has ' + list.length + ' files in total.' : '');
  }

  async function writeFile(run, bb, f, isEdit, cc, B) {
    var A = RC.agents, plan = bb.plan, code = '', tries = 0, extra = 0;
    var others = St.fileList().filter(function (p) { return p !== f.path; }).map(function (p) { return '- ' + p + ' -> ' + A.digest(p, St.files[p]); }).join('\n');
    var ctxBlocks = [
      { t: 'Project: ' + plan.summary + '\nOriginal request: ' + U.clip(bb.text, 500), p: 9, min: 200 },
      { t: bb.contract && 'Contract (follow exactly):\n' + bb.contract, p: 8, min: 300 },
      { t: bb.notes && 'Research notes:\n' + bb.notes, p: 3, min: 150 },
      { t: skillBlock(bb.text + ' ' + f.path + ' ' + plan.summary, 'coder', 700), p: 5, min: 150 },
      { t: bb.rag && 'Knowledge:\n' + bb.rag, p: 2, min: 150 },
      { t: others && 'Other files in this project:\n' + others, p: 4, min: 200 },
      { t: isEdit ? 'CURRENT CONTENT of ' + f.path + ' (change it as requested, keep the rest):\n```\n' + St.files[f.path] + '\n```' : '', p: 7, min: 1500 },
      { t: 'FILE TO WRITE: ' + f.path + '\nPURPOSE: ' + f.purpose + '\nWrite the complete ' + f.path + ' now.', p: 10, min: 50 }
    ];
    while (tries < 2) {
      var s = step(run, 'coder', (isEdit ? 'Updating ' : 'Writing ') + f.path + (tries ? ' (retry)' : ''));
      var out = await llmStep(run, s, cc.prompt, A.fit(B - cc.prompt.length, ctxBlocks), maxOf('coder', 1800));
      var ex = A.extractCode(out);
      if (ex.code.trim().length >= 10 && !(ex.weak && ex.code.length < 30)) {
        code = ex.code;
        // the model stopped in the middle: continue in a new isolated turn that only sees the end of the file
        var open = ex.open || A.looksTruncated(f.path, code, false);
        while (open && extra < 3) {
          extra++;
          var cs = step(run, 'coder', 'Continuing ' + f.path);
          var cp = A.fit(B - cc.prompt.length, [
            { t: 'Project: ' + plan.summary + (bb.contract ? '\nContract:\n' + bb.contract : ''), p: 6, min: 200 },
            { t: 'The file ' + f.path + ' was cut off. This is its END so far:\n```\n' + code.slice(-1400) + '\n```\nContinue writing from exactly where it stops until the file is complete. Output ONLY the continuation inside one code block (do not repeat existing lines).', p: 10, min: 600 }
          ]);
          var co = await llmStep(run, cs, cc.prompt, cp, maxOf('coder', 1800));
          var cx = A.extractCode(co);
          if (!cx.code.trim()) break;
          code = code.replace(/\s+$/, '') + '\n' + cx.code;
          open = cx.open || A.looksTruncated(f.path, code, false);
        }
        s.note = U.bytes(code.length); return code;
      }
      s.note = 'empty answer'; tries++;
    }
    throw new Error('The model returned no code for ' + f.path + '. Try a bigger model or a shorter request.');
  }

  // ------------------------------------------------------------------ CHAT / RESEARCH
  async function runChat(run, bb) {
    var S = RC.settings, A = RC.agents, B = budget(), text = bb.text, ac = RC.agentCfg('assistant');
    var useWeb = run.mode === 'research' || S.webChat, pages = [];
    if (useWeb) {
      if (!N.online()) skip(run, 'notes', 'Web search', 'No internet connection - answering offline');
      else pages = await webResearch(run, [U.clip(text.replace(/\s+/g, ' '), 90, '')], bb);
    }
    var rag = await ragStep(run, bb, text);
    var hist = St.msgs.filter(function (m) { return m.text; }).slice(-7, -1).map(function (m) { return (m.role === 'user' ? 'User: ' : 'Assistant: ') + U.clip(m.text, 400, '…'); }).join('\n');
    var files = St.fileList();
    var s = step(run, 'assistant', run.mode === 'research' ? 'Writing the answer' : 'Thinking');
    var prompt = A.fit(B - ac.prompt.length, [
      { t: 'Question: ' + U.clip(text, 1500), p: 10, min: 300 },
      { t: pages.length && 'Web sources:\n' + pagesText(pages, 2500), p: 6, min: 400 },
      { t: rag && 'Knowledge / project passages:\n' + rag, p: 5, min: 300 },
      { t: files.length && 'Project files: ' + files.join(', '), p: 2, min: 50 },
      { t: hist && 'Earlier in this chat (oldest first):\n' + hist, p: 3, min: 150 }
    ]);
    var out = await llmStep(run, s, ac.prompt, prompt, maxOf('assistant', 900));
    run.final = out.trim() || '(no answer)';
    if (run.sources.length) run.final += '\n\n**Sources**\n' + run.sources.map(function (x) { return '[' + x.n + '] ' + x.title + ' - ' + x.url; }).join('\n');
  }
})();
