/* ReCode V10: Harness-inspired workflow helpers.
 * This layer strengthens ReCode's existing agent loop; it does not pretend to add
 * native shell/MCP/Shizuku capabilities that are not implemented by this app.
 */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  RC.engine = RC.engine || {};
  RC.engine.version = '10.0.0';
  RC.engine.workflow = ['reconnaissance', 'plan', 'implement', 'verify', 'report'];
  RC.engine.capabilities = {
    projectMap: true, skills: true, specialistAgents: true, permissions: true, hooks: true,
    memory: true, contextCompaction: true, sandboxPreview: true, syntaxChecks: true,
    projectTests: true, nativeShell: false, mcpClient: false, shizuku: false,
    deviceAutomation: false, browserAutomation: false
  };
  RC.engine.verificationSummary = function (state) {
    state = state || {};
    return { changedFiles: (state.modified || []).slice(), verified: !!state.verified,
      calls: state.calls || 0, status: state.verified ? 'verified-by-available-project-checks' : 'verification-required' };
  };
})();
