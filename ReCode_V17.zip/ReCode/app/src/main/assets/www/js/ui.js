/* ReCode - app shell: navigation, responsive layout, sheets, drawer, toast, small form widgets. */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var U = RC.u, h = U.h, St = RC.store;

  var UI = RC.ui = { view: 'build', wsTab: 'act', wide: false, sheetStack: [], mods: {} };
  var NAV = [['build', 'message', 'Chats'], ['projects', 'folder', 'Projects'], ['files', 'code', 'Code'], ['run', 'grid', 'Artifacts'], ['lib', 'cpu', 'Models'], ['set', 'sliders', 'Settings']];
  var TITLES = { build: null, projects: 'Projects', files: 'Code', run: 'Artifacts', lib: 'Models', set: 'Settings', act: 'Activity' };

  // ------------------------------------------------------------------ toast
  var tt;
  UI.toast = function (m) {
    var t = U.$('#toast'); t.textContent = m; t.classList.add('on');
    clearTimeout(tt); tt = setTimeout(function () { t.classList.remove('on'); }, 2400);
  };

  // ------------------------------------------------------------------ theme
  UI.applyTheme = function () {
    var t = RC.settings.theme, dark = t === 'dark' || (t === 'system' && window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches);
    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
    var bg = dark ? '#15110F' : '#FAF9F5';
    RC.native.call('setBars', dark, bg);
  };

  // ------------------------------------------------------------------ widgets
  UI.btn = function (label, icon, cls, fn) { return h('button.btn' + (cls ? '.' + cls.split(' ').join('.') : ''), { onclick: fn }, icon ? h('span', { html: RC.i(icon, 18) }) : null, label); };
  UI.rbtn = function (icon, fn, label, cls) { return h('button.rbtn' + (cls ? '.' + cls : ''), { html: RC.i(icon, 20), onclick: fn, 'aria-label': label || icon }); };
  UI.card = function () { var c = h('div.card'); for (var i = 0; i < arguments.length; i++) U.add(c, arguments[i]); return c; };
  UI.sec = function (t) { return h('div.sec', t); };
  UI.row = function (o) {
    var el = h(o.onclick ? 'button.row' : 'div.row', { style: { width: '100%', textAlign: 'left', padding: o.pad === false ? 0 : '4px 0' }, onclick: o.onclick },
      o.icon ? h('div.ico' + (o.fill ? '.fill' : ''), { html: RC.i(o.icon, 20) }) : null,
      h('div.grow', h('div.t1.ell', o.title), o.sub ? h('div.t2' + (o.wrapSub ? '' : '.ell'), o.sub) : null),
      o.right || null);
    return el;
  };
  UI.toggle = function (key, label, sub, onchange) {
    var t = h('div.tog' + (RC.settings[key] ? '.on' : ''));
    var r = h('button.setrow', { style: { width: '100%', textAlign: 'left' }, onclick: function () {
      RC.set(key, !RC.settings[key]); t.classList.toggle('on', !!RC.settings[key]); onchange && onchange(RC.settings[key]);
    } }, h('div.grow', h('div.t1', label), sub ? h('div.t2', sub) : null), t);
    return r;
  };
  UI.slider = function (key, label, min, max, step, fmt, sub) {
    var v = RC.settings[key], b = h('b', fmt ? fmt(v) : v);
    var inp = h('input', { type: 'range', min: min, max: max, step: step, value: v, oninput: function () {
      var x = +inp.value; b.textContent = fmt ? fmt(x) : x; RC.settings[key] = x;
    }, onchange: function () { RC.saveSettings(); } });
    return h('div.setrow', h('div.grow', h('div.t1', label), sub ? h('div.t2', sub) : null), h('div.slider', inp, b));
  };
  UI.seg = function (opts, cur, fn) {
    var el = h('div.seg');
    opts.forEach(function (o) {
      var b = h('button' + (o[0] === cur ? '.on' : ''), { onclick: function () { U.$$('button', el).forEach(function (x) { x.classList.remove('on'); }); b.classList.add('on'); fn(o[0]); } }, o[1]);
      el.appendChild(b);
    });
    return el;
  };
  UI.field = function (label, input) { return h('div.field', h('label', label), input); };

  // ------------------------------------------------------------------ sheets
  function sheetEl() { return U.$('#sheet'); }
  /** open a bottom sheet (centered dialog on wide screens). o: {title, body, back, foot} */
  UI.sheet = function (o) {
    var s = sheetEl(), top = UI.sheetStack[UI.sheetStack.length - 1];
    if (top && o.replace) UI.sheetStack.pop();
    UI.sheetStack.push(o);
    paintSheet();
    s.classList.add('on'); U.$('#scrim').classList.add('on');
    return o;
  };
  function paintSheet() {
    var s = sheetEl(), o = UI.sheetStack[UI.sheetStack.length - 1];
    U.clear(s);
    if (!o) return;
    s.appendChild(h('div.grab'));
    s.appendChild(h('div.sh', o.back ? UI.rbtn('chevL', function () { o.back(); }, 'Back', 'sm') : UI.rbtn('x', function () { UI.closeSheet(true); }, 'Close', 'sm'),
      h('h3', o.title || ''), o.action || h('div', { style: { width: '36px' } })));
    var b = h('div.sb'); U.add(b, o.body); s.appendChild(b);
    if (o.foot) s.appendChild(h('div', { style: { padding: '0 18px 16px' } }, o.foot));
    o.el = b;
  }
  UI.sheetRepaint = function () { paintSheet(); };
  UI.closeSheet = function (all) {
    var o = UI.sheetStack.pop();
    if (all) { while (UI.sheetStack.length) UI.sheetStack.pop(); }
    if (o && o.onClose) o.onClose();
    if (UI.sheetStack.length) { paintSheet(); return; }
    sheetEl().classList.remove('on');
    if (!U.$('#drawer').classList.contains('on')) U.$('#scrim').classList.remove('on');
  };
  UI.confirm = function (msg, ok, danger) {
    return new Promise(function (res) {
      var done = false;
      function fin(v) { if (done) return; done = true; UI.closeSheet(); res(v); }
      UI.sheet({ title: 'Please confirm', body: h('div', h('p', { style: { margin: '6px 0 18px' } }, msg),
        h('div.row', { style: { justifyContent: 'flex-end' } }, UI.btn('Cancel', null, 'ghost', function () { fin(false); }), UI.btn(ok || 'OK', null, danger ? 'danger' : '', function () { fin(true); }))), onClose: function () { if (!done) { done = true; res(false); } } });
    });
  };
  UI.prompt = function (title, val, ph, multiline) {
    return new Promise(function (res) {
      var done = false, inp = multiline ? h('textarea.in', { placeholder: ph || '', style: { minHeight: '200px' } }) : h('input', { type: 'text', value: val || '', placeholder: ph || '' });
      if (multiline && val) inp.value = val;
      function fin(v) { if (done) return; done = true; UI.closeSheet(); res(v); }
      UI.sheet({ title: title, body: h('div', inp, h('div.row', { style: { justifyContent: 'flex-end', marginTop: '12px' } }, UI.btn('Cancel', null, 'ghost', function () { fin(null); }), UI.btn('OK', null, '', function () { fin(inp.value); }))), onClose: function () { if (!done) { done = true; res(null); } } });
      setTimeout(function () { inp.focus(); }, 300);
    });
  };

  // ------------------------------------------------------------------ drawer + sidebar (projects)
  function projectList(close) {
    var box = h('div.plist');
    St.projects.forEach(function (p) {
      box.appendChild(h('button.pitem' + (St.cur && St.cur.id === p.id ? '.on' : ''), { onclick: function () { St.open(p.id).then(function () { UI.go('build'); close && close(); }); } },
        h('span', { html: RC.i('code', 18), style: { color: 'var(--brand)' } }),
        h('div.grow', h('div.t1.ell', p.name), h('div.t2', U.ago(p.updated))),
        h('span.x', { html: RC.i('more', 18), onclick: function (e) { e.stopPropagation(); projectMenu(p); } })));
    });
    return box;
  }
  function projectMenu(p) {
    var body = h('div',
      UI.row({ icon: 'edit', title: 'Rename', onclick: function () { UI.closeSheet(); UI.prompt('Rename project', p.name).then(function (n) { if (n && n.trim()) { p.name = n.trim(); RC.db.put('projects', p); RC.bus.emit('project'); } }); } }),
      h('div.hr'),
      UI.row({ icon: 'trash', title: 'Delete project', sub: 'Files and chat are removed', onclick: function () { UI.closeSheet(); UI.confirm('Delete "' + p.name + '" with all its files and chat?', 'Delete', true).then(function (y) { if (y) St.remove(p.id); }); } }));
    UI.sheet({ title: p.name, body: body });
  }
  function newProject() {
    UI.prompt('New project', '', 'Project name').then(function (n) { if (n && n.trim()) St.create(n.trim()).then(function () { UI.go('build'); closeDrawer(); }); });
  }
  function navList(close) {
    var box = h('div');
    NAV.forEach(function (n) {
      box.appendChild(h('button.navitem' + (UI.cur() === n[0] ? '.on' : ''), { onclick: function () { UI.go(n[0]); close && close(); } }, h('span', { html: RC.i(n[1], 20) }), n[2]));
    });
    return box;
  }
  function paintProjects() {
    var root = U.$('#v-projects'); U.clear(root);
    var body = h('div.scroll.project-screen');
    body.appendChild(h('div.project-heading', h('div.eyebrow', 'YOUR WORKSPACE'), h('h2', 'Projects'), h('p', 'Keep chats, code and files organized in one place.')));
    var search = h('input', { type: 'text', placeholder: 'Search projects…', oninput: function () { draw(search.value); } });
    body.appendChild(h('div.project-search', h('span', { html: RC.i('search', 18) }), search));
    var list = h('div.project-cards'); body.appendChild(list);
    function draw(q) {
      U.clear(list); var ps = St.projects.filter(function (p) { return !q || p.name.toLowerCase().indexOf(q.toLowerCase()) >= 0; });
      if (!ps.length) list.appendChild(h('div.empty', 'No projects found. Create your first project to get started.'));
      ps.forEach(function (p) {
        list.appendChild(h('button.project-card', { onclick: function () { St.open(p.id).then(function () { UI.go('build'); }); } },
          h('div.project-card-icon', { html: RC.i('code', 22) }), h('div.grow', h('b', p.name), h('small', 'Updated ' + U.ago(p.updated))),
          h('span', { html: RC.i('chevR', 18) })));
      });
    }
    draw('');
    body.appendChild(h('div.project-create', UI.btn('New project', 'plus', '', newProject)));
    root.appendChild(body);
  }

  function paintSide() {
    var s = U.$('#side'), d = U.$('#drawer');
    [s, d].forEach(function (el, i) {
      U.clear(el);
      var close = i ? closeDrawer : null;
      el.appendChild(h('div.brand', { html: RC.logo(34) + '<span>ReCode</span><small>AI workspace</small>' }));
      el.appendChild(navList(close));
      el.appendChild(h('div.drawer-label', 'Recent chats'));
      var recent = h('div.plist.recent-list');
      St.msgs.slice(-8).reverse().forEach(function (m) {
        if (m.role !== 'user') return;
        recent.appendChild(h('button.pitem', { onclick: function () { UI.go('build'); close && close(); } },
          h('span', { html: RC.i('message', 16) }), h('div.grow.ell', U.clip(m.text, 46, ''))));
      });
      if (!recent.children.length) recent.appendChild(h('div.drawer-empty', 'Your recent conversations will appear here.'));
      el.appendChild(recent);
      el.appendChild(h('div.drawer-footer',
        h('button.profile-row', { onclick: function () { UI.go('set'); close && close(); } },
          h('span.profile-avatar', 'R'), h('span.grow', h('b', 'ReCode workspace'), h('small', 'Settings and preferences')), h('span', { html: RC.i('more', 18) }))));
    });
  }
  function openDrawer() { paintSide(); U.$('#drawer').classList.add('on'); U.$('#scrim').classList.add('on'); }
  function closeDrawer() { U.$('#drawer').classList.remove('on'); if (!sheetEl().classList.contains('on')) U.$('#scrim').classList.remove('on'); }
  U.$ && document.addEventListener('DOMContentLoaded', function () { });

  // ------------------------------------------------------------------ navigation
  UI.cur = function () {
    if (UI.wide) return (UI.view === 'build' && (UI.wsTab === 'files' || UI.wsTab === 'run') && UI.lastNav) || UI.view;
    return UI.view;
  };
  UI.go = function (name) {
    if (name === 'act') {
      if (UI.wide) { UI.view = 'build'; UI.wsTab = 'act'; UI.lastNav = null; }
      else { RC.ui.openActivity && RC.ui.openActivity(); return; }
    } else if (UI.wide && (name === 'files' || name === 'run')) { UI.view = 'build'; UI.wsTab = name; UI.lastNav = name; }
    else { UI.view = name; UI.lastNav = null; }
    UI.paint();
  };
  UI.paint = function () {
    var cur = UI.cur(), wide = UI.wide;
    ['build', 'projects', 'act', 'files', 'run', 'lib', 'set'].forEach(function (v) {
      var el = U.$('#v-' + v), on;
      if (wide) on = v === UI.view || (UI.view === 'build' && v === UI.wsTab);
      else on = v === UI.view;
      if (v === 'act' && !wide) on = false;
      el.classList.toggle('on', on);
    });
    var title = TITLES[UI.view];
    U.$('#title').textContent = UI.view === 'build' ? '' : title;
    var pill = U.clear(U.$('#pill'));
    NAV.forEach(function (n) {
      pill.appendChild(h('button' + (n[0] === cur ? '.on' : ''), { onclick: function () { UI.go(n[0]); }, 'aria-label': n[2], html: RC.i(n[1], 21) + '<span>' + n[2] + '</span>' }));
    });
    var ta = U.clear(U.$('#topact'));
    if (UI.view === 'build' && !wide) {
      ta.appendChild(h('button.model-trigger', { onclick: function () { UI.openModelPicker && UI.openModelPicker(); }, title: 'Choose model' }, h('span', { html: RC.i('cpu', 17) }), h('span', 'Model')));
      ta.appendChild(UI.rbtn('layers', function () { UI.go('act'); }, 'Activity', 'sm'));
    }
    var mods = UI.mods[UI.wide && UI.view === 'build' ? UI.wsTab : UI.view];
    mods && mods.show && mods.show();
    if (UI.view === 'build' && UI.mods.build) UI.mods.build.show();
    wsTabs();
    paintSide();
  };
  function wsTabs() {
    var box = U.clear(U.$('#wstabs'));
    [['act', 'layers', 'Activity'], ['files', 'folder', 'Files'], ['run', 'play', 'Preview']].forEach(function (t) {
      box.appendChild(h('button.chip' + (UI.wsTab === t[0] ? '.on' : ''), { onclick: function () { UI.wsTab = t[0]; UI.lastNav = t[0] === 'act' ? null : t[0]; UI.paint(); } }, h('span', { html: RC.i(t[1], 15) }), t[2]));
    });
  }
  UI.layout = function () {
    var wide = innerWidth >= 960;
    var changed = wide !== UI.wide;
    UI.wide = wide;
    document.body.classList.toggle('wide', wide);
    if (changed) {
      var host = wide ? U.$('#wsbody') : U.$('#views');
      ['act', 'files', 'run'].forEach(function (v) { host.appendChild(U.$('#v-' + v)); });
      if (wide && (UI.view === 'files' || UI.view === 'run')) { UI.wsTab = UI.view; UI.lastNav = UI.view; UI.view = 'build'; }
      if (!wide && UI.view === 'build' && UI.wsTab !== 'act') { UI.view = UI.wsTab; UI.lastNav = null; }
      if (UI.sheetStack.length && UI.sheetStack[0].isActivity && wide) UI.closeSheet(true);
      UI.paint();
    }
  };
  /** Android back button: close things first; returns true when it handled the press */
  RC.back = function () {
    if (UI.sheetStack.length) { var o = UI.sheetStack[UI.sheetStack.length - 1]; if (o.back) o.back(); else UI.closeSheet(); return true; }
    if (U.$('#drawer').classList.contains('on')) { closeDrawer(); return true; }
    var m = UI.mods[UI.wide && UI.view === 'build' ? UI.wsTab : UI.view];
    if (m && m.back && m.back()) return true;
    if (UI.view !== 'build') { UI.go('build'); return true; }
    return false;
  };
  UI.init = function () {
    U.$('#btnMenu').innerHTML = RC.i('menu', 22);
    U.$('#btnMenu').onclick = openDrawer;
    U.$('#scrim').onclick = function () { closeDrawer(); if (UI.sheetStack.length) UI.closeSheet(true); };
    addEventListener('resize', U.debounce(UI.layout, 80));
    RC.bus.on('project', function () { paintSide(); U.$('#title').textContent = UI.view === 'build' ? (St.cur ? St.cur.name : 'ReCode') : TITLES[UI.view]; });
    UI.mods.projects = { show: paintProjects };
    UI.layout(); UI.paint();
  };
})();
