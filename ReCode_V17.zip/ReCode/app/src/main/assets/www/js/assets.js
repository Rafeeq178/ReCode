/* ReCode v8 - assets: image/binary guard, deterministic SVG generator (logo, hero, icons), broken-reference repair,
   empty-section detector and the repeat-loop detector. A small on-phone model cannot write a PNG (it loops on garbage like
   "Xu9995777333Xu99957..."), so every image the project needs is an SVG written by code, never by the model. */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var U = RC.u || {};
  var IMG = /^(png|jpe?g|gif|webp|bmp|ico|avif|tiff?|heic)$/i;
  var BIN = /^(mp3|wav|ogg|m4a|mp4|webm|mov|avi|pdf|zip|rar|7z|apk|exe|woff2?|ttf|otf|eot|docx?|xlsx?|pptx?|psd|ai)$/i;
  function ext(p) { var m = /\.([A-Za-z0-9]+)$/.exec(String(p || '')); return m ? m[1].toLowerCase() : ''; }
  function base(p) { return String(p || '').split('/').pop(); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function hash(s) { var h = 2166136261; s = String(s); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }

  var PAL = {
    coffee: { a: '#6f4e37', b: '#d9a566', bg: '#fff7ee', ink: '#2b1d14', soft: '#f3e3d0' },
    restaurant: { a: '#b3261e', b: '#f2a900', bg: '#fff8f3', ink: '#2a1612', soft: '#fde8d8' },
    portfolio: { a: '#4f46e5', b: '#06b6d4', bg: '#f7f8ff', ink: '#14162b', soft: '#e6e8ff' },
    business: { a: '#0f4c81', b: '#1fb5a3', bg: '#f5f9fc', ink: '#10202e', soft: '#dcebf6' },
    shop: { a: '#d9467a', b: '#ff9f43', bg: '#fff7fa', ink: '#2b1420', soft: '#fde1ec' },
    saas: { a: '#6d28d9', b: '#22d3ee', bg: '#f8f7ff', ink: '#17112b', soft: '#e9e3ff' },
    blog: { a: '#0b7285', b: '#f59f00', bg: '#f6fbfc', ink: '#0f2227', soft: '#d9eef2' },
    generic: { a: '#2563eb', b: '#f97316', bg: '#f8fafc', ink: '#0f172a', soft: '#e2e8f0' }
  };
  function pal(type, name) {
    var p = PAL[type] || PAL.generic; return p;
  }
  function initials(name) {
    var w = String(name || 'R').replace(/[^\w\s&]/g, '').split(/\s+/).filter(Boolean);
    return ((w[0] || 'R').charAt(0) + (w.length > 1 ? w[1].charAt(0) : '')).toUpperCase();
  }
  var head = function (w, h, extra) { return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + w + ' ' + h + '" width="' + w + '" height="' + h + '"' + (extra || '') + ' role="img">'; };

  function mark(name, p, size) {
    var s = size || 96, id = 'g' + (hash(name) % 9973);
    return head(s, s) + '<title>' + esc(name) + '</title><defs><linearGradient id="' + id + '" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="' + p.a + '"/><stop offset="1" stop-color="' + p.b + '"/></linearGradient></defs>' +
      '<rect width="' + s + '" height="' + s + '" rx="' + Math.round(s * .26) + '" fill="url(#' + id + ')"/>' +
      '<text x="50%" y="54%" text-anchor="middle" dominant-baseline="middle" font-family="Georgia,\'Times New Roman\',serif" font-weight="700" font-size="' + Math.round(s * (initials(name).length > 1 ? .42 : .52)) + '" fill="#fff">' + esc(initials(name)) + '</text></svg>';
  }
  function logo(name, p) {
    var id = 'g' + (hash(name) % 9973), w = Math.max(220, 120 + String(name).length * 17);
    return head(w, 96) + '<title>' + esc(name) + '</title><defs><linearGradient id="' + id + '" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="' + p.a + '"/><stop offset="1" stop-color="' + p.b + '"/></linearGradient></defs>' +
      '<rect x="8" y="8" width="80" height="80" rx="22" fill="url(#' + id + ')"/>' +
      '<text x="48" y="52" text-anchor="middle" dominant-baseline="middle" font-family="Georgia,serif" font-weight="700" font-size="34" fill="#fff">' + esc(initials(name)) + '</text>' +
      '<text x="102" y="56" dominant-baseline="middle" font-family="Georgia,\'Times New Roman\',serif" font-weight="700" font-size="30" fill="' + p.ink + '">' + esc(name) + '</text></svg>';
  }
  function cup(p, x, y, k) {
    return '<g transform="translate(' + x + ',' + y + ') scale(' + k + ')"><path d="M20 60h160v70a60 60 0 0 1-60 60h-40a60 60 0 0 1-60-60z" fill="' + p.a + '"/>' +
      '<path d="M180 80h20a28 28 0 0 1 0 56h-24" fill="none" stroke="' + p.a + '" stroke-width="14" stroke-linecap="round"/>' +
      '<rect x="20" y="60" width="160" height="22" rx="11" fill="' + p.b + '"/>' +
      '<path d="M70 40c-14-14 14-22 0-38M110 40c-14-14 14-22 0-38M150 40c-14-14 14-22 0-38" fill="none" stroke="' + p.b + '" stroke-width="8" stroke-linecap="round" opacity=".7"/></g>';
  }
  function hero(name, p, type) {
    var s = hash(name), o = '', i;
    for (i = 0; i < 6; i++) o += '<circle cx="' + (80 + (s >> i) % 1040) + '" cy="' + (60 + (s >> (i + 3)) % 560) + '" r="' + (30 + (s >> (i + 5)) % 90) + '" fill="' + (i % 2 ? p.b : p.a) + '" opacity=".16"/>';
    var art = type === 'coffee' ? cup(p, 470, 190, 1.45) :
      '<g fill="none" stroke="' + p.a + '" stroke-width="14" stroke-linecap="round" opacity=".85"><path d="M300 470c90-160 170 60 280-60s150-170 330-60"/><path d="M280 540c110-130 200 40 300-40s170-130 340-40" stroke="' + p.b + '"/></g><circle cx="600" cy="270" r="92" fill="' + p.a + '"/><circle cx="640" cy="250" r="46" fill="' + p.b + '"/>';
    return head(1200, 700, ' preserveAspectRatio="xMidYMid slice"') + '<title>' + esc(name) + '</title><defs><linearGradient id="hg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="' + p.bg + '"/><stop offset="1" stop-color="' + p.soft + '"/></linearGradient></defs>' +
      '<rect width="1200" height="700" fill="url(#hg)"/>' + o + art + '</svg>';
  }
  function item(label, p) {
    var h = hash(label), c1 = h % 2 ? p.a : p.b, c2 = h % 2 ? p.b : p.a;
    return head(160, 160) + '<title>' + esc(label) + '</title><rect width="160" height="160" rx="28" fill="' + p.soft + '"/><circle cx="80" cy="80" r="46" fill="' + c1 + '"/><circle cx="96" cy="68" r="22" fill="' + c2 + '" opacity=".85"/>' +
      '<text x="80" y="140" text-anchor="middle" font-family="system-ui,sans-serif" font-size="13" fill="' + p.ink + '" opacity=".7">' + esc(String(label).slice(0, 16)) + '</text></svg>';
  }

  var A = RC.assets = {
    IMG: IMG, BIN: BIN, PAL: PAL, esc: esc, hash: hash, ext: ext,
    isImage: function (p) { return IMG.test(ext(p)); },
    isBinary: function (p) { return IMG.test(ext(p)) || BIN.test(ext(p)); },
    /** a path the model must not write as text -> '' (drop) or the same name as .svg */
    fixPath: function (p) {
      var e = ext(p);
      if (IMG.test(e)) return String(p).replace(/\.[A-Za-z0-9]+$/, '.svg');
      if (BIN.test(e)) return '';
      return p;
    },
    palette: pal, mark: mark, logo: logo, hero: hero, item: item, cup: cup,
    /** SVG text for an asset path (logo / favicon / hero / generic picture) */
    make: function (path, ctx) {
      ctx = ctx || {}; var name = ctx.name || 'Brand', type = ctx.type || 'generic', p = pal(type, name), b = base(path).toLowerCase();
      if (/logo|brand|wordmark/.test(b)) return logo(name, p);
      if (/fav|icon|mark|avatar/.test(b)) return mark(name, p);
      if (/hero|banner|cover|bg|background|header/.test(b)) return hero(name, p, type);
      return item(b.replace(/\.\w+$/, '').replace(/[-_]/g, ' '), p);
    },
    isGenerated: function (p) { return ext(p) === 'svg' && /(^|\/)(assets?|images?|img)\//i.test(p) || /(^|[\/_-])(logo|favicon|hero|banner)\.svg$/i.test(p); },

    /** repeat loop detector: true when the end of the text repeats the same short pattern for 160+ characters */
    degenerate: function (text) {
      text = String(text || ''); if (text.length < 200) return false;
      var tail = text.slice(-420), n = tail.length;
      for (var p = 1; p <= 80; p++) {
        var L = Math.max(160, p * 5); if (L > n) break;
        var ok = true;
        for (var i = n - L + p; i < n; i++) if (tail.charCodeAt(i) !== tail.charCodeAt(i - p)) { ok = false; break; }
        if (ok) { if (/^[\s\-=_*#~.+|]*$/.test(tail.slice(n - L))) continue; return true; }
      }
      return false;
    },
    /** cut the repeating tail away */
    trimLoop: function (text) {
      text = String(text || ''); var n = text.length, cut = n;
      for (var p = 1; p <= 80; p++) {
        var i = n - 1; while (i >= p && text.charCodeAt(i) === text.charCodeAt(i - p)) i--;
        if (n - i > Math.max(150, p * 4)) cut = Math.min(cut, i + p + 1 - p);
      }
      return text.slice(0, Math.max(0, cut));
    },

    /** headings without content (the "Menu" section that shows nothing) -> [{file,msg}] */
    emptySections: function (file, html) {
      var out = [], re = /<(section|div|article)\b([^>]*)>([\s\S]*?)<\/\1>/gi, m;
      while ((m = re.exec(html))) {
        var inner = m[3];
        if (!/<h[1-4]\b/i.test(inner) || /<(section|div|article)\b/i.test(inner)) continue; // only leaf blocks
        if (/<(img|svg|canvas|form|input|ul|ol|table|iframe|video|button|a)\b/i.test(inner)) continue;
        var txt = inner.replace(/<h[1-4][\s\S]*?<\/h[1-4]>/gi, '').replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
        if (txt.length < 25) { var h = /<h[1-4][^>]*>([\s\S]*?)<\/h[1-4]>/i.exec(inner); out.push({ file: file, msg: 'The section "' + U.clip((h ? h[1].replace(/<[^>]+>/g, '') : ''), 40, '') + '" has a heading but no content. Add real content (cards, text, list) under it.' }); }
      }
      return out.slice(0, 4);
    },

    /** local images / css urls that point to missing files -> create an SVG for them and rewrite the reference.
        files: {path: text}. Returns {files:{path:newText}, fixes:[text]} (only changed / new files) */
    repair: function (files, ctx) {
      var out = {}, fixes = [], names = Object.keys(files);
      function resolve(from, ref) {
        ref = String(ref).split('#')[0].split('?')[0]; if (!ref || /^(https?:|data:|\/\/|mailto:|tel:|#|javascript:)/i.test(ref)) return '';
        var dir = from.indexOf('/') >= 0 ? from.replace(/[^\/]*$/, '') : '', parts = (ref.charAt(0) === '/' ? ref.slice(1) : dir + ref).split('/'), r = [];
        parts.forEach(function (x) { if (x === '..') r.pop(); else if (x && x !== '.') r.push(x); });
        return r.join('/');
      }
      names.forEach(function (f) {
        if (!/\.(html?|css)$/i.test(f)) return;
        var txt = files[f], ch = false;
        txt = txt.replace(/(<img\b[^>]*?\bsrc\s*=\s*["'])([^"']+)(["'])|(<link\b[^>]*?rel\s*=\s*["'][^"']*icon[^"']*["'][^>]*?href\s*=\s*["'])([^"']+)(["'])|(url\(\s*["']?)([^"')]+)(["']?\s*\))/gi, function (all, a1, r1, z1, a2, r2, z2, a3, r3, z3) {
          var ref = r1 || r2 || r3, pre = a1 || a2 || a3, post = z1 || z2 || z3, p = resolve(f, ref);
          if (!p || files[p] !== undefined || out[p] !== undefined) return all;
          var e = ext(p);
          if (!IMG.test(e) && e !== 'svg') return all;
          var np = IMG.test(e) ? p.replace(/\.[A-Za-z0-9]+$/, '.svg') : p;
          if (files[np] === undefined && out[np] === undefined) { out[np] = A.make(np, ctx); fixes.push('Created ' + np + ' (SVG) because ' + ref + ' was missing'); }
          ch = true;
          var rel = f.indexOf('/') >= 0 ? np.split('/').slice(f.replace(/[^\/]*$/, '').split('/').length - 1).join('/') : np;
          return pre + rel + post;
        });
        if (ch) out[f] = txt;
      });
      return { files: out, fixes: fixes };
    }
  };
})();
