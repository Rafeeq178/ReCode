/* ReCode - Phase 2: permission manager. Every tool call is judged here before it runs.
   Levels: allow | ask | deny. Priority when several rules apply: DENY > ASK > ALLOW (the strictest wins).
   Rule sources (all of them are evaluated, then the strictest level wins):
     1. tool rule: project override (St.cur.perms) else global rule (settings.perms.global) else the built-in default
     2. file rules (settings.perms.files and project files): glob + level + optional operations
     3. dangerous command detection (run_command)
     4. delete confirmation and overwrite confirmation
   Modes: plan = read-only (hard DENY for everything that is not a read), ask = ASK opens a dialog,
          auto = ASK is approved automatically. DENY is never bypassed in any mode. Deletions always ask, even in auto. */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var U = RC.u;

  var RANK = { allow: 0, ask: 1, deny: 2 };
  var DEFAULTS = {
    read_file: 'allow', list_files: 'allow', search_files: 'allow', search_text: 'allow', get_file_info: 'allow', check_syntax: 'allow',
    write_file: 'ask', edit_file: 'ask', create_directory: 'ask', rename_file: 'ask', move_file: 'ask',
    delete_file: 'deny', run_command: 'ask', run_tests: 'allow', delegate: 'allow', search_knowledge: 'allow', todo: 'allow', remember: 'allow', web_search: 'ask', web_read: 'ask'
  };
  // each pattern is a reason string returned to the user and the model
  var DANGER = [
    [/\brm\s+(-[a-z]*[rf][a-z]*\s+)+/i, 'recursive delete'], [/\bsudo\b|\bsu\s+-?\s*\w*/i, 'privilege escalation'],
    [/\b(curl|wget)\b[^|;]*\|\s*(ba|z)?sh\b/i, 'download and execute'], [/\bchmod\s+(-R\s+)?[0-7]*7[0-7]*\b|\bchown\b/i, 'permission change'],
    [/\b(mkfs|fdisk|dd)\b\s/i, 'disk operation'], [/\b(shutdown|reboot|halt|poweroff)\b/i, 'system power'],
    [/:\s*\(\)\s*\{.*\};\s*:/, 'fork bomb'], [/>\s*\/(dev|etc|sys|proc)\b/i, 'writes to system path'],
    [/\b(format|del|erase)\s+[a-z]:/i, 'drive wipe'], [/\bgit\s+(push\s+(-f|--force)|reset\s+--hard|clean\s+-[a-z]*f)/i, 'destructive git'],
    [/(^|[\s;&|])(\.\.[\/\\]|\/etc\/|\/data\/|~\/|[a-z]:[\\\/])/i, 'path outside the project'], [/`[^`]*`|\$\([^)]*\)|&&|\|\||;\s*\w/, 'command chaining'],
    [/\b(nc|ncat|ssh|scp|telnet|ftp)\b/i, 'network access']
  ];

  function S() { return RC.settings; }
  function P() { var s = S(); s.perms = s.perms || {}; return s.perms; }
  function projRules() { return (RC.store && RC.store.cur && RC.store.cur.perms) || {}; }
  function worse(a, b) { return RANK[b] > RANK[a] ? b : a; }
  function globRe(g) {
    var s = String(g).replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*\*/g, '\u0000').replace(/\*/g, '[^/]*').replace(/\?/g, '[^/]').replace(/\u0000/g, '.*');
    return new RegExp('^' + s + '$', 'i');
  }
  function targets(call) {
    var a = call.args || {};
    return [a.path, a.from, a.to, a.folder].filter(Boolean).map(function (p) { try { return U.normPath(String(p)); } catch (e) { return ''; } }).filter(Boolean);
  }
  function histLoad() { try { return JSON.parse(localStorage.getItem('rc.permhist') || '[]'); } catch (e) { return []; } }
  var hist = histLoad();

  var M = RC.perms = {
    LEVELS: ['allow', 'ask', 'deny'], DEFAULTS: DEFAULTS,
    /** UI hook: requester(req, signal) -> Promise<'once'|'always'|'deny'>. Set by permui.js. Without it every ASK is denied. */
    requester: null,

    isDangerous: function (cmd) {
      cmd = String(cmd || '');
      for (var i = 0; i < DANGER.length; i++) if (DANGER[i][0].test(cmd)) return DANGER[i][1];
      return '';
    },
    mode: function () { var m = S().permMode; return m === 'plan' || m === 'auto' ? m : 'ask'; },
    /** configured base level of a tool (project override > global > default) and where it came from */
    base: function (tool) {
      var pr = projRules()[tool], gl = (P().global || {})[tool];
      if (pr) return { level: pr, src: 'project' };
      if (gl) return { level: gl, src: 'global' };
      return { level: DEFAULTS[tool] || 'ask', src: 'default' };
    },
    setRule: function (tool, level, scope) {
      if (M.LEVELS.indexOf(level) < 0) throw new Error('Bad level ' + level);
      if (scope === 'project' && RC.store.cur) {
        var c = RC.store.cur; c.perms = c.perms || {};
        if (level === 'default') delete c.perms[tool]; else c.perms[tool] = level;
        RC.store.touch();
      } else {
        var p = P(); p.global = p.global || {};
        if (level === 'default') delete p.global[tool]; else p.global[tool] = level;
        RC.saveSettings();
      }
    },
    addFileRule: function (glob, level, ops, scope) {
      var r = { glob: U.normPath(glob), level: level, ops: ops && ops.length ? ops : null };
      if (scope === 'project' && RC.store.cur) { var c = RC.store.cur; c.fileRules = (c.fileRules || []).concat([r]); RC.store.touch(); }
      else { var p = P(); p.files = (p.files || []).concat([r]); RC.saveSettings(); }
    },
    removeFileRule: function (i, scope) {
      if (scope === 'project' && RC.store.cur) { RC.store.cur.fileRules.splice(i, 1); RC.store.touch(); }
      else { P().files.splice(i, 1); RC.saveSettings(); }
    },
    fileRules: function () { return (P().files || []).map(function (r) { return Object.assign({ scope: 'global' }, r); }).concat(((RC.store && RC.store.cur && RC.store.cur.fileRules) || []).map(function (r) { return Object.assign({ scope: 'project' }, r); })); },

    /**
     * Evaluate a call -> {level, reasons:[], sticky}. sticky = the ask cannot be auto-approved (deletes).
     * mode: plan | ask | auto (defaults to the current mode)
     */
    check: function (call, mode) {
      var t = RC.tools.registry[call.name], reasons = [], sticky = false;
      mode = mode || M.mode();
      if (!t) return { level: 'deny', reasons: ['unknown tool'], sticky: false };
      if (mode === 'plan' && t.perm !== 'read') return { level: 'deny', reasons: ['plan mode is read-only'], sticky: false, plan: true };
      var b = M.base(call.name), level = b.level;
      if (level !== 'allow') reasons.push(call.name + ' is ' + level.toUpperCase() + ' (' + b.src + ' rule)');
      var tg = targets(call), rules = M.fileRules();
      rules.forEach(function (r) {
        if (r.ops && r.ops.indexOf(t.perm) < 0) return;
        var re = globRe(r.glob);
        if (tg.some(function (x) { return re.test(x); })) { level = worse(level, r.level); if (r.level !== 'allow') reasons.push('file rule ' + r.glob + ' = ' + r.level.toUpperCase()); }
      });
      if (call.name === 'run_command') {
        var d = M.isDangerous((call.args || {}).command || (call.args || {}).cmd);
        if (d) { var dl = P().dangerous === 'ask' ? 'ask' : 'deny'; level = worse(level, dl); reasons.push('dangerous command: ' + d); }
      }
      if (t.perm === 'delete' && P().confirmDelete !== false && level !== 'deny') { level = worse(level, 'ask'); sticky = true; reasons.push('deleting needs confirmation'); }
      if (call.name === 'write_file' && P().confirmOverwrite !== false && level !== 'deny' && RC.store.files[tg[0]] !== undefined) { level = worse(level, 'ask'); reasons.push('overwrites an existing file'); }
      return { level: level, reasons: reasons, sticky: sticky };
    },

    record: function (call, level, decision, why) {
      hist.push({ t: Date.now(), tool: call.name, target: targets(call).join(', ') || U.clip(String((call.args || {}).command || ''), 60, '…'), level: level, decision: decision, why: why || '', mode: M.mode() });
      while (hist.length > 200) hist.shift();
      try { localStorage.setItem('rc.permhist', JSON.stringify(hist)); } catch (e) { }
      RC.bus && RC.bus.emit('perm');
    },
    history: function () { return hist.slice().reverse(); },
    clearHistory: function () { hist = []; try { localStorage.removeItem('rc.permhist'); } catch (e) { } RC.bus && RC.bus.emit('perm'); },

    /** the gate used by RC.tools.exec: -> Promise<{ok, why}> */
    gate: async function (call, ctx) {
      ctx = ctx || {};
      var mode = ctx.mode || M.mode(), r = M.check(call, mode), t = RC.tools.registry[call.name];
      if (r.level === 'deny') {
        M.record(call, 'deny', 'denied', r.reasons.join('; '));
        return { ok: false, why: (r.plan ? 'Plan mode is read-only: ' + call.name + ' cannot run until the plan is approved.' : 'DENIED by permissions (' + r.reasons.join('; ') + ').') };
      }
      if (r.level === 'allow') { M.record(call, 'allow', 'allowed', ''); return { ok: true }; }
      // ask
      if (mode === 'auto' && !r.sticky) { M.record(call, 'ask', 'auto-approved', r.reasons.join('; ')); return { ok: true }; }
      if (!M.requester) { M.record(call, 'ask', 'denied', 'no approval dialog available'); return { ok: false, why: 'Needs approval but no approval dialog is available.' }; }
      if (ctx.ts) ctx.ts.note = 'waiting for your approval';
      var ans = 'deny';
      try { ans = await M.requester({ call: call, tool: t, reasons: r.reasons, targets: targets(call), sticky: r.sticky, preview: M.preview(call) }, ctx.signal); }
      catch (e) { if (e && e.name === 'AbortError') throw e; }
      if (ans === 'always' && !r.sticky && RC.store.cur && M.base(call.name).level === 'ask' && !r.reasons.some(function (x) { return /file rule|dangerous/.test(x); })) {
        M.setRule(call.name, 'allow', 'project');
        M.record(call, 'ask', 'user-allowed-always', 'project rule added');
        return { ok: true };
      }
      if (ans === 'once' || ans === 'always') { M.record(call, 'ask', 'user-allowed', r.reasons.join('; ')); return { ok: true }; }
      M.record(call, 'ask', 'user-denied', r.reasons.join('; '));
      return { ok: false, why: 'The user REJECTED this action. Do not retry it; explain what you wanted to do or choose another approach.' };
    },
    /** short human readable preview of what the call would do */
    preview: function (call) {
      var a = call.args || {}, f = RC.store.files;
      if (call.name === 'write_file') { var p = U.normPath(a.path || ''), old = f[p]; return (old === undefined ? 'New file ' : 'Replace file ') + p + ' (' + U.bytes(String(a.content || '').length) + (old !== undefined ? ', was ' + U.bytes(old.length) : '') + ')\n\n' + U.clip(String(a.content || ''), 700, '\n…'); }
      if (call.name === 'edit_file') return 'Edit ' + a.path + '\n\n- ' + U.clip(String(a.old_text == null ? '' : a.old_text), 300, '…').split('\n').join('\n- ') + '\n+ ' + U.clip(String(a.new_text == null ? '' : a.new_text), 300, '…').split('\n').join('\n+ ');
      if (call.name === 'delete_file') return 'Delete ' + a.path;
      if (call.name === 'run_command') return 'Command: ' + a.command;
      return call.name + ' ' + targets(call).join(' → ');
    }
  };

  RC.tools.gate = M.gate;
})();
