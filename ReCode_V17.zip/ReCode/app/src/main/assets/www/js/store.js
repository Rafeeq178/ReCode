/* ReCode - settings (localStorage) + projects / files / chat / knowledge (IndexedDB, in-memory fallback). */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var U = RC.u;

  // ------------------------------------------------------------------ tiny event bus
  var subs = {};
  RC.bus = {
    on: function (e, fn) { (subs[e] = subs[e] || []).push(fn); return function () { subs[e] = subs[e].filter(function (f) { return f !== fn; }); }; },
    emit: function (e, a, b) { (subs[e] || []).slice().forEach(function (f) { try { f(a, b); } catch (x) { console.error(x); } }); }
  };

  // ------------------------------------------------------------------ settings
  RC.defaults = {
    theme: 'light',
    provider: 'local',            // local (GGUF on the phone) | api (online, OpenAI compatible)
    model: '',
    api: { preset: 'openai', base: 'https://api.openai.com/v1', key: '', model: 'gpt-4o-mini', temp: 0.3 },
    hfToken: '',
    maxFile: 1800,                // answer length (tokens) for one code file
    maxPlan: 450,
    maxChat: 900,
    ctxChars: 7000,               // how much text one agent may be given (the local model has a small context)
    fixLoops: 2,
    maxIter: 20,                  // agent mode: maximum model turns per request
    autoCompact: true,            // agent mode: fold old steps into a short summary when the transcript gets long (Phase 4)
    compactKeep: 6,               // how many of the newest transcript entries stay word for word
    useNotes: true,               // agent mode: read RECODE.md (project notes) at the start of every run
    notesChars: 1000,             // how much of RECODE.md goes into the prompt
    useTemplates: true,           // calculator / snake / todo requests start from a tested template (v6)
    autoAgent: false,             // Auto mode uses the agent loop for build requests (off = classic pipeline)
    permMode: 'ask',              // plan (read-only) | ask (dialog for protected actions) | auto (approve ASK automatically)
    perms: { global: {}, files: [], confirmDelete: true, confirmOverwrite: true, dangerous: 'deny' },
    hooks: { format: true, syntax: true, overwrite: true, backup: true, structure: true, errors: true, autoTest: true, maxFiles: 60, custom: [] },
    mode: 'auto',                 // auto | build | chat | research
    useSkills: true,              // v8: built-in skill playbooks are added to the prompts
    useSiteKit: true,             // v8: websites are built by the tested site kit (model writes only the text)
    siteCopy: true,               // v8: ask the model for the website text (off = tested default text)
    skills: [], skillsOff: [],
    autoResearch: true,           // the planner may ask for an internet research step
    webChat: false,
    useRag: true,
    ragFiles: true,
    ragK: 3,
    architect: true,
    review: true,
    autoPreview: true,
    netPreview: false,            // let the preview page use the internet
    keepAwake: true,
    agents: {}                    // per-agent overrides: {planner:{on, max, prompt}}
  };
  function merge(base, over) {
    var o = Array.isArray(base) ? base.slice() : Object.assign({}, base);
    Object.keys(over || {}).forEach(function (k) {
      if (over[k] && typeof over[k] === 'object' && !Array.isArray(over[k]) && base[k] && typeof base[k] === 'object') o[k] = merge(base[k], over[k]);
      else o[k] = over[k];
    });
    return o;
  }
  var S = RC.settings = merge(RC.defaults, {});
  try { S = RC.settings = merge(RC.defaults, JSON.parse(localStorage.getItem('rc.settings') || '{}')); } catch (e) { }
  // v6 one-time migration: settings saved by older versions keep their old defaults otherwise
  try {
    if ((+S.v || 0) < 6) {
      if (+S.maxIter === 12) S.maxIter = 20;
      if (S.hooks && S.hooks.autoTest === false) S.hooks.autoTest = true;
      S.v = 6;
      localStorage.setItem('rc.settings', JSON.stringify(S));
    }
  } catch (e) { }
  RC.saveSettings = function () {
    try { localStorage.setItem('rc.settings', JSON.stringify(RC.settings)); } catch (e) { }
    RC.bus.emit('settings');
  };
  RC.set = function (k, v) { RC.settings[k] = v; RC.saveSettings(); };
  RC.agentCfg = function (id) {
    var a = (RC.settings.agents || {})[id] || {};
    var d = (RC.agents && RC.agents.def[id]) || {};
    return {
      on: a.on === undefined ? (d.on !== false) : a.on,
      max: a.max || d.max || 0,
      prompt: (a.prompt && a.prompt.trim()) ? a.prompt : (d.system || '')
    };
  };

  // ------------------------------------------------------------------ database
  var DB = null, mem = {};
  var STORES = { projects: 'id', files: 'key', msgs: 'id', kb: 'id', meta: 'id' };
  function open() {
    return new Promise(function (res) {
      var req;
      try { req = indexedDB.open('recode', 1); } catch (e) { return res(null); }
      req.onupgradeneeded = function () {
        var d = req.result;
        Object.keys(STORES).forEach(function (s) {
          if (!d.objectStoreNames.contains(s)) {
            var st = d.createObjectStore(s, { keyPath: STORES[s] });
            if (s === 'files' || s === 'msgs') st.createIndex('pid', 'pid');
          }
        });
      };
      req.onsuccess = function () { res(req.result); };
      req.onerror = function () { res(null); };
      req.onblocked = function () { res(null); };
    });
  }
  function tx(store, mode, fn) {
    return new Promise(function (res, rej) {
      if (!DB) {
        mem[store] = mem[store] || {};
        try { return res(fn({
          put: function (o) { mem[store][o[STORES[store]]] = o; },
          get: function (k) { return mem[store][k]; },
          del: function (k) { delete mem[store][k]; },
          all: function () { return Object.keys(mem[store]).map(function (k) { return mem[store][k]; }); }
        }, true)); } catch (e) { return rej(e); }
      }
      var t = DB.transaction(store, mode), st = t.objectStore(store), out;
      try { out = fn(st, false); } catch (e) { return rej(e); }
      t.oncomplete = function () { res(out && out.__req ? out.__req.result : out); };
      t.onerror = t.onabort = function () { rej(t.error); };
    });
  }
  function reqResult(st, req) { return new Promise(function (res, rej) { req.onsuccess = function () { res(req.result); }; req.onerror = function () { rej(req.error); }; }); }
  var D = RC.db = {
    put: function (s, o) { return tx(s, 'readwrite', function (st, m) { if (m) st.put(o); else st.put(o); }); },
    del: function (s, k) { return tx(s, 'readwrite', function (st, m) { if (m) st.del(k); else st.delete(k); }); },
    get: function (s, k) {
      if (!DB) return Promise.resolve((mem[s] || {})[k]);
      return reqResult(null, DB.transaction(s).objectStore(s).get(k));
    },
    all: function (s) {
      if (!DB) return Promise.resolve(Object.keys(mem[s] || {}).map(function (k) { return mem[s][k]; }));
      return reqResult(null, DB.transaction(s).objectStore(s).getAll());
    },
    byPid: function (s, pid) {
      if (!DB) return Promise.resolve(Object.keys(mem[s] || {}).map(function (k) { return mem[s][k]; }).filter(function (o) { return o.pid === pid; }));
      return reqResult(null, DB.transaction(s).objectStore(s).index('pid').getAll(pid));
    }
  };

  // ------------------------------------------------------------------ projects, files, messages, knowledge
  var St = RC.store = {
    projects: [], cur: null, files: {}, msgs: [], kb: [],

    init: function () {
      return open().then(function (d) { DB = d; return D.all('projects'); }).then(function (ps) {
        St.projects = ps.sort(function (a, b) { return b.updated - a.updated; });
        return D.all('kb');
      }).then(function (kb) {
        St.kb = kb.sort(function (a, b) { return a.added - b.added; });
        var last = null; try { last = localStorage.getItem('rc.last'); } catch (e) { }
        var p = St.projects.filter(function (x) { return x.id === last; })[0] || St.projects[0];
        return p ? St.open(p.id) : St.create('My first project');
      });
    },
    create: function (name) {
      var p = { id: U.uid('p'), name: name || 'New project', created: Date.now(), updated: Date.now(), ls: {} };
      St.projects.unshift(p);
      return D.put('projects', p).then(function () { return St.open(p.id); });
    },
    open: function (id) {
      var p = St.projects.filter(function (x) { return x.id === id; })[0];
      if (!p) return Promise.resolve();
      return Promise.all([D.byPid('files', id), D.byPid('msgs', id)]).then(function (r) {
        St.cur = p; St.files = {};
        r[0].forEach(function (f) { St.files[f.path] = f.content; });
        St.msgs = r[1].sort(function (a, b) { return a.t - b.t; });
        try { localStorage.setItem('rc.last', id); } catch (e) { }
        RC.bus.emit('project');
      });
    },
    touch: function () { if (St.cur) { St.cur.updated = Date.now(); D.put('projects', St.cur); } },
    rename: function (name) { St.cur.name = name; St.touch(); RC.bus.emit('project'); },
    remove: function (id) {
      return Promise.all([D.byPid('files', id), D.byPid('msgs', id)]).then(function (r) {
        return Promise.all(r[0].map(function (f) { return D.del('files', f.key); }).concat(r[1].map(function (m) { return D.del('msgs', m.id); }), [D.del('projects', id)]));
      }).then(function () {
        St.projects = St.projects.filter(function (p) { return p.id !== id; });
        if (St.cur && St.cur.id === id) return St.projects[0] ? St.open(St.projects[0].id) : St.create('My first project');
        RC.bus.emit('project');
      });
    },
    fileList: function () {
      return Object.keys(St.files).sort(function (a, b) {
        var da = a.indexOf('/') >= 0, db = b.indexOf('/') >= 0;
        if (da !== db) return da ? 1 : -1;
        return a.localeCompare(b);
      });
    },
    putFile: function (path, content) {
      path = U.normPath(path);
      St.files[path] = content;
      St.touch();
      RC.bus.emit('files', path);
      return D.put('files', { key: St.cur.id + '|' + path, pid: St.cur.id, path: path, content: content, updated: Date.now() });
    },
    delFile: function (path) {
      delete St.files[path]; St.touch();
      RC.bus.emit('files', path);
      return D.del('files', St.cur.id + '|' + path);
    },
    renameFile: function (a, b) {
      b = U.normPath(b);
      if (!U.validPath(b) || St.files[b] !== undefined) return Promise.reject(new Error('Bad or existing name'));
      var c = St.files[a];
      return St.delFile(a).then(function () { return St.putFile(b, c); });
    },
    addMsg: function (m) {
      m.id = m.id || U.uid('m'); m.t = m.t || Date.now(); m.pid = St.cur.id;
      St.msgs.push(m); St.touch();
      return D.put('msgs', m);
    },
    saveMsg: function (m) { return D.put('msgs', m); },
    clearMsgs: function () {
      var ids = St.msgs.map(function (m) { return m.id; }); St.msgs = [];
      return Promise.all(ids.map(function (i) { return D.del('msgs', i); }));
    },
    // knowledge base: pid '*' = every project, otherwise only that project
    addKb: function (doc) {
      doc.id = doc.id || U.uid('k'); doc.added = Date.now();
      St.kb.push(doc);
      return D.put('kb', doc).then(function () { RC.bus.emit('kb'); });
    },
    delKb: function (id) {
      St.kb = St.kb.filter(function (k) { return k.id !== id; });
      return D.del('kb', id).then(function () { RC.bus.emit('kb'); });
    },
    kbFor: function () { return St.kb.filter(function (k) { return k.pid === '*' || (St.cur && k.pid === St.cur.id); }); },
    // localStorage shim of the preview page (persisted per project)
    getLS: function () { return (St.cur && St.cur.ls) || {}; },
    setLS: function (d) { if (St.cur) { St.cur.ls = d; D.put('projects', St.cur); } }
  };
})();
