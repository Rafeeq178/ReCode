/* ReCode V13: real native adapters plus coordinated specialist workflows. */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  RC.engine = RC.engine || {};
  RC.engine.version = '13.0.0';
  RC.engine.workflow = ['environment_check','reconnaissance','plan','parallel_specialist_review','implement','native_tooling_when_authorized','security_review','verify','build_if_toolchain_available','report'];
  RC.engine.capabilities = Object.assign(RC.engine.capabilities || {}, {
    nativeShell: true, liveMcpTransport: true, mcpJsonRpcClient: true, shizuku: true, shizukuPermissionBridge: true,
    realGitOperations: true, liveBrowserAutomation: true, browserWebViewAutomation: true, nativeAndroidBuild: true, androidGradleBuildRunner: true,
    advancedMultiAgentOrchestration: true, nativeWorkspaceSync: true,
    shellScope: 'app-private-workspace', mcpTransport: 'HTTP JSON-RPC with initialize handshake'
  });
  RC.engine.nativeStatus = function () {
    return {
      androidApp: !!(RC.native && RC.native.has),
      workspace: RC.native && RC.native.has ? RC.native.workspace() : null,
      shizuku: RC.native && RC.native.has ? RC.native.shizukuStatus() : 'Android app required',
      note: 'Shell and build run in ReCode private storage. Shizuku privilege is never assumed.'
    };
  };
  /* Read-only reviewers run concurrently; implementation and verification agents run serially
     to prevent concurrent edits to the same project files. */
  RC.engine.runTeam = async function (task, run) {
    if (!RC.subagents || !run) throw new Error('Multi-agent runtime context is unavailable.');
    var reports = [];
    var inspect = await Promise.all(['planner','explorer','architect','security'].map(function (name) {
      return RC.subagents.run(name, 'Analyze this task without editing files: ' + task, { run: run, goal: task, depth: 0 });
    }));
    inspect.forEach(function (r) { reports.push(r); });
    var context = inspect.map(function (r) { return '[' + r.name + '] ' + r.text; }).join('\n\n');
    var coder = await RC.subagents.run('coder', 'Implement this task with the smallest compatible changes. Use this inspection context:\n' + context + '\n\nTASK: ' + task, { run: run, goal: task, depth: 0 });
    reports.push(coder);
    if (coder.ok) {
      var tester = await RC.subagents.run('tester', 'Verify the implementation for this task. Add/update focused tests if needed, run available tests, and report exact results.\nTASK: ' + task, { run: run, goal: task, depth: 0 });
      reports.push(tester);
      var reviewer = await RC.subagents.run('reviewer', 'Review the completed implementation and test results. Do not edit files. Identify remaining risks.\nTASK: ' + task, { run: run, goal: task, depth: 0 });
      reports.push(reviewer);
    }
    return reports.map(function (r) { return '## ' + r.name + ' (' + (r.ok ? 'ok' : 'failed') + ')\n' + r.text; }).join('\n\n');
  };
  RC.engine.capabilityReport = function () {
    var native = RC.engine.nativeStatus();
    return { version: RC.engine.version, capabilities: RC.engine.capabilities, native: native,
      boundaries: ['Android SDK build requires a usable JDK, Gradle wrapper and Android SDK in the app-private workspace.',
        'Shizuku requires the separate Shizuku service and explicit user permission.',
        'MCP endpoints must be configured by the user; remote tools are not trusted automatically.',
        'Browser automation is an isolated WebView and is limited to HTTPS pages.'] };
  };
})();
