/* ReCode v8 - SKILLS. A skill is a short Markdown playbook (frontmatter + rules) that is injected into the prompt of the agents
   whose job matches the request (like Claude skills). Small local models get compact rules; online models get the same.
   Built-in skills below; you can add your own (RC.skills.importText) or learn one from a web page (RC.skills.fromUrl, needs internet).
   Settings: useSkills (default on), skills (array of custom skills), skillsOff (names switched off). */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var U = RC.u;

  var B = [
    { name: 'web-design', roles: 'planner,architect,coder,agent', triggers: 'website,web site,landing,page,portfolio,homepage,blog,shop,store,restaurant,cafe,coffee,business,html,css,ui,design,site,saas,menu,contact,bana,banao,bnao,sheet',
      body: 'Every site has: header with logo + nav (hamburger on phones), hero (headline, one sentence, call-to-action), 3 feature cards, the main content section WITH REAL ITEMS (menu/services/products with name, short text, price), about, testimonials, contact form, footer. ' +
        'No empty sections: a heading always has content under it. Use realistic copy for the business, never "Lorem ipsum". One font stack (system-ui), 2 brand colors + neutrals, 8px spacing scale, rounded cards, soft shadows, sticky header, smooth scroll. Text contrast at least 4.5:1.' },
    { name: 'images-and-logos', roles: 'planner,architect,coder,agent', triggers: 'logo,image,images,icon,favicon,hero,banner,png,jpg,jpeg,photo,picture,illustration,background,svg,assets',
      body: 'You can NOT write PNG/JPG/ICO files (binary). Never name them. Every picture is an inline <svg> or a file ending .svg (assets/logo.svg, assets/hero.svg) written as text: shapes, gradients, text. ' +
        'Logo = rounded square with a gradient + the brand initials + name in <text>. Hero = gradient background + simple shapes. Always add alt text. ReCode creates missing logo/hero/favicon SVG files itself.' },
    { name: 'responsive-mobile', roles: 'architect,coder,agent', triggers: 'responsive,mobile,phone,layout,grid,flex,navbar,menu,css,design,website,page,landing,app',
      body: 'Mobile first. <meta name="viewport" content="width=device-width, initial-scale=1">. box-sizing:border-box. Use rem/%, clamp() for font sizes, CSS grid with repeat(auto-fit,minmax(220px,1fr)). Images max-width:100%. ' +
        'Touch targets at least 44px. Nav collapses to a button below 720px. No horizontal scroll. Add prefers-color-scheme dark and prefers-reduced-motion rules.' },
    { name: 'forms-validation', roles: 'coder,agent', triggers: 'form,contact,login,signup,register,input,validation,email,subscribe,newsletter,message',
      body: 'Each input has a <label for>, type (email/tel), required and autocomplete. JS validates on submit (preventDefault), shows an inline error under the field and a success message; trims values; never trusts input; escapes text before using innerHTML (use textContent). ' +
        'Offline pages have no server: store the message in localStorage or open a mailto: link, and say so honestly.' },
    { name: 'safe-animation', roles: 'coder,agent', triggers: 'animation,animate,reveal,scroll,transition,fade,slide,hover,effect',
      body: 'Content must be visible WITHOUT JavaScript: never set opacity:0 in plain CSS. Add the hidden state with a class that JS adds (html.js .reveal{opacity:0}), use IntersectionObserver, and add a 1.5s fallback that shows everything. Respect prefers-reduced-motion. Animate only transform and opacity.' },
    { name: 'js-no-bugs', roles: 'architect,coder,fixer,agent', triggers: 'javascript,js,script,function,button,click,game,calculator,app,fix,bug,error,debug,todo,timer',
      body: 'Create each element in ONE place (HTML or JS). Use ids that exist in the HTML; check null before use. Wrap startup in DOMContentLoaded. No globals clashing, no eval, no document.write. localStorage reads inside try/catch with JSON.parse fallbacks. ' +
        'Handle empty input, division by zero, double clicks. Controls must work by touch (click + pointer events). After editing, run run_tests and fix every PROBLEM.' },
    { name: 'accessibility-seo', roles: 'coder,agent', triggers: 'website,page,landing,blog,seo,accessibility,a11y,business,portfolio',
      body: 'One <h1>, headings in order, <header><nav><main><section><footer>, lang on <html>, <title> and meta description, Open Graph tags, alt on images, aria-label on icon buttons, aria-expanded on the menu button, visible :focus-visible outline, skip link.' },
    { name: 'research-method', roles: 'planner,notes,assistant,agent', triggers: 'research,search,latest,news,api,documentation,docs,how to,compare,best,review,internet,web',
      body: 'Search docs and primary sources first (MDN, official docs, GitHub, Wikipedia, W3C). Sites like Behance, Dribbble, Pinterest, Instagram, Facebook, X, LinkedIn block apps: do not use them. ' +
        'Prefer two sources that agree; write notes as short facts with [n] source numbers; if nothing usable is found, say so and use built-in knowledge instead of guessing.' },
    { name: 'python-termux', roles: 'architect,coder,agent', triggers: 'python,termux,script,bot,flask,requests,api,cli,.py',
      body: 'Python 3 standard library first. main() + if __name__ == "__main__". argparse for options, try/except around network and file calls with timeouts, logging not print for errors, pathlib for paths, no hard-coded secrets (read env vars). ' +
        'On Termux: pkg install python; pip install only what is needed; avoid heavy packages (numpy builds are slow).' },
    { name: 'security-basics', roles: 'coder,fixer,agent', triggers: 'login,auth,password,token,api key,database,sql,php,upload,admin,security,secure,payment',
      body: 'Never put API keys or passwords in client code. Validate and escape all input; use prepared statements for SQL; hash passwords (password_hash / bcrypt); check file upload type and size; use HTTPS; rate-limit login; set secure cookies; never echo raw errors to users.' }
  ];

  function parseMd(text) {
    text = String(text || '').replace(/\r/g, '');
    var m = /^---\n([\s\S]*?)\n---\n?([\s\S]*)$/.exec(text), meta = {}, body = text;
    if (m) { body = m[2]; m[1].split('\n').forEach(function (l) { var k = /^(\w[\w-]*):\s*(.*)$/.exec(l); if (k) meta[k[1].toLowerCase()] = k[2].trim().replace(/^["']|["']$/g, ''); }); }
    return { meta: meta, body: body.trim() };
  }
  function settings() { return RC.settings || {}; }
  function words(t) { return String(t || '').toLowerCase().replace(/[^a-z0-9.+# \u0600-\u06ff]/g, ' ').split(/\s+/).filter(Boolean); }

  var S = RC.skills = {
    builtin: B,
    all: function () {
      var off = settings().skillsOff || [], custom = (settings().skills || []).map(function (c) { return { name: c.name, roles: c.roles || 'planner,architect,coder,agent', triggers: c.triggers || c.name, body: c.body, custom: true }; });
      return B.concat(custom).map(function (k) { return Object.assign({}, k, { on: off.indexOf(k.name) < 0 }); });
    },
    get: function (name) { return S.all().filter(function (k) { return k.name === name; })[0] || null; },
    enabled: function () { return settings().useSkills !== false; },
    /** best matching skills for a request and a role ('planner','architect','coder','fixer','notes','assistant','agent') */
    pick: function (text, role, max) {
      if (!S.enabled()) return [];
      var w = words(text), joined = ' ' + w.join(' ') + ' ';
      return S.all().filter(function (k) { return k.on && (!role || (' ' + k.roles + ' ').replace(/,/g, ' ').indexOf(' ' + role + ' ') >= 0); })
        .map(function (k) {
          var sc = 0; String(k.triggers).split(',').forEach(function (t) { t = t.trim().toLowerCase(); if (t && (t.indexOf(' ') >= 0 || /[.]/.test(t) ? joined.indexOf(' ' + t) >= 0 || String(text).toLowerCase().indexOf(t) >= 0 : w.indexOf(t) >= 0)) sc++; });
          return { k: k, sc: sc };
        }).filter(function (x) { return x.sc > 0; }).sort(function (a, b) { return (b.sc + (b.k.custom ? 0.5 : 0)) - (a.sc + (a.k.custom ? 0.5 : 0)); }).slice(0, max || 2).map(function (x) { return x.k; });
    },
    /** text for the prompt, at most `chars` long (each skill is cut at a sentence end) */
    prompt: function (text, role, chars) {
      var list = S.pick(text, role, 2); if (!list.length) return '';
      var per = Math.floor((chars || 900) / list.length), out = list.map(function (k) { return '[' + k.name + '] ' + U.clip(k.body, per, ''); });
      return 'Skills (follow them):\n' + out.join('\n');
    },
    names: function (text, role) { return S.pick(text, role, 2).map(function (k) { return k.name; }); },
    /** add / replace a custom skill from Markdown text (frontmatter: name, description, triggers, roles) */
    importText: function (text, fallbackName) {
      var p = parseMd(text), name = (p.meta.name || fallbackName || '').toLowerCase().replace(/[^a-z0-9-]+/g, '-').replace(/^-|-$/g, '');
      if (!name || p.body.length < 20) throw new Error('A skill needs a name and some text.');
      var list = (settings().skills || []).filter(function (k) { return k.name !== name; });
      list.push({ name: name, description: p.meta.description || '', triggers: p.meta.triggers || p.meta.description || name, roles: p.meta.roles || 'planner,architect,coder,agent', body: U.clip(p.body, 1800, '') });
      if (RC.set) RC.set('skills', list); else settings().skills = list;
      return name;
    },
    remove: function (name) { var list = (settings().skills || []).filter(function (k) { return k.name !== name; }); if (RC.set) RC.set('skills', list); else settings().skills = list; },
    toggle: function (name, on) { var off = (settings().skillsOff || []).filter(function (x) { return x !== name; }); if (!on) off.push(name); if (RC.set) RC.set('skillsOff', off); else settings().skillsOff = off; },
    /** learn a skill from a web page (internet needed): the page text is condensed into rules */
    fromUrl: async function (url, name) {
      var d = await RC.native.read(url, 3000);
      var body = String(d.text || '').split('\n').map(function (l) { return l.trim(); }).filter(function (l) { return l.length > 25; }).slice(0, 14).join(' ');
      return S.importText('---\nname: ' + (name || (d.title || 'learned').slice(0, 30)) + '\ntriggers: ' + words(d.title + ' ' + name).slice(0, 8).join(',') + '\n---\n' + body);
    },
    parseMd: parseMd
  };
})();
