/* ReCode V17: live agent telemetry, serialized/conflict-aware task queue, context budgeting,
   APK build/test gates, checkpoints and safe native-workspace ZIP utilities. */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  RC.engine = RC.engine || {};
  RC.engine.version = '17.0.0';
  RC.engine.workflow = (RC.engine.workflow || []).concat([
    'live_agent_dashboard', 'queued_task_execution', 'file_scope_conflict_resolution',
    'context_budgeting', 'project_checkpoint', 'apk_build_test_lint',
    'bounded_error_recovery', 'workspace_zip_import_export'
  ]);
  RC.engine.capabilities = Object.assign(RC.engine.capabilities || {}, {
    realTimeAgentDashboard: true, liveCodingProgress: true, advancedTaskQueue: true,
    agentConflictResolution: true, intelligentContextManagement: true,
    automaticApkTesting: true, advancedErrorRecovery: true, fullProjectCheckpoints: true,
    zipExtract: true, zipCompress: true, safeZipPathValidation: true
  });
  var V = RC.engine.v17 = { tools: [], maxQueue: 30, maxContextChars: 18000, maxCheckpointBytes: 1500000 };
  var queue = [], running = false, seq = 0, locks = Object.create(null), events = [], active = {};
  function files() { return RC.store && RC.store.files || {}; }
  function fail(m) { var e = new Error(m); e.tool = true; return e; }
  function clip(s, n) { s = String(s == null ? '' : s); return s.length > n ? s.slice(0, n) + '\n[context clipped by ReCode V17]' : s; }
  function emit(kind, data) {
    var ev = { id: 'v17-' + (++seq), at: Date.now(), kind: kind, data: data || {} };
    events.push(ev); if (events.length > 120) events.shift();
    if (RC.bus && RC.bus.emit) { try { RC.bus.emit('v17', ev); } catch (_) {} }
    return ev;
  }
  function status() {
    return { version: '17.0.0', running: running, active: Object.keys(active).map(function (k) { return active[k]; }),
      queued: queue.map(function (x) { return { id:x.id, title:x.title, state:x.state, scope:x.scope }; }),
      recent: events.slice(-25), capabilities: RC.engine.capabilities };
  }
  function validScope(scope) {
    var s = (scope || []).map(function (x) { return String(x).replace(/^\/+|\/+$/g, ''); }).filter(Boolean);
    for (var i=0;i<s.length;i++) if (s[i].indexOf('..') >= 0 || /^([a-z]:|\/)/i.test(s[i])) throw fail('Task scope must contain safe project-relative paths.');
    return s;
  }
  function conflicts(a,b) {
    if (!a.length || !b.length) return true;
    return a.some(function(x){ return b.some(function(y){ return x===y || x.indexOf(y + '/')===0 || y.indexOf(x + '/')===0 || x==='*' || y==='*'; }); });
  }
  function acquire(task) {
    var names = Object.keys(locks);
    for (var i=0;i<names.length;i++) if (conflicts(task.scope, locks[names[i]])) return false;
    locks[task.id] = task.scope; return true;
  }
  function release(task) { delete locks[task.id]; }
  async function runTask(task) {
    task.state='running'; task.started=Date.now(); active[task.id]=task;
    emit('task-start',{id:task.id,title:task.title,scope:task.scope});
    try {
      if (!RC.subagents || !RC.subagents.run) throw fail('Specialist agent runtime is unavailable.');
      var prompt = clip(task.prompt, V.maxContextChars);
      var result = await RC.subagents.run(task.agent || 'coder', prompt, { run: RC.currentRun || null, goal: task.title, depth: 0 });
      task.state = result && result.ok ? 'completed' : 'failed'; task.result = clip(result && result.text || 'Agent returned no report.', 6000);
      task.files = result && result.files || [];
      emit('task-finish',{id:task.id,state:task.state,files:task.files,result:task.result});
    } catch(e) { task.state='failed'; task.result=String(e.message || e); emit('task-error',{id:task.id,error:task.result}); }
    task.finished=Date.now(); delete active[task.id]; release(task);
    return task;
  }
  async function pump() {
    if (running) return; running=true;
    try {
      while(queue.length) {
        var index=-1;
        for(var i=0;i<queue.length;i++) if(acquire(queue[i])) { index=i; break; }
        if(index<0) { emit('queue-wait',{reason:'All queued task scopes conflict with active work.'}); break; }
        var task=queue.splice(index,1)[0];
        await runTask(task); // sequential execution avoids unsafe concurrent project mutations
      }
    } finally { running=false; emit('queue-idle',{queued:queue.length}); }
  }
  V.enqueue = function(spec) {
    spec=spec||{}; if(queue.length+Object.keys(active).length>=V.maxQueue) throw fail('Task queue is full.');
    if(!String(spec.prompt||'').trim()) throw fail('Task prompt is required.');
    var task={id:'task-'+Date.now()+'-'+(++seq),title:String(spec.title||'Coding task').slice(0,100),prompt:String(spec.prompt),agent:spec.agent||'coder',scope:validScope(spec.scope||[]),state:'queued',created:Date.now()};
    queue.push(task); emit('task-queued',{id:task.id,title:task.title,scope:task.scope}); pump(); return task.id;
  };
  V.dashboard = status;
  V.context = function(text, limit) {
    var cap=Math.max(1000,Math.min(V.maxContextChars,Number(limit)||V.maxContextChars));
    var src=String(text||''); var lines=src.split(/\n/), out=[], used=0;
    // Keep the beginning (task constraints) and tail (recent evidence); discard middle when over budget.
    if(src.length<=cap) return {text:src,originalChars:src.length,usedChars:src.length,clipped:false};
    var head=Math.floor(cap*0.62), tail=cap-head-50;
    var packed=src.slice(0,head)+'\n\n[... middle context compacted ...]\n\n'+src.slice(-tail);
    return {text:packed,originalChars:src.length,usedChars:packed.length,clipped:true,policy:'preserve task prefix and latest evidence'};
  };
  V.checkpoint = async function(label) {
    var snapshot={}, total=0; Object.keys(files()).forEach(function(p){ snapshot[p]=files()[p]; total+=String(files()[p]).length; });
    if(total>V.maxCheckpointBytes) throw fail('Project checkpoint exceeds 1.5 MB. Use a smaller project snapshot.');
    var cp={id:'cp-'+Date.now(),label:String(label||'Checkpoint').slice(0,80),created:Date.now(),files:snapshot,bytes:total};
    var list=(RC.store.cur.v17Checkpoints||[]); list.push(cp); while(list.length>5) list.shift();
    RC.store.cur.v17Checkpoints=list; RC.store.touch();
    emit('checkpoint-created',{id:cp.id,label:cp.label,files:Object.keys(snapshot).length,bytes:total});
    return 'Checkpoint '+cp.id+' created: '+Object.keys(snapshot).length+' files, '+total+' characters. Last five checkpoints are retained.';
  };
  V.restore = async function(id) {
    var list=RC.store.cur.v17Checkpoints||[], cp=list.find(function(x){return x.id===id;});
    if(!cp) throw fail('Checkpoint not found.');
    var current=Object.keys(files());
    for(var i=0;i<current.length;i++) if(cp.files[current[i]]===undefined) await RC.store.delFile(current[i]);
    var paths=Object.keys(cp.files);
    for(var j=0;j<paths.length;j++) await RC.store.putFile(paths[j],cp.files[paths[j]]);
    emit('checkpoint-restored',{id:id,files:paths.length});
    return 'Restored '+paths.length+' files from '+id+'. Review the project before building.';
  };
  V.apkTest = async function(task) {
    if(!RC.native || !RC.native.has) throw fail('APK build/test requires the installed Android app and configured JDK, Gradle wrapper and Android SDK.');
    var tasks=(task==='release'?['assembleRelease','testReleaseUnitTest','lint']:['assembleDebug','testDebugUnitTest','lint']);
    var reports=[];
    for(var i=0;i<tasks.length;i++) {
      emit('apk-test-progress',{task:tasks[i],step:i+1,total:tasks.length});
      try { var r=await RC.native.androidBuild(tasks[i]); reports.push('## '+tasks[i]+'\n'+r); if(/exit=[1-9]|BUILD FAILED|FAILURE:|\bFAILED\b/i.test(String(r))) break; }
      catch(e) { reports.push('## '+tasks[i]+'\nERROR: '+e.message); break; }
    }
    return 'AUTOMATIC APK VALIDATION\n'+reports.join('\n\n')+'\n\nNote: this runs Gradle build/unit-test/lint tasks. Installing and UI-testing on an emulator/device requires a connected test device or emulator and is not claimed here.';
  };
  V.recover = async function(task) {
    if(RC.engine.v16 && RC.engine.v16.recoverBuild) return RC.engine.v16.recoverBuild(task||'assembleDebug',RC.currentRun||null);
    return V.apkTest(task);
  };
  V.zip = async function(action,name,overwrite) {
    if(!RC.native || !RC.native.has) throw fail('ZIP workspace tools require the installed ReCode Android app.');
    if(action==='compress') return RC.native.zipWorkspace(name||'recode-workspace.zip');
    if(action==='extract') return RC.native.unzipWorkspace(name,!!overwrite);
    throw fail('Action must be compress or extract.');
  };
  function add(name,perm,params,description,fn) {
    V.tools.push(name);
    if(RC.tools&&RC.tools.registry&&!RC.tools.registry[name]) RC.tools.registry[name]={name:name,perm:perm,params:params,description:description,run:fn};
  }
  add('agent_dashboard','read','','Show real-time agent/task status and recent progress events.',function(){return JSON.stringify(status(),null,2);});
  add('queue_coding_task','exec','title, prompt, [agent], [scope]','Queue a coding task with explicit file/folder ownership. Conflicting scopes are held until safe; project writes are serialized.',function(a){return 'Queued task: '+V.enqueue(a);});
  add('context_compact','read','text, [max_chars]','Compact long context while preserving task constraints and latest evidence.',function(a){return JSON.stringify(V.context(a.text,a.max_chars),null,2);});
  add('create_project_checkpoint','write','[label]','Save a full text-project snapshot (up to 1.5 MB, latest five checkpoints retained).',function(a){return V.checkpoint(a.label);});
  add('restore_project_checkpoint','write','checkpoint_id','Restore all project files from a prior checkpoint. This overwrites current project files.',function(a){return V.restore(a.checkpoint_id);});
  add('automatic_apk_testing','exec','[variant]','Run Gradle assemble, unit tests and lint for debug or release; requires configured Android toolchain.',function(a){return V.apkTest(a.variant);});
  add('advanced_error_recovery','exec','[task]','Use V16 bounded debugger/fixer build recovery when available, otherwise run APK validation.',function(a){return V.recover(a.task);});
  add('zip_workspace_compress','exec','[archive_name]','Compress files from ReCode private native workspace into a ZIP archive stored in app-private storage.',function(a){return V.zip('compress',a.archive_name,false);});
  add('zip_workspace_extract','exec','archive_name, [overwrite]','Safely extract an archive already stored in ReCode private app storage into its private workspace; blocks traversal and limits expansion to 250 MB.',function(a){return V.zip('extract',a.archive_name,a.overwrite);});
  RC.engine.capabilityReport=(function(old){return function(){var r=old?old():{};r.version='17.0.0';r.capabilities=RC.engine.capabilities;r.v17={tools:V.tools,queueMode:'serialized writes with path-scope conflict locks',checkpointLimitBytes:V.maxCheckpointBytes,zipWorkspaceOnly:true,apkTests:['assembleDebug/Release','testDebugUnitTest/ReleaseUnitTest','lint']};return r;};})(RC.engine.capabilityReport);
  emit('engine-ready',{version:'17.0.0',tools:V.tools});
})();
