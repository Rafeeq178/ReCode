/* ReCode V16: bounded self-healing, regression gates, optimization/performance analysis,
   shared specialist memory, failed-build recovery and continuous verification. */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  RC.engine = RC.engine || {};
  var prior = RC.engine.capabilities || {};
  RC.engine.version = '16.0.0';
  RC.engine.workflow = [
    'inspect_project', 'load_shared_agent_memory', 'capture_regression_baseline',
    'parallel_read_only_analysis', 'plan', 'scoped_implementation',
    'static_and_runtime_bug_detection', 'bounded_self_healing',
    'regression_verification', 'performance_analysis', 'independent_code_review',
    'build_recovery_if_needed', 'final_verification', 'report_evidence'
  ];
  RC.engine.capabilities = Object.assign(prior, {
    selfHealingAgent: true, automaticRegressionTesting: true,
    intelligentCodeOptimization: true, automaticPerformanceAnalysis: true,
    multiAgentMemorySharing: true, automaticFailedBuildRecovery: true,
    continuousCodingVerification: true, boundedRepairAttempts: true,
    regressionBaseline: true, evidenceBasedOptimization: true
  });
  var MEMORY_FILE = 'RECODE_AGENT_MEMORY.md';
  var MAX_REPAIR = 2;
  function files() { return RC.store && RC.store.files || {}; }
  function fail(s) { var e = new Error(s); e.tool = true; return e; }
  function clip(s, n) { s = String(s || ''); return s.length > n ? s.slice(0, n) + '…' : s; }
  function hash(s) { var h = 2166136261; s = String(s); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0).toString(16); }
  function snapshot() { var out = {}; Object.keys(files()).sort().forEach(function (p) { out[p] = hash(files()[p]); }); return out; }
  function diff(a, b) { var changed = [], added = [], removed = []; Object.keys(b).forEach(function (p) { if (!(p in a)) added.push(p); else if (a[p] !== b[p]) changed.push(p); }); Object.keys(a).forEach(function (p) { if (!(p in b)) removed.push(p); }); return { changed: changed, added: added, removed: removed }; }
  async function tests() { if (!RC.tools || !RC.tools.registry.run_tests) return 'UNAVAILABLE: run_tests tool missing'; return await RC.tools.registry.run_tests.run({}); }
  async function review(task, run) {
    if (!RC.subagents) return 'UNAVAILABLE: specialist agents not loaded';
    var names = ['reviewer', 'security'];
    var results = await Promise.all(names.map(function (n) { return RC.subagents.run(n, task || 'Review the current project for correctness, security and maintainability. Read-only; cite file paths and evidence.', { run: run || null, goal: 'ReCode V16 code review', depth: 0 }); }));
    return results.map(function (r) { return '## ' + r.name + ' (' + (r.ok ? 'completed' : 'failed') + ')\n' + r.text; }).join('\n\n');
  }
  var V = RC.engine.v16 = {
    tools: ['self_healing_agent','automatic_regression_test','intelligent_code_optimization','performance_analysis','share_agent_memory','recover_failed_build','continuous_coding_verification'],
    repairLimit: MAX_REPAIR,
    snapshot: snapshot,
    regression: async function (baseline) {
      var before = baseline || (RC.store && RC.store.cur && RC.store.cur.v16Baseline) || null;
      if (!before) { var fresh = snapshot(); if (RC.store && RC.store.cur) { RC.store.cur.v16Baseline = fresh; RC.store.touch && RC.store.touch(); } return 'BASELINE CAPTURED\n' + Object.keys(fresh).length + ' project files fingerprinted. Run this again after changes to compare.'; }
      var delta = diff(before, snapshot());
      var result = await tests();
      return 'REGRESSION CHECK\nChanged: ' + (delta.changed.join(', ') || 'none') + '\nAdded: ' + (delta.added.join(', ') || 'none') + '\nRemoved: ' + (delta.removed.join(', ') || 'none') + '\n\n' + result;
    },
    memory: async function (note, agent) {
      note = clip(String(note || '').replace(/[\r\n]+/g, ' ').trim(), 400);
      if (!note) throw fail('Provide a concise verified project fact to share with agents.');
      var existing = String(files()[MEMORY_FILE] || '# Shared ReCode Agent Memory\n\n');
      var line = '- [' + new Date().toISOString() + '] ' + (agent ? '[' + clip(agent, 30) + '] ' : '') + note;
      if (existing.indexOf(line.slice(line.indexOf('] ') + 2)) >= 0) return 'Similar memory already exists.';
      if (existing.length > 12000) existing = '# Shared ReCode Agent Memory\n\n' + existing.split('\n').slice(-80).join('\n') + '\n';
      await RC.store.putFile(MEMORY_FILE, existing.replace(/\s*$/, '\n') + line + '\n');
      return 'Shared memory saved in ' + MEMORY_FILE + '. It is available to future agent tasks when explicitly included.';
    },
    performance: function () {
      var all = files(), rows = Object.keys(all).map(function (p) { return { path: p, chars: String(all[p] || '').length, lines: String(all[p] || '').split('\n').length }; });
      rows.sort(function (a,b) { return b.chars-a.chars; });
      var js = rows.filter(function (r) { return /\.m?js$/i.test(r.path); });
      var html = Object.keys(all).filter(function (p) { return /\.html?$/i.test(p); }).map(function (p) { return { path:p, scripts:(String(all[p]).match(/<script\b/gi)||[]).length, styles:(String(all[p]).match(/<link\b[^>]*stylesheet/gi)||[]).length }; });
      var total = rows.reduce(function (n,r) { return n+r.chars; },0);
      return 'STATIC PERFORMANCE PROFILE (not a runtime benchmark)\nFiles: ' + rows.length + '\nTotal source size: ' + total + ' characters\nLargest files:\n' + rows.slice(0,8).map(function (r) { return r.path + ' — ' + r.chars + ' chars / ' + r.lines + ' lines'; }).join('\n') + '\nJavaScript files: ' + js.length + '\nHTML resource counts:\n' + (html.map(function (h) { return h.path + ': ' + h.scripts + ' script tags, ' + h.styles + ' stylesheet links'; }).join('\n') || 'No HTML entry point found') + '\n\nUse device profiling for actual startup, memory, frame-time and network measurements.';
    },
    optimize: async function (focus) {
      var analysis = V.performance();
      if (!RC.subagents) return analysis + '\n\nOptimizer agent unavailable; no files changed.';
      var r = await RC.subagents.run('optimizer', 'Analyze and recommend safe, measurable optimizations. Focus: ' + clip(focus || 'largest files and repeated work', 180) + '. First report bottlenecks and expected measurement. Do not change code unless a concrete bottleneck is evidenced; preserve behaviour and run tests after any edit. Shared memory:\n' + String(files()[MEMORY_FILE] || '').slice(-2500), { run: RC.currentRun || null, goal: 'Evidence-based code optimization', depth: 0 });
      return analysis + '\n\nOPTIMIZER AGENT\n' + r.text;
    },
    selfHeal: async function (task, run) {
      var reports = [], before = snapshot();
      for (var i=0; i<MAX_REPAIR; i++) {
        var scan = RC.tools.registry.detect_bugs ? await RC.tools.registry.detect_bugs.run({ run_tests: true }, {}) : 'Bug scanner unavailable';
        reports.push('SCAN ' + (i+1) + '\n' + scan);
        if (/No bugs|No issues|0 finding|no problem/i.test(scan) && !/FAILED|PROBLEM|TEST ERROR/.test(scan)) break;
        if (!RC.subagents) { reports.push('Repair stopped: specialist agent runtime unavailable.'); break; }
        var diagnosis = await RC.subagents.run('debugger', 'Diagnose the current failures and identify root causes with file/path evidence. Do not edit.\n' + scan, { run: run || null, goal: task || 'Self-heal verified project failures', depth: 0 });
        reports.push('DIAGNOSIS\n' + diagnosis.text);
        if (!diagnosis.ok) break;
        var repair = await RC.subagents.run('fixer', 'Fix only the confirmed root causes below using minimal changes. Run tests after editing. Stop if evidence is insufficient.\n' + diagnosis.text, { run: run || null, goal: task || 'Self-heal verified project failures', depth: 0 });
        reports.push('REPAIR\n' + repair.text);
        if (!repair.ok || !repair.files || !repair.files.length) break;
      }
      var verify = await tests(), delta = diff(before, snapshot());
      return reports.join('\n\n') + '\n\nFINAL VERIFICATION\n' + verify + '\n\nFiles changed: ' + (delta.changed.concat(delta.added).join(', ') || 'none') + '\nRemoved: ' + (delta.removed.join(', ') || 'none') + '\nRepair attempts are capped at ' + MAX_REPAIR + '; review changes before accepting.';
    },
    recoverBuild: async function (task, run) {
      if (!RC.native || !RC.native.has) throw fail('Native Android build bridge is unavailable in this runtime.');
      var first = await RC.native.androidBuild(task || 'assembleDebug');
      if (!/FAIL|ERROR|exception|could not|unable/i.test(String(first))) return 'BUILD RESULT\n' + first;
      var diagnosis = RC.subagents ? await RC.subagents.run('debugger', 'Analyze this failed Gradle build output. Find root cause and propose minimal fix; do not edit yet.\n' + clip(first, 5000), { run: run || null, goal: 'Recover failed Android build', depth: 0 }) : { ok:false, text:'Debugger unavailable' };
      if (!diagnosis.ok) return 'INITIAL BUILD FAILED\n' + first + '\n\nRECOVERY DIAGNOSIS\n' + diagnosis.text + '\nNo automatic changes made.';
      var fix = await RC.subagents.run('fixer', 'Apply only the confirmed minimal fix for this Gradle failure, then run available checks.\n' + diagnosis.text, { run: run || null, goal: 'Recover failed Android build', depth: 0 });
      if (!fix.ok || !fix.files || !fix.files.length) return 'INITIAL BUILD FAILED\n' + first + '\n\nRECOVERY\n' + fix.text + '\nBuild was not retried because no verified fix was made.';
      var retry = await RC.native.androidBuild(task || 'assembleDebug');
      return 'INITIAL BUILD\n' + first + '\n\nFIX\n' + fix.text + '\n\nRETRY BUILD\n' + retry;
    },
    continuous: async function (task, run) {
      var reports = [];
      var baseline = snapshot();
      if (RC.subagents) {
        var reads = await Promise.all(['planner','explorer','architect','security'].map(function (n) { return RC.subagents.run(n, 'Analyze without editing for this continuous coding task: ' + task + '\nShared agent memory:\n' + String(files()[MEMORY_FILE] || '').slice(-2000), { run: run || null, goal: task, depth: 0 }); }));
        reports = reports.concat(reads.map(function (r) { return r.name + ': ' + r.text; }));
        var coder = await RC.subagents.run('coder', 'Implement the task with minimal compatible changes. Read shared agent memory first. Run syntax checks and tests. TASK: ' + task, { run: run || null, goal: task, depth: 0 });
        reports.push('CODER: ' + coder.text);
        if (coder.ok && coder.files && coder.files.length) {
          reports.push('REGRESSION: ' + await V.regression(baseline));
          reports.push('REVIEW: ' + await review('Review the latest code changes for task: ' + task, run));
        }
      } else reports.push('Specialist agents unavailable; no coding performed.');
      return reports.join('\n\n');
    }
  };
  function add(name, perm, params, description, run) { if (RC.tools && RC.tools.registry && !RC.tools.registry[name]) RC.tools.registry[name] = { name:name, perm:perm, params:params, description:description, run:run }; }
  add('self_healing_agent','exec','[task]','Run evidence-based bug scan, debugger diagnosis, bounded minimal repair (maximum two attempts), then verify with tests.', function(a,c){ return V.selfHeal(a.task,c && c.run); });
  add('automatic_regression_test','exec','[baseline]','Capture a project fingerprint baseline or compare changed/added/removed files and rerun the project test suite.', function(a){ var b=null; if(a.baseline){try{b=JSON.parse(a.baseline);}catch(_){throw fail('baseline must be a JSON object returned by a prior snapshot.');}} return V.regression(b); });
  add('intelligent_code_optimization','exec','[focus]','Ask the optimizer agent for evidence-based, behaviour-preserving improvements. Reports recommendations and any verified edits.', function(a){ return V.optimize(a.focus); });
  add('performance_analysis','read','','Generate a static source-size and resource-count profile. Does not claim runtime benchmark results.', function(){ return V.performance(); });
  add('share_agent_memory','write','note, [agent]','Append a concise project fact to shared RECODE_AGENT_MEMORY.md for later specialist tasks.', function(a){ return V.memory(a.note,a.agent); });
  add('recover_failed_build','exec','[task]','Retry a failed Android Gradle build only after debugger diagnosis and a verified minimal repair.', function(a,c){ return V.recoverBuild(a.task,c && c.run); });
  add('continuous_coding_verification','exec','task','Run parallel read-only planning/architecture/security analysis, sequential implementation, regression tests and independent review.', function(a){ if(!String(a.task||'').trim()) throw fail('task is required'); return V.continuous(a.task,c && c.run); });
  RC.engine.capabilityReport = (function(old){ return function(){ var r = old ? old() : {}; r.version='16.0.0'; r.capabilities=RC.engine.capabilities; r.v16={tools:V.tools,repairAttempts:MAX_REPAIR,sharedMemoryFile:MEMORY_FILE,performanceProfile:'static-only'}; return r; }; })(RC.engine.capabilityReport);
})();
