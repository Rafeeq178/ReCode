/* ReCode - offline HTML/CSS/JS runner: bundles project files into one page, runs it in a sandboxed iframe
   (no network by default, no access to the app), captures console + errors, and checks projects for problems. */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var U = RC.u;

  var SHIM = '<script>(function(){var SID="__SID__",INIT=__LS__;function send(o){try{parent.postMessage(Object.assign({rc:1,sid:SID},o),"*")}catch(e){}}' +
    'function fmt(a){return Array.prototype.map.call(a,function(x){try{return typeof x==="object"?JSON.stringify(x):String(x)}catch(e){return String(x)}}).join(" ")}' +
    '["log","info","warn","error","debug"].forEach(function(l){var o=console[l];console[l]=function(){send({k:"console",lvl:l,text:fmt(arguments)});try{o.apply(console,arguments)}catch(e){}}});' +
    'window.addEventListener("error",function(e){send({k:"error",msg:e.message||"Script error",line:e.lineno||0,col:e.colno||0})});' +
    'window.addEventListener("unhandledrejection",function(e){send({k:"error",msg:"Unhandled promise rejection: "+(e.reason&&e.reason.message||e.reason),line:0,col:0})});' +
    'function mk(init,persist){var d=Object.assign({},init);function p(){if(persist)send({k:"ls",data:d})}' +
    'var api={getItem:function(k){return Object.prototype.hasOwnProperty.call(d,k)?d[k]:null},setItem:function(k,v){d[k]=String(v);p()},removeItem:function(k){delete d[k];p()},clear:function(){d={};p()},key:function(i){return Object.keys(d)[i]||null}};' +
    'return new Proxy(api,{get:function(t,k){if(k==="length")return Object.keys(d).length;if(k in t)return t[k];return Object.prototype.hasOwnProperty.call(d,k)?d[k]:undefined},set:function(t,k,v){t.setItem(k,v);return true},deleteProperty:function(t,k){t.removeItem(k);return true}})}' +
    'try{Object.defineProperty(window,"localStorage",{value:mk(INIT,true),configurable:true});Object.defineProperty(window,"sessionStorage",{value:mk({},false),configurable:true})}catch(e){}' +
    'window.addEventListener("message",function(e){var d=e.data;if(!d||d.rc!==1)return;' +
    'if(d.k==="key"){var t=d.key,code=t===" "?"Space":t,kc={ArrowLeft:37,ArrowUp:38,ArrowRight:39,ArrowDown:40,Enter:13," ":32}[t]||0;' +
    'var ev=function(){var x=new KeyboardEvent(d.type,{key:t,code:code,keyCode:kc,which:kc,bubbles:true,cancelable:true});try{Object.defineProperty(x,"keyCode",{get:function(){return kc}});Object.defineProperty(x,"which",{get:function(){return kc}})}catch(_){}return x};' +
    '[document.activeElement&&document.activeElement!==document.body?document.activeElement:null,document,window].forEach(function(n){if(n)try{n.dispatchEvent(ev())}catch(_){}});}' +
    'else if(d.k==="smoke"){scan();smoke()}});' +
    'function scan(){try{var b=document.body;if(!b)return;var bt={},dup=[];Array.prototype.forEach.call(document.querySelectorAll("button,[role=button],input[type=button]"),function(x){var t=(x.textContent||x.value||"").trim();if(t&&t.length<=3)bt[t]=(bt[t]||0)+1});for(var k in bt)if(bt[k]>1)dup.push(k);' +
    'var txt=b.innerText||"",rep=/(\\b[A-Za-z]{3,}:)\\s*\\1/.exec(txt);' +
    'send({k:"dom",dupBtn:dup,rep:rep?rep[0]:"",len:txt.trim().length,els:b.querySelectorAll("*").length,canvas:document.querySelectorAll("canvas").length,btns:document.querySelectorAll("button").length})}catch(e){}}' +
    'function smoke(){try{var bs=Array.prototype.slice.call(document.querySelectorAll("button,[role=button]")).slice(0,40);bs.forEach(function(x){try{x.click()}catch(e){}});' +
    '["ArrowUp","ArrowRight","ArrowDown","ArrowLeft"," ","Enter"].forEach(function(k){["keydown","keyup"].forEach(function(t){try{var x=new KeyboardEvent(t,{key:k,bubbles:true});document.dispatchEvent(x);window.dispatchEvent(x)}catch(e){}})})}catch(e){}}' +
    'window.addEventListener("load",function(){send({k:"load"})});})();</script>';

  function csp(net) {
    var c = net
      ? "default-src 'self' data: blob: https: 'unsafe-inline' 'unsafe-eval'"
      : "default-src 'none'; script-src 'unsafe-inline' 'unsafe-eval' blob:; style-src 'unsafe-inline' data:; img-src data: blob:; font-src data:; media-src data: blob:; connect-src 'none'; form-action 'none'";
    return '<meta http-equiv="Content-Security-Policy" content="' + c + '">';
  }
  function resolve(base, href) {
    href = String(href || '').split('#')[0].split('?')[0];
    if (!href || /^([a-z]+:|\/\/|data:)/i.test(href)) return null;
    var dir = base.indexOf('/') >= 0 ? base.replace(/\/[^\/]*$/, '/') : '';
    return U.normPath(href.charAt(0) === '/' ? href : dir + href);
  }

  var Run = RC.run = {
    entry: function (files) {
      var names = Object.keys(files);
      if (files['index.html']) return 'index.html';
      var h = names.filter(function (n) { return /\.html?$/i.test(n); }).sort(function (a, b) { return a.split('/').length - b.split('/').length; });
      return h[0] || null;
    },
    /** -> {html, ranges:[{file,from,to}], entry} or null when there is nothing to run */
    bundle: function (files, opts) {
      opts = opts || {};
      var entry = opts.entry || Run.entry(files), src;
      var ranges = [];
      if (!entry) {
        var js = Object.keys(files).filter(function (n) { return /\.m?js$/i.test(n); });
        if (!js.length) return null;
        src = '<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"></head><body>' +
          js.map(function (n) { return '<script src="' + n + '"></script>'; }).join('') + '</body></html>';
        entry = '(generated)';
      } else src = files[entry];
      var out = '', last = 0, re = /<link\b[^>]*>|<script\b([^>]*)>\s*<\/script>/gi, m;
      function lines(s) { return s.split('\n').length - 1; }
      while ((m = re.exec(src))) {
        var tag = m[0], rep = null, path, body;
        if (/^<link/i.test(tag)) {
          if (/rel\s*=\s*["']?stylesheet/i.test(tag)) {
            var hm = /href\s*=\s*["']([^"']+)["']/i.exec(tag);
            path = hm && resolve(entry, hm[1]);
            if (path && files[path] !== undefined) rep = ['<style>\n', files[path].replace(/<\/style/gi, '<\\/style'), '\n</style>'];
          }
        } else {
          var sm = /\bsrc\s*=\s*["']([^"']+)["']/i.exec(m[1] || '');
          path = sm && resolve(entry, sm[1]);
          if (path && files[path] !== undefined) {
            var attrs = (m[1] || '').replace(/\bsrc\s*=\s*["'][^"']+["']/i, '');
            rep = ['<script' + attrs + '>\n', files[path].replace(/<\/script/gi, '<\\/script'), '\n</script>'];
          }
        }
        out += src.slice(last, m.index);
        if (rep) {
          out += rep[0];
          var from = lines(out) + 1;
          out += rep[1];
          ranges.push({ file: path, from: from, to: from + lines(rep[1]) });
          out += rep[2];
        } else out += tag;
        last = m.index + tag.length;
      }
      out += src.slice(last);
      // the entry page's own inline <script> blocks count as the entry file
      return { html: out, ranges: ranges, entry: entry };
    },
    /** full srcdoc: CSP + console/error/storage shim inserted on ONE line so error line numbers stay valid */
    frame: function (files, sid, opts) {
      var b = Run.bundle(files, opts);
      if (!b) return null;
      var ls = RC.store && RC.store.cur ? RC.store.getLS() : {};
      var head = csp(!!RC.settings.netPreview) + SHIM.replace('__SID__', sid).replace('__LS__', JSON.stringify(ls).replace(/</g, '\\u003c'));
      var h = b.html, done = false;
      h = h.replace(/<head(\s[^>]*)?>/i, function (x) { done = true; return x + head; });
      if (!done) h = h.replace(/<html(\s[^>]*)?>/i, function (x) { done = true; return x + '<head>' + head + '</head>'; });
      if (!done) h = '<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">' + head + '</head><body>' + h + '</body></html>';
      b.srcdoc = h;
      return b;
    },
    fileForLine: function (b, line) {
      for (var i = 0; i < b.ranges.length; i++) if (line >= b.ranges[i].from && line <= b.ranges[i].to) return { file: b.ranges[i].file, line: line - b.ranges[i].from + 1 };
      return { file: b.entry, line: line };
    },
    SANDBOX: 'allow-scripts allow-modals allow-forms allow-pointer-lock',

    /** run the page invisibly for a moment; resolves {errors:[{msg,file,line}], logs:[]} */
    probe: function (files, ms) {
      return new Promise(function (resolve) {
        var sid = U.uid('probe'), b = Run.frame(files, sid);
        if (!b) return resolve({ errors: [], logs: [], skipped: true });
        var fr = document.createElement('iframe'), errors = [], logs = [], fin = false, t;
        fr.setAttribute('sandbox', Run.SANDBOX);
        fr.style.cssText = 'position:fixed;left:-9999px;top:0;width:390px;height:700px;border:0;visibility:hidden';
        function finish() {
          if (fin) return; fin = true; clearTimeout(t); window.removeEventListener('message', on);
          try { fr.remove(); } catch (e) { }
          resolve({ errors: errors, logs: logs });
        }
        function on(ev) {
          var d = ev.data;
          if (ev.source !== fr.contentWindow || !d || d.rc !== 1 || d.sid !== sid) return;
          if (d.k === 'error') { var w = Run.fileForLine(b, d.line); errors.push({ msg: d.msg, file: w.file, line: w.line }); }
          else if (d.k === 'console') { logs.push(d.lvl + ': ' + d.text); if (d.lvl === 'error') errors.push({ msg: 'console.error: ' + d.text, file: '', line: 0 }); }
          else if (d.k === 'load') { clearTimeout(t); t = setTimeout(finish, (ms || 900) + 500); setTimeout(function () { try { fr.contentWindow.postMessage({ rc: 1, k: 'smoke' }, '*'); } catch (e) { } }, 250); }
          else if (d.k === 'dom') {
            if (d.dupBtn && d.dupBtn.length >= 2) errors.push({ msg: 'DUPLICATE BUTTONS: the buttons ' + d.dupBtn.slice(0, 6).join(' ') + ' appear twice on the page (the HTML already contains them AND the JavaScript creates them again). Create them in ONE place only: delete the JavaScript code that creates or appends buttons (createElement / innerHTML) and attach the click handlers to the buttons that already exist in the HTML.', file: '', line: 0, kind: 'dup' });
            if (d.rep) errors.push({ msg: 'REPEATED TEXT \"' + d.rep + '\" on the page: the HTML already contains the label and the JavaScript writes it again. The JavaScript must write only the value into a <span id=...> (for example scoreEl.textContent = score), not the label.', file: '', line: 0, kind: 'rep' });
            if (!d.len && !d.canvas && d.els < 4) errors.push({ msg: 'The page is blank: nothing is visible. Check that the HTML has content and that the script runs.', file: '', line: 0, kind: 'blank' });
          }
        }
        window.addEventListener('message', on);
        t = setTimeout(finish, (ms || 900) + 2500);
        fr.srcdoc = b.srcdoc;
        document.body.appendChild(fr);
      });
    },

    /** static checks + automatic repairs. Returns {issues:[{file,msg}], fixes:[text]} (project files are changed in place via store) */
    lint: async function () {
      var St = RC.store, files = St.files, issues = [], fixes = [];
      var names = Object.keys(files), entry = Run.entry(files);
      for (var n = 0; n < names.length; n++) {
        if (files[names[n]].trim().length < 15) issues.push({ file: names[n], msg: 'The file is empty or almost empty. Write the full content.' });
      }
      if (entry) {
        var html = files[entry], changed = false;
        // references to files that do not exist -> point to the only unused file of that type, else report
        html = html.replace(/(<link\b[^>]*href\s*=\s*["'])([^"']+)(["'][^>]*>)|(<script\b[^>]*src\s*=\s*["'])([^"']+)(["'][^>]*>)/gi, function (all, a1, p1, z1, a2, p2, z2) {
          var ref = p1 || p2, path = resolve(entry, ref);
          if (!path || files[path] !== undefined) return all;
          var ext = U.ext(path), cands = names.filter(function (x) { return U.ext(x) === ext && x !== entry && html.indexOf(U.base(x)) < 0; });
          if (cands.length === 1) { changed = true; fixes.push('Fixed reference ' + ref + ' -> ' + cands[0]); return (a1 || a2) + cands[0] + (z1 || z2); }
          issues.push({ file: entry, msg: 'It references "' + ref + '" but the project has no such file. Files: ' + names.join(', ') });
          return all;
        });
        // css / js files nobody loads -> add them to the page
        names.forEach(function (x) {
          if (x.indexOf('/') >= 0 || x === entry) return;
          var e = U.ext(x), isRef = html.indexOf(x) >= 0;
          if (isRef) return;
          if (e === 'css') { html = /<\/head>/i.test(html) ? html.replace(/<\/head>/i, '  <link rel="stylesheet" href="' + x + '">\n</head>') : '<link rel="stylesheet" href="' + x + '">\n' + html; changed = true; fixes.push('Linked ' + x + ' in ' + entry); }
          else if (e === 'js') { html = /<\/body>/i.test(html) ? html.replace(/<\/body>/i, '  <script src="' + x + '"></script>\n</body>') : html + '\n<script src="' + x + '"></script>'; changed = true; fixes.push('Linked ' + x + ' in ' + entry); }
        });
        if (changed) { files[entry] = html; await St.putFile(entry, html); }
        // ids used by scripts must exist in the page
        var ids = {}, all = names.map(function (x) { return files[x]; }).join('\n');
        all.replace(/\bid\s*=\s*\\?["']([\w-]+)\\?["']/g, function (_, i) { ids[i] = 1; });
        all.replace(/\.id\s*=\s*["']([\w-]+)["']/g, function (_, i) { ids[i] = 1; });
        names.forEach(function (x) {
          if (!/\.m?js$/i.test(x)) return;
          var miss = {}, c = files[x], mm, r1 = /getElementById\(\s*["']([^"']+)["']\s*\)/g, r2 = /querySelector(?:All)?\(\s*["']#([\w-]+)["']\s*\)/g;
          while ((mm = r1.exec(c))) if (!ids[mm[1]]) miss[mm[1]] = 1;
          while ((mm = r2.exec(c))) if (!ids[mm[1]]) miss[mm[1]] = 1;
          var k = Object.keys(miss);
          if (k.length) issues.push({ file: x, msg: 'It looks up element id(s) ' + k.join(', ') + ' that do not exist in the page. Ids that exist: ' + (Object.keys(ids).join(', ') || 'none') + '. Use only those ids (or fix the HTML).' });
        });
      }
      // v8: images that do not exist get a generated SVG, and sections with a heading but no content are reported
      if (RC.assets) {
        var rep = RC.assets.repair(files, { name: (St.cur && St.cur.name) || 'Brand', type: 'generic' });
        for (var rk in rep.files) { files[rk] = rep.files[rk]; await St.putFile(rk, rep.files[rk]); }
        rep.fixes.forEach(function (m) { fixes.push(m); });
        names.forEach(function (x) { if (/\.html?$/i.test(x)) RC.assets.emptySections(x, files[x]).forEach(function (i) { issues.push(i); }); });
      }
      return { issues: issues, fixes: fixes };
    },
    /** lint + a real run in the hidden sandbox */
    check: async function () {
      var r = await Run.lint(), pr = await Run.probe(RC.store.files, 900), seen = {};
      pr.errors.forEach(function (e) {
        var key = e.file + e.msg; if (seen[key]) return; seen[key] = 1;
        var file = e.file && RC.store.files[e.file] !== undefined ? e.file : '';
        if (!file) { var js = Object.keys(RC.store.files).filter(function (x) { return /\.m?js$/i.test(x); }); file = js.length === 1 ? js[0] : (Run.entry(RC.store.files) || ''); }
        if (!file) return;
        if (r.issues.some(function (i) { return i.file === file && /do not exist in the page/.test(i.msg); }) && /null|undefined/.test(e.msg)) return; // already explained
        r.issues.push({ file: file, msg: 'Runtime error' + (e.line ? ' at line ' + e.line : '') + ': ' + e.msg });
      });
      r.logs = pr.logs; r.ran = !pr.skipped;
      return r;
    }
  };
})();
