/* ReCode - Phase 2 UI: approval dialog, plan preview actions, permission settings. */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var U = RC.u, h = U.h, UI = RC.ui, M = RC.perms;
  var LV = [['allow', 'Allow'], ['ask', 'Ask'], ['deny', 'Deny']];
  var GROUPS = [
    ['Read', ['read_file', 'list_files', 'search_files', 'search_text', 'get_file_info', 'check_syntax']],
    ['Write', ['write_file', 'create_directory']],
    ['Edit', ['edit_file', 'rename_file', 'move_file']],
    ['Delete', ['delete_file']],
    ['Terminal and tests', ['run_command', 'run_tests']],
    ['Plan and notes', ['todo', 'remember']]
  ];

  // ------------------------------------------------------------------ approval dialog
  M.requester = function (req, signal) {
    return new Promise(function (res, rej) {
      var done = false;
      function fin(v) { if (done) return; done = true; if (signal) signal.removeEventListener('abort', onAbort); UI.closeSheet(); res(v); }
      function onAbort() { if (done) return; done = true; UI.closeSheet(); var e = new Error('Stopped'); e.name = 'AbortError'; rej(e); }
      if (signal) { if (signal.aborted) return onAbort(); signal.addEventListener('abort', onAbort); }
      var body = h('div',
        h('div.t1', req.tool.name + (req.targets.length ? ' · ' + req.targets.join(' → ') : '')),
        h('div.t2', { style: { margin: '4px 0 10px' } }, req.reasons.join(' · ') || 'This action needs your approval.'),
        h('pre.code', { style: { maxHeight: '220px', overflow: 'auto', whiteSpace: 'pre-wrap' } }, req.preview),
        h('div.col', { style: { display: 'flex', flexDirection: 'column', gap: '8px', marginTop: '14px' } },
          UI.btn('Allow once', 'check', '', function () { fin('once'); }),
          req.sticky ? null : UI.btn('Always allow ' + req.tool.name + ' in this project', 'shield', 'ghost', function () { fin('always'); }),
          UI.btn('Deny', 'x', 'ghost danger', function () { fin('deny'); })));
      UI.sheet({ title: 'Permission needed', body: body, onClose: function () { if (!done) { done = true; if (signal) signal.removeEventListener('abort', onAbort); res('deny'); } } });
    });
  };

  // ------------------------------------------------------------------ plan actions
  /** buttons under a plan message. m.plan = {text, status: pending|approved|rejected, task} */
  UI.planActions = function (m, onExecute) {
    var pl = m.plan;
    if (!pl) return null;
    if (pl.status !== 'pending') return h('div.t2', { style: { marginTop: '6px' } }, pl.status === 'approved' ? 'Plan approved and executed.' : 'Plan rejected.');
    function setStatus(s) { pl.status = s; RC.store.saveMsg(m); RC.bus.emit('project'); }
    return h('div.acts',
      UI.btn('Approve', 'check', 'sm', function () { setStatus('approved'); onExecute(pl); }),
      UI.btn('Edit plan', 'edit', 'sm ghost', function () { UI.prompt('Edit plan', pl.text, '', true).then(function (v) { if (v != null && v.trim()) { pl.text = v.trim(); m.text = v.trim(); RC.store.saveMsg(m); RC.bus.emit('project'); } }); }),
      UI.btn('Reject', 'x', 'sm ghost danger', function () { setStatus('rejected'); }));
  };

  // ------------------------------------------------------------------ permission settings
  function open() {
    var scope = 'global';
    function body() {
      var S = RC.settings, P = S.perms, box = h('div');
      box.appendChild(h('div.sec', 'Mode'));
      box.appendChild(UI.card(UI.seg([['plan', 'Plan'], ['ask', 'Ask'], ['auto', 'Auto']], M.mode(), function (v) { RC.set('permMode', v); }),
        h('div.t2', { style: { marginTop: '8px' } }, 'Plan: read-only, you approve a plan first. Ask: dialog for protected actions. Auto: ASK is approved automatically. DENY is never bypassed.')));
      box.appendChild(h('div.sec', 'Rules apply to'));
      box.appendChild(UI.card(UI.seg([['global', 'All projects'], ['project', 'This project']], scope, function (v) { scope = v; UI.sheetRepaint && refresh(); })));
      GROUPS.forEach(function (g) {
        box.appendChild(h('div.sec', g[0]));
        var c = UI.card();
        g[1].forEach(function (tool) {
          var b = M.base(tool), cur = scope === 'project' ? ((RC.store.cur && RC.store.cur.perms || {})[tool] || '') : ((P.global || {})[tool] || '');
          var shown = cur || b.level;
          c.appendChild(h('div.setrow', { style: { flexWrap: 'wrap' } }, h('div.grow', h('div.t1', tool), h('div.t2', cur ? 'custom rule' : 'default: ' + b.level)),
            UI.seg(LV, shown, function (v) { M.setRule(tool, v, scope); setTimeout(refresh, 0); })));
        });
        box.appendChild(c);
      });
      box.appendChild(h('div.sec', 'Safety'));
      box.appendChild(UI.card(
        toggleP('confirmDelete', 'Confirm every delete', 'Even in Auto mode'),
        toggleP('confirmOverwrite', 'Confirm overwriting files', 'write_file on an existing file asks first'),
        h('div.setrow', h('div.grow', h('div.t1', 'Dangerous commands'), h('div.t2', 'rm -rf, sudo, downloads piped to a shell, paths outside the project…')), UI.seg([['deny', 'Deny'], ['ask', 'Ask']], P.dangerous === 'ask' ? 'ask' : 'deny', function (v) { P.dangerous = v; RC.saveSettings(); }))));
      box.appendChild(h('div.sec', 'Hooks'));
      box.appendChild(UI.card(
        toggleH('format', 'Auto-format after writes', 'Trailing spaces, line endings'),
        toggleH('syntax', 'Syntax check after writes', 'Errors are shown to the agent at once'),
        toggleH('overwrite', 'Overwrite protection', 'Blocks a write that would erase most of a file'),
        toggleH('backup', 'Backup before changes', 'Last 60 old file versions kept in memory'),
        toggleH('structure', 'Project structure checks', 'File count, folder depth, missing references'),
        toggleH('errors', 'Error reporting hints', 'Classifies failed tool calls'),
        toggleH('autoTest', 'Run tests before finishing', 'Slower: runs the page in the sandbox at the end')));
      box.appendChild(h('div.sec', 'File rules'));
      var fc = UI.card(), rules = M.fileRules();
      if (!rules.length) fc.appendChild(h('div.t2', 'No file rules. Example: deny writes to data/**'));
      rules.forEach(function (r, i) {
        var idx = r.scope === 'project' ? RC.store.cur.fileRules.indexOf(RC.store.cur.fileRules.filter(function (x) { return x.glob === r.glob && x.level === r.level; })[0]) : (RC.settings.perms.files || []).indexOf((RC.settings.perms.files || []).filter(function (x) { return x.glob === r.glob && x.level === r.level; })[0]);
        fc.appendChild(h('div.setrow', h('div.grow', h('div.t1', r.glob), h('div.t2', r.level.toUpperCase() + (r.ops ? ' · ' + r.ops.join(',') : ' · all operations') + ' · ' + r.scope)), UI.rbtn('trash', function () { M.removeFileRule(idx, r.scope); refresh(); }, 'Remove', 'sm')));
      });
      fc.appendChild(UI.btn('Add file rule', 'plus', 'sm', function () {
        UI.prompt('File rule', '', 'pattern level  e.g.  data/** deny').then(function (v) {
          if (!v) return;
          var m = /^\s*(\S+)\s+(allow|ask|deny)\s*(?:\s(read|write|delete|exec)(?:,(read|write|delete|exec))*)?\s*$/i.exec(v);
          if (!m) { UI.toast('Use: pattern allow|ask|deny'); return; }
          M.addFileRule(m[1], m[2].toLowerCase(), null, scope); open();
        });
      }));
      box.appendChild(fc);
      box.appendChild(h('div.sec', 'Permission history'));
      var hc = UI.card(), hs = M.history().slice(0, 25);
      if (!hs.length) hc.appendChild(h('div.t2', 'Nothing yet.'));
      hs.forEach(function (x) { hc.appendChild(h('div.setrow', h('div.grow', h('div.t1.ell', x.tool + ' ' + x.target), h('div.t2', x.decision + ' · ' + x.mode + ' · ' + U.ago(x.t) + (x.why ? ' · ' + U.clip(x.why, 60, '…') : ''))))); });
      if (hs.length) hc.appendChild(UI.btn('Clear history', 'trash', 'sm ghost', function () { M.clearHistory(); refresh(); }));
      box.appendChild(hc);
      return box;
    }
    function toggleP(key, label, sub) {
      var P = RC.settings.perms, t = h('div.tog' + (P[key] !== false ? '.on' : ''));
      return h('button.setrow', { style: { width: '100%', textAlign: 'left' }, onclick: function () { P[key] = P[key] === false; t.classList.toggle('on', P[key] !== false); RC.saveSettings(); } }, h('div.grow', h('div.t1', label), h('div.t2', sub)), t);
    }
    function toggleH(key, label, sub) {
      var H = RC.settings.hooks, t = h('div.tog' + (H[key] !== false && !(key === 'autoTest' && !H[key]) ? '.on' : ''));
      return h('button.setrow', { style: { width: '100%', textAlign: 'left' }, onclick: function () { H[key] = key === 'autoTest' ? !H[key] : H[key] === false; t.classList.toggle('on', key === 'autoTest' ? !!H[key] : H[key] !== false); RC.saveSettings(); } }, h('div.grow', h('div.t1', label), h('div.t2', sub)), t);
    }
    function refresh() { var top = UI.sheetStack[UI.sheetStack.length - 1]; if (top && top.isPerms) { top.body = body(); UI.sheetRepaint(); } }
    UI.sheetStack.length && UI.closeSheet(true);
    UI.sheet({ title: 'Permissions', body: body(), isPerms: true });
  }
  UI.openPerms = open;
})();
