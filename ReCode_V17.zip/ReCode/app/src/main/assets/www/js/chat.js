/* ReCode - the Build tab: conversation, live work card, composer. */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var U = RC.u, h = U.h, UI = RC.ui, St = RC.store, P = RC.pipe, N = RC.native;
  var col = U.$('#chatcol');
  var msgs = h('div.scroll'), wrap = h('div.msgwrap'), ta, sendBtn, liveEl = null, follow = true, timer = null;
  msgs.appendChild(wrap);
  msgs.addEventListener('scroll', function () { follow = msgs.scrollHeight - msgs.scrollTop - msgs.clientHeight < 80; });

  var SUGG = [
    ['globe', 'Landing page', 'Build a modern landing page for a coffee shop with a menu and contact form'],
    ['check', 'Todo app', 'Create a todo app that saves tasks in localStorage with filters and dark mode'],
    ['bolt', 'Calculator', 'Make a scientific calculator with history, mobile friendly'],
    ['box', 'Zip project', 'Build a small snake game with html, css and js and give it to me as a zip']
  ];

  // ------------------------------------------------------------------ rich text with code widgets
  function codeBlock(c) {
    var lang = (c.lang || '').toLowerCase();
    var runnable = /^(html|htm|svg|js|javascript)$/.test(lang) || (!lang && /<html|<!doctype/i.test(c.code));
    var pre = h('pre', { html: U.hl(c.code, lang) });
    var hd = h('div.hd', h('b', lang || 'code'),
      runnable ? h('button', { html: RC.i('play', 14) + ' Run', onclick: function () { UI.runSnippet(c.code, lang); } }) : null,
      h('button', { html: RC.i('download', 14) + ' Save', onclick: function () { saveSnippet(c, lang); } }),
      h('button', { html: RC.i('copy', 14) + ' Copy', onclick: function () { N.copy(c.code).then(function () { UI.toast('Copied'); }, function () { }); } }));
    return h('div.codeblk', hd, pre);
  }
  function saveSnippet(c, lang) {
    var ext = ({ javascript: 'js', python: 'py', typescript: 'ts', markdown: 'md' })[lang] || lang || 'txt';
    UI.prompt('Save into project as', 'snippet.' + ext).then(function (n) {
      if (!n) return; n = U.normPath(n);
      if (!U.validPath(n)) return UI.toast('Use a name like app.js');
      St.putFile(n, c.code).then(function () { UI.toast('Saved ' + n); });
    });
  }
  UI.rich = function (text) {
    var box = h('div.ai');
    U.mdSplit(text).forEach(function (p) {
      if (p.type === 'text') { if (p.text.trim()) box.appendChild(h('div', { html: U.md(p.text) })); }
      else box.appendChild(codeBlock(p));
    });
    U.$$('a[data-href]', box).forEach(function (a) { a.onclick = function (e) { e.preventDefault(); N.open(a.getAttribute('data-href')); }; });
    return box;
  };

  // ------------------------------------------------------------------ messages
  function workCard(run, live) {
    var card = h('button.work.hd', { style: { width: '100%', textAlign: 'left', display: 'block', padding: 0 }, onclick: function () { UI.openActivity(live ? null : run); } });
    paintWork(card, run, live);
    return card;
  }
  function paintWork(card, run, live) {
    U.clear(card);
    var cur = run.steps.filter(function (s) { return s.status === 'running'; }).pop() || run.steps[run.steps.length - 1];
    var ok = run.status === 'done', err = run.status === 'error';
    var head = h('div.hd', { style: { display: 'flex' } });
    if (live && run.status === 'running') {
      head.appendChild(h('div.spin'));
      head.appendChild(h('div.tt', h('div.a', cur ? (cur.kind === 'tool' ? 'Running command' : RC.agents.def[cur.agent].name + ' · ' + (({ loading: 'loading model', thinking: 'thinking', writing: 'writing' })[cur.phase] || 'starting')) : 'Starting'),
        h('div.b.pulse', cur ? cur.title : 'Getting ready…')));
      head.appendChild(h('div.tm.live', { 'data-t0': run.t0 }, U.dur(Date.now() - run.t0)));
    } else {
      head.appendChild(ok ? h('div.dotok', { html: RC.i('check', 12) }) : h('div.dotok.doterr', { html: RC.i(err ? 'x' : 'pause', 12) }));
      head.appendChild(h('div.tt', h('div.b', (ok ? 'Worked for ' : run.status === 'stopped' ? 'Stopped after ' : 'Failed after ') + U.dur((run.t1 || Date.now()) - run.t0)),
        h('div.t2', run.steps.length + ' steps · tap to see every agent')));
    }
    head.appendChild(h('span', { html: RC.i('chevR', 16), style: { color: 'var(--muted2)' } }));
    card.appendChild(head);
    if (live && cur && cur.out && cur.kind !== 'tool') {
      var tail = cur.out.split('\n').slice(-4).join('\n');
      card.appendChild(h('div.tail', U.clip(tail, 400, '')));
    }
  }
  function chips(run) {
    var box = h('div', { style: { marginTop: '4px' } });
    (run.files || []).forEach(function (p) {
      box.appendChild(h('button.chipfile', { onclick: function () { UI.mods.files.open(p); } }, h('span', { html: RC.i('file', 15), style: { color: 'var(--brand)' } }), p));
    });
    return box;
  }
  function actions(m) {
    var run = m.run, box = h('div.acts'), n = St.fileList().length;
    if (run && (run.mode === 'build' || run.mode === 'agent') && run.files.length) {
      box.appendChild(UI.btn('Run preview', 'play', 'sm', function () { UI.go('run'); }));
      box.appendChild(UI.btn('Download ZIP', 'download', 'sm ghost', function () { downloadZip(); }));
    }
    box.appendChild(UI.btn('Copy', 'copy', 'sm ghost', function () { N.copy(m.text).then(function () { UI.toast('Copied'); }, function () { }); }));
    return box;
  }
  function downloadZip() {
    if (!St.fileList().length) return UI.toast('The project has no files yet');
    N.save(P.zipName(), P.zipBytes(), 'application/zip').then(function () { UI.toast('ZIP saved'); }, function (e) { if (e.message !== 'cancelled') UI.toast(e.message); });
  }
  UI.downloadZip = downloadZip;

  function msgEl(m) {
    if (m.role === 'user') return h('div.msg.user', h('div.bubble', m.text));
    var el = h('div.msg');
    if (m.run && m.run.steps.length) el.appendChild(workCard(m.run, false));
    el.appendChild(UI.rich(m.text || ''));
    if (m.run && m.run.files && m.run.files.length) el.appendChild(chips(m.run));
    if (m.plan) el.appendChild(UI.planActions(m, executePlan));
    el.appendChild(actions(m));
    return el;
  }

  function hero() {
    var rdy = RC.llm.ready(), box = h('div.hero');
    box.appendChild(h('div.hero-mark', { html: RC.logo(42) }));
    box.appendChild(h('h2', 'Good to see you.'));
    box.appendChild(h('p', 'What would you like to make today?'));
    box.appendChild(h('button.card.modelcard', { onclick: function () { modelPicker(); } },
      h('div.ico.fill', { html: RC.i('cpu', 20) }),
      h('div.grow', h('div.t1.ell', rdy.ok ? RC.llm.label() : 'Add a model to start'), h('div.t2.ell', rdy.ok ? (RC.settings.provider === 'api' ? 'Online API · needs internet' : 'On-device · works offline') : rdy.why)),
      rdy.ok ? h('span.badge', 'Ready') : h('span.badge.warn', 'Setup')));
    var g = h('div.sugg');
    SUGG.forEach(function (s) {
      g.appendChild(h('button', { onclick: function () { ta.value = s[2]; grow(); ta.focus(); } }, h('div.ico', { html: RC.i(s[0], 19) }), h('div.grow', h('div.t1', s[1]), h('div.t2.ell', s[2]))));
    });
    box.appendChild(g);
    return box;
  }

  function modelPicker() {
    var list = N.models(), box = h('div.model-picker');
    if (RC.settings.provider === 'api') {
      box.appendChild(h('button.model-option.on', { onclick: function () { UI.closeSheet(true); UI.go('lib'); } },
        h('div.model-symbol', { html: RC.i('globe', 19) }), h('div.grow', h('b', RC.settings.api.model || 'Online API'), h('small', 'OpenAI-compatible provider')), h('span.badge', 'Active')));
    } else if (!list.length) {
      box.appendChild(h('div.model-empty', 'No local model is installed yet. Add a model to start chatting.'));
    }
    list.forEach(function (m) {
      var active = RC.settings.model === m.name;
      box.appendChild(h('button.model-option' + (active ? '.on' : ''), { onclick: function () { RC.set('provider', 'local'); RC.set('model', m.name); UI.closeSheet(true); UI.toast('Model selected'); render(); } },
        h('div.model-symbol', { html: RC.i('cpu', 19) }), h('div.grow', h('b', m.name.replace(/\.gguf$/i, '')), h('small', active ? 'Currently selected' : 'On-device model')), active ? h('span', { html: RC.i('check', 19), style: { color: 'var(--brand)' } }) : null));
    });
    box.appendChild(h('div.model-divider'));
    box.appendChild(h('button.model-option', { onclick: function () { UI.closeSheet(true); UI.go('lib'); } }, h('div.model-symbol', { html: RC.i('settings', 19) }), h('div.grow', h('b', 'More models and providers'), h('small', 'Manage local models or connect an API')), h('span', { html: RC.i('chevR', 18) })));
    UI.sheet({ title: 'Choose a model', body: box });
  }

  function attachSheet() {
    var body = h('div.attach-grid');
    [['camera', 'Camera', function () { UI.closeSheet(true); UI.toast('Camera capture is not available in this build yet.'); }],
     ['image', 'Photos', function () { UI.closeSheet(true); UI.toast('Photo picker is not available in this build yet.'); }],
     ['file', 'Files', function () { UI.closeSheet(true); attach(); }]].forEach(function (a) {
      body.appendChild(h('button.attach-tile', { onclick: a[2] }, h('span', { html: RC.i(a[0], 22) }), a[1]));
    });
    body.appendChild(h('div.hr'));
    body.appendChild(h('button.attach-row', { onclick: function () { UI.closeSheet(true); UI.go('projects'); } }, h('span', { html: RC.i('folder', 19) }), h('span.grow', h('b', 'Add to project'), h('small', St.cur ? St.cur.name : 'Choose a project')) , h('span', { html: RC.i('chevR', 17) })));
    body.appendChild(h('button.attach-row', { onclick: function () { RC.set('webChat', !RC.settings.webChat); UI.sheetStack.length && UI.sheetRepaint(); } }, h('span', { html: RC.i('globe', 19) }), h('span.grow', h('b', 'Web search'), h('small', 'Allow web research in this chat')), h('span.attach-state' + (RC.settings.webChat ? '.on' : ''), RC.settings.webChat ? 'On' : 'Off')));
    UI.sheet({ title: 'Add to chat', body: body });
  }

  function render() {
    U.clear(wrap); liveEl = null;
    if (!St.msgs.length && !P.current) wrap.appendChild(hero());
    St.msgs.forEach(function (m) { wrap.appendChild(msgEl(m)); });
    if (P.current) { liveEl = liveMsg(P.current); wrap.appendChild(liveEl); }
    if (follow && (St.msgs.length || P.current)) bottom(); else if (!St.msgs.length) msgs.scrollTop = 0;
  }
  function liveMsg(run) {
    var el = h('div.msg'), card = workCard(run, true), body = h('div');
    el.appendChild(card); el.appendChild(body); el._card = card; el._body = body; el._run = run;
    return el;
  }
  function bottom() { msgs.scrollTop = msgs.scrollHeight; }

  // live updates while a run is active
  RC.bus.on('run', U.raf(function () {
    var run = P.current;
    if (!liveEl || !run || liveEl._run !== run) return;
    paintWork(liveEl._card, run, true);
    if (run.mode === 'agent') {
      U.clear(liveEl._body);
      if (run.files.length) liveEl._body.appendChild(chips(run));
    } else if (run.mode !== 'build') {
      var s = run.steps.filter(function (x) { return x.agent === 'assistant'; }).pop();
      if (s && s.out) { U.clear(liveEl._body); liveEl._body.appendChild(UI.rich(RC.agents.stripThink(s.out))); }
    } else if (run.files.length) {
      U.clear(liveEl._body); liveEl._body.appendChild(chips(run));
    }
    if (follow) bottom();
  }));
  RC.bus.on('project', function () { follow = true; render(); });
  RC.bus.on('settings', function () { if (!St.msgs.length) render(); paintModes(); });
  setInterval(function () { U.$$('.tm.live').forEach(function (e) { e.textContent = U.dur(Date.now() - (+e.getAttribute('data-t0'))); }); }, 1000);

  // ------------------------------------------------------------------ composer
  var modesBox = h('div.modes');
  function paintModes() {
    U.clear(modesBox);
    [['auto', 'Auto'], ['build', 'Build'], ['agent', 'Agent'], ['chat', 'Chat'], ['research', 'Research']].forEach(function (m) {
      modesBox.appendChild(h('button.chip' + (RC.settings.mode === m[0] ? '.on' : ''), { onclick: function () { RC.set('mode', m[0]); } }, m[1]));
    });
    if (RC.settings.mode === 'agent' || RC.settings.autoAgent) {
      [['plan', 'Plan'], ['ask', 'Ask'], ['auto', 'Auto-approve']].forEach(function (m) {
        modesBox.appendChild(h('button.chip' + (RC.perms.mode() === m[0] ? '.on' : ''), { style: { outline: '2px solid var(--line)' }, onclick: function () { RC.set('permMode', m[0]); } }, h('span', { html: RC.i('shield', 14) }), m[1]));
      });
    }
    modesBox.appendChild(h('button.chip' + (RC.settings.webChat ? '.on' : ''), { onclick: function () { RC.set('webChat', !RC.settings.webChat); } }, h('span', { html: RC.i('globe', 14) }), 'Web'));
    modesBox.appendChild(h('button.chip' + (RC.settings.useRag ? '.on' : ''), { onclick: function () { RC.set('useRag', !RC.settings.useRag); } }, h('span', { html: RC.i('book', 14) }), 'Knowledge'));
  }
  function grow() { ta.style.height = 'auto'; ta.style.height = Math.min(ta.scrollHeight, 140) + 'px'; }
  function paintSend() {
    var running = !!P.current;
    sendBtn.className = 'send' + (running ? ' stop' : '');
    sendBtn.innerHTML = RC.i(running ? 'stop' : 'send', 20);
  }
  function attach() {
    N.pickDocs().then(function (docs) {
      var ok = docs.filter(function (d) { return d.text; });
      docs.filter(function (d) { return d.error; }).forEach(function (d) { UI.toast(d.name + ': ' + d.error); });
      if (!ok.length) return;
      Promise.all(ok.map(function (d) { return St.addKb({ pid: St.cur.id, name: d.name, text: d.text }); })).then(function () { UI.toast(ok.length + ' file(s) added to this project\'s knowledge'); });
    }, function (e) { UI.toast(e.message); });
  }
  /** an approved plan runs as a normal agent request (permission mode: Ask, or Auto if the user chose Auto-approve before planning) */
  function executePlan(pl) {
    if (P.current) { UI.toast('Wait for the current run to finish'); return; }
    var next = RC.settings.planThen === 'auto' ? 'auto' : 'ask';
    RC.set('permMode', next);
    var text = 'Execute this approved plan. Request: ' + pl.original + '\n\nPLAN:\n' + pl.text;
    St.addMsg({ role: 'user', text: 'Approved plan - executing.' }).then(function () {
      var run = P.start(text, 'agent');
      render(); paintSend();
      run.done.then(function () { return St.addMsg({ role: 'assistant', text: run.final, run: UI.timeline.slim(run) }); }).then(function () { paintSend(); render(); });
    });
  }
  function send() {
    if (P.current) { P.stop(); return; }
    var text = ta.value.trim(); if (!text) return;
    var rdy = RC.llm.ready();
    if (!rdy.ok) { UI.toast(rdy.why); UI.go('lib'); return; }
    ta.value = ''; grow(); follow = true;
    St.addMsg({ role: 'user', text: text }).then(function () {
      var run = P.start(text, RC.settings.mode);
      render(); paintSend();
      run.done.then(function () {
        var m = { role: 'assistant', text: run.final, run: UI.timeline.slim(run) };
        if (run.plan) m.plan = { text: run.plan, status: 'pending', task: run.title, original: text };
        return St.addMsg(m);
      }).then(function () {
        paintSend(); render();
        if (UI.wide && P.lastWasBuild !== false && St.fileList().length) { /* keep the user's tab */ }
      });
    });
  }

  var composer = h('div#composer', h('div.cwrap', modesBox, (function () {
    ta = h('textarea', { rows: 1, placeholder: 'Message ReCode…', oninput: grow, onkeydown: function (e) { if (e.key === 'Enter' && !e.shiftKey && UI.wide) { e.preventDefault(); send(); } } });
    sendBtn = h('button.send', { onclick: send, 'aria-label': 'Send' });
    return h('div.cbox', h('button.cbtn', { html: RC.i('plus', 22), onclick: attachSheet, 'aria-label': 'Add to chat' }), ta, sendBtn);
  })()));
  col.appendChild(msgs); col.appendChild(composer);
  paintModes(); paintSend();
  RC.bus.on('run', function (r) { if (r.status !== 'running') paintSend(); else if (sendBtn.className.indexOf('stop') < 0) paintSend(); });

  UI.openModelPicker = modelPicker;
  UI.mods.build = { show: function () { render(); paintSend(); }, render: render };
})();
