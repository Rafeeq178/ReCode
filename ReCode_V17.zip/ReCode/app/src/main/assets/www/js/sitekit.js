/* ReCode v8 - SITE KIT. Builds a complete, responsive, bug-free website (HTML + CSS + JS + SVG logo/hero/favicon) from a small spec.
   The model is not asked to write layout code (small models leave sections empty or break images); it only supplies the TEXT
   (name, tagline, items) as short JSON. Everything else is tested code. Types: coffee, restaurant, portfolio, business, shop, saas, blog, generic. */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var A = RC.assets, esc = A.esc;

  var TYPES = [
    ['coffee', /\b(coffee|cafe|café|espresso|chai|tea shop|tea house|bakery|barista)\b/i],
    ['restaurant', /\b(restaurant|food|pizza|burger|biryani|grill|bbq|dine|dining|kitchen|fast ?food)\b/i],
    ['portfolio', /\b(portfolio|resume|cv|personal (site|website|page)|freelanc\w+|developer site)\b/i],
    ['shop', /\b(shop|store|ecommerce|e-commerce|products?|clothing|fashion|boutique|sale)\b/i],
    ['saas', /\b(saas|software|startup|app landing|ai tool|platform|dashboard)\b/i],
    ['blog', /\b(blog|magazine|news|articles?)\b/i],
    ['business', /\b(business|company|agency|services?|consult\w*|clinic|salon|gym|school|academy|real estate|travel)\b/i]
  ];
  var SITE_RE = /\b(web ?site|landing( page)?|home ?page|web ?page|portfolio|blog|online store|business site)\b|\b(site|page)\b.*\b(for|of)\b/i;

  var D = {
    coffee: { name: 'Brew & Bean', tag: 'Small-batch coffee, roasted fresh every morning.', about: 'We roast single-origin beans in small batches and brew every cup by hand. Pull up a chair, bring a book, stay a while.',
      nav: 'Menu', itemsTitle: 'Our Menu', itemsSub: 'Fresh coffee, tea and pastries made daily.', cta: 'View menu',
      feats: [['Fresh roasted', 'Beans roasted in-house every week for the fullest flavour.'], ['Hand brewed', 'Espresso, pour-over and cold brew made by trained baristas.'], ['Cozy space', 'Warm lighting, fast Wi-Fi and plenty of seats to work or relax.']],
      items: [['Espresso', 'Rich double shot with a golden crema.', '$3.00'], ['Cappuccino', 'Espresso, steamed milk and thick foam.', '$4.20'], ['Caramel Latte', 'Smooth latte with house-made caramel.', '$4.80'], ['Cold Brew', 'Steeped 18 hours, served over ice.', '$4.50'], ['Butter Croissant', 'Flaky, baked fresh every morning.', '$3.40'], ['Chocolate Cake', 'Dark chocolate layers with ganache.', '$5.20']] },
    restaurant: { name: 'Spice Garden', tag: 'Honest food, bold flavours, made from scratch.', about: 'Our kitchen cooks family recipes with fresh local ingredients. Dine in, take away or order for your next gathering.',
      nav: 'Menu', itemsTitle: 'Our Menu', itemsSub: 'Chef favourites, served hot.', cta: 'See the menu',
      feats: [['Fresh ingredients', 'Vegetables, meat and spices bought fresh every day.'], ['Family recipes', 'Slow-cooked dishes with authentic taste.'], ['Fast service', 'Dine in, take away or delivery in under 30 minutes.']],
      items: [['Chicken Biryani', 'Fragrant rice layered with spiced chicken.', '$8.50'], ['Beef Burger', 'Grilled patty, cheddar and house sauce.', '$7.90'], ['Margherita Pizza', 'Stone-baked with fresh basil and mozzarella.', '$9.20'], ['Grilled Platter', 'Mixed grill with mint chutney.', '$12.50'], ['Caesar Salad', 'Crisp romaine, parmesan, croutons.', '$6.40'], ['Gulab Jamun', 'Warm milk dumplings in sweet syrup.', '$3.80']] },
    portfolio: { name: 'Alex Morgan', tag: 'Developer & designer building clean, fast digital products.', about: 'I design and build websites and apps that are simple to use and reliable. I care about clear code, honest communication and finishing on time.',
      nav: 'Work', itemsTitle: 'Selected Work', itemsSub: 'A few recent projects.', cta: 'See my work',
      feats: [['Web development', 'Responsive websites and web apps built with modern HTML, CSS and JavaScript.'], ['UI design', 'Clean interfaces that feel natural on every screen size.'], ['Support', 'Fixes, updates and hosting help after launch.']],
      items: [['Task Manager App', 'Offline-first to-do app with reminders.', 'Web'], ['Store Front', 'Fast e-commerce landing with cart.', 'Web'], ['Weather Dashboard', 'Live forecast with charts.', 'API'], ['Chat App', 'Real-time messaging with profiles.', 'Full-stack'], ['Brand Identity', 'Logo and style guide for a startup.', 'Design'], ['Blog Theme', 'Lightweight theme with dark mode.', 'Theme']] },
    shop: { name: 'Urban Cart', tag: 'Everyday essentials, delivered to your door.', about: 'We pick quality products at fair prices and ship them fast. Easy returns, secure checkout and friendly support.',
      nav: 'Products', itemsTitle: 'Popular Products', itemsSub: 'Customer favourites this week.', cta: 'Shop now',
      feats: [['Fast delivery', 'Orders leave our warehouse within 24 hours.'], ['Easy returns', '30 days to change your mind, no questions.'], ['Secure payment', 'Encrypted checkout and trusted payment partners.']],
      items: [['Classic Backpack', 'Water-resistant, laptop sleeve.', '$39'], ['Wireless Earbuds', '24-hour battery, clear calls.', '$29'], ['Smart Watch', 'Heart-rate and sleep tracking.', '$59'], ['Desk Lamp', 'Dimmable LED with USB port.', '$24'], ['Water Bottle', 'Insulated steel, 750 ml.', '$18'], ['Phone Stand', 'Foldable aluminium stand.', '$12']] },
    saas: { name: 'Flowly', tag: 'Automate your busywork and get your day back.', about: 'Flowly connects your tools and runs repetitive tasks for you. Set it up in minutes, no code needed.',
      nav: 'Pricing', itemsTitle: 'Simple Pricing', itemsSub: 'Start free. Upgrade when you grow.', cta: 'Get started',
      feats: [['Set up in minutes', 'Pick a template, connect your apps, done.'], ['Works with your tools', 'Email, calendars, spreadsheets and more.'], ['Private by default', 'Your data stays yours, encrypted at rest.']],
      items: [['Free', 'For trying things out. 1 project, 100 runs a month.', '$0'], ['Pro', 'For individuals. 10 projects, unlimited runs.', '$12'], ['Team', 'For teams. Shared workspace and roles.', '$29']] },
    blog: { name: 'The Daily Note', tag: 'Short, useful writing on technology and everyday life.', about: 'A small independent blog. New articles every week, no ads in your face, just clear writing.',
      nav: 'Articles', itemsTitle: 'Latest Articles', itemsSub: 'Fresh posts from the blog.', cta: 'Read articles',
      feats: [['Clear writing', 'Plain language, short paragraphs.'], ['Weekly posts', 'A new article every week.'], ['Open to ideas', 'Tell us what you want us to cover.']],
      items: [['Getting started with web design', 'Five habits that make any page look professional.', '5 min'], ['Faster phones, simple tricks', 'Free up space and battery in ten minutes.', '4 min'], ['How to learn coding alone', 'A realistic plan for self-taught developers.', '7 min'], ['Working offline', 'Tools that keep working without internet.', '6 min']] },
    business: { name: 'Bright Path', tag: 'Reliable professional services for growing businesses.', about: 'Our team helps you plan, launch and grow. We listen first, then deliver clear results on a clear schedule.',
      nav: 'Services', itemsTitle: 'Our Services', itemsSub: 'Everything you need, from one trusted team.', cta: 'Our services',
      feats: [['Experienced team', 'Years of hands-on work across many industries.'], ['Clear pricing', 'Fixed quotes, no hidden costs.'], ['Fast response', 'We reply to every message within one working day.']],
      items: [['Consultation', 'One-to-one planning session for your goals.', 'From $40'], ['Setup & Launch', 'We get everything ready and live.', 'From $250'], ['Monthly Support', 'Ongoing help, updates and reports.', '$99/mo'], ['Training', 'Practical workshops for your team.', 'From $120']] },
    generic: { name: 'My Website', tag: 'Welcome. Here is what we do and how to reach us.', about: 'We are a small team focused on doing a few things really well. Learn more below and get in touch any time.',
      nav: 'Services', itemsTitle: 'What we offer', itemsSub: 'A few things we do best.', cta: 'Learn more',
      feats: [['Quality', 'Careful work you can rely on.'], ['Speed', 'Quick turnaround without cutting corners.'], ['Support', 'Real people who answer your questions.']],
      items: [['Service One', 'A short description of this service.', ''], ['Service Two', 'A short description of this service.', ''], ['Service Three', 'A short description of this service.', '']] }
  };
  var QUOTES = [['Absolutely love it. Friendly people and great quality.', 'Sara K.'], ['Fast, reliable and exactly what I needed.', 'Daniel R.'], ['I recommend it to all my friends.', 'Ayesha M.']];

  function clip(s, n) { s = String(s == null ? '' : s).replace(/\s+/g, ' ').trim(); return s.length > n ? s.slice(0, n - 1).trim() + '…' : s; }

  var K = RC.sitekit = {
    types: D,
    isSite: function (text) { return SITE_RE.test(String(text || '')) && !/\b(python|kotlin|java\b|flutter|android app|apk|react native)\b/i.test(text); },
    detectType: function (text) { for (var i = 0; i < TYPES.length; i++) if (TYPES[i][1].test(text)) return TYPES[i][0]; return 'generic'; },
    /** brand name written in the request: called X / named X / "X" / for X coffee shop */
    detectName: function (text) {
      var m = /\b(?:called|named|name is|naam|brand)\s*[:\-]?\s*["“']?([A-Z][\w&' .-]{1,28})/i.exec(text) || /["“]([^"”]{2,28})["”]/.exec(text);
      return m ? clip(m[1].replace(/[.\s]+$/, ''), 28) : '';
    },
    spec: function (text, copy) {
      var type = K.detectType(text), d = D[type], s = { type: type, name: K.detectName(text) || d.name, tag: d.tag, about: d.about, nav: d.nav, itemsTitle: d.itemsTitle, itemsSub: d.itemsSub, cta: d.cta, feats: d.feats.slice(), items: d.items.slice(), quotes: QUOTES.slice(), phone: '+1 (555) 010-2030', email: 'hello@example.com', address: '123 Main Street, Your City', hours: 'Mon–Sat 8:00–20:00' };
      if (copy && typeof copy === 'object') {
        if (copy.name && !K.detectName(text)) s.name = clip(copy.name, 28);
        if (copy.tagline) s.tag = clip(copy.tagline, 110);
        if (copy.about) s.about = clip(copy.about, 320);
        if (Array.isArray(copy.features) && copy.features.length >= 3) s.feats = copy.features.slice(0, 3).map(function (f, i) { return [clip(f.title || f[0] || d.feats[i][0], 30), clip(f.text || f[1] || d.feats[i][1], 110)]; });
        if (Array.isArray(copy.items) && copy.items.length >= 3) s.items = copy.items.slice(0, 8).map(function (it) { return [clip(it.name || it[0], 34), clip(it.desc || it.text || it[1] || '', 90), clip(it.price || it[2] || '', 12)]; }).filter(function (x) { return x[0]; });
      }
      return s;
    },
    /** parse the JSON the copywriter model returned (tolerant: fenced, extra text) */
    parseCopy: function (text) {
      var t = String(text || ''), a = t.indexOf('{'), b = t.lastIndexOf('}');
      if (a < 0 || b <= a) return null;
      try { var o = JSON.parse(t.slice(a, b + 1)); return o && typeof o === 'object' ? o : null; } catch (e) { return null; }
    },
    files: function (s) {
      var p = A.palette(s.type), year = new Date().getFullYear(), out = {};
      var items = s.items.map(function (it) {
        return '<article class="card reveal"><div class="thumb">' + A.item(it[0], p).replace(/ width="160" height="160"/, '').replace(/<title>[^<]*<\/title>/, '') + '</div><div class="card-body"><h3>' + esc(it[0]) + '</h3><p>' + esc(it[1]) + '</p>' + (it[2] ? '<span class="price">' + esc(it[2]) + '</span>' : '') + '</div></article>';
      }).join('\n      ');
      var feats = s.feats.map(function (f, i) { return '<div class="feat reveal"><span class="num" aria-hidden="true">' + (i + 1) + '</span><h3>' + esc(f[0]) + '</h3><p>' + esc(f[1]) + '</p></div>'; }).join('\n      ');
      var quotes = s.quotes.map(function (q) { return '<figure class="quote reveal"><blockquote>“' + esc(q[0]) + '”</blockquote><figcaption>— ' + esc(q[1]) + '</figcaption></figure>'; }).join('\n      ');
      var itemsId = s.type === 'portfolio' ? 'work' : s.type === 'saas' ? 'pricing' : s.type === 'blog' ? 'articles' : s.type === 'business' ? 'services' : s.type === 'shop' ? 'products' : 'menu';
      out['index.html'] = '<!DOCTYPE html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n<title>' + esc(s.name) + ' – ' + esc(clip(s.tag, 60)) + '</title>\n<meta name="description" content="' + esc(clip(s.about, 150)) + '">\n<meta property="og:title" content="' + esc(s.name) + '">\n<meta property="og:description" content="' + esc(clip(s.tag, 120)) + '">\n<meta name="theme-color" content="' + p.a + '">\n<link rel="icon" href="assets/favicon.svg" type="image/svg+xml">\n<link rel="stylesheet" href="style.css">\n</head>\n<body>\n<a class="skip" href="#main">Skip to content</a>\n' +
        '<header class="top"><div class="wrap bar"><a class="brand" href="#home" aria-label="' + esc(s.name) + ' home"><img src="assets/logo.svg" alt="' + esc(s.name) + ' logo" height="40"></a>\n  <button class="burger" id="burger" aria-label="Open menu" aria-expanded="false" aria-controls="nav"><span></span><span></span><span></span></button>\n  <nav id="nav" aria-label="Main"><a href="#about">About</a><a href="#' + itemsId + '">' + esc(s.nav) + '</a><a href="#reviews">Reviews</a><a class="btn small" href="#contact">Contact</a></nav></div></header>\n<main id="main">\n' +
        '<section class="hero" id="home"><div class="wrap hero-grid"><div class="hero-text"><p class="eyebrow">' + esc(s.name) + '</p><h1>' + esc(s.tag) + '</h1><p class="lead">' + esc(clip(s.about, 150)) + '</p><div class="actions"><a class="btn" href="#' + itemsId + '">' + esc(s.cta) + '</a><a class="btn ghost" href="#contact">Contact us</a></div></div><div class="hero-art"><img src="assets/hero.svg" alt="' + esc(s.name) + ' illustration"></div></div></section>\n' +
        '<section class="band" aria-label="Highlights"><div class="wrap grid3">\n      ' + feats + '\n</div></section>\n' +
        '<section id="about" class="sec"><div class="wrap narrow"><h2>About us</h2><p>' + esc(s.about) + '</p></div></section>\n' +
        '<section id="' + itemsId + '" class="sec alt"><div class="wrap"><h2>' + esc(s.itemsTitle) + '</h2><p class="sub">' + esc(s.itemsSub) + '</p><div class="cards">\n      ' + items + '\n</div></div></section>\n' +
        '<section id="reviews" class="sec"><div class="wrap"><h2>What people say</h2><div class="grid3">\n      ' + quotes + '\n</div></div></section>\n' +
        '<section id="contact" class="sec alt"><div class="wrap contact"><div><h2>Get in touch</h2><p class="sub">Send a message and we will reply soon.</p><ul class="info"><li><strong>Phone</strong> ' + esc(s.phone) + '</li><li><strong>Email</strong> ' + esc(s.email) + '</li><li><strong>Address</strong> ' + esc(s.address) + '</li><li><strong>Hours</strong> ' + esc(s.hours) + '</li></ul></div>\n' +
        '<form id="contactForm" novalidate><div class="field"><label for="cName">Name</label><input id="cName" name="name" type="text" autocomplete="name" required minlength="2"><small class="err" id="eName"></small></div><div class="field"><label for="cEmail">Email</label><input id="cEmail" name="email" type="email" autocomplete="email" required><small class="err" id="eEmail"></small></div><div class="field"><label for="cMsg">Message</label><textarea id="cMsg" name="message" rows="4" required minlength="10"></textarea><small class="err" id="eMsg"></small></div><button class="btn" type="submit">Send message</button><p id="formOk" class="ok" role="status" hidden></p></form></div></section>\n</main>\n' +
        '<footer class="foot"><div class="wrap"><p>© ' + year + ' ' + esc(s.name) + '. All rights reserved.</p><p><a href="#home">Back to top ↑</a></p></div></footer>\n<script src="script.js"></script>\n</body>\n</html>\n';
      out['style.css'] = ':root{--a:' + p.a + ';--b:' + p.b + ';--bg:' + p.bg + ';--ink:' + p.ink + ';--soft:' + p.soft + ';--card:#fff;--muted:#5b6472;--r:18px;--sh:0 8px 28px rgba(0,0,0,.08)}\n@media (prefers-color-scheme:dark){:root{--bg:#14110f;--ink:#f4efe9;--soft:#1e1a17;--card:#241f1c;--muted:#b9b0a6;--sh:0 8px 28px rgba(0,0,0,.4)}}\n' +
        '*{box-sizing:border-box}html{scroll-behavior:smooth;scroll-padding-top:72px}body{margin:0;background:var(--bg);color:var(--ink);font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;line-height:1.6;-webkit-tap-highlight-color:transparent}\nimg,svg{max-width:100%;height:auto;display:block}a{color:var(--a)}h1,h2,h3{line-height:1.2;margin:0 0 .5em;font-family:Georgia,"Times New Roman",serif}h1{font-size:clamp(2rem,6vw,3.4rem)}h2{font-size:clamp(1.6rem,4.5vw,2.3rem)}h3{font-size:1.15rem}p{margin:0 0 1em}\n' +
        '.wrap{width:min(1120px,92%);margin-inline:auto}.narrow{max-width:720px}.skip{position:absolute;left:-999px}.skip:focus{left:8px;top:8px;background:#fff;color:#000;padding:8px 12px;z-index:99}\n:focus-visible{outline:3px solid var(--b);outline-offset:2px}\n' +
        '.top{position:sticky;top:0;z-index:20;background:color-mix(in srgb,var(--bg) 90%,transparent);backdrop-filter:blur(10px);border-bottom:1px solid rgba(128,128,128,.18)}.bar{display:flex;align-items:center;justify-content:space-between;min-height:64px}.brand img{height:40px;width:auto}\n' +
        'nav{display:flex;gap:20px;align-items:center}nav a{text-decoration:none;color:var(--ink);font-weight:600}nav a:hover{color:var(--a)}\n.burger{display:none;background:none;border:0;width:44px;height:44px;cursor:pointer;padding:10px}.burger span{display:block;height:3px;background:var(--ink);margin:5px 0;border-radius:2px;transition:.25s}\n' +
        '.btn{display:inline-block;background:var(--a);color:#fff!important;border:0;border-radius:999px;padding:12px 26px;font:600 1rem system-ui,sans-serif;text-decoration:none;cursor:pointer;min-height:44px;box-shadow:var(--sh);transition:transform .15s}.btn:hover{transform:translateY(-2px)}.btn.small{padding:8px 18px;min-height:0}.btn.ghost{background:transparent;color:var(--a)!important;box-shadow:inset 0 0 0 2px var(--a)}\n' +
        '.hero{padding:clamp(36px,8vw,90px) 0;background:linear-gradient(135deg,var(--bg),var(--soft))}.hero-grid{display:grid;grid-template-columns:1.1fr .9fr;gap:36px;align-items:center}.eyebrow{text-transform:uppercase;letter-spacing:.14em;font-weight:700;color:var(--a);font-size:.85rem}.lead{font-size:1.1rem;color:var(--muted);max-width:52ch}.actions{display:flex;gap:12px;flex-wrap:wrap;margin-top:20px}.hero-art img{border-radius:var(--r);box-shadow:var(--sh);width:100%;aspect-ratio:12/7;object-fit:cover}\n' +
        '.sec{padding:clamp(40px,7vw,84px) 0}.alt{background:var(--soft)}.band{padding:34px 0}.sub{color:var(--muted);margin-bottom:28px}.grid3{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:20px}\n' +
        '.feat{background:var(--card);border-radius:var(--r);padding:22px;box-shadow:var(--sh)}.num{display:inline-grid;place-items:center;width:36px;height:36px;border-radius:50%;background:var(--a);color:#fff;font-weight:700;margin-bottom:10px}\n.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:22px}.card{background:var(--card);border-radius:var(--r);overflow:hidden;box-shadow:var(--sh);display:flex;flex-direction:column}.thumb{background:var(--soft)}.thumb svg{width:100%;height:150px}.card-body{padding:16px 18px 20px}.card-body p{color:var(--muted);margin-bottom:8px}.price{display:inline-block;background:var(--soft);color:var(--a);font-weight:700;padding:3px 12px;border-radius:999px}\n' +
        '.quote{margin:0;background:var(--card);padding:22px;border-radius:var(--r);box-shadow:var(--sh)}.quote blockquote{margin:0 0 10px;font-style:italic}.quote figcaption{color:var(--muted);font-weight:600}\n' +
        '.contact{display:grid;grid-template-columns:1fr 1fr;gap:32px}.info{list-style:none;padding:0;margin:0}.info li{padding:6px 0}form{background:var(--card);padding:24px;border-radius:var(--r);box-shadow:var(--sh)}.field{margin-bottom:14px}label{display:block;font-weight:600;margin-bottom:4px}input,textarea{width:100%;padding:12px 14px;border:2px solid rgba(128,128,128,.3);border-radius:12px;font:inherit;background:var(--bg);color:var(--ink)}input:focus,textarea:focus{border-color:var(--a);outline:none}.err{color:#c62828;display:block;min-height:1.1em}.ok{color:#1b7f3b;font-weight:600;margin:12px 0 0}input.bad,textarea.bad{border-color:#c62828}\n' +
        '.foot{background:#17110d;color:#f1e8df;padding:26px 0;text-align:center}.foot p{margin:4px 0}.foot a{color:var(--b)}\n' +
        '.js .reveal.pre{opacity:0;transform:translateY(18px)}.js .reveal{transition:opacity .6s ease,transform .6s ease}.js .reveal.in{opacity:1;transform:none}\n' +
        '@media (max-width:760px){.burger{display:block}nav{position:absolute;left:0;right:0;top:100%;flex-direction:column;align-items:stretch;gap:0;background:var(--bg);border-bottom:1px solid rgba(128,128,128,.2);max-height:0;overflow:hidden;transition:max-height .3s}nav.open{max-height:360px}nav a{padding:14px 5%}nav .btn{margin:8px 5% 14px;text-align:center}.hero-grid,.contact{grid-template-columns:1fr}.hero-art{order:-1}}\n' +
        '@media (prefers-reduced-motion:reduce){*{transition:none!important;animation:none!important;scroll-behavior:auto!important}}\n';
      out['script.js'] = '(function () {\n  "use strict";\n  document.documentElement.classList.add("js");\n  var burger = document.getElementById("burger"), nav = document.getElementById("nav");\n  function setMenu(open) { nav.classList.toggle("open", open); burger.setAttribute("aria-expanded", String(open)); burger.setAttribute("aria-label", open ? "Close menu" : "Open menu"); }\n  if (burger && nav) {\n    burger.addEventListener("click", function () { setMenu(!nav.classList.contains("open")); });\n    nav.addEventListener("click", function (e) { if (e.target.tagName === "A") setMenu(false); });\n  }\n  // scroll reveal: content is visible by default; hidden only while the observer is ready, and always shown after 1.5s\n  var items = [].slice.call(document.querySelectorAll(".reveal"));\n  if ("IntersectionObserver" in window && items.length) {\n    var io = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } }); }, { threshold: 0.12 });\n    items.forEach(function (el) { el.classList.add("pre"); io.observe(el); });\n    setTimeout(function () { items.forEach(function (el) { el.classList.add("in"); }); }, 1500);\n  }\n  var form = document.getElementById("contactForm");\n  function fail(id, input, msg) { document.getElementById(id).textContent = msg; input.classList.toggle("bad", !!msg); return !msg; }\n  if (form) form.addEventListener("submit", function (e) {\n    e.preventDefault();\n    var n = document.getElementById("cName"), m = document.getElementById("cEmail"), t = document.getElementById("cMsg"), ok = document.getElementById("formOk");\n    var a = fail("eName", n, n.value.trim().length < 2 ? "Please enter your name." : "");\n    var b = fail("eEmail", m, /^[^\\s@]+@[^\\s@]+\\.[^\\s@]{2,}$/.test(m.value.trim()) ? "" : "Please enter a valid email.");\n    var c = fail("eMsg", t, t.value.trim().length < 10 ? "Message must be at least 10 characters." : "");\n    if (!(a && b && c)) { ok.hidden = true; return; }\n    try { var list = JSON.parse(localStorage.getItem("messages") || "[]"); list.push({ name: n.value.trim(), email: m.value.trim(), message: t.value.trim(), at: new Date().toISOString() }); localStorage.setItem("messages", JSON.stringify(list.slice(-50))); } catch (err) { /* storage can be blocked: the message is still acknowledged */ }\n    ok.textContent = "Thank you, " + n.value.trim() + "! Your message was received."; ok.hidden = false; form.reset();\n  });\n})();\n';
      out['assets/logo.svg'] = A.logo(s.name, p);
      out['assets/hero.svg'] = A.hero(s.name, p, s.type);
      out['assets/favicon.svg'] = A.mark(s.name, p, 64);
      return out;
    }
  };
})();
