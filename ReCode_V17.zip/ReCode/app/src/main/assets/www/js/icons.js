/* ReCode - icon set (24x24, stroke based). RC.i('name', size) -> svg string. */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var P = {
    menu: 'M5 8h14M5 16h9',
    message: 'M4 5h16v12H8l-4 3V5z',
    image: 'M4 4h16v16H4zM4 15l5-5 4 4 3-3 4 4M9 8h.01',
    camera: 'M4 7h4l2-2h4l2 2h4v12H4zM12 10a4 4 0 1 0 0 8 4 4 0 0 0 0-8z',
    settings: 'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM4 12l2-1 1-3-1-2 2-2 2 1 3-1 1-2h3l1 2 3 1 2-1 2 2-1 2 1 3 2 1v3l-2 1-1 3 1 2-2 2-2-1-3 1-1 2h-3l-1-2-3-1-2 1-2-2 1-2-1-3-2-1z',
    send: 'M12 19V5M5 12l7-7 7 7',
    code: 'M8 8l-5 4 5 4M16 8l5 4-5 4M14 5l-4 14',
    folder: 'M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7z',
    play: 'M8 5.5v13l11-6.5z',
    grid: 'M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z',
    sliders: 'M4 7h8M16 7h4M4 17h3M11 17h9M14 4v6M9 14v6',
    plus: 'M12 5v14M5 12h14',
    x: 'M6 6l12 12M18 6L6 18',
    check: 'M5 12.5l4.5 4.5L19 7.5',
    chevR: 'M9 6l6 6-6 6',
    chevL: 'M15 6l-6 6 6 6',
    chevD: 'M6 9l6 6 6-6',
    trash: 'M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3',
    download: 'M12 4v11M7 11l5 5 5-5M5 20h14',
    upload: 'M12 16V5M7 9l5-5 5 5M5 20h14',
    copy: 'M9 9h11v11H9zM5 15V4h11',
    edit: 'M4 20l1-4L16 5l3 3L8 19l-4 1zM14 7l3 3',
    search: 'M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM20 20l-4-4',
    globe: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18',
    cpu: 'M7 7h10v10H7zM10 10h4v4h-4zM9 3v4M15 3v4M9 17v4M15 17v4M3 9h4M3 15h4M17 9h4M17 15h4',
    box: 'M4 8l8-4 8 4v8l-8 4-8-4V8zM4 8l8 4 8-4M12 12v8',
    refresh: 'M20 5v5h-5M4 19v-5h5M5.6 9A7.5 7.5 0 0 1 19 8l1 2M18.4 15A7.5 7.5 0 0 1 5 16l-1-2',
    terminal: 'M4 5h16v14H4zM8 10l3 2-3 2M13 15h4',
    book: 'M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3V4zM5 17a3 3 0 0 1 3-3h11',
    spark: 'M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3zM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8L19 16z',
    file: 'M6 3h8l4 4v14H6zM14 3v4h4',
    clock: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 7v5l3 2',
    info: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 11v5M12 8h.01',
    layers: 'M12 3l9 5-9 5-9-5 9-5zM3 13l9 5 9-5',
    eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z',
    more: 'M12 6h.01M12 12h.01M12 18h.01',
    link: 'M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1',
    wifiOff: 'M3 3l18 18M8.5 8.5A11 11 0 0 0 3 12M5 15a8 8 0 0 1 5-3M12 20h.01M16 11a11 11 0 0 1 5 1M11 5a14 14 0 0 1 10 4',
    shield: 'M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3z',
    bolt: 'M13 3L5 14h6l-1 7 8-11h-6l1-7z',
    tool: 'M14.7 6.3a4 4 0 0 0-5 5L3 18l3 3 6.7-6.7a4 4 0 0 0 5-5l-2.4 2.4-2.6-.6-.6-2.6 2.6-2.2z',
    pause: 'M8 5v14M16 5v14',
    expand: 'M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5',
    star: 'M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9L12 3z'
  };
  RC.i = function (name, size, cls) {
    size = size || 20;
    if (name === 'stop') return '<svg class="ic ' + (cls || '') + '" width="' + size + '" height="' + size + '" viewBox="0 0 24 24" fill="currentColor"><rect x="7" y="7" width="10" height="10" rx="2.4"/></svg>';
    if (name === 'play') return '<svg class="ic ' + (cls || '') + '" width="' + size + '" height="' + size + '" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"><path d="' + P.play + '"/></svg>';
    var d = P[name] || P.info;
    return '<svg class="ic ' + (cls || '') + '" width="' + size + '" height="' + size + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="' + d + '"/></svg>';
  };
  /** Brand mark (code brackets around a reload loop) - same geometry as the Android launcher icon. */
  RC.logo = function (size, tile) {
    var g = '<g fill="none" stroke="#fff" stroke-width="4.4" stroke-linecap="round" stroke-linejoin="round"><path d="M40.5 42L29.5 54l11 12M67.5 42l11 12-11 12M58.6 46.2A9 9 0 1 1 49.4 46.2"/></g><path d="M54.2 41.6L47.2 44.6l4 6.4z" fill="#fff" stroke="#fff" stroke-width="1.6" stroke-linejoin="round"/>';
    var bg = tile === false ? '' : '<defs><linearGradient id="lg' + size + '" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#DB7A58"/><stop offset="1" stop-color="#B4512F"/></linearGradient></defs><rect x="24" y="24" width="60" height="60" rx="17" fill="url(#lg' + size + ')"/>';
    return '<svg width="' + size + '" height="' + size + '" viewBox="24 24 60 60" aria-label="ReCode">' + bg + g + '</svg>';
  };
})();
