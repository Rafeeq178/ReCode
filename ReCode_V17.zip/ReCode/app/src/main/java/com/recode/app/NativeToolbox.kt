package com.recode.app

import android.content.Context
import android.content.pm.PackageManager
import android.os.ParcelFileDescriptor
import android.webkit.WebView
import android.webkit.WebViewClient
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import dev.rikka.shizuku.Shizuku
import moe.shizuku.server.IShizukuService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.eclipse.jgit.api.Git
import java.io.File
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference
import java.util.concurrent.TimeUnit

/** Native integrations are deliberately scoped to ReCode's private workspace. */
object NativeToolbox {
    private val gson = Gson()
    private val browserLock = Any()
    private val browserMutex = Mutex()
    private var browser: WebView? = null
    private var browserReady = false

    fun workspace(context: Context): File = File(context.filesDir, "recode-workspace").apply { mkdirs() }

    suspend fun writeWorkspaceFile(context: Context, relativePath: String, content: String): String = withContext(Dispatchers.IO) {
        require(relativePath.isNotBlank() && !relativePath.startsWith("/") && !relativePath.contains("..")) { "Invalid workspace path." }
        val root = workspace(context).canonicalFile
        val target = File(root, relativePath).canonicalFile
        require(target.path.startsWith(root.path + File.separator)) { "Path escapes workspace." }
        target.parentFile?.mkdirs()
        target.writeText(content, Charsets.UTF_8)
        "Wrote ${relativePath} (${content.length} chars)"
    }

    suspend fun shell(context: Context, command: String, timeoutSeconds: Int = 45): String = withContext(Dispatchers.IO) {
        require(command.isNotBlank() && command.length <= 4000) { "Command is empty or too long." }
        require(!Regex("(^|[;&|`]\\s*(rm\\s+-rf\\s+/|mkfs|dd\\s+if=|reboot|poweroff)|\\$\\(|>\\s*/)", RegexOption.IGNORE_CASE).containsMatchIn(command)) {
            "Blocked potentially destructive shell syntax."
        }
        val dir = workspace(context)
        val p = ProcessBuilder("/system/bin/sh", "-c", command)
            .directory(dir).redirectErrorStream(true)
        p.environment().clear()
        p.environment()["HOME"] = dir.absolutePath
        p.environment()["PATH"] = "/system/bin:/system/xbin"
        val process = p.start()
        val output = AtomicReference("")
        val reader = Thread { output.set(runCatching { process.inputStream.bufferedReader().use { it.readText().take(24000) } }.getOrDefault("")) }
        reader.start()
        val finished = process.waitFor(timeoutSeconds.coerceIn(1, 120).toLong(), TimeUnit.SECONDS)
        if (!finished) { process.destroyForcibly(); throw IllegalStateException("Command timed out after ${timeoutSeconds}s") }
        reader.join(1500)
        "exit=${process.exitValue()}\n${output.get()}".trim()
    }

    suspend fun git(context: Context, action: String, message: String = "ReCode update"): String = withContext(Dispatchers.IO) {
        val dir = workspace(context)
        when (action.lowercase()) {
            "init" -> {
                if (File(dir, ".git").exists()) return@withContext "Git repository already initialized at ${dir.absolutePath}"
                Git.init().setDirectory(dir).call().use { "Initialized Git repository at ${dir.absolutePath}" }
            }
            "status" -> {
                val git = Git.open(dir)
                git.use { g ->
                    val s = g.status().call()
                    "branch=${g.repository.branch}\nadded=${s.added}\nchanged=${s.changed}\nmodified=${s.modified}\nuntracked=${s.untracked}\nremoved=${s.removed}"
                }
            }
            "commit" -> {
                val git = Git.open(dir)
                git.use { g ->
                    g.add().addFilepattern(".").call()
                    val result = g.commit().setMessage(message.take(200)).setAllowEmpty(false).call()
                    "Committed ${result.name} — ${result.shortMessage}"
                }
            }
            "branches" -> Git.open(dir).use { g -> g.branchList().call().joinToString("\n") { it.name } }
            else -> error("Unsupported Git action: $action")
        }
    }

    suspend fun mcp(context: Context, endpoint: String, method: String, params: String): String = withContext(Dispatchers.IO) {
        val uri = URL(endpoint)
        require(uri.protocol == "https" || (uri.protocol == "http" && (uri.host == "127.0.0.1" || uri.host == "localhost"))) {
            "MCP endpoint must use HTTPS (HTTP is allowed only for localhost)."
        }
        require(method.matches(Regex("[A-Za-z0-9_./-]{1,100}"))) { "Invalid MCP method." }
        var sessionId: String? = null
        var requestId = 1
        fun send(m: String, p: com.google.gson.JsonElement?, id: Int?): String {
            val payload = JsonObject().apply {
                addProperty("jsonrpc", "2.0")
                if (id != null) addProperty("id", id)
                addProperty("method", m)
                if (p != null) add("params", p)
            }
            val conn = (uri.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 12000; readTimeout = 25000; doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Accept", "application/json, text/event-stream")
                setRequestProperty("MCP-Protocol-Version", "2025-03-26")
                sessionId?.let { setRequestProperty("Mcp-Session-Id", it) }
            }
            try {
                conn.outputStream.use { it.write(gson.toJson(payload).toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                if (sessionId == null) sessionId = conn.getHeaderField("Mcp-Session-Id")
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val body = stream?.bufferedReader()?.use { it.readText().take(30000) } ?: ""
                if (code !in 200..299) error("MCP HTTP $code: $body")
                return body
            } finally { conn.disconnect() }
        }
        val empty = JsonObject()
        if (method != "initialize" && method != "notifications/initialized") {
            val init = JsonObject().apply {
                addProperty("protocolVersion", "2025-03-26")
                add("capabilities", JsonObject())
                add("clientInfo", JsonObject().apply { addProperty("name", "ReCode Android"); addProperty("version", "13.0.0") })
            }
            send("initialize", init, requestId++)
            send("notifications/initialized", null, null)
        }
        val parsed = runCatching { JsonParser.parseString(params) }.getOrElse { empty }
        send(method, parsed, if (method.startsWith("notifications/")) null else requestId)
    }

    suspend fun shizukuShell(context: Context, command: String, timeoutSeconds: Int = 45): String = withContext(Dispatchers.IO) {
        require(command.isNotBlank() && command.length <= 4000) { "Command is empty or too long." }
        require(!Regex("(^|[;&|`]\\s*(rm\\s+-rf\\s+/|mkfs|dd\\s+if=|reboot|poweroff)|\\$\\(|>\\s*/)", RegexOption.IGNORE_CASE).containsMatchIn(command)) {
            "Blocked potentially destructive shell syntax."
        }
        check(Shizuku.pingBinder()) { "Shizuku is not running." }
        check(Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) { "Grant ReCode permission in Shizuku first." }
        check(Shizuku.getVersion() in 11..13) { "This Shizuku server version is not supported (requires API 11–13)." }
        val uid = Shizuku.getUid()
        check(uid == 0 || uid == 2000) { "Shizuku provided an unsupported identity: uid=$uid" }
        val server = IShizukuService.Stub.asInterface(Shizuku.getBinder())
        val process = requireNotNull(server.newProcess(arrayOf("/system/bin/sh", "-c", command), null, workspace(context).absolutePath)) {
            "Shizuku could not start the shell process."
        }
        val out = AtomicReference("")
        val err = AtomicReference("")
        val stdout = ParcelFileDescriptor.AutoCloseInputStream(process.inputStream)
        val stderr = ParcelFileDescriptor.AutoCloseInputStream(process.errorStream)
        val a = Thread { out.set(runCatching { stdout.bufferedReader().use { it.readText().take(20000) } }.getOrDefault("")) }
        val b = Thread { err.set(runCatching { stderr.bufferedReader().use { it.readText().take(4000) } }.getOrDefault("")) }
        try {
            a.start(); b.start()
            process.waitForTimeout(timeoutSeconds.coerceIn(1, 120).toLong(), TimeUnit.SECONDS.name)
            a.join(1500); b.join(1500)
            "uid=$uid\nexit=${runCatching { process.exitValue() }.getOrDefault(-1)}\n${out.get()}${if (err.get().isNotBlank()) "\nstderr: ${err.get()}" else ""}".trim()
        } finally {
            runCatching { process.destroy() }; runCatching { stdout.close() }; runCatching { stderr.close() }
        }
    }

    fun shizukuStatus(): String {
        val running = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        val granted = running && runCatching { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED }.getOrDefault(false)
        return when { granted -> "Shizuku running; permission granted"; running -> "Shizuku running; permission not granted"; else -> "Shizuku service not connected" }
    }

    fun requestShizukuPermission(): String {
        if (!runCatching { Shizuku.pingBinder() }.getOrDefault(false)) return "Start Shizuku first, then retry."
        if (runCatching { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED }.getOrDefault(false)) return "Shizuku permission already granted."
        return runCatching { Shizuku.requestPermission(13013); "Shizuku permission request sent. Approve it in the Shizuku prompt." }
            .getOrElse { "Could not request Shizuku permission: ${it.message}" }
    }

    suspend fun browse(context: Context, url: String, script: String): String = browserMutex.withLock { withContext(Dispatchers.Main) {
        require(url.startsWith("https://")) { "Browser automation accepts HTTPS pages only." }
        require(script.length <= 8000) { "Automation script is too long." }
        val wv = synchronized(browserLock) {
            browser ?: WebView(context).also { v ->
                v.settings.javaScriptEnabled = true
                v.settings.domStorageEnabled = true
                v.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, page: String) { browserReady = true }
                }
                browser = v
            }
        }
        browserReady = false
        val latch = CountDownLatch(1)
        val result = AtomicReference<String>("")
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, page: String) {
                browserReady = true
                view.evaluateJavascript("(async()=>{try{return JSON.stringify(await (async()=>{" + script + "})())}catch(e){return JSON.stringify({error:String(e)})}})()") { value ->
                    result.set(value ?: "null"); latch.countDown()
                }
            }
        }
        wv.loadUrl(url)
        withContext(Dispatchers.IO) { if (!latch.await(35, TimeUnit.SECONDS)) error("Browser page/script timed out") }
        "url=$url\nresult=${result.get()}"
    } }


    /** Compresses the private workspace into a ZIP file. Output remains inside app-private storage. */
    suspend fun zipWorkspace(context: Context, archiveName: String): String = withContext(Dispatchers.IO) {
        val safe = File(archiveName).name.let { if (it.endsWith(".zip", true)) it else "$it.zip" }
        require(safe.matches(Regex("[A-Za-z0-9._-]{1,100}\\.zip", RegexOption.IGNORE_CASE))) { "Invalid archive name." }
        val root = workspace(context).canonicalFile
        val outFile = File(context.filesDir, safe).canonicalFile
        require(outFile.parentFile == context.filesDir.canonicalFile) { "Invalid archive destination." }
        ZipOutputStream(BufferedOutputStream(FileOutputStream(outFile))).use { zos ->
            var count = 0
            root.walkTopDown().filter { it.isFile && it.canonicalPath != outFile.canonicalPath && !it.path.contains(File.separator + ".git" + File.separator) }.forEach { file ->
                require(++count <= 5000) { "Workspace has too many files to archive." }
                val rel = file.relativeTo(root).invariantSeparatorsPath
                zos.putNextEntry(ZipEntry(rel))
                file.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
        "ZIP created: ${outFile.name} (${outFile.length()} bytes, private app storage)"
    }

    /** Extracts a ZIP into the private workspace, rejecting traversal and oversized archives. */
    suspend fun unzipWorkspace(context: Context, archiveName: String, overwrite: Boolean): String = withContext(Dispatchers.IO) {
        val safe = File(archiveName).name
        require(safe.endsWith(".zip", true) && safe == archiveName) { "Use an archive filename stored in ReCode private storage." }
        val archive = File(context.filesDir, safe).canonicalFile
        require(archive.parentFile == context.filesDir.canonicalFile && archive.isFile) { "ZIP archive not found in ReCode private storage." }
        val root = workspace(context).canonicalFile
        var count = 0
        var total = 0L
        ZipInputStream(BufferedInputStream(FileInputStream(archive))).use { zis ->
            while (true) {
                val entry = zis.nextEntry ?: break
                val name = entry.name.replace('\\', '/')
                val safeEntry = name.trimEnd('/')
                require(safeEntry.isNotBlank() && !safeEntry.startsWith("/") && !safeEntry.split('/').any { it == ".." || it == "." || it.isBlank() }) { "Unsafe ZIP entry: $name" }
                val target = File(root, safeEntry).canonicalFile
                require(target.path.startsWith(root.path + File.separator)) { "ZIP entry escapes workspace: $name" }
                if (entry.isDirectory) target.mkdirs() else {
                    require(++count <= 5000) { "ZIP contains too many files." }
                    if (target.exists() && !overwrite) error("File already exists: $safeEntry (enable overwrite to replace).")
                    target.parentFile?.mkdirs()
                    FileOutputStream(target).use { out ->
                        val buf = ByteArray(8192)
                        while (true) {
                            val n = zis.read(buf); if (n < 0) break
                            total += n
                            require(total <= 250L * 1024L * 1024L) { "ZIP expands beyond 250 MB limit." }
                            out.write(buf, 0, n)
                        }
                    }
                }
                zis.closeEntry()
            }
        }
        "Extracted $count files (${total} bytes) into private workspace ${root.name}/"
    }

    suspend fun androidBuild(context: Context, task: String): String {
        val dir = workspace(context)
        val wrapper = File(dir, "gradlew")
        if (!wrapper.isFile) return "Build unavailable: no gradlew found in ReCode native workspace. Sync an Android Gradle project first."
        require(task.matches(Regex("(assembleDebug|assembleRelease|test|lint|tasks)"))) { "Unsupported Gradle task." }
        return shell(context, "chmod 700 ./gradlew && ./gradlew --no-daemon $task", 120)
    }

    fun closeBrowser() { synchronized(browserLock) { browser?.stopLoading(); browser?.destroy(); browser = null; browserReady = false } }
}
