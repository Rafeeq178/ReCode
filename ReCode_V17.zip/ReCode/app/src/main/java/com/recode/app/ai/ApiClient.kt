package com.recode.app.ai

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/** Optional online model: any OpenAI-compatible /chat/completions endpoint, streamed (SSE). Needs internet. */
object ApiClient {
    @Volatile
    private var current: HttpURLConnection? = null

    /** Closes the running request (used by the Stop button). */
    fun abort() {
        try { current?.disconnect() } catch (_: Throwable) { }
    }

    fun stream(
        baseUrl: String, key: String, model: String, system: String, prompt: String,
        maxTokens: Int, temperature: Double, onToken: (String) -> Unit,
    ) {
        val base = baseUrl.trim().trimEnd('/')
        if (base.isEmpty()) throw IOException("API address is empty (Library -> Online API)")
        if (!base.startsWith("http")) throw IOException("API address must start with https://")
        val url = if (base.endsWith("/chat/completions")) base else "$base/chat/completions"
        val msgs = JSONArray()
            .put(JSONObject().put("role", "system").put("content", system))
            .put(JSONObject().put("role", "user").put("content", prompt))
        val body = JSONObject()
            .put("model", model)
            .put("stream", true)
            .put("max_tokens", maxTokens)
            .put("temperature", temperature)
            .put("messages", msgs)
            .toString()
            .toByteArray(Charsets.UTF_8)

        val c = URL(url).openConnection() as HttpURLConnection
        current = c
        try {
            c.connectTimeout = 20_000
            c.readTimeout = 90_000
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Accept", "text/event-stream")
            if (key.isNotBlank()) c.setRequestProperty("Authorization", "Bearer " + key.trim())
            c.outputStream.use { it.write(body) }
            val code = c.responseCode
            if (code >= 400) {
                val err = try { c.errorStream?.bufferedReader()?.readText() ?: "" } catch (_: Throwable) { "" }
                throw IOException("API error $code " + err.take(300))
            }
            BufferedReader(InputStreamReader(c.inputStream, Charsets.UTF_8)).use { r ->
                while (true) {
                    val line = r.readLine() ?: break
                    if (!line.startsWith("data:")) continue
                    val d = line.substring(5).trim()
                    if (d == "[DONE]") break
                    try {
                        val ch = JSONObject(d).optJSONArray("choices") ?: continue
                        if (ch.length() == 0) continue
                        val delta = ch.getJSONObject(0).optJSONObject("delta") ?: continue
                        if (!delta.isNull("content")) {
                            val t = delta.getString("content")
                            if (t.isNotEmpty()) onToken(t)
                        }
                    } catch (_: org.json.JSONException) {
                        // keep-alive / non-JSON line: ignore
                    }
                }
            }
        } finally {
            current = null
            try { c.disconnect() } catch (_: Throwable) { }
        }
    }
}
