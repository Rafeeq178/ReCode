# ReCode V17 — live engineering operations

V17 builds on V16 and adds:

- Real-time agent dashboard telemetry (`agent_dashboard`) and progress events on `RC.bus` (`v17`).
- Advanced task queue (`queue_coding_task`) with explicit project-relative path scopes, conflict locks, queue limits and serialized project writes. It deliberately does not run concurrent writers against the same project state.
- Intelligent context compaction (`context_compact`) that preserves the task prefix and newest evidence within a bounded character budget.
- Full text-project checkpoints (`create_project_checkpoint`) and restore (`restore_project_checkpoint`); keeps the latest five snapshots and limits each snapshot to 1.5 MB.
- Automatic Gradle APK validation (`automatic_apk_testing`): assemble, unit tests and lint for debug/release variants. It does not claim emulator/device UI testing.
- Bounded advanced build recovery (`advanced_error_recovery`) reusing V16 diagnosis/repair/retry logic when available.
- Native ZIP workspace compressor/extractor (`zip_workspace_compress`, `zip_workspace_extract`). ZIP files live in app-private storage and are processed into the app-private native workspace. Extraction blocks absolute paths and `..` traversal, limits to 5,000 entries and 250 MB expanded data, and requires explicit overwrite for existing files.

## Important boundaries

- Queue writes are serialized to protect project consistency; scope locks detect and defer conflicting queued work. Read-only specialist analysis may still be parallelized by existing workflows.
- Checkpoints cover text files in the current ReCode project store, not binary attachments or the Android native workspace.
- ZIP utilities operate on ReCode's private native workspace, not the browser's current in-memory project. The archive must already be present in app-private storage to extract it; external document-picker import/export is not included in this iteration.
- APK checks require a valid Gradle wrapper, JDK and Android SDK in the native workspace. Unit tests/lint are not a substitute for installing and exercising an APK on a physical device/emulator.
- Dashboard events are live in the current app session; durable historical telemetry is not promised.
