# ReCode V13 — Native Engineering Integrations

V13 upgrades the V12 Android app with executable integrations instead of readiness-only flags.

## Implemented

- **Native shell:** executes `/system/bin/sh` in the app-private `files/recode-workspace` directory, with bounded command length, timeout, restricted environment and basic destructive-command guard. It is a real device shell, not the old project simulator.
- **Native workspace sync:** copies the currently open IndexedDB project files into the private on-device workspace. Native Git/build/shell tools operate on this synced copy; they do not silently mutate the IndexedDB project.
- **MCP client:** HTTP JSON-RPC client with an MCP `initialize` handshake, initialized notification, session ID support and `tools/list` / `tools/call`-style methods. HTTPS is required except localhost. Authentication/OAuth UI and SSE streaming are not implemented yet.
- **Shizuku:** SDK dependency, provider registration, live binder/permission status, explicit permission request and a real Shizuku shell process (`shizuku_shell`) after the user grants permission. It accepts Shizuku API 11–13 and verifies the reported identity is shell (2000) or root (0).
- **Git:** actual local repository init/status/branches/commit using JGit. `git_commit` stages the synced workspace contents.
- **Browser automation:** isolated Android WebView loads HTTPS pages and executes a bounded JavaScript function body against the page DOM.
- **Android build runner:** invokes the synced project's Gradle wrapper for a small allowlist of tasks. A real build still requires a usable JDK, Gradle wrapper and Android SDK available to the app process.
- **Multi-agent coding:** parallel read-only planning/exploration/architecture/security reviews, followed by serial coder, tester and reviewer agents to avoid concurrent file edits.

## Important boundaries

- Native workspace is app-private storage. It is separate from the active IndexedDB project until `sync_native_workspace` is run.
- Native shell and external MCP calls are `exec` tools and must remain subject to ReCode's permission gate. Do not set execution permissions to unrestricted for untrusted prompts.
- Shizuku is optional and requires the Shizuku app/service plus user approval. This build only connects and requests permission; it does not run privileged commands.
- Browser automation is not a general-purpose Chrome replacement. It uses a dedicated WebView, HTTPS only, and page scripts supplied by the agent.
- Android SDK builds are attempted, not guaranteed: many Android devices do not provide a JDK/SDK to ordinary apps.
- No APK build or device-side integration test was performed in this environment.

## New tool names

`sync_native_workspace`, `native_shell`, `git_status`, `git_init`, `git_commit`, `mcp_request`, `shizuku_status`, `shizuku_request_permission`, `shizuku_shell`, `browser_automate`, `android_build`, `multi_agent_code`.
