# ReCode V9 — AndroidHarness skill-pack merge

ReCode V9 keeps ReCode V8's application architecture, project format, agent loop, tools, permission manager, hooks, specialist agents, memory/todo, context compaction, website kit, and API/provider setup. It adds the reusable AndroidHarness Markdown skill library to ReCode's existing skill-selection pipeline.

## What changed

- Added `app/src/main/assets/harness-skills/` with the AndroidHarness skill documents, references, templates, and helper scripts.
- Added `app/src/main/assets/www/js/harness-skills.js`, which registers compact versions of the imported playbooks with `RC.skills.builtin`. ReCode's existing trigger matching, role filtering, skill toggles, and prompt-budget logic remain in control.
- Loaded the integration immediately after `skills.js` in `index.html`.
- Updated Android version metadata to `versionCode 9` / `versionName 9.0.0`.

## Imported capabilities

The skill pack covers Git safety/workflows, planning, test-driven development, systematic debugging, code review, simplification, web documentation research, browser work, web design, design tokens, React, Node APIs, Android builds, Android/Jetpack Compose, Linux/Termux environment guidance, security basics, accessibility-minded implementation, and related specialist playbooks. Original Markdown files remain available for inspection and editing.

## Important compatibility boundary

AndroidHarness and ReCode are separate Android applications with different UI, persistence, agent orchestration, native bridges, and tool contracts. AndroidHarness's Kotlin/Compose classes, shell backends, MCP transports, browser automation, plugin manager, Shizuku/Wireless-ADB integration, provider implementations, and device services were **not** copied wholesale into ReCode: doing so would create duplicate app entry points and incompatible dependencies rather than a working merge. The imported skills are instructions/playbooks, not a claim that ReCode suddenly has every AndroidHarness native tool. ReCode continues to expose only the tools implemented by its own bridge and JavaScript runtime.

## Build note

This source archive expects `setup.sh` to clone and adapt `llama.cpp` into `llama.cpp/examples/llama.android/lib` before Gradle can resolve `:lib`. That external dependency is not vendored in this ZIP. Run the setup script in a Termux/Linux environment with network access, then build with Gradle. A full Android build was not run in this environment.

## Attribution

The added skill documents are derived from the AndroidHarness project (MIT License). See `HARNESS_LICENSE` for the upstream license text. ReCode's original files remain under their existing license/terms.
