# ReCode V14

V14 builds on V13 and adds three requested engineering workflows.

## 1. Automatic Bug Detection & Repair

- `detect_bugs` performs read-only checks over the open project: supported syntax checks, empty files, missing local HTML/JS/CSS references, and optionally the existing runtime/test runner.
- `automatic_bug_repair` runs the scan, asks the debugger agent for evidence-based root-cause diagnosis, asks the fixer agent to make minimal confirmed fixes, then reruns the available tests.
- The result distinguishes successful verification from remaining failures. Static heuristics are not represented as proof of correctness.

## 2. Parallel Coding Workers

- `parallel_coding_workers` accepts 2–3 workers, each with a task and an explicit list of project-relative files.
- Overlapping file ownership is rejected before execution.
- File-scope restrictions are carried into each worker's agent-loop context and enforced centrally by the tool executor for write/edit/delete/rename/move operations.
- Workers execute concurrently. The project test suite runs after all workers finish.

Example tool arguments:

```json
{
  "workers": [
    {"task": "Implement the settings view logic", "files": ["src/settings.js"]},
    {"task": "Add responsive styles for settings", "files": ["src/settings.css"]}
  ]
}
```

## 3. Automatic Code Review

- `automatic_code_review` runs the reviewer and security agents concurrently.
- Review is read-only and asks for severity, file/line, impact and recommendation.
- Findings remain advisory and should be verified before applying changes.

## New tools

- `detect_bugs`
- `automatic_bug_repair`
- `parallel_coding_workers`
- `automatic_code_review`

Aliases: `bug_scan`, `fix_bugs`, `parallel_workers`, `review_code`.

## Verification boundaries

The repository JavaScript syntax can be checked independently. Android compilation, APK generation, runtime behavior on a device, and actual model-driven agent runs require the Android/JDK/SDK environment and configured model provider; they must not be claimed unless run successfully.
