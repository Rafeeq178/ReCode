# ReCode V11 — Repository intelligence and safe engineering workflow

V11 builds on V10 and adds practical, read-only engineering tools modeled on AndroidHarness workflows without importing incompatible Android runtime classes.

## Added
- `project_diagnostics`: inventory entry point, manifests, tests, empty/large files, and supported syntax issues.
- `dependency_audit`: inspect package and Gradle manifests, dependency pins, and package scripts.
- `secret_scan`: heuristic credential scan; matched values are never printed.
- `change_impact`: find references to a file before rename/delete operations.
- `v11-engine.js`: versioned workflow, capability report, and honest verification summary.
- Updated agent protocol and Android version metadata to 11.0.0 / versionCode 11.

## Safety and capability boundaries
All four tools are read-only and inspect only the currently open in-app project. They do not install packages, access arbitrary phone paths, run OS commands, or transmit project contents. Secret scanning is heuristic and cannot prove that no credentials exist.

Native shell, real Git operations, MCP client, Shizuku, device automation, browser automation, and native Android build are still not implemented in ReCode. AndroidHarness components were not copied across incompatible runtimes.

## Verification
JavaScript syntax checks and archive integrity checks were run during packaging. Full Gradle/APK build and on-device testing were not run in this environment.
