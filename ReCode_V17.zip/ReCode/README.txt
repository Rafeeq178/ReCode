RECODE - private multi-agent coding app for Android (offline GGUF, llama.cpp)

BUILD (GitHub only)
  1. Put ReCode_v1.zip and .github/workflows/build.yml in a GitHub repo (main branch). Push.
  2. Actions -> "Build APK" -> download ReCode-debug.apk from the Release. Android 10+, arm64.
  3. Newer version = upload ReCode_v2.zip; the workflow builds the highest ReCode_v*.zip.
  debug.keystore inside the project keeps the signature fixed so updates install over each other.

HOW IT WORKS
  - UI + agents are HTML/CSS/JS in app/src/main/assets/www (shown in a WebView, works offline).
  - Kotlin is only the bridge (Bridge.kt): llama.cpp model, downloads, file picker, save, web search.
  - Every agent step RELOADS the model with that agent's own system prompt and gets only the hand-over text
    from the orchestrator (js/pipeline.js): Planner -> Researcher -> Architect -> Coder (file by file)
    -> checks -> Fixer -> optional ZIP. Activity (Summary) shows each step live and what each agent knew.
  - Runner: project files are bundled and run in a sandboxed iframe, no network unless enabled in Settings.
  - RAG: BM25 keyword search over your documents and project files (no neural embeddings: the llama.cpp
    Android library has no embedding API).
  - Online API (OpenAI compatible) is optional and needs internet; web research needs internet.

LIMITS
  - Temperature/sampler of the local model is fixed by the llama.cpp Android library.
  - Local context is small (~4k tokens): that is why work is split into small isolated steps.
  - Output files are text (html, css, js, json, md, py ... and ZIP). Not docx/pdf/images.
  - Not compiled here (no Android SDK in the build sandbox): the first CI run may show a Kotlin error
    in the build log - send it and it gets fixed. The web UI and agent pipeline were tested in a browser
    with a mock model; the real model behaviour depends on the GGUF you choose.

UPGRADE PHASE 1 (agent loop + tools) - ReCode_v2
  - New "Agent" chip in the chat. The model picks each next action: it calls tools, gets the results, repeats until
    it writes a final answer (js/loop.js). Max turns: Settings maxIter (default 12). Stop button cancels.
  - Tools (js/tools.js): read_file, write_file, edit_file, delete_file, list_files, search_files, search_text,
    create_directory, rename_file, move_file, get_file_info, run_command, check_syntax, run_tests.
    They only touch the open project (no disk access, paths like ../ or /abs are rejected).
  - Tool calls: text form "TOOL: read_file | index.html" (+ code block for write_file / edit_file) for small models;
    also accepts JSON / <tool_call> / OpenAI tool_calls shapes in the reply text.
  - Safety for now: delete_file is DENIED by default, run_command only has built-ins (run, check, ls, cat, grep, wc;
    there is no shell on the phone). Changed files must be verified (check_syntax / run_tests) before the final answer.
  - The classic Build / Chat / Research pipeline is unchanged. Settings autoAgent=true makes Auto use the agent loop.
  - Tests: node tests/phase1.test.js (67 checks, mock model). Not yet run on a real phone / real GGUF model.
  - (superseded by Phase 2 below: delete is still DENY by default, but now configurable)
  - NOT done yet (later phases): memory, compaction, skills, todo,
    checkpoints, MCP, workflows, settings screens for these. True structured API tool-calling needs a Kotlin
    Bridge change (apiRun is text-only today).

UPGRADE PHASE 2 (hooks, permissions, plan/ask/auto) - ReCode_v3
  - Permission manager (js/perms.js): levels ALLOW / ASK / DENY, strictest wins (DENY > ASK > ALLOW).
    Sources: tool rule (project override > global > default), file rules (glob + level), dangerous commands,
    delete confirmation, overwrite confirmation. Defaults: read tools ALLOW, write/edit/move/command ASK, delete DENY.
    Every tool call goes through it; DENY is never bypassed, in any mode. Permission history is kept (last 200).
  - Modes (chips appear under Agent): Plan = read-only, the agent returns a plan with Approve / Edit plan / Reject;
    Ask = approval dialog (Allow once / Always allow in this project / Deny); Auto-approve = ASK is approved
    automatically, but deletes still ask.
  - Hooks (js/hooks.js): SessionStart, SessionEnd, UserPromptSubmit, PreToolUse, PostToolUse, Stop, PreCompact.
    Built in: dangerous-command block, overwrite protection, project structure checks, backup before changes,
    auto-format, syntax check after writes, error hints, and a Stop check that sends the agent back if files
    still have syntax errors (optional full test run). A PreToolUse hook can block or rewrite a call.
    A hook that crashes never crashes a run; safety hooks fail closed. User hooks: settings.hooks.custom.
  - Settings > Permissions and hooks: mode, per-tool rules (all projects / this project), file rules, safety
    toggles, hook toggles, history. Settings > Agent turns / Auto uses the Agent.
  - Tests: node tests/phase1.test.js and node tests/phase2.test.js (mock model). The new dialogs and settings
    screens were not opened in a browser or on a phone yet.
  - PreCompact is defined but nothing triggers it until Phase 4 (context compaction).

UPGRADE PHASE 3 (subagents + dynamic selection) - ReCode_v4
  - 15 specialist agents as Markdown + YAML frontmatter (js/subagents.js): planner, explorer, researcher, architect,
    frontend, backend, database, coder, debugger, fixer, tester, reviewer, security, optimizer, documentation.
    Frontmatter: name, description, tools, permissions (read/write/exec/delete), triggers, max_turns, max_tokens.
    Each runs with its own system prompt, ONLY its own tools (further capped by its permission classes), a fresh
    isolated context, status and a short report back to the main agent. They never delegate further.
  - Stored in the app database as .recode/agents/<name>.md (the project file system cannot hold dot-folders).
    Settings > Agents > Specialist agents: enable/disable, Edit .md, New, Reset/Delete, Export ZIP.
    Import: RC.subagents.importFiles([{name,text}]) (no file-picker screen yet).
  - Selection: the main agent sees only the 1-3 best matching specialists for the request (small requests get none),
    and calls TOOL: delegate | agent | task. Manual: start a message with @frontend ... to talk to one directly.
    Several read-only specialists requested in one turn run side by side; note the model queue in llm.js still
    serialises model calls, so on-device this is scheduling, not a speed-up.
  - Subagents inherit the permission mode (Plan = read-only) and all hooks. Classic pipeline agents are untouched
    (subagent ids are "sub:<name>").
  - New tools: delegate, search_knowledge (BM25), web_search / web_read (ASK by default; only for agents that list them).
  - Tests: node tests/phase1|phase2|phase3.test.js (all pass, mock model). UI not opened on a phone yet.

UPGRADE PHASE 4 (memory, todo, context compaction) - ReCode_v6
  - New js/memory.js. Three things, all for the Agent (also used by specialists where noted):
  - RECODE.md (project notes): a normal project file. Every agent run reads it first and puts it at the top of the prompt
    (Settings > Memory and context: on/off, how many characters). The agent saves lasting facts with
    TOOL: remember | text  (appends "- text", no duplicates, 3000 character limit, blocked in Plan mode, permission default ALLOW).
    You can edit it yourself: Settings > Edit project notes (creates it if missing). Lower-case recode.md also works.
    It is a project file, so it is included in the ZIP export. Specialists see a shorter copy.
  - todo tool: TOOL: todo | set | step one; step two  /  add / start N / done N / remove N / list / clear. Max 12 items.
    The list is shown in every prompt of the main agent, is stored in the project, and before the final answer the agent is
    reminded once if items are still open. A new request starts with an empty list; saying "continue" keeps unfinished items.
    Works in Plan mode (it does not change files). Specialists cannot use it.
  - Compaction: when an agent run gets long (transcript beyond ~80% of its share of the prompt, or more than 20 entries)
    the oldest steps are folded into a short summary (changed files, checks, problems seen, specialist reports, files read,
    last words) and only the newest steps (Settings > Steps kept word for word, default 6) stay in full. It is deterministic,
    so it costs no extra model call. It shows as a "Compacting context" step in Activity. The PreCompact hook now fires:
    payload {entries, chars, reason, state, todos}; {block:true} skips it, {feedback} text is kept in the summary.
  - Tests: node tests/phase1|phase2|phase3|phase4.test.js (all pass, mock model). Not yet run on a phone / real GGUF model.
  - NOT done yet: model-written summaries, checkpoints/undo, skills, MCP, workflows, loading the model once for all steps,
    notes/todo for the classic Build pipeline.


UPGRADE V8 (reliability: websites, images, research, skills) - ReCode_v8
  Problems fixed (seen in real use on the phone):
  1. Logo as PNG: the model was asked to "write" assets/logo.png as text, looped on "Xu9995777333..." and the page showed a broken image.
     -> js/assets.js: binary files (png/jpg/ico/mp3/pdf...) are never written by the model. Planner paths are rewritten to .svg, the
        write_file tool turns logo.png into a real SVG, and logo/favicon/hero SVGs are generated by code. Missing images in HTML/CSS
        are repaired automatically (SVG created + reference rewritten) in the check step.
  2. Endless repeat loops: llm.js watches the stream; when the same short pattern repeats for 160+ characters it stops the model and keeps
     the good part (step note "stopped an endless repeat"). write_file refuses looping content.
  3. Empty pages (heading "Menu" with nothing under it): the checker now reports sections that have a heading but no content,
     and websites come from the SITE KIT (js/sitekit.js): coffee, restaurant, portfolio, shop, saas, blog, business, generic.
     Header + hamburger menu, hero, features, items (menu/products/services/projects), about, reviews, contact form with validation,
     footer, dark mode, SVG logo/hero/favicon, scroll-reveal that can never hide content. The model writes ONLY the text as JSON
     (1 model call instead of 14 steps, ~10 seconds). If it answers badly, tested default text is used. Existing projects are never replaced.
  4. Web research: Behance/Dribbble/Pinterest/Instagram/Facebook/X/LinkedIn/YouTube/Reddit/Quora are skipped (they block apps, 403).
     Queries exclude them and ask for docs/tutorials; up to 8 results are tried until 2 pages are readable. Web.kt retries 403 with a
     mobile browser agent and then the free text reader r.jina.ai (sends only the page URL to that service).
  5. Skills (js/skills.js): 10 built-in playbooks (web-design, images-and-logos, responsive-mobile, forms-validation, safe-animation,
     js-no-bugs, accessibility-seo, research-method, python-termux, security-basics). The 1-2 best matches for the request are added
     to Planner / Architect / Coder / Fixer / Agent prompts, inside the prompt budget. Custom skills: RC.skills.importText(markdown with
     frontmatter name/triggers/roles) or RC.skills.fromUrl(url) (internet); your own skills win ties. Settings: Skills / Website kit / Website text by AI.
  Tests: node tests/phase1..5.test.js (all pass, mock model). Kotlin (Web.kt) is not compiled here: if the GitHub build shows an error, send the log.
  NOT done: image generation (only SVG), a skills screen in Settings (toggle exists, import is by API), real-model testing on the phone.


RECODE V11
==========
Version: 11.0.0 (versionCode 11)
New read-only repository tools: project_diagnostics, dependency_audit, secret_scan, change_impact.
Workflow: environment check -> reconnaissance -> impact analysis -> plan -> implement -> static security review -> verify -> report.
These tools inspect only files in the currently open ReCode project. They do not provide OS shell, real Git, MCP, Shizuku, device automation, or native Android builds.


RECODE V12
Version: 12.0.0 (versionCode 12; historical release)
New read-only tools: environment_doctor, mcp_config_audit, browser_readiness_audit, git_readiness_audit, release_readiness_audit.
These were readiness audits in V12. V13 adds the executable integrations documented below. See MERGE_V12.md for the historical V12 scope.


RECODE V13 NATIVE INTEGRATIONS
==============================
See MERGE_V13.md for the full integration notes and safety boundaries. V13 adds a real app-private Android shell workspace, workspace sync, JGit repository operations, an MCP HTTP JSON-RPC initialize client, Shizuku permission bridge and user-approved shell, HTTPS WebView automation, an on-device Gradle wrapper runner, and serial/parallel specialist-agent orchestration. These integrations require the installed Android app. The Gradle build runner depends on a JDK/SDK toolchain available to the app and does not guarantee that every phone can build APKs.

V13: 13.0.0 (versionCode 13)


RECODE V14
==========
V14 adds evidence-based automatic bug detection and repair, scoped parallel coding workers with centrally enforced disjoint file ownership, and read-only parallel reviewer/security code review. See MERGE_V14.md for tool details and verification boundaries.

RECODE V15 — UI / UX REFRESH
============================
Version: 15.0.0 (versionCode 15)
Reference-inspired mobile UI refresh: drawer-first navigation (Chats / Projects / Code / Artifacts / Models / Settings), searchable Projects screen, recent chats, model chooser sheet, Add to chat sheet, calmer white/ivory palette, editorial headings, and a redesigned floating composer. See MERGE_V15_UI.md for exact scope and limitations. Camera and Photos are UI placeholders until native image-picker bridges are implemented.

RECODE V16 — SELF-HEALING AND CONTINUOUS VERIFICATION
Seven workflows: bounded self-healing bug repair, file-fingerprint regression checks, evidence-based optimization, static performance profiling, project-local shared specialist memory, diagnosed Gradle build recovery, and continuous multi-agent coding/verification. Repair attempts and build retries are bounded. Static performance analysis is not a runtime benchmark. See MERGE_V16.md for implementation details and limits.

RECODE V17
==========
V17 adds a live agent/task dashboard, progress event stream, bounded task queue with
project-path conflict locks and serialized writes, context compaction, full text-project
checkpoints/restore, Gradle APK build + unit-test + lint validation, bounded failed-build
recovery, and safe ZIP compression/extraction for the app-private native workspace.

New tools:
- agent_dashboard
- queue_coding_task
- context_compact
- create_project_checkpoint
- restore_project_checkpoint
- automatic_apk_testing
- advanced_error_recovery
- zip_workspace_compress
- zip_workspace_extract

ZIP note: these tools operate on ReCode's app-private native workspace. The archive must
already be stored in app-private storage for extraction. Traversal is blocked and expanded
archives are limited to 250 MB / 5,000 files. Checkpoints cover text files in the current
project store (latest five; 1.5 MB per snapshot).
