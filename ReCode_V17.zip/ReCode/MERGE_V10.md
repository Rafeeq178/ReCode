# ReCode V10 — Harness-inspired coding workflow integration

V10 builds on the supplied ReCode V9 source and AndroidHarness skill pack. It improves the working coding-agent pipeline without copying incompatible AndroidHarness application classes into ReCode.

## V10 changes

- Adds the read-only `project_map` tool (aliases: `map`, `repo_map`, `inspect_project`) to inventory folders, file types, build manifests, likely entry points, tests, and unusually large files in the currently open project.
- Adds a Harness-inspired engineering protocol to the agent system prompt: reconnaissance, inspect, plan, smallest compatible implementation, verification, root-cause repair, and honest reporting.
- Adds `v10-engine.js` with explicit workflow metadata, capability flags, and a structured verification summary.
- Fixes a verification-state bug: `run_command` (which is only a project simulator, not a phone shell) can no longer mark edited code as verified. `check_syntax` and `run_tests` now mark a run unverified when their output contains problems.
- Updates Android version metadata to `versionCode 10` / `versionName 10.0.0`.

## Existing ReCode features retained

V9's AndroidHarness skill documents, skill selection, agent loop, specialist agents, memory, context compaction, permissions, hooks, project tools, sandbox preview, and existing provider/model setup remain in place.

## Explicit capability boundary

The supplied AndroidHarness repository is a separate Android application with its own Kotlin runtime, shell policy, MCP client, Shizuku/device integrations, browser tools, and plugin system. These were not blindly copied into ReCode because their runtime contracts and dependencies do not match ReCode's WebView bridge. V10 does **not** claim native shell, MCP, Shizuku, device automation, or browser automation support. Its project tools operate on the open ReCode project only.

## Build and verification

JavaScript source syntax was checked during packaging. A complete Android Gradle build was not run: the ReCode project setup requires the external llama.cpp `:lib` dependency to be prepared by `setup.sh` in a network-enabled Termux/Linux environment.

## Upstream attribution

The imported Harness skill material remains attributed under `HARNESS_LICENSE`. ReCode's original source and license terms remain unchanged.
