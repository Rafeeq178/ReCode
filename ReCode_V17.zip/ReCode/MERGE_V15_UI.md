# ReCode V15 — Reference-inspired mobile UI refresh

This release refreshes the app's HTML/CSS/JS workspace to follow the supplied 41-second mobile UI reference: a quiet white/ivory chat canvas, restrained warm accent, editorial serif headings, compact top bar, floating composer, rounded bottom sheets, a left navigation drawer, recent chats, a project browser, and model selection.

## UI changes
- Replaced the previous five-icon bottom pill with a drawer-first workspace navigation.
- Navigation: Chats, Projects, Code, Artifacts (preview workspace), Models, and Settings.
- Added a Projects screen with search, project cards, and a floating New project action.
- Added a model chooser sheet showing installed local models and a route to provider/model management.
- Added an Add to chat sheet with Camera, Photos, and Files entry points, project routing, and a Web Search toggle.
- Refined chat greeting, quick-start cards, message bubbles, composer, sheet surfaces, spacing, typography, and dark theme.
- Added a model shortcut in the chat top bar.

## Capability notes
- Files is connected to the existing Android document picker.
- Camera and Photos are visual entry points only in this release; the existing native bridge does not yet expose camera capture or image selection. Selecting either shows an explanatory message rather than pretending an upload occurred.
- Projects, Code, Artifacts/Preview, Models, and Settings route to existing app capabilities. This is a UI/navigation refresh, not a new model provider or backend.
- The reference is used as visual direction. Pixel-identical reproduction cannot be guaranteed from a compressed screen recording, and ReCode branding/assets remain original.

## Verification
- `node --check` passed for every `app/src/main/assets/www/js/*.js` file.
- AndroidManifest XML parsed successfully.
- Android APK build and on-device visual QA were not run in this environment.
