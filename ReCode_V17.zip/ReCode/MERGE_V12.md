# ReCode V12 — Engineering diagnostics and integration readiness

V12 extends V11 with additional read-only audits inspired by AndroidHarness engineering workflows. The tools run only against the currently open ReCode project model (`RC.store.files`).

## Added tools
- `environment_doctor`: inventories Gradle/Android manifests, source files, tests, and wrapper metadata.
- `mcp_config_audit`: locates common MCP configuration files and reports declaration markers; it does not connect to servers.
- `browser_readiness_audit`: locates browser automation configs, e2e tests, and web entry/build files.
- `git_readiness_audit`: inventories ignore rules, CI workflows, and build manifests; it does not invoke Git.
- `release_readiness_audit`: statically checks Android release metadata, manifest, and CI workflow presence.
- `v12-engine.js`: versioned workflow, capability report, and explicit verification boundaries.

## Safety and capability boundaries
All new tools are read-only. They cannot access arbitrary phone paths, execute shell commands, access `.git` internals, connect to MCP servers, control a browser, use Shizuku, or build/install an APK. Static readiness checks are not proof of a successful build or release. Existing V9–V11 code and Harness skill assets are retained.

## Verification
JavaScript syntax validation and ZIP integrity checks were run for this package. Full Gradle/APK build and on-device testing were not run in this environment.
