# ReCode V16 — autonomous quality and recovery workflows

V16 adds seven tool-registry workflows in `app/src/main/assets/www/js/v16-engine.js`:

- `self_healing_agent`: bug scan → debugger diagnosis → minimal fixer pass, capped at two repair attempts → final test run.
- `automatic_regression_test`: captures a per-file fingerprint baseline and compares added/changed/removed project files while rerunning `run_tests`.
- `intelligent_code_optimization`: invokes the optimizer specialist with a static source profile; optimization is evidence-led and test-aware.
- `performance_analysis`: static source-size, largest-file, script and stylesheet counts. This is explicitly not a runtime benchmark.
- `share_agent_memory`: stores concise project facts in `RECODE_AGENT_MEMORY.md` for later specialist tasks.
- `recover_failed_build`: attempts a native Gradle build, asks the debugger to diagnose failures, applies a minimal fixer pass only when diagnosis succeeds, then retries once.
- `continuous_coding_verification`: parallel read-only planning/exploration/architecture/security, sequential coder, regression check and independent reviewer/security review.

Safety and limits:
- Repair loops are bounded to two attempts; build recovery retries once.
- No optimization is assumed safe merely because a static heuristic flags it.
- Shared memory is project-local and user-readable; it is not hidden agent state.
- Regression checks combine file fingerprints and the existing project test runner; they are not a guarantee of full behavioural coverage.
- Runtime performance measurements require profiling on a real device.
- Android build recovery requires the V13 native workspace/build bridge, Gradle wrapper, JDK and Android SDK to be available. No build is claimed until a real build succeeds.
