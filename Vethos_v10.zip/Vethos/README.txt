VETHOS - native Android app (Kotlin, no WebView, no ads)

Termux build:
  1. pkg install git openjdk-17 gradle   (plus Android SDK + NDK + cmake)
  2. ./setup.sh          # clones llama.cpp and prepares its Android lib
  3. gradle assembleRelease
  APK: app/build/outputs/apk/release/

Needs Android 10+ (API 29), arm64 phone.

v2 changes
  - Settings crash fixed: the settings layout had a view with id "root", which clashes with ViewBinding's
    .root and caused "The specified child already has a parent". It is now called "content".
  - New UI matching the reference recordings (gradient background, pill nav, side drawer, personalities,
    new Library / Insights / Settings screens).
  - Chat: live typing animation with a blinking dot, thumbs / copy / share / regenerate actions,
    options sheet, personality sheet, voice input, export chat.
  - Settings that are saved but not yet applied by the engine: Creativity, Repetition penalty, CPU threads,
    Multi-thread, GPU, Context size (llama.android's sendUserPrompt only takes the prompt and max tokens).

v3 changes
  - Code blocks: ```lang ... ``` in an answer is now drawn as a dark code block with its own "Copy" button
    (also while the answer is still typing).
  - File attach (clip button): pick any text / code file (.txt .php .js .html .json .csv .kt .py ...) or .docx.
    The first 6000 characters go to the model together with your question. PDF / images can't be read by the
    offline text model. No storage permission needed (system file picker).
  - Permissions: notifications (Android 13+, asked once with a reason) + foreground service so model
    downloads keep running in the background and show progress in the notification bar.
    Microphone: voice input uses the system speech screen, so the app itself needs no mic permission.

v4 changes (Batch 1)
  - Personalities: each one now has role (system prompt), tone, reply language, creativity and its own
    list of allowed phone tools. New / edit / duplicate / delete (tap the 3-dots on a row), Export all,
    Export one, Import JSON. "Translator" added; "General Assistant" can use all tools.
  - Phone tools (drawer -> Phone tools): Flashlight, Volume, Wi-Fi, Battery, Open app, Call, Send SMS,
    WhatsApp draft. Tap a tool to try it by hand. The switch turns a tool off for all personalities.
  - In chat the model asks for a tool with  <tool>{"name":"flashlight","args":{"on":true}}</tool>.
    The app runs it and shows the result. Call and SMS always ask "Allow?" first.
  - Tool instructions are only added to the system prompt for the tools a personality may use.
  - NOT done yet (library limits): GBNF grammar and per-personality Creativity cannot reach llama.cpp,
    because llama.android's sendUserPrompt only takes prompt + max tokens. Creativity is saved with the
    personality and will be applied when the native sampler is patched.
  - Android limits: Wi-Fi cannot be switched on/off by apps (the Wi-Fi panel opens instead).
    SMS/Call ask for permission the first time; if refused, the messages app / dialer opens instead.

v5 changes (Batch 2)  - 10 new phone tools (Phone tools screen / personality "Tools" list)
  - Navigate (Google Maps navigation, falls back to any maps app), Camera (opens the camera app, photo or video),
    Notification (shows a notification; asks the Android 13+ permission once), Calculator (+ - * / ^ %, sqrt, sin,
    log, pi, "20% of 500"), Random / password (password, PIN, number, dice, coin; a password is also copied),
    Hash / Base64 (base64, URL, hex, MD5, SHA-1/256/512), Clipboard (read asks first, write copies),
    QR maker (shown on screen, "Save to gallery"), QR scanner (camera, fully offline), Read file (system picker;
    text / code / .docx).
  - Read-type tools (Read file, Clipboard read, QR scan) hand their content back to the model once, so it can
    answer ("summarize this file"). The model gets at most 1500 characters.
  - New libraries: zxing-android-embedded 4.3.0 (QR scanner) and zxing core 3.5.3 (QR maker). Both come from
    Maven Central, so the GitHub build needs internet as usual.
  - CAMERA permission is only asked by the scanner (the library asks it the first time you scan).
  - PDF reading comes in the next batch together with the HTML runner.

v6 changes (Batch 3)  - offline HTML/CSS/JS runner, mini apps, file write, PDF reading
  - Code blocks in chat: "▶ Run" appears on HTML (and JavaScript / SVG) blocks, "Save" saves any code block
    to a file you choose (name and extension follow the language).
  - Runner screen: fullscreen preview, Code button (edit and Run again), Reload, Console (console.log and
    JavaScript errors), Save as mini app, Export as .html. Fully offline: every network request is blocked,
    links to other sites do not open, only in-page # anchors work.
  - Mini apps (drawer -> Mini apps): list, New mini app, Run, Edit code, Rename, Export .html, Delete.
    Each app keeps its own localStorage.
  - JS bridge: inside a page, Vethos.tool("battery", {}) returns a Promise with {ok, text, data}.
    Vethos.tools() lists the tools, Vethos.toast("hi"), Vethos.copy("text"). Call and SMS still ask "Allow?".
    "Phone tools for this page" can be switched off in the runner menu.
  - New tool "Save to file" (write_file): the assistant writes text/code into a file you choose.
  - PDF text: "Read file" and the attach (paperclip) button now read PDFs (first 30 pages, text layer only,
    scanned PDFs have no text). New library: pdfbox-android 2.0.27.0 (adds a few MB to the APK).

v7 changes (Batch 4, part 1)  - offline translator + "English mode"
  - English mode (Settings -> LANGUAGE, on by default): whatever language you write, the model always
    receives English. The chat still shows what you typed.
      * Roman Urdu / Hinglish: built-in word list (about 830 words + 330 phrases). Instant, no download,
        rough word-by-word. The model also gets your original text in [brackets] so it can fix mistakes.
      * Hindi / Urdu script / Arabic / Bengali / Persian / Turkish / Spanish / French / German / Russian /
        Chinese / Indonesian: Google ML Kit offline packs (about 30 MB each). The language is detected
        offline. If a pack is missing the app starts a Wi-Fi-only download and sends the original text
        until it is ready. Packs can also be downloaded or deleted in the Translator screen.
  - "Reply in my language" (off by default): asks the model to answer in the language you wrote.
  - Translator screen (drawer -> Translator): any language -> English or other packs, Copy, Read aloud.
  - Chat quick commands: /summarize, /hashtags, /title, /meaning, /translate [language] [text], /help.
    With no text they use the clipboard.
  - New tools: Translate and Read aloud (text-to-speech). Every AI message now has a speaker button.
  - Voice input still uses the phone's speech recognizer (mic button). Whisper comes with the voice batch.
  - Limits: ML Kit needs Google Play services on the phone to download packs. Roman Urdu output
    (English -> Roman Urdu) is not available, only Hindi / Urdu script and the other pack languages.
  - The n8n-style automation editor is the next version (v8).

v8 changes (Batch 4, part 2)  - n8n-style Automations + fewer install warnings
  - Drawer -> Automations: a list of automations (like n8n workflows) with an on/off switch each.
    New automation, Examples (torch phrase, charger connected, morning battery report, battery low warning).
    Hold an automation for Run now / Edit / Duplicate / Rename / Delete.
  - Editor (tap an automation): a canvas with nodes. Drag nodes, drag from the dot on the right of a node
    onto another node to connect (the "If" node has a yes and a no dot), tap the x on a line to remove it,
    pinch to zoom, drag the background to move. Tap a node = settings, hold = Settings / Duplicate / Delete.
    + Add node, ▶ run (nodes light up amber / green / red), Log shows the last run, menu: switch on/off, fit, rename, delete.
  - Nodes: Triggers = Manual start, Chat phrase, Time (daily or every N minutes), Phone event (charger connected /
    disconnected, battery low, Wi-Fi connected, screen on). Logic = If (contains, equals, not empty, greater, less,
    starts with, regex), Wait. Actions = Phone tool (any of the tools), Ask the model, Translate, Set text, Open mini app.
    Text fields can use {{input}} {{last}} {{data}} {{time}}.
  - Chat phrase trigger: when your chat message contains the phrase, the automation runs (the model answers too
    only if you choose "Yes, answer too").
  - Limits (Android rules): time alarms are not exact (can be a few minutes late). Events are watched while the
    Vethos process is alive. If Vethos is not on screen when a trigger fires, a notification "Tap to run" is shown,
    because Android does not let an app open screens or call tools in the background by itself.
    "Ask the model" loads the last used model if none is loaded (takes a few seconds).
  - Install warnings: CALL_PHONE and SEND_SMS permissions were removed (they are what Google Play Protect dislikes
    most). The Call tool now opens the dialer and the SMS tool opens the messages app with the text ready.
    The first warning ("unknown apps") is Android's normal message for any APK that is not from the Play Store.
    Added permission: RECEIVE_BOOT_COMPLETED (to set the time triggers again after a restart).

v9 changes  - smart commands, internet tools, advanced automations
  - SMART COMMANDS (Settings -> INTERNET AND COMMANDS, on by default): short commands are understood by the app
    itself, in English, Roman Urdu, Hindi and Urdu script, and the tool runs without asking the model:
    "torch on", "flashlight band karo", "light jala do", "volume kam karo", "volume 40", "mute", "battery kitni hai",
    "open whatsapp", "youtube chalao", "camera", "video record karo", "wifi", "weather in Lahore", "lahore ka mausam",
    "news", "pakistan news", "wiki einstein", "search python tutorial", "12*5", "20% of 500", "password banao",
    "qr scan karo", "navigate to Lahore airport", "call 0300...", "whatsapp 0300... hello". Longer chat goes to the model.
    "open X" only runs if an app called X is installed, so normal sentences are never hijacked.
  - INTERNET TOOLS (also usable by the model and in automations): Web search, Read web page, Wikipedia (topic or
    latest news), Weather (Open-Meteo), News headlines (BBC / Dawn RSS). Offline mode (Settings) blocks all of them.
    Page text is cleaned (menus and ads removed) and cut to a few thousand characters: a whole page does not fit
    into a small model.
  - /research question : searches, reads the best 2 pages, the model answers from them and the sources are listed.
    /search words : the result list only.
  - AUTOMATIONS v2 (drawer -> Automations). New nodes: HTTP request (any API, headers, body, basic login),
    Web search, Read web page, Wikipedia, News / RSS, Weather, Telegram message, Send email, Read emails (IMAP),
    Post to Blogger (Blogger "post by email" address), Pick from JSON, Save value ({{name}}), If "is empty".
    New examples: Morning news to Blogger, Weather every morning, Unread emails alert, Research to Telegram.
  - Email: Automations -> Email account (Gmail needs 2-step verification and an App password). The password is
    stored encrypted in the Android Keystore. Telegram tokens typed into a node are saved in the app's private storage.
  - BACKGROUND RUNS: an automation made only of steps that need no screen (web, email, model, translate, notification,
    battery, torch, volume...) now runs by itself when its trigger fires, even if Vethos is closed (a small "running"
    notification is shown). Allow "Exact alarms" and set Battery to unrestricted (buttons on the Automations screen).
    Steps that need the screen (open app, camera, QR, files...) still show a "Tap to run" notification.
    Phones with strong battery savers (Transsion, Xiaomi...) may still stop background work: turn off battery
    optimization for Vethos and allow auto-start.
  - New permissions: SCHEDULE_EXACT_ALARM, WAKE_LOCK, FOREGROUND_SERVICE_SPECIAL_USE. New library: jsoup.
