package com.vethos.app.tools

import com.vethos.app.R
import com.vethos.app.data.Store
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** More built-in tools that work fully offline: date/time, notes, unit converter, text helpers, JSON. */
object ExtraTools {
    private fun ok(t: String, data: String? = null) = ToolResult(true, t, data)
    private fun bad(t: String) = ToolResult(false, t)

    private fun first(a: JSONObject, vararg keys: String): String {
        for (k in keys) {
            val v = a.optString(k).trim()
            if (v.isNotEmpty() && v != "null") return v
        }
        return ""
    }

    fun build(): List<ToolDef> = listOf(
        ToolDef(
            id = "datetime", title = "Date & time", icon = R.drawable.ic_hist, sensitive = false,
            desc = "Current date, time and weekday",
            params = emptyList(),
            usage = "{}",
            run = { c, a, d -> datetime(c, a, d) },
            headless = true,
        ),
        ToolDef(
            id = "notes", title = "Notes", icon = R.drawable.ic_edit, sensitive = false,
            desc = "Remember things: add, list, delete or clear notes (saved on this phone)",
            params = listOf(
                ToolParam("action", "add / list / delete / clear", "default add if text is given", optional = true),
                ToolParam("text", "Note text, or the number to delete", "", optional = true),
            ),
            usage = """{"action":"add|list|delete|clear","text":"note text"}""",
            run = { c, a, d -> notes(c, a, d) },
            headless = true,
        ),
        ToolDef(
            id = "unit_convert", title = "Unit converter", icon = R.drawable.ic_dollar, sensitive = false,
            desc = "Convert length, weight, volume, temperature and data size",
            params = listOf(
                ToolParam("value", "Number"),
                ToolParam("from", "From unit", "km, mile, kg, lb, c, f, l, gb ..."),
                ToolParam("to", "To unit"),
            ),
            usage = """{"value":"5","from":"km","to":"mile"}""",
            run = { c, a, d -> unitConvert(c, a, d) },
            headless = true,
        ),
        ToolDef(
            id = "text_tools", title = "Text tools", icon = R.drawable.ic_hash, sensitive = false,
            desc = "Count words or characters, change case, reverse, sort lines, remove duplicate lines",
            params = listOf(
                ToolParam("op", "Operation", "word_count, char_count, upper, lower, title, reverse, sort_lines, dedupe_lines"),
                ToolParam("text", "Text"),
            ),
            usage = """{"op":"word_count|char_count|upper|lower|title|reverse|sort_lines|dedupe_lines","text":"..."}""",
            run = { c, a, d -> textTools(c, a, d) },
            headless = true,
        ),
        ToolDef(
            id = "json_tool", title = "JSON tool", icon = R.drawable.ic_code, sensitive = false,
            desc = "Check, pretty-print or minify JSON",
            params = listOf(
                ToolParam("op", "validate / pretty / minify"),
                ToolParam("text", "JSON"),
            ),
            usage = """{"op":"validate|pretty|minify","text":"{...}"}""",
            run = { c, a, d -> jsonTool(c, a, d) },
            headless = true,
        ),
    )

    // ---------- date & time ----------
    private fun datetime(c: ToolCtx, a: JSONObject, done: (ToolResult) -> Unit) {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, h:mm a", Locale.getDefault()).format(Date())
        done(ok(now, data = "Current date and time on the user's phone: $now"))
    }

    // ---------- notes ----------
    private fun notes(c: ToolCtx, a: JSONObject, done: (ToolResult) -> Unit) {
        val text = first(a, "text", "note", "content")
        val action = first(a, "action", "op").lowercase().ifEmpty { if (text.isNotEmpty()) "add" else "list" }
        val p = Store.app.getSharedPreferences("vethos", 0)
        val list = mutableListOf<String>()
        try {
            val arr = JSONArray(p.getString("notes_json", "[]"))
            for (i in 0 until arr.length()) list.add(arr.getString(i))
        } catch (_: Exception) { list.clear() }
        fun save() = p.edit().putString("notes_json", JSONArray(list).toString()).apply()
        when (action) {
            "add", "save", "remember", "write", "new" -> {
                if (text.isEmpty()) { done(bad("What should I remember?")); return }
                list.add(text.take(500)); save()
                done(ok("Saved note #" + list.size))
            }
            "list", "show", "read", "get", "all" -> {
                if (list.isEmpty()) { done(ok("No notes yet")); return }
                val s = list.mapIndexed { i, n -> "" + (i + 1) + ". " + n }.joinToString("\n")
                done(ok(s, data = "The user's saved notes:\n$s"))
            }
            "delete", "remove" -> {
                val n = Regex("\\d+").find(text)?.value?.toIntOrNull()
                if (n == null || n < 1 || n > list.size) { done(bad("Which note number should I delete?")); return }
                list.removeAt(n - 1); save()
                done(ok("Deleted note #$n"))
            }
            "clear" -> { list.clear(); save(); done(ok("All notes deleted")) }
            else -> done(bad("Use add, list, delete or clear"))
        }
    }

    // ---------- unit converter ----------
    private class U(val cat: String, val f: Double)

    private val units: Map<String, U> = HashMap<String, U>().apply {
        fun def(cat: String, f: Double, vararg names: String) { names.forEach { n -> this[n] = U(cat, f) } }
        def("len", 0.001, "mm", "millimeter", "millimeters", "millimetre", "millimetres")
        def("len", 0.01, "cm", "centimeter", "centimeters", "centimetre", "centimetres")
        def("len", 1.0, "m", "meter", "meters", "metre", "metres")
        def("len", 1000.0, "km", "kilometer", "kilometers", "kilometre", "kilometres")
        def("len", 0.0254, "in", "inch", "inches")
        def("len", 0.3048, "ft", "foot", "feet")
        def("len", 0.9144, "yd", "yard", "yards")
        def("len", 1609.344, "mi", "mile", "miles")
        def("mass", 0.000001, "mg", "milligram", "milligrams")
        def("mass", 0.001, "g", "gram", "grams")
        def("mass", 1.0, "kg", "kgs", "kilogram", "kilograms", "kilo", "kilos")
        def("mass", 0.45359237, "lb", "lbs", "pound", "pounds")
        def("mass", 0.028349523125, "oz", "ounce", "ounces")
        def("vol", 0.001, "ml", "milliliter", "milliliters", "millilitre", "millilitres")
        def("vol", 1.0, "l", "liter", "liters", "litre", "litres")
        def("vol", 3.785411784, "gal", "gallon", "gallons")
        def("vol", 0.2365882365, "cup", "cups")
        def("data", 1.0, "b", "byte", "bytes")
        def("data", 1024.0, "kb", "kilobyte", "kilobytes")
        def("data", 1048576.0, "mb", "megabyte", "megabytes")
        def("data", 1073741824.0, "gb", "gigabyte", "gigabytes")
        def("data", 1099511627776.0, "tb", "terabyte", "terabytes")
        def("temp", 1.0, "c", "celsius", "centigrade")
        def("temp", 1.0, "f", "fahrenheit")
        def("temp", 1.0, "k", "kelvin")
    }

    private fun unitKey(s: String) = s.trim().lowercase().removePrefix("°").removePrefix("degrees ").removePrefix("degree ")

    private fun unitConvert(c: ToolCtx, a: JSONObject, done: (ToolResult) -> Unit) {
        val v = first(a, "value", "number", "amount", "x").replace(",", "").toDoubleOrNull()
        if (v == null) { done(bad("Give me a number to convert")); return }
        val fk = unitKey(first(a, "from", "unit", "from_unit"))
        val tk = unitKey(first(a, "to", "to_unit", "target"))
        val f = units[fk]; val t = units[tk]
        if (f == null || t == null) { done(bad("I don't know the unit: " + (if (f == null) fk else tk))); return }
        if (f.cat != t.cat) { done(bad("Cannot convert $fk to $tk")); return }
        val r: Double = if (f.cat == "temp") {
            val c0 = when (fk) {
                "f", "fahrenheit" -> (v - 32) * 5 / 9
                "k", "kelvin" -> v - 273.15
                else -> v
            }
            when (tk) {
                "f", "fahrenheit" -> c0 * 9 / 5 + 32
                "k", "kelvin" -> c0 + 273.15
                else -> c0
            }
        } else v * f.f / t.f
        val s = fmtNum(v) + " " + fk + " = " + fmtNum(r) + " " + tk
        done(ok(s, data = s))
    }

    private fun fmtNum(d: Double): String {
        if (d == Math.rint(d) && Math.abs(d) < 1e12) return d.toLong().toString()
        return String.format(Locale.US, "%.6f", d).trimEnd('0').trimEnd('.')
    }

    // ---------- text tools ----------
    private fun textTools(c: ToolCtx, a: JSONObject, done: (ToolResult) -> Unit) {
        val text = first(a, "text", "input", "content")
        if (text.isEmpty()) { done(bad("Give me some text")); return }
        val op = first(a, "op", "operation", "action").lowercase().replace(' ', '_')
        val r = when (op) {
            "word_count", "words", "count_words" -> "Words: " + text.trim().split(Regex("\\s+")).size
            "char_count", "characters", "count_chars", "length" -> "Characters: " + text.length
            "upper", "uppercase" -> text.uppercase()
            "lower", "lowercase" -> text.lowercase()
            "title", "titlecase" -> text.split(' ').joinToString(" ") { w -> w.lowercase().replaceFirstChar { it.uppercase() } }
            "reverse" -> text.reversed()
            "sort_lines", "sort" -> text.lines().sorted().joinToString("\n")
            "dedupe_lines", "dedupe", "unique" -> text.lines().distinct().joinToString("\n")
            else -> { done(bad("Unknown operation: $op")); return }
        }
        done(ok(r, data = r))
    }

    // ---------- JSON ----------
    private fun jsonTool(c: ToolCtx, a: JSONObject, done: (ToolResult) -> Unit) {
        val text = first(a, "text", "json", "input", "content")
        if (text.isEmpty()) { done(bad("Give me some JSON")); return }
        val op = first(a, "op", "operation", "action").lowercase().ifEmpty { "validate" }
        val v: Any = try {
            if (text.startsWith("[")) JSONArray(text) else JSONObject(text)
        } catch (e: Exception) {
            done(bad("Not valid JSON: " + (e.message ?: "")))
            return
        }
        val out = when (op) {
            "pretty", "format", "beautify" -> if (v is JSONArray) v.toString(2) else (v as JSONObject).toString(2)
            "minify", "compact" -> v.toString()
            else -> "Valid JSON"
        }
        done(ok(out, data = out))
    }
}
