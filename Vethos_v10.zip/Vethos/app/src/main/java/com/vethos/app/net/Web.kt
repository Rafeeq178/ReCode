package com.vethos.app.net

import org.json.JSONObject
import org.jsoup.Jsoup
import org.jsoup.parser.Parser
import java.io.IOException
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.Calendar
import java.util.TimeZone

/** Search, page reading, Wikipedia, weather and news. All blocking: call from a background thread. */
object Web {
    class Hit(val title: String, val url: String, val snippet: String)
    class Research(val prompt: String, val sources: String)

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    // ---------- reading a page ----------
    /** Title and the readable text of a page (menus, ads, scripts removed). */
    fun readable(url: String, maxChars: Int = 4000): Pair<String, String> {
        val r = Net.request("GET", url, mapOf("Accept" to "text/html,application/xhtml+xml,text/plain;q=0.8"))
        if (r.code >= 400) throw IOException("The site answered HTTP " + r.code)
        val doc = Jsoup.parse(r.body, r.url)
        doc.select("script,style,noscript,nav,footer,header,aside,form,iframe,svg,button,figure").remove()
        val root = doc.selectFirst("article") ?: doc.selectFirst("main") ?: doc.body()
        val sb = StringBuilder()
        if (root != null) {
            for (el in root.select("h1,h2,h3,p,li,pre,blockquote")) {
                val t = el.text().trim()
                if (t.length >= 30 || el.tagName().startsWith("h")) sb.append(t).append('\n')
                if (sb.length > maxChars * 2) break
            }
        }
        var text = sb.toString().trim()
        if (text.length < 200) text = (root?.text() ?: doc.text()).trim()
        if (text.isEmpty()) throw IOException("No readable text on this page")
        return doc.title().trim() to text.take(maxChars)
    }

    // ---------- web search ----------
    private fun unwrap(href: String): String {
        val h = if (href.startsWith("//")) "https:$href" else href
        val m = Regex("[?&]uddg=([^&]+)").find(h)
        return if (m != null) URLDecoder.decode(m.groupValues[1], "UTF-8") else h
    }

    fun search(query: String, count: Int = 5): List<Hit> {
        val hits = ArrayList<Hit>()
        try {
            val r = Net.request(
                "POST", "https://html.duckduckgo.com/html/",
                mapOf("Content-Type" to "application/x-www-form-urlencoded", "Referer" to "https://html.duckduckgo.com/"),
                "q=" + enc(query)
            )
            val doc = Jsoup.parse(r.body)
            for (res in doc.select("div.result")) {
                if (res.hasClass("result--ad")) continue
                val a = res.selectFirst("a.result__a") ?: continue
                val url = unwrap(a.attr("href"))
                if (!url.startsWith("http")) continue
                hits.add(Hit(a.text().trim(), url, res.selectFirst(".result__snippet")?.text()?.trim() ?: ""))
                if (hits.size >= count) break
            }
        } catch (e: Net.OfflineException) {
            throw e
        } catch (_: Exception) { }
        if (hits.isEmpty()) {
            try {
                val r = Net.request("GET", "https://lite.duckduckgo.com/lite/?q=" + enc(query))
                val doc = Jsoup.parse(r.body)
                val links = doc.select("a.result-link")
                val snips = doc.select("td.result-snippet")
                for ((i, a) in links.withIndex()) {
                    val url = unwrap(a.attr("href"))
                    if (!url.startsWith("http")) continue
                    hits.add(Hit(a.text().trim(), url, snips.getOrNull(i)?.text()?.trim() ?: ""))
                    if (hits.size >= count) break
                }
            } catch (e: Net.OfflineException) {
                throw e
            } catch (_: Exception) { }
        }
        if (hits.isEmpty()) {
            // last resort: Wikipedia search, so there is always something
            try {
                val r = Net.request("GET", "https://en.wikipedia.org/w/api.php?action=query&list=search&format=json&utf8=1&srlimit=$count&srsearch=" + enc(query))
                val arr = JSONObject(r.body).optJSONObject("query")?.optJSONArray("search")
                if (arr != null) for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val title = o.optString("title")
                    hits.add(Hit(title + " (Wikipedia)", "https://en.wikipedia.org/wiki/" + enc(title.replace(' ', '_')).replace("+", "%20"),
                        Jsoup.parse(o.optString("snippet")).text()))
                }
            } catch (e: Net.OfflineException) {
                throw e
            } catch (_: Exception) { }
        }
        if (hits.isEmpty()) throw IOException("The search engines did not answer. Try again in a moment.")
        return hits
    }

    fun format(hits: List<Hit>): String {
        val sb = StringBuilder()
        hits.forEachIndexed { i, h ->
            sb.append(i + 1).append(". ").append(h.title).append('\n').append("   ").append(h.url).append('\n')
            if (h.snippet.isNotBlank()) sb.append("   ").append(h.snippet).append('\n')
        }
        return sb.toString().trim()
    }

    /** Search, read the top pages and build one prompt for the model. */
    fun research(query: String, englishQuestion: String): Research {
        val hits = search(query, 5)
        val src = StringBuilder()
        val list = StringBuilder()
        var used = 0
        hits.forEachIndexed { i, h ->
            list.append(i + 1).append(". ").append(h.title).append('\n').append("   ").append(h.url).append('\n')
        }
        for (h in hits) {
            if (used >= 2) break
            try {
                val (t, text) = readable(h.url, 2200)
                used++
                src.append('[').append(used).append("] ").append(t.ifBlank { h.title }).append(" (").append(h.url).append(")\n").append(text).append("\n\n")
            } catch (e: Net.OfflineException) {
                throw e
            } catch (_: Exception) {
                if (h.snippet.isNotBlank()) {
                    used++
                    src.append('[').append(used).append("] ").append(h.title).append(" (").append(h.url).append(")\n").append(h.snippet).append("\n\n")
                }
            }
        }
        if (src.isEmpty()) throw IOException("Could not read any of the pages.")
        val prompt = "Use the web sources below to answer the question. If they do not contain the answer, say so.\n" +
            "Question: " + englishQuestion + "\n\nSources:\n" + src.toString().take(5200) +
            "Answer in a few short paragraphs and mention the source numbers you used."
        return Research(prompt, list.toString().trim())
    }

    // ---------- Wikipedia ----------
    fun wikiSummary(query: String): String {
        val s = Net.request("GET", "https://en.wikipedia.org/w/api.php?action=query&list=search&format=json&utf8=1&srlimit=1&srsearch=" + enc(query))
        val title = JSONObject(s.body).optJSONObject("query")?.optJSONArray("search")?.optJSONObject(0)?.optString("title")
            ?: throw IOException("Nothing found on Wikipedia for “$query”")
        val r = Net.request("GET", "https://en.wikipedia.org/api/rest_v1/page/summary/" + enc(title.replace(' ', '_')).replace("+", "%20"))
        val j = JSONObject(r.body)
        val link = j.optJSONObject("content_urls")?.optJSONObject("desktop")?.optString("page") ?: ""
        return title + "\n" + j.optString("extract") + (if (link.isNotEmpty()) "\n" + link else "")
    }

    /** "In the news" box of today's Wikipedia front page. */
    fun wikiNews(): String {
        val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        for (back in 0..2) {
            val y = cal.get(Calendar.YEAR)
            val m = "%02d".format(cal.get(Calendar.MONTH) + 1)
            val d = "%02d".format(cal.get(Calendar.DAY_OF_MONTH))
            try {
                val r = Net.request("GET", "https://en.wikipedia.org/api/rest_v1/feed/featured/$y/$m/$d")
                if (r.code < 400) {
                    val arr = JSONObject(r.body).optJSONArray("news")
                    if (arr != null && arr.length() > 0) {
                        val sb = StringBuilder("Wikipedia, In the news:\n")
                        for (i in 0 until arr.length()) {
                            sb.append("- ").append(Jsoup.parse(arr.getJSONObject(i).optString("story")).text()).append('\n')
                        }
                        return sb.toString().trim()
                    }
                }
            } catch (e: Net.OfflineException) {
                throw e
            } catch (_: Exception) { }
            cal.add(Calendar.DAY_OF_MONTH, -1)
        }
        throw IOException("Could not load Wikipedia news right now")
    }

    // ---------- weather (Open-Meteo, no key) ----------
    private fun wmo(code: Int): String = when (code) {
        0 -> "clear sky"
        1 -> "mostly clear"
        2 -> "partly cloudy"
        3 -> "overcast"
        45, 48 -> "fog"
        in 51..57 -> "drizzle"
        in 61..67 -> "rain"
        in 71..77 -> "snow"
        in 80..82 -> "rain showers"
        85, 86 -> "snow showers"
        in 95..99 -> "thunderstorm"
        else -> "unknown"
    }

    fun weather(city: String): String {
        val g = JSONObject(Net.request("GET", "https://geocoding-api.open-meteo.com/v1/search?count=1&name=" + enc(city)).body)
        val p = g.optJSONArray("results")?.optJSONObject(0) ?: throw IOException("City not found: $city")
        val lat = p.optDouble("latitude")
        val lon = p.optDouble("longitude")
        val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&timezone=auto&forecast_days=1" +
            "&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m" +
            "&daily=temperature_2m_max,temperature_2m_min"
        val w = JSONObject(Net.request("GET", url).body)
        val c = w.getJSONObject("current")
        val d = w.optJSONObject("daily")
        val max = d?.optJSONArray("temperature_2m_max")?.optDouble(0)
        val min = d?.optJSONArray("temperature_2m_min")?.optDouble(0)
        return p.optString("name") + (p.optString("country").let { if (it.isNotEmpty()) ", $it" else "" }) + ": " +
            Math.round(c.optDouble("temperature_2m")) + "°C (feels " + Math.round(c.optDouble("apparent_temperature")) + "°C), " +
            wmo(c.optInt("weather_code")) + ", humidity " + c.optInt("relative_humidity_2m") + "%, wind " +
            Math.round(c.optDouble("wind_speed_10m")) + " km/h" +
            (if (max != null && min != null) ". Today " + Math.round(min) + "° to " + Math.round(max) + "°C" else "")
    }

    // ---------- news / RSS ----------
    val feeds = mapOf(
        "world" to "https://feeds.bbci.co.uk/news/world/rss.xml",
        "pakistan" to "https://www.dawn.com/feeds/home",
        "tech" to "https://feeds.bbci.co.uk/news/technology/rss.xml",
        "technology" to "https://feeds.bbci.co.uk/news/technology/rss.xml",
        "business" to "https://feeds.bbci.co.uk/news/business/rss.xml",
        "sports" to "https://feeds.bbci.co.uk/sport/rss.xml",
        "sport" to "https://feeds.bbci.co.uk/sport/rss.xml",
        "science" to "https://feeds.bbci.co.uk/news/science_and_environment/rss.xml",
        "health" to "https://feeds.bbci.co.uk/news/health/rss.xml",
        "entertainment" to "https://feeds.bbci.co.uk/news/entertainment_and_arts/rss.xml",
    )

    fun rss(feedOrTopic: String, count: Int = 5): String {
        val key = feedOrTopic.trim().lowercase()
        val url = if (key.startsWith("http")) feedOrTopic.trim() else feeds[key] ?: feeds.getValue("world")
        val r = Net.request("GET", url)
        if (r.code >= 400) throw IOException("The news feed answered HTTP " + r.code)
        val doc = Jsoup.parse(r.body, "", Parser.xmlParser())
        var items = doc.select("item")
        if (items.isEmpty()) items = doc.select("entry")
        if (items.isEmpty()) throw IOException("No news items in this feed")
        val sb = StringBuilder()
        var n = 0
        for (item in items) {
            val title = item.selectFirst("title")?.text()?.trim().orEmpty()
            val desc = Jsoup.parse(item.selectFirst("description")?.text() ?: item.selectFirst("summary")?.text() ?: "").text().trim()
            val link = item.selectFirst("link")?.let { l -> l.text().ifBlank { l.attr("href") } }.orEmpty().trim()
            if (title.isEmpty()) continue
            n++
            sb.append(n).append(". ").append(title).append('\n')
            if (desc.isNotEmpty()) sb.append("   ").append(desc.take(220)).append('\n')
            if (link.isNotEmpty()) sb.append("   ").append(link).append('\n')
            if (n >= count) break
        }
        return sb.toString().trim()
    }
}
