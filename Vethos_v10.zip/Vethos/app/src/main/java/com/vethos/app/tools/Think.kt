package com.vethos.app.tools

/**
 * Helpers for reasoning ("thinking") models such as LiquidAI LFM3.
 * LFM3's chat template ends the prompt with "<think>", so the answer often arrives as
 *   reasoning text </think> final answer
 * (no opening tag). Some builds print the opening tag too. Both forms are handled here.
 */
object Think {
    private const val OPEN = "<think>"
    private const val CLOSE = "</think>"
    private val block = Regex("(?s)<think>.*?</think>")

    /** true for models whose reasoning starts without an opening tag (LFM3) */
    fun implicitOpen(modelFile: String?): Boolean = lfm3(modelFile)

    /** LFM3 uses ChatML + XML tool calls: <tool_call><function=name><parameter=key>value</parameter></function></tool_call> */
    fun lfm3(modelFile: String?): Boolean = modelFile?.contains("lfm3", ignoreCase = true) == true

    /** The final text to keep in the chat: reasoning removed. */
    @Suppress("UNUSED_PARAMETER")
    fun clean(raw: String, implicit: Boolean): String {
        var s = raw
        val close = s.indexOf(CLOSE)
        val open = s.indexOf(OPEN)
        // a closing tag with no opening tag before it: the reasoning started silently (LFM3), drop everything up to it
        if (close >= 0 && (open < 0 || open > close)) s = s.substring(close + CLOSE.length)
        s = s.replace(block, "")
        // reasoning that never finished (token limit): drop the unfinished part
        if (s.contains(OPEN)) s = s.substringBefore(OPEN)
        return s.trim()
    }

    /** Text shown while the answer is still being typed. */
    fun live(raw: String, implicit: Boolean): String {
        if (raw.contains(CLOSE)) return clean(raw, implicit)
        val open = raw.indexOf(OPEN)
        if (open >= 0) return raw.substring(0, open).trim().ifEmpty { "💭 Thinking…" }
        return if (implicit) "💭 Thinking…" else raw
    }

    /** Final text of a finished answer. If the model never closed its reasoning, keep what it wrote. */
    fun finish(raw: String, implicit: Boolean): String {
        val c = clean(raw, implicit)
        if (c.isNotEmpty()) return c
        return raw.replace(OPEN, "").replace(CLOSE, "").trim()
    }
}
