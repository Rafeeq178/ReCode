package com.vethos.app.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.text.TextUtils
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewConfiguration
import com.vethos.app.R
import com.vethos.app.flow.FEdge
import com.vethos.app.flow.FNode
import com.vethos.app.flow.Flow
import com.vethos.app.flow.FlowRunner
import com.vethos.app.flow.NodeSpecs
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * The n8n-style canvas: drag nodes, drag from the dot on the right of a node to another node to connect,
 * drag the background to move around, pinch to zoom, tap the x on a line to remove it.
 */
class FlowCanvasView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    var flow: Flow? = null
        set(v) { field = v; fitPending = true; invalidate(); if (width > 0) post { fit() } }
    var onNodeTap: ((FNode) -> Unit)? = null
    var onNodeLong: ((FNode) -> Unit)? = null
    var onChanged: (() -> Unit)? = null
    val states = HashMap<String, Int>()

    private val d = resources.displayMetrics.density
    private val nodeW = 176 * d
    private val nodeH = 66 * d
    private val portR = 8 * d
    private var scale = 1f
    private var ox = 0f
    private var oy = 0f
    private var fitPending = true

    private val cText = ctx.getColor(R.color.v_text)
    private val cMuted = ctx.getColor(R.color.v_muted)
    private val cLine = ctx.getColor(R.color.v_line)
    private val cSolid = ctx.getColor(R.color.v_solid)

    private val pFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val pStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2 * d }
    private val pEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2.4f * d; color = cMuted; strokeCap = Paint.Cap.ROUND
    }
    private val pTitle = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = cText; textSize = 14.5f * d; typeface = Typeface.DEFAULT_BOLD }
    private val pSub = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = cMuted; textSize = 12f * d }
    private val pDot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = cLine }
    private val pLbl = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = cMuted; textSize = 10f * d; typeface = Typeface.DEFAULT_BOLD }
    private val path = Path()
    private val rect = RectF()

    private val stateColors = intArrayOf(0, 0xFFE8A33D.toInt(), 0xFF3FA37A.toInt(), 0xFFD9534F.toInt())

    // ---------- geometry ----------
    private fun outX(n: FNode) = n.x + nodeW
    private fun outY(n: FNode, port: Int): Float {
        val outs = NodeSpecs.get(n.type)?.outputs ?: 1
        return if (outs == 1) n.y + nodeH / 2 else n.y + nodeH * (0.3f + 0.4f * port)
    }
    private fun inX(n: FNode) = n.x
    private fun inY(n: FNode) = n.y + nodeH / 2
    private fun hasInput(n: FNode) = NodeSpecs.get(n.type)?.isTrigger != true

    private fun toWorldX(sx: Float) = (sx - ox) / scale
    private fun toWorldY(sy: Float) = (sy - oy) / scale

    /** centre of what the user sees, in canvas coordinates (new nodes are placed here) */
    fun centerX() = toWorldX(width / 2f)
    fun centerY() = toWorldY(height / 2f)

    fun fit() {
        val f = flow ?: return
        if (f.nodes.isEmpty() || width == 0) return
        var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
        f.nodes.forEach {
            minX = min(minX, it.x); minY = min(minY, it.y); maxX = max(maxX, it.x + nodeW); maxY = max(maxY, it.y + nodeH)
        }
        val pad = 28 * d
        val s = min(1f, min((width - 2 * pad) / (maxX - minX), (height - 2 * pad) / (maxY - minY)))
        scale = max(0.45f, s)
        ox = (width - (maxX - minX) * scale) / 2f - minX * scale
        oy = (height - (maxY - minY) * scale) / 2f - minY * scale
        fitPending = false
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (fitPending) fit()
    }

    // ---------- drawing ----------
    override fun onDraw(c: Canvas) {
        val f = flow ?: return
        c.save()
        c.translate(ox, oy)
        c.scale(scale, scale)

        // dotted background
        val step = 28 * d
        val x0 = toWorldX(0f); val y0 = toWorldY(0f); val x1 = toWorldX(width.toFloat()); val y1 = toWorldY(height.toFloat())
        var gx = Math.floor((x0 / step).toDouble()).toFloat() * step
        while (gx < x1) {
            var gy = Math.floor((y0 / step).toDouble()).toFloat() * step
            while (gy < y1) { c.drawCircle(gx, gy, 1.2f * d, pDot); gy += step }
            gx += step
        }

        // lines
        f.edges.forEach { e ->
            val a = f.node(e.from) ?: return@forEach
            val b = f.node(e.to) ?: return@forEach
            drawCurve(c, outX(a), outY(a, e.port), inX(b), inY(b))
            val mx = (outX(a) + inX(b)) / 2f
            val my = (outY(a, e.port) + inY(b)) / 2f
            pFill.color = cSolid
            c.drawCircle(mx, my, 9 * d, pFill)
            pStroke.color = cMuted; pStroke.strokeWidth = 1.5f * d
            c.drawCircle(mx, my, 9 * d, pStroke)
            val k = 3.2f * d
            c.drawLine(mx - k, my - k, mx + k, my + k, pStroke)
            c.drawLine(mx - k, my + k, mx + k, my - k, pStroke)
        }
        // line being dragged
        connFrom?.let { n ->
            pEdge.color = NodeSpecs.get(n.type)?.color ?: cMuted
            drawCurve(c, outX(n), outY(n, connPort), curX, curY)
            pEdge.color = cMuted
        }

        // nodes
        f.nodes.forEach { n ->
            val spec = NodeSpecs.get(n.type)
            val color = spec?.color ?: cMuted
            rect.set(n.x, n.y, n.x + nodeW, n.y + nodeH)
            pFill.color = cSolid
            c.drawRoundRect(rect, 14 * d, 14 * d, pFill)
            val st = states[n.id] ?: 0
            pStroke.strokeWidth = (if (st == FlowRunner.RUNNING) 3.5f else 2f) * d
            pStroke.color = if (st > 0) stateColors[st] else color
            c.drawRoundRect(rect, 14 * d, 14 * d, pStroke)
            // colour tab
            pFill.color = color
            c.drawRoundRect(n.x + 10 * d, n.y + 14 * d, n.x + 15 * d, n.y + nodeH - 14 * d, 3 * d, 3 * d, pFill)
            val tw = nodeW - 36 * d
            c.drawText(TextUtils.ellipsize(spec?.title ?: n.type, android.text.TextPaint(pTitle), tw, TextUtils.TruncateAt.END).toString(),
                n.x + 26 * d, n.y + 28 * d, pTitle)
            val sub = spec?.summary?.invoke(n.cfg) ?: ""
            c.drawText(TextUtils.ellipsize(sub, android.text.TextPaint(pSub), tw, TextUtils.TruncateAt.END).toString(),
                n.x + 26 * d, n.y + 48 * d, pSub)
            // input dot
            if (hasInput(n)) drawPort(c, inX(n), inY(n), cSolid, color)
            // output dots
            val outs = spec?.outputs ?: 1
            for (p in 0 until outs) {
                drawPort(c, outX(n), outY(n, p), color, color)
                if (outs == 2) c.drawText(if (p == 0) "yes" else "no", n.x + nodeW - 30 * d, outY(n, p) + 3.5f * d, pLbl)
            }
        }
        c.restore()
    }

    private fun drawPort(c: Canvas, x: Float, y: Float, fill: Int, stroke: Int) {
        pFill.color = fill
        c.drawCircle(x, y, portR, pFill)
        pStroke.strokeWidth = 2 * d; pStroke.color = stroke
        c.drawCircle(x, y, portR, pStroke)
    }

    private fun drawCurve(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) {
        val dx = max(50 * d, abs(x2 - x1) / 2f)
        path.reset()
        path.moveTo(x1, y1)
        path.cubicTo(x1 + dx, y1, x2 - dx, y2, x2, y2)
        c.drawPath(path, pEdge)
    }

    // ---------- touch ----------
    private var mode = 0   // 0 none, 1 pan, 2 drag node, 3 connect, 4 pinch
    private var dragNode: FNode? = null
    private var connFrom: FNode? = null
    private var connPort = 0
    private var curX = 0f
    private var curY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private var longFired = false
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val longRun = Runnable {
        val n = dragNode
        if (mode == 2 && !moved && n != null) { longFired = true; performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS); onNodeLong?.invoke(n) }
    }

    private val scaler = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(g: ScaleGestureDetector): Boolean {
            val ns = (scale * g.scaleFactor).coerceIn(0.4f, 2f)
            val k = ns / scale
            ox = g.focusX - (g.focusX - ox) * k
            oy = g.focusY - (g.focusY - oy) * k
            scale = ns
            invalidate()
            return true
        }
    })

    private fun nodeAt(wx: Float, wy: Float): FNode? =
        flow?.nodes?.lastOrNull { wx >= it.x && wx <= it.x + nodeW && wy >= it.y && wy <= it.y + nodeH }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val f = flow ?: return false
        scaler.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                downX = e.x; downY = e.y; lastX = e.x; lastY = e.y
                moved = false; longFired = false
                val wx = toWorldX(e.x); val wy = toWorldY(e.y)
                val hitR = max(portR * 1.9f, 18 * d / scale * scale)
                // 1) a line's x button
                for (ed in f.edges) {
                    val a = f.node(ed.from) ?: continue
                    val b = f.node(ed.to) ?: continue
                    val mx = (outX(a) + inX(b)) / 2f
                    val my = (outY(a, ed.port) + inY(b)) / 2f
                    if (hypot(wx - mx, wy - my) < 14 * d) {
                        f.edges.remove(ed)
                        invalidate(); onChanged?.invoke()
                        mode = 0
                        return true
                    }
                }
                // 2) an output dot starts a new line
                for (n in f.nodes.reversed()) {
                    val outs = NodeSpecs.get(n.type)?.outputs ?: 1
                    for (p in 0 until outs) {
                        if (hypot(wx - outX(n), wy - outY(n, p)) < hitR) {
                            mode = 3; connFrom = n; connPort = p; curX = wx; curY = wy
                            invalidate()
                            return true
                        }
                    }
                }
                // 3) a node
                val n = nodeAt(wx, wy)
                if (n != null) {
                    mode = 2; dragNode = n
                    f.nodes.remove(n); f.nodes.add(n)   // bring to front
                    postDelayed(longRun, ViewConfiguration.getLongPressTimeout().toLong())
                } else {
                    mode = 1
                }
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                removeCallbacks(longRun)
                mode = 4
                connFrom = null
            }
            MotionEvent.ACTION_MOVE -> {
                if (mode == 4 || scaler.isInProgress) { mode = 4; return true }
                val dx = e.x - lastX
                val dy = e.y - lastY
                if (!moved && hypot(e.x - downX, e.y - downY) > slop) { moved = true; removeCallbacks(longRun) }
                when (mode) {
                    1 -> { ox += dx; oy += dy; invalidate() }
                    2 -> if (moved && !longFired) {
                        dragNode?.let { it.x += dx / scale; it.y += dy / scale }
                        invalidate()
                    }
                    3 -> { curX = toWorldX(e.x); curY = toWorldY(e.y); invalidate() }
                }
                lastX = e.x; lastY = e.y
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longRun)
                when (mode) {
                    3 -> {
                        val from = connFrom
                        val target = nodeAt(toWorldX(e.x), toWorldY(e.y))
                        if (from != null && target != null && target.id != from.id && hasInput(target) &&
                            f.edges.none { it.from == from.id && it.port == connPort && it.to == target.id }
                        ) {
                            f.edges.add(FEdge(from.id, connPort, target.id))
                            onChanged?.invoke()
                        }
                    }
                    2 -> {
                        val n = dragNode
                        if (n != null && !moved && !longFired) onNodeTap?.invoke(n)
                        else if (moved) onChanged?.invoke()
                    }
                }
                connFrom = null; dragNode = null; mode = 0
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longRun)
                connFrom = null; dragNode = null; mode = 0
                invalidate()
            }
        }
        return true
    }
}
