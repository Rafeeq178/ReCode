package com.vethos.app.tools

import android.os.Handler
import android.os.Looper
import com.vethos.app.R
import com.vethos.app.cap.Caps
import com.vethos.app.cap.CustomTool
import com.vethos.app.net.Net
import org.json.JSONObject
import java.net.URLEncoder

/** Turns the tools the user made (Tools screen) into real [ToolDef]s the model can call. */
object CustomTools {
    fun defs(): List<ToolDef> = Caps.customTools().map { make(it) }

    private fun make(t: CustomTool): ToolDef {
        val keys = Caps.keys(t.params)
        val usage = JSONObject().also { o -> keys.forEach { o.put(it, "VALUE") } }.toString()
        val http = t.kind == "http"
        return ToolDef(
            id = t.id,
            title = t.title,
            desc = t.desc.ifBlank { t.title },
            icon = R.drawable.ic_chip,
            sensitive = http && t.method.equals("POST", true),
            params = keys.map { ToolParam(it, it) },
            usage = usage,
            run = { _, a, done -> if (http) runHttp(t, keys, a, done) else runPrompt(t, keys, a, done) },
            headless = http,
        )
    }

    private fun fill(template: String, keys: List<String>, a: JSONObject, encode: (String) -> String): String {
        var s = template
        keys.forEach { k -> s = s.replace("{" + k + "}", encode(a.optString(k))) }
        return s
    }

    private fun runPrompt(t: CustomTool, keys: List<String>, a: JSONObject, done: (ToolResult) -> Unit) {
        val filled = fill(t.body, keys, a) { it }
        done(ToolResult(true, "Prompt ready", data = filled))
    }

    private fun runHttp(t: CustomTool, keys: List<String>, a: JSONObject, done: (ToolResult) -> Unit) {
        Thread {
            val r: ToolResult = try {
                val url = fill(t.url.trim(), keys, a) { URLEncoder.encode(it, "UTF-8") }
                val post = t.method.equals("POST", true)
                var body: String? = null
                if (post) {
                    val json = t.body.trimStart().let { it.startsWith("{") || it.startsWith("[") }
                    body = fill(t.body, keys, a) { v ->
                        if (json) JSONObject.quote(v).let { q -> q.substring(1, q.length - 1) } else URLEncoder.encode(v, "UTF-8")
                    }
                }
                val resp = Net.request(if (post) "POST" else "GET", url, body = body, maxBytes = 300_000)
                var text = resp.body
                if (text.trimStart().startsWith("<")) text = org.jsoup.Jsoup.parse(text).text()
                text = text.trim().take(2500)
                if (resp.code in 200..299) ToolResult(true, text.ifBlank { "(empty response)" }.take(300), data = text.ifBlank { "(empty response)" })
                else ToolResult(false, "HTTP " + resp.code + ": " + text.take(200))
            } catch (e: Throwable) {
                ToolResult(false, e.message ?: "The request failed")
            }
            Handler(Looper.getMainLooper()).post { done(r) }
        }.start()
    }
}
