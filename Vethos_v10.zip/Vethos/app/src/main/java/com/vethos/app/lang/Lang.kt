package com.vethos.app.lang

import android.content.Context
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.languageid.LanguageIdentificationOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.vethos.app.data.Store
import kotlinx.coroutines.CancellationException
import java.util.Locale

/**
 * English-first translation layer.
 *  - Roman Urdu / Hinglish  -> built-in glossary (instant, no download)
 *  - other languages        -> ML Kit offline packs
 * Everything runs on the phone.
 */
object Lang {
    class Prepared(val text: String, val langName: String, val translated: Boolean, val note: String? = null)
    class Detected(val code: String, val roman: Boolean)

    val supported = listOf(
        "hi" to "Hindi", "ur" to "Urdu", "ar" to "Arabic", "bn" to "Bengali", "fa" to "Persian",
        "tr" to "Turkish", "es" to "Spanish", "fr" to "French", "de" to "German",
        "ru" to "Russian", "zh" to "Chinese", "id" to "Indonesian",
    )

    fun name(code: String): String = when (code) {
        "en" -> "English"
        "roman" -> "Roman Urdu"
        else -> supported.firstOrNull { it.first == code }?.second
            ?: Locale(code).getDisplayLanguage(Locale.ENGLISH).ifEmpty { code }
    }

    /** "hindi" / "hi" -> "hi" (null if unknown) */
    fun codeFor(word: String): String? {
        val w = word.trim().lowercase()
        if (w == "english" || w == "en") return "en"
        if (w == "farsi") return "fa"
        return supported.firstOrNull { it.first == w || it.second.lowercase() == w }?.first
    }

    private val lid by lazy {
        LanguageIdentification.getClient(LanguageIdentificationOptions.Builder().setConfidenceThreshold(0.4f).build())
    }

    private suspend fun identify(text: String): String =
        try { lid.identifyLanguage(text).await() } catch (e: Throwable) { "und" }

    private fun scriptGuess(t: String): String {
        for (ch in t) {
            val c = ch.code
            if (c in 0x0900..0x097F) return "hi"
            if (c in 0x0600..0x06FF || c in 0x0750..0x077F) return "ur"
            if (c in 0x0980..0x09FF) return "bn"
            if (c in 0x0400..0x04FF) return "ru"
            if (c in 0x4E00..0x9FFF) return "zh"
        }
        return "und"
    }

    suspend fun detect(text: String): Detected {
        val t = text.trim()
        val letters = t.filter { it.isLetter() }
        if (letters.isEmpty()) return Detected("en", false)
        val latin = letters.count { it.code < 0x250 }
        if (latin * 10 >= letters.length * 9) {
            if (RomanGlossary.isRoman(t)) return Detected("ur", true)
            if (t.length < 12) return Detected("en", false)
            val c = identify(t)
            if (c == "und" || c == "en") return Detected("en", false)
            if (c.endsWith("-Latn")) return Detected("hi", true)
            return Detected(c.substringBefore('-'), false)
        }
        val c = identify(t).substringBefore('-')
        return Detected(if (c != "und") c else scriptGuess(t), false)
    }

    private val translators = HashMap<String, Translator>()

    /** Returns the translation, or null if a needed pack is not downloaded yet (a Wi-Fi download is then started). */
    private suspend fun mlTranslate(src: String, tgt: String, text: String): String? {
        if (src == tgt) return text
        val s = TranslateLanguage.fromLanguageTag(src) ?: throw IllegalArgumentException("Unsupported language: $src")
        val t = TranslateLanguage.fromLanguageTag(tgt) ?: throw IllegalArgumentException("Unsupported language: $tgt")
        if (!Packs.isReady(src) || !Packs.isReady(tgt)) {
            Packs.background(src)
            Packs.background(tgt)
            return null
        }
        val tr = translators.getOrPut("$s>$t") {
            Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(s).setTargetLanguage(t).build())
        }
        return tr.translate(text).await()
    }

    private fun packMissing(code: String) = IllegalStateException(
        "The ${name(code)} language pack is not downloaded yet. Open Translator > Offline language packs (Wi-Fi once, then it works offline)."
    )

    /** Turns what the user typed into what the model receives (always English). */
    suspend fun prepare(ctx: Context, text: String): Prepared {
        val t = text.trim()
        if (!Store.englishMode || t.isEmpty()) return Prepared(text, "", false)
        val d = try { detect(t) } catch (e: CancellationException) { throw e } catch (e: Throwable) { Detected("en", false) }
        if (d.code == "en" && !d.roman) return Prepared(t, "English", false)
        if (d.roman) {
            val eng = RomanGlossary.toEnglish(t)
            return Prepared(eng + "\n[Original in Roman Urdu/Hindi: " + t + "]", "Roman Urdu", true)
        }
        val langName = name(d.code)
        val res = try {
            mlTranslate(d.code, "en", t)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            null
        }
        if (res != null) return Prepared(res, langName, true)
        return Prepared(
            t + "\n[The message above is in $langName. Understand it and answer in English.]",
            langName, false,
            "Downloading the $langName pack in the background (Wi-Fi only). Until then your text is sent as it is."
        )
    }

    /** Offline translator for the Translator screen, /translate and the translate tool. [from]: auto, roman or a code. */
    suspend fun translate(ctx: Context, text: String, from: String, to: String): Result<String> = try {
        val t = text.trim()
        if (t.isEmpty()) throw IllegalArgumentException("Nothing to translate")
        var src = from
        var roman = false
        if (from == "auto") {
            val d = detect(t)
            src = d.code
            roman = d.roman
        } else if (from == "roman") {
            roman = true
        }
        if (roman) {
            val eng = RomanGlossary.toEnglish(t)
            if (to == "en") Result.success(eng)
            else Result.success(mlTranslate("en", to, eng) ?: throw packMissing(to))
        } else if (src == to) {
            Result.success(t)
        } else {
            Result.success(mlTranslate(src, to, t) ?: throw packMissing(if (Packs.isReady(src)) to else src))
        }
    } catch (e: CancellationException) {
        throw e
    } catch (e: Throwable) {
        Result.failure(e)
    }
}
