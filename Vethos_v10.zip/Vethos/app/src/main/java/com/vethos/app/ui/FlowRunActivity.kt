package com.vethos.app.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.vethos.app.flow.Flows
import com.vethos.app.flow.FlowRunner
import com.vethos.app.tools.Launchers
import com.vethos.app.tools.PermHelper
import com.vethos.app.tools.ToolCtx
import kotlinx.coroutines.launch

/** An invisible screen that runs one automation (from a trigger, a chat phrase or a notification) and closes. */
class FlowRunActivity : AppCompatActivity() {
    private val perms = PermHelper(this)
    private val launchers = Launchers(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val flow = Flows.get(intent.getStringExtra("flow"))
        val node = intent.getStringExtra("node") ?: ""
        val input = intent.getStringExtra("input") ?: ""
        if (flow == null) { finish(); return }
        lifecycleScope.launch {
            val ok = FlowRunner(ToolCtx(this@FlowRunActivity, perms, launchers)).run(flow, node, input)
            toast("⚡ " + flow.name + (if (ok) ": done" else ": finished with errors (see Log in the editor)"))
            finish()
        }
    }

    companion object {
        fun intent(ctx: Context, flowId: String, nodeId: String, input: String): Intent =
            Intent(ctx, FlowRunActivity::class.java)
                .putExtra("flow", flowId).putExtra("node", nodeId).putExtra("input", input)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_MULTIPLE_TASK)

        fun start(ctx: Context, flowId: String, nodeId: String, input: String) {
            ctx.startActivity(intent(ctx, flowId, nodeId, input))
        }
    }
}
