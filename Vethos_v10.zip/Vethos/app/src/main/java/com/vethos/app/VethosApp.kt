package com.vethos.app

import android.app.Activity
import android.app.Application
import android.os.Bundle
import androidx.appcompat.app.AppCompatDelegate
import com.vethos.app.data.Store
import java.io.File

class VethosApp : Application() {
    override fun onCreate() {
        // Save any crash to files/crash.txt; the next launch shows it on screen (CrashActivity).
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                File(filesDir, "crash.txt").writeText(
                    "Android ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT})\n" +
                    "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}\n" +
                    "abis=${android.os.Build.SUPPORTED_ABIS.joinToString()}\n" +
                    "thread=${t.name}\n\n" + android.util.Log.getStackTraceString(e)
                )
            } catch (_: Throwable) { }
            old?.uncaughtException(t, e)
        }
        super.onCreate()
        Store.init(this)
        applyTheme()

        // is any Vethos screen visible? (automation triggers run at once if yes, else show a notification)
        registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            override fun onActivityStarted(a: Activity) { started++ }
            override fun onActivityStopped(a: Activity) { if (started > 0) started-- }
            override fun onActivityCreated(a: Activity, b: Bundle?) {}
            override fun onActivityResumed(a: Activity) {}
            override fun onActivityPaused(a: Activity) {}
            override fun onActivitySaveInstanceState(a: Activity, b: Bundle) {}
            override fun onActivityDestroyed(a: Activity) {}
        })
    }

    companion object {
        private var started = 0
        val isForeground: Boolean get() = started > 0

        fun applyTheme() {
            AppCompatDelegate.setDefaultNightMode(
                when (Store.theme) {
                    1 -> AppCompatDelegate.MODE_NIGHT_NO
                    2 -> AppCompatDelegate.MODE_NIGHT_YES
                    else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                }
            )
        }
    }
}
