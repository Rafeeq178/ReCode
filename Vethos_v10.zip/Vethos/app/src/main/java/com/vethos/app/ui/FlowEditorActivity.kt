package com.vethos.app.ui

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.vethos.app.R
import com.vethos.app.databinding.ActivityFlowEditorBinding
import com.vethos.app.flow.FNode
import com.vethos.app.flow.Flow
import com.vethos.app.flow.FlowRunner
import com.vethos.app.flow.Flows
import com.vethos.app.flow.NodeSpecs
import com.vethos.app.flow.Triggers
import com.vethos.app.tools.Launchers
import com.vethos.app.tools.PermHelper
import com.vethos.app.tools.ToolCtx
import kotlinx.coroutines.launch

/** The n8n-style editor of one automation. */
class FlowEditorActivity : AppCompatActivity() {
    private lateinit var b: ActivityFlowEditorBinding
    private lateinit var flow: Flow
    private val perms = PermHelper(this)
    private val launchers = Launchers(this)
    private var running = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityFlowEditorBinding.inflate(layoutInflater)
        setContentView(b.root)
        val f = Flows.get(intent.getStringExtra("id"))
        if (f == null) { finish(); return }
        flow = f

        b.title.text = flow.name
        b.canvas.flow = flow
        b.canvas.onChanged = { Flows.save(); refreshHint() }
        b.canvas.onNodeTap = { edit(it) }
        b.canvas.onNodeLong = { nodeMenu(it) }
        refreshHint()

        b.btnBack.setOnClickListener { finish() }
        b.title.setOnClickListener { rename() }
        b.btnRun.setOnClickListener { runFlow() }
        b.btnMore.setOnClickListener { more() }
        b.btnAdd.setOnClickListener { addNode() }
        b.btnLog.setOnClickListener { showLog() }
    }

    override fun onPause() {
        super.onPause()
        Flows.save()
        try { Triggers.rearm(this) } catch (_: Throwable) { }
    }

    private fun refreshHint() {
        b.hint.visibility = if (flow.nodes.size <= 2 && flow.edges.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun rename() {
        inputDialog("Rename automation", flow.name, "Name") { n ->
            flow.name = n.trim().ifEmpty { flow.name }
            b.title.text = flow.name
            Flows.save()
        }
    }

    // ---------- nodes ----------
    private fun addNode() {
        val icon = mapOf("Triggers" to R.drawable.ic_play, "Logic" to R.drawable.ic_regen, "Actions" to R.drawable.ic_chip, "Internet" to R.drawable.ic_search, "Email" to R.drawable.ic_chat)
        showSheet("Add a node", NodeSpecs.all.map { s ->
            SheetRow(icon[s.group] ?: R.drawable.ic_chip, s.title, s.group) { add(s.type) }
        })
    }

    private fun add(type: String) {
        val d = resources.displayMetrics.density
        val n = FNode(Flows.newId("n"), type, b.canvas.centerX() - 88 * d, b.canvas.centerY() - 33 * d, NodeSpecs.defaults(type))
        flow.nodes.add(n)
        Flows.save()
        b.canvas.invalidate()
        refreshHint()
        edit(n)
    }

    private fun edit(n: FNode) {
        NodeEditor.show(this, n) {
            Flows.save()
            b.canvas.invalidate()
        }
    }

    private fun nodeMenu(n: FNode) {
        val spec = NodeSpecs.get(n.type)
        showSheet(spec?.title ?: "Node", listOf(
            SheetRow(R.drawable.ic_edit, "Settings") { edit(n) },
            SheetRow(R.drawable.ic_copy, "Duplicate") {
                val c = FNode(Flows.newId("n"), n.type, n.x + 30f, n.y + 30f, org.json.JSONObject(n.cfg.toString()))
                flow.nodes.add(c)
                Flows.save()
                b.canvas.invalidate()
            },
            SheetRow(R.drawable.ic_trash, "Delete") {
                flow.nodes.remove(n)
                flow.edges.removeAll { it.from == n.id || it.to == n.id }
                Flows.save()
                b.canvas.invalidate()
                refreshHint()
            },
        ))
    }

    // ---------- run ----------
    private fun runFlow() {
        if (running) return
        val trig = flow.triggers()
        if (trig.isEmpty()) {
            toast("Add a trigger first: Manual start, Chat phrase, Time or Phone event")
            return
        }
        if (trig.size == 1) start(trig[0])
        else showSheet("Start from", trig.map { n ->
            val s = NodeSpecs.get(n.type)
            SheetRow(R.drawable.ic_play, s?.title ?: n.type, s?.summary?.invoke(n.cfg)) { start(n) }
        })
    }

    private fun start(n: FNode) {
        running = true
        b.canvas.states.clear()
        b.canvas.invalidate()
        val input = if (n.type == "keyword") n.cfg.optString("phrase") else ""
        lifecycleScope.launch {
            val ok = FlowRunner(ToolCtx(this@FlowEditorActivity, perms, launchers)).run(flow, n.id, input) { id, st ->
                b.canvas.states[id] = st
                b.canvas.invalidate()
            }
            running = false
            toast(if (ok) "✔ Done" else "✖ Finished with errors. Tap Log.")
        }
    }

    private fun showLog() {
        val lines = FlowRunner.logs[flow.id]
        MaterialAlertDialogBuilder(this)
            .setTitle("Last run")
            .setMessage(if (lines.isNullOrEmpty()) "Nothing yet. Press ▶ to run this automation." else lines.joinToString("\n"))
            .setPositiveButton("Close", null)
            .show()
    }

    private fun more() {
        showSheet(flow.name, listOf(
            SheetRow(R.drawable.ic_check, "Switched on", "Triggers only work while it is on", flow.enabled) {
                flow.enabled = !flow.enabled
                Flows.save()
                try { Triggers.rearm(this) } catch (_: Throwable) { }
                toast(if (flow.enabled) "Switched on" else "Switched off")
            },
            SheetRow(R.drawable.ic_expand, "Fit to screen") { b.canvas.fit() },
            SheetRow(R.drawable.ic_pin, "Rename") { rename() },
            SheetRow(R.drawable.ic_trash, "Delete automation") {
                confirm("Delete this automation?", flow.name, "Delete") {
                    Flows.delete(flow.id)
                    try { Triggers.rearm(this) } catch (_: Throwable) { }
                    finish()
                }
            },
        ))
    }
}
