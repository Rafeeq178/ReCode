package com.vethos.app.flow

import com.vethos.app.data.Store
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class FNode(val id: String, var type: String, var x: Float, var y: Float, var cfg: JSONObject = JSONObject())

/** from-node output [port] -> to-node. An "if" node has port 0 = yes and port 1 = no. */
class FEdge(val from: String, val port: Int, val to: String)

class Flow(
    val id: String,
    var name: String,
    var enabled: Boolean,
    val nodes: MutableList<FNode> = mutableListOf(),
    val edges: MutableList<FEdge> = mutableListOf(),
) {
    fun node(id: String): FNode? = nodes.firstOrNull { it.id == id }
    fun triggers(): List<FNode> = nodes.filter { NodeSpecs.get(it.type)?.isTrigger == true }
}

/** Storage of all automations (files/flows.json). */
object Flows {
    private var cache: MutableList<Flow>? = null
    private val file get() = File(Store.app.filesDir, "flows.json")
    private var counter = 0

    fun newId(prefix: String) = prefix + System.currentTimeMillis() + "_" + (counter++)

    fun all(): MutableList<Flow> {
        cache?.let { return it }
        val out = mutableListOf<Flow>()
        try {
            if (file.exists()) {
                val a = JSONArray(file.readText())
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    val f = Flow(o.getString("id"), o.optString("name", "Automation"), o.optBoolean("on", true))
                    val ns = o.optJSONArray("nodes") ?: JSONArray()
                    for (k in 0 until ns.length()) {
                        val n = ns.getJSONObject(k)
                        f.nodes.add(FNode(n.getString("id"), n.getString("type"), n.optDouble("x", 0.0).toFloat(), n.optDouble("y", 0.0).toFloat(), n.optJSONObject("cfg") ?: JSONObject()))
                    }
                    val es = o.optJSONArray("edges") ?: JSONArray()
                    for (k in 0 until es.length()) {
                        val e = es.getJSONObject(k)
                        f.edges.add(FEdge(e.getString("f"), e.optInt("p", 0), e.getString("t")))
                    }
                    out.add(f)
                }
            }
        } catch (_: Exception) { }
        cache = out
        return out
    }

    fun get(id: String?): Flow? = all().firstOrNull { it.id == id }

    fun save() {
        val a = JSONArray()
        all().forEach { f ->
            val ns = JSONArray()
            f.nodes.forEach { n ->
                ns.put(JSONObject().put("id", n.id).put("type", n.type).put("x", n.x.toDouble()).put("y", n.y.toDouble()).put("cfg", n.cfg))
            }
            val es = JSONArray()
            f.edges.forEach { e -> es.put(JSONObject().put("f", e.from).put("p", e.port).put("t", e.to)) }
            a.put(JSONObject().put("id", f.id).put("name", f.name).put("on", f.enabled).put("nodes", ns).put("edges", es))
        }
        file.writeText(a.toString())
    }

    fun add(f: Flow): Flow { all().add(f); save(); return f }

    fun create(name: String): Flow {
        val f = Flow(newId("f"), name, true)
        f.nodes.add(FNode(newId("n"), "manual", 40f, 120f))
        return add(f)
    }

    fun delete(id: String) { all().removeAll { it.id == id }; save() }

    fun duplicate(src: Flow): Flow {
        val idMap = HashMap<String, String>()
        val f = Flow(newId("f"), src.name + " copy", false)
        src.nodes.forEach { n ->
            val nid = newId("n")
            idMap[n.id] = nid
            f.nodes.add(FNode(nid, n.type, n.x + 24f, n.y + 24f, JSONObject(n.cfg.toString())))
        }
        src.edges.forEach { e -> idMap[e.from]?.let { a -> idMap[e.to]?.let { b -> f.edges.add(FEdge(a, e.port, b)) } } }
        return add(f)
    }

    /** Enabled automations whose keyword trigger is contained in what the user typed. */
    fun matchKeyword(text: String): List<Pair<Flow, FNode>> {
        val t = text.lowercase()
        val out = ArrayList<Pair<Flow, FNode>>()
        all().filter { it.enabled }.forEach { f ->
            f.nodes.filter { it.type == "keyword" }.forEach { n ->
                val ph = n.cfg.optString("phrase").trim().lowercase()
                if (ph.isNotEmpty() && t.contains(ph)) out.add(f to n)
            }
        }
        return out
    }

    // ---------- ready-made examples ----------
    class Example(val title: String, val desc: String, val build: () -> Flow)

    private fun chain(name: String, vararg steps: Pair<String, JSONObject>): Flow {
        val f = Flow(newId("f"), name, false)
        var prev: FNode? = null
        steps.forEachIndexed { i, (type, cfg) ->
            val n = FNode(newId("n"), type, 40f + i * 210f, 140f, cfg)
            f.nodes.add(n)
            prev?.let { f.edges.add(FEdge(it.id, 0, n.id)) }
            prev = n
        }
        return f
    }

    private fun tool(id: String, vararg args: Pair<String, String>): JSONObject {
        val a = JSONObject()
        args.forEach { a.put(it.first, it.second) }
        return JSONObject().put("tool", id).put("args", a)
    }

    val examples: List<Example> = listOf(
        Example("Torch phrase", "Type “torch on” in a chat and the flashlight turns on") {
            chain("Torch phrase",
                "keyword" to JSONObject().put("phrase", "torch on"),
                "tool" to tool("flashlight", "on" to "true"))
        },
        Example("Charger connected", "When the charger is plugged in, show the battery level") {
            chain("Charger connected",
                "event" to JSONObject().put("event", "charging_on"),
                "tool" to tool("battery"),
                "tool" to tool("notify", "title" to "Charging", "text" to "{{last}}"))
        },
        Example("Morning battery report", "Every day at 07:00 send a battery notification") {
            chain("Morning battery report",
                "time" to JSONObject().put("mode", "daily").put("time", "07:00"),
                "tool" to tool("battery"),
                "tool" to tool("notify", "title" to "Good morning", "text" to "{{last}}"))
        },
        Example("Battery low warning", "On low battery, warn only if it is under 20%") {
            val f = chain("Battery low warning",
                "event" to JSONObject().put("event", "battery_low"),
                "tool" to tool("battery"),
                "if" to JSONObject().put("left", "{{last}}").put("op", "less").put("right", "20"),
                "tool" to tool("notify", "title" to "Battery is low", "text" to "{{last}}"))
            // the notification must hang on the "yes" port (port 0), which chain() already used
            f
        },
        Example("Morning news to Blogger", "Every day 08:00: fetch headlines, let the model write a post, send it to Blogger") {
            chain("Morning news to Blogger",
                "time" to JSONObject().put("mode", "daily").put("time", "08:00"),
                "rss" to JSONObject().put("feed", "world").put("count", "5"),
                "ai" to JSONObject().put("prompt", "Write a short blog post of about 150 words about today's world news. Put a catchy title on the first line. Use these headlines:\n{{last}}"),
                "blogger" to JSONObject().put("to", "").put("title", "Today's news").put("body", "{{last}}"))
        },
        Example("Weather every morning", "Every day 07:30 send a weather notification (set your city)") {
            chain("Weather every morning",
                "time" to JSONObject().put("mode", "daily").put("time", "07:30"),
                "weather" to JSONObject().put("city", "Lahore"),
                "tool" to tool("notify", "title" to "Weather", "text" to "{{last}}"))
        },
        Example("Unread emails alert", "Every hour check unread emails and notify") {
            chain("Unread emails alert",
                "time" to JSONObject().put("mode", "interval").put("every", "60"),
                "email_read" to JSONObject().put("only", "unread").put("count", "5"),
                "tool" to tool("notify", "title" to "Emails", "text" to "{{last}}"))
        },
        Example("Research to Telegram", "Press play: search the web, summarize with the model, send to Telegram") {
            chain("Research to Telegram",
                "manual" to JSONObject(),
                "search" to JSONObject().put("query", "latest AI news").put("count", "5"),
                "ai" to JSONObject().put("prompt", "Summarize these search results in 5 short bullet points:\n{{last}}"),
                "telegram" to JSONObject().put("token", "").put("chat", "").put("text", "{{last}}"))
        },
    )
}
