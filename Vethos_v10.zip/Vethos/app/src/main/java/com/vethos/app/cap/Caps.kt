package com.vethos.app.cap

import com.vethos.app.data.Store
import org.json.JSONArray
import org.json.JSONObject

/** A skill = ready-made instructions the app hands to the model when the request matches. */
class Skill(
    val id: String,
    var name: String,
    var desc: String,
    /** comma separated words; "!word" = strong match */
    var triggers: String,
    var instructions: String,
    /** comma separated tool ids this skill needs (optional) */
    var tools: String = "",
    var on: Boolean = true,
)

/** A tone = how the assistant should sound. One tone can be active. */
class Tone(val id: String, var name: String, var text: String)

/**
 * A tool made by the user.
 * kind "http"   = calls [url] (use {param} placeholders), GET or POST with [body].
 * kind "prompt" = fills [body] (a prompt template with {param} placeholders) and gives it to the model.
 */
class CustomTool(
    val id: String,
    var title: String,
    var desc: String,
    var kind: String,
    var url: String,
    var method: String,
    var params: String,
    var body: String,
    var triggers: String,
)

/** Storage + defaults for skills, tones and custom tools (all editable, all exportable). */
object Caps {
    private val prefs get() = Store.app.getSharedPreferences("vethos", 0)
    private var skillCache: MutableList<Skill>? = null
    private var toneCache: MutableList<Tone>? = null
    private var toolCache: MutableList<CustomTool>? = null
    private var counter = 0

    private fun newId(prefix: String) = prefix + System.currentTimeMillis() + "_" + (counter++)

    // ---------------- skills ----------------

    fun skills(): MutableList<Skill> {
        skillCache?.let { return it }
        val out = mutableListOf<Skill>()
        val raw = prefs.getString("skills_v1", null)
        if (raw != null) {
            try {
                val a = JSONArray(raw)
                for (i in 0 until a.length()) out.add(skillFrom(a.getJSONObject(i), a.getJSONObject(i).optString("id")))
            } catch (_: Exception) { out.clear() }
        }
        if (raw == null) out.addAll(defaultSkills())
        skillCache = out
        return out
    }

    fun newSkill(name: String, desc: String, triggers: String, instructions: String, tools: String): Skill {
        val s = Skill(newId("s"), name, desc, triggers, instructions, tools)
        skills().add(s); saveSkills()
        return s
    }

    fun saveSkills() {
        val a = JSONArray()
        skills().forEach { a.put(skillTo(it, true)) }
        prefs.edit().putString("skills_v1", a.toString()).apply()
    }

    private fun skillTo(s: Skill, withId: Boolean) = JSONObject().apply {
        if (withId) put("id", s.id)
        put("name", s.name); put("desc", s.desc); put("triggers", s.triggers)
        put("instructions", s.instructions); put("tools", s.tools); put("on", s.on)
    }

    private fun skillFrom(o: JSONObject, id: String) = Skill(
        id.ifBlank { newId("s") }, o.optString("name", "Skill"), o.optString("desc"), o.optString("triggers"),
        o.optString("instructions"), o.optString("tools"), o.optBoolean("on", true),
    )

    private fun defaultSkills(): List<Skill> = listOf(
        Skill("sk_summary", "Summarizer", "Short summary of any text",
            "!summarize,!summarise,summary,tldr,short mein,mukhtasar,khulasa",
            "Summarize the given text in 3 to 5 short bullet points. Keep the key facts and numbers. Do not add new information."),
        Skill("sk_email", "Email & message writer", "Writes emails and messages",
            "!email,!draft,mail likho,write a message,message likho,letter,application",
            "Write the requested email or message. For emails give a clear subject line, a polite greeting, short paragraphs and a closing. Match the tone the user asks for."),
        Skill("sk_code", "Coder & debugger", "Code, bugs and errors",
            "code,bug,error,function,program,python,javascript,kotlin,debug,fix this",
            "Give working code in a code block first, then a 2 to 3 line explanation. For a bug, name the cause and show the fixed code."),
        Skill("sk_math", "Math step by step", "Solves problems with steps",
            "solve,equation,math,step by step,sawal hal,problem",
            "Solve step by step. Put each step on its own line. Use the calc tool for arithmetic. End with: Answer: ...", "calc"),
        Skill("sk_study", "Study notes & quiz", "Notes, MCQs and revision",
            "notes,quiz,mcq,exam,revise,study,flashcard,imtihan",
            "Make short study notes with headings and bullet points, then 3 quiz questions with their answers."),
        Skill("sk_proof", "Proofreader", "Fixes spelling and grammar",
            "!proofread,correct grammar,fix grammar,spelling,galti theek,grammar",
            "Fix spelling and grammar. Give the corrected text first, then a short list of what you changed. Keep the original meaning."),
        Skill("sk_simple", "Simple explainer", "Explains in easy words",
            "explain,samjhao,simple words,eli5,kya hota hai",
            "Explain in very simple words with one everyday example. Use at most 5 sentences."),
        Skill("sk_research", "Researcher", "Searches the web and cites links",
            "!research,sources,latest,find out,pata karo,investigate",
            "Use web_search first, then fetch_url on the best link if needed. Answer only from the results and mention the source links.", "web_search,fetch_url"),
        Skill("sk_title", "Title & hashtags", "Titles, captions and hashtags",
            "title,hashtags,hashtag,caption,headline",
            "Give 5 catchy titles and 8 relevant hashtags."),
        Skill("sk_word", "Word meaning", "Meaning, example, synonym",
            "meaning,matlab,define,definition,synonym,opposite",
            "Give: the meaning in simple words, one example sentence, one synonym and one opposite."),
        Skill("sk_plan", "Planner & brainstorm", "Plans, to-do lists, ideas",
            "plan,schedule,to-do,todo,brainstorm,ideas,routine",
            "Give a short numbered plan with realistic steps or times. For brainstorming give 7 different ideas.", "notes"),
    )

    // ---------------- tones ----------------

    fun tones(): MutableList<Tone> {
        toneCache?.let { return it }
        val out = mutableListOf<Tone>()
        val raw = prefs.getString("tones_v1", null)
        if (raw != null) {
            try {
                val a = JSONArray(raw)
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    out.add(Tone(o.optString("id").ifBlank { newId("t") }, o.optString("name", "Tone"), o.optString("text")))
                }
            } catch (_: Exception) { out.clear() }
        }
        if (raw == null) out.addAll(defaultTones())
        toneCache = out
        return out
    }

    fun newTone(name: String, text: String): Tone {
        val t = Tone(newId("t"), name, text)
        tones().add(t); saveTones()
        return t
    }

    fun saveTones() {
        val a = JSONArray()
        tones().forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("text", it.text)) }
        prefs.edit().putString("tones_v1", a.toString()).apply()
    }

    /** id of the active tone, "" = none */
    var toneId: String
        get() = prefs.getString("tone_sel", "")!!
        set(v) = prefs.edit().putString("tone_sel", v).apply()

    fun activeToneText(): String = tones().firstOrNull { it.id == toneId }?.text.orEmpty()

    private fun defaultTones(): List<Tone> = listOf(
        Tone("tn_friendly", "Friendly", "warm, friendly and casual, like a helpful friend"),
        Tone("tn_pro", "Professional", "professional, clear and polite"),
        Tone("tn_short", "Short and direct", "very short and direct, no filler, at most 3 sentences unless asked for more"),
        Tone("tn_formal", "Formal", "formal and respectful, with complete sentences"),
        Tone("tn_teacher", "Teacher", "patient like a teacher, explaining step by step with simple examples"),
        Tone("tn_funny", "Funny", "light-hearted and a little funny, but still helpful"),
        Tone("tn_kind", "Empathetic", "kind and understanding, acknowledging the user's feelings first"),
        Tone("tn_motivate", "Motivational", "encouraging and energetic, motivating the user to take action"),
        Tone("tn_urdu", "Roman Urdu", "casual Roman Urdu (Urdu written in English letters) with simple words"),
    )

    // ---------------- custom tools ----------------

    fun customTools(): MutableList<CustomTool> {
        toolCache?.let { return it }
        val out = mutableListOf<CustomTool>()
        try {
            val a = JSONArray(prefs.getString("custom_tools_v1", "[]"))
            for (i in 0 until a.length()) out.add(toolFrom(a.getJSONObject(i)))
        } catch (_: Exception) { out.clear() }
        toolCache = out
        return out
    }

    fun saveTools() {
        val a = JSONArray()
        customTools().forEach { a.put(toolTo(it)) }
        prefs.edit().putString("custom_tools_v1", a.toString()).apply()
    }

    /** A new tool id that is not used by any built-in or custom tool. */
    fun uniqueToolId(title: String): String {
        var base = title.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_')
        if (base.isEmpty()) base = "tool"
        val taken = com.vethos.app.tools.Tools.builtIn.map { it.id }.toSet() + customTools().map { it.id }.toSet()
        var id = base
        var n = 2
        while (id in taken) { id = base + "_" + n; n++ }
        return id
    }

    private fun toolTo(t: CustomTool) = JSONObject().apply {
        put("id", t.id); put("title", t.title); put("desc", t.desc); put("kind", t.kind); put("url", t.url)
        put("method", t.method); put("params", t.params); put("body", t.body); put("triggers", t.triggers)
    }

    private fun toolFrom(o: JSONObject) = CustomTool(
        o.optString("id"), o.optString("title", "Tool"), o.optString("desc"), o.optString("kind", "http"),
        o.optString("url"), o.optString("method", "GET"), o.optString("params"), o.optString("body"), o.optString("triggers"),
    )

    fun keys(params: String): List<String> =
        params.split(',').map { it.trim() }.filter { it.isNotEmpty() && Regex("[A-Za-z0-9_]+").matches(it) }

    // ---------------- reset / export / import ----------------

    fun resetDefaults() {
        skillCache = defaultSkills().toMutableList(); saveSkills()
        toneCache = defaultTones().toMutableList(); saveTones()
        toneId = ""
    }

    fun exportAll(): String {
        val sk = JSONArray(); skills().forEach { sk.put(skillTo(it, false)) }
        val tn = JSONArray(); tones().forEach { tn.put(JSONObject().put("name", it.name).put("text", it.text)) }
        val tl = JSONArray(); customTools().forEach { tl.put(toolTo(it).apply { remove("id") }) }
        return JSONObject().put("vethos", "capabilities").put("version", 1)
            .put("skills", sk).put("tones", tn).put("tools", tl).toString(2)
    }

    /** Adds what is new (same name = skipped). Returns a short summary. Throws on invalid JSON. */
    fun importAll(text: String): String {
        val o = JSONObject(text.trim())
        var ns = 0; var nt = 0; var nc = 0
        o.optJSONArray("skills")?.let { a ->
            for (i in 0 until a.length()) {
                val x = a.getJSONObject(i)
                val name = x.optString("name").trim()
                if (name.isEmpty() || x.optString("instructions").isBlank()) continue
                if (skills().any { it.name.equals(name, true) }) continue
                skills().add(skillFrom(x, "")); ns++
            }
        }
        o.optJSONArray("tones")?.let { a ->
            for (i in 0 until a.length()) {
                val x = a.getJSONObject(i)
                val name = x.optString("name").trim()
                if (name.isEmpty() || x.optString("text").isBlank()) continue
                if (tones().any { it.name.equals(name, true) }) continue
                tones().add(Tone(newId("t"), name, x.optString("text"))); nt++
            }
        }
        o.optJSONArray("tools")?.let { a ->
            for (i in 0 until a.length()) {
                val x = a.getJSONObject(i)
                val title = x.optString("title").trim()
                val kind = x.optString("kind", "http")
                if (title.isEmpty() || (kind != "http" && kind != "prompt")) continue
                if (customTools().any { it.title.equals(title, true) }) continue
                val t = toolFrom(x)
                customTools().add(CustomTool(uniqueToolId(title), t.title, t.desc, t.kind, t.url, t.method, t.params, t.body, t.triggers)); nc++
            }
        }
        if (ns > 0) saveSkills()
        if (nt > 0) saveTones()
        if (nc > 0) saveTools()
        return "Added $ns skills, $nt tones, $nc tools"
    }
}
