package com.vethos.app.data

/** Decides which code blocks can be run and turns them into a complete HTML page. */
object HtmlRun {
    private const val VIEWPORT = """<meta name="viewport" content="width=device-width, initial-scale=1">"""

    private val htmlLangs = setOf("html", "htm", "xhtml")
    private val jsLangs = setOf("js", "javascript", "mjs")
    private val looksHtml = Regex("""(?is)<!doctype\s+html|<html|<body|<script|<div|<canvas|<style|<h1|<button""")

    fun isRunnable(lang: String, code: String): Boolean = prepare(lang, code) != null

    /** Returns a full HTML page for the code, or null if the block is not something the browser can run. */
    fun prepare(lang: String, code: String): String? {
        val l = lang.trim().lowercase()
        val c = code.trim()
        if (c.isEmpty()) return null
        return when {
            l in htmlLangs -> fixHtml(c)
            l in jsLangs -> "<!DOCTYPE html><html><head><meta charset=\"utf-8\">$VIEWPORT</head><body><script>\n$c\n</script></body></html>"
            l == "svg" || (l in setOf("", "code", "text", "xml") && c.startsWith("<svg")) ->
                "<!DOCTYPE html><html><head><meta charset=\"utf-8\">$VIEWPORT</head><body style=\"margin:0\">$c</body></html>"
            l in setOf("", "code", "text", "xml") && looksHtml.containsMatchIn(c) -> fixHtml(c)
            else -> null
        }
    }

    private fun fixHtml(c: String): String {
        if (!Regex("(?i)<html").containsMatchIn(c)) {
            return "<!DOCTYPE html><html><head><meta charset=\"utf-8\">$VIEWPORT</head><body>$c</body></html>"
        }
        if (c.contains("viewport", ignoreCase = true)) return c
        return insertAfter(c, Regex("(?i)<head(\\s[^>]*)?>"), VIEWPORT)
            ?: insertAfter(c, Regex("(?i)<html[^>]*>"), "<head>$VIEWPORT</head>")
            ?: c
    }

    private fun insertAfter(html: String, re: Regex, add: String): String? {
        val m = re.find(html) ?: return null
        val at = m.range.last + 1
        return html.substring(0, at) + add + html.substring(at)
    }

    /** Page-side helper: window.Vethos.tool("battery", {}) -> Promise({ok, text, data}). */
    private const val SHIM = """<script>(function(){var cbs={},n=0;
window.__vcb=function(id,ok,text,data){var c=cbs[id];if(c){delete cbs[id];c({ok:ok,text:text,data:data});}};
window.Vethos={version:6,
tool:function(name,args){return new Promise(function(res){var id=++n;cbs[id]=res;try{__VethosNative.call(String(name),JSON.stringify(args||{}),id);}catch(e){delete cbs[id];res({ok:false,text:String(e),data:""});}});},
tools:function(){try{return JSON.parse(__VethosNative.list());}catch(e){return [];}},
toast:function(t){try{__VethosNative.toast(String(t));}catch(e){}},
copy:function(t){return window.Vethos.tool('clipboard',{action:'write',text:String(t)});}};
})();</script>"""

    /** The page that is really loaded: the user's HTML with the Vethos helper added at the top. */
    fun withShim(html: String): String =
        insertAfter(html, Regex("(?i)<head(\\s[^>]*)?>"), SHIM)
            ?: insertAfter(html, Regex("(?i)<html[^>]*>"), SHIM)
            ?: (SHIM + html)

    fun extFor(lang: String): String = when (lang.trim().lowercase()) {
        "html", "htm", "xhtml" -> "html"
        "js", "javascript", "mjs" -> "js"
        "ts", "typescript" -> "ts"
        "css" -> "css"
        "python", "py" -> "py"
        "kotlin", "kt" -> "kt"
        "java" -> "java"
        "php" -> "php"
        "json" -> "json"
        "sql" -> "sql"
        "bash", "sh", "shell" -> "sh"
        "c" -> "c"
        "cpp", "c++" -> "cpp"
        "xml", "svg" -> lang.trim().lowercase()
        "md", "markdown" -> "md"
        else -> "txt"
    }
}
