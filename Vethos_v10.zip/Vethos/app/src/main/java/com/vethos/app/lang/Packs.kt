package com.vethos.app.lang

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Offline language packs (Google ML Kit): about 30 MB each, downloaded once, then used with no internet. */
object Packs {
    private val ready = HashSet<String>().apply { add("en") }
    private val loading = HashSet<String>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val mgr get() = RemoteModelManager.getInstance()

    private fun model(tag: String) = TranslateRemoteModel.Builder(tag).build()

    suspend fun isReady(code: String): Boolean {
        if (code in ready) return true
        val tag = TranslateLanguage.fromLanguageTag(code) ?: return false
        val ok = try { mgr.isModelDownloaded(model(tag)).await() } catch (e: Throwable) { false }
        if (ok) ready.add(code)
        return ok
    }

    suspend fun download(code: String, wifiOnly: Boolean): Boolean {
        val tag = TranslateLanguage.fromLanguageTag(code) ?: return false
        val cond = DownloadConditions.Builder().apply { if (wifiOnly) requireWifi() }.build()
        return try {
            mgr.download(model(tag), cond).await()
            ready.add(code)
            true
        } catch (e: Throwable) {
            false
        }
    }

    suspend fun delete(code: String) {
        val tag = TranslateLanguage.fromLanguageTag(code) ?: return
        try { mgr.deleteDownloadedModel(model(tag)).await() } catch (_: Throwable) { }
        ready.remove(code)
    }

    /** Starts a Wi-Fi-only download without waiting (used when a chat message needs a pack that is missing). */
    fun background(code: String) {
        if (code == "en" || code in ready || TranslateLanguage.fromLanguageTag(code) == null) return
        if (!loading.add(code)) return
        scope.launch {
            try { download(code, true) } finally { loading.remove(code) }
        }
    }
}
