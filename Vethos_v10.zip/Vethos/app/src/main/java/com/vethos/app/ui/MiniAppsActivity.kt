package com.vethos.app.ui

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.vethos.app.R
import com.vethos.app.data.MiniApp
import com.vethos.app.data.MiniApps
import com.vethos.app.databinding.ActivityMiniappsBinding
import com.vethos.app.databinding.ItemPersonaBinding
import com.vethos.app.tools.Launchers

/** The mini app library: run, edit, rename, export and delete saved pages. */
class MiniAppsActivity : AppCompatActivity() {
    private lateinit var b: ActivityMiniappsBinding
    private val launchers = Launchers(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMiniappsBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnBack.setOnClickListener { finish() }
        b.btnNew.setOnClickListener { RunnerActivity.startNew(this) }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        b.list.removeAllViews()
        val apps = MiniApps.all()
        b.empty.visibility = if (apps.isEmpty()) View.VISIBLE else View.GONE
        apps.forEach { a ->
            val r = ItemPersonaBinding.inflate(layoutInflater, b.list, false)
            r.icon.setImageResource(R.drawable.ic_code)
            r.icon.imageTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.v_blue))
            r.title.text = a.name
            r.sub.text = fmtDate(a.ts) + "  ·  %.1f KB".format(MiniApps.size(a.id) / 1024.0)
            r.trail.setImageResource(R.drawable.ic_more)
            r.trail.setBackgroundResource(0)
            r.trail.imageTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.v_muted))
            r.trail.setPadding(dp(8), dp(8), dp(8), dp(8))
            r.trail.setOnClickListener { menu(a) }
            r.root.setOnClickListener { RunnerActivity.startApp(this, a.id) }
            r.root.setOnLongClickListener { menu(a); true }
            b.list.addView(r.root)
        }
    }

    private fun menu(a: MiniApp) {
        showSheet(a.name, listOf(
            SheetRow(R.drawable.ic_play, "Run") { RunnerActivity.startApp(this, a.id) },
            SheetRow(R.drawable.ic_edit, "Edit code") { RunnerActivity.startApp(this, a.id, edit = true) },
            SheetRow(R.drawable.ic_pin, "Rename") {
                inputDialog("Rename", a.name, "App name") { n ->
                    MiniApps.rename(a.id, n.trim().ifEmpty { a.name })
                    render()
                }
            },
            SheetRow(R.drawable.ic_dl, "Export as .html file") {
                val file = a.name.replace(Regex("[^A-Za-z0-9_-]"), "_").ifEmpty { "page" } + ".html"
                launchers.saveText(file, MiniApps.html(a.id) ?: "") { ok, msg -> toast(if (ok) "Saved $msg" else msg) }
            },
            SheetRow(R.drawable.ic_trash, "Delete") {
                confirm("Delete mini app?", a.name, "Delete") { MiniApps.delete(a.id); render() }
            },
        ))
    }
}
