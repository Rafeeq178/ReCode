package com.vethos.app.cap

import com.vethos.app.tools.ToolDef
import com.vethos.app.tools.Tools
import org.json.JSONObject

/**
 * The part that makes even a small model use tools and skills:
 *  1. picks the 1 skill and up to 4 tools that fit THIS message (by trigger words, not by asking the model),
 *  2. puts only those, with an exact example in the model's own tool format, right in front of the request,
 *  3. gives a strict retry prompt and a deterministic fallback when the model still gets it wrong.
 */
object Compose {
    class Plan(
        val skill: Skill?,
        val tools: List<ToolDef>,
        /** the app is sure this message needs this tool (strong trigger, short message) */
        val forced: ToolDef?,
    )

    /** "!word" = strong trigger (counts 5), plain word counts 3. A tool is offered from 3 points, forced from 5. */
    private val BUILTIN: Map<String, String> = mapOf(
        "calc" to "!calculate,!hisab,!hisaab,percent,square root,sqrt,kitna hota",
        "random" to "!password,!paasword,!random number,dice,coin toss,!flip a coin,!roll a dice",
        "encode" to "!base64,!md5,!sha256,!sha1,!sha512,hash,url encode,url decode,hex encode",
        "clipboard" to "clipboard,paste,copy this,copy to clipboard",
        "qr_make" to "!qr code,!make qr,!qr banao",
        "qr_scan" to "!scan qr,!scan barcode,scan a qr",
        "read_file" to "!read a file,read file,open file,pick a file,file padho",
        "write_file" to "save to file,write to file,!save as file,file me save",
        "speak" to "!read aloud,!read it out,speak this,!bolo",
        "web_search" to "!search,!google,find online,!dhoondo,!talash,look up",
        "fetch_url" to "open this link,read this page,webpage",
        "wikipedia" to "!wikipedia,!wiki",
        "weather" to "!weather,!mausam,!temperature,forecast,barish",
        "news" to "!news,!khabar,!khabrein,!headlines,akhbar",
        "datetime" to "!what time,!current time,!kitne baje,!todays date,!aaj ki tareekh,what day is,!waqt kya",
        "notes" to "!take a note,!note this,!yaad rakho,remember this,my notes,!show notes,!save a note,note kar lo",
        "unit_convert" to "!convert,conversion,km to,kg to,celsius,fahrenheit,miles to,pounds to",
        "text_tools" to "!word count,!count words,!uppercase,!lowercase,!reverse this,character count,sort lines",
        "json_tool" to "!json,!validate json,!format json,pretty json",
    )

    private val calcRe = Regex("""\d\s*[+*/^×÷]\s*\d|\d\s+[-x]\s+\d""")
    private val dateRe = Regex("""\d{1,2}[/.-]\d{1,2}[/.-]\d{2,4}""")
    private val urlRe = Regex("""https?://\S+""")

    private fun norm(s: String): String {
        val sb = StringBuilder(" ")
        var lastSpace = true
        for (ch in s.lowercase()) {
            if (ch == '\'' || ch == '’') continue
            if (ch.isLetterOrDigit()) { sb.append(ch); lastSpace = false }
            else if (!lastSpace) { sb.append(' '); lastSpace = true }
        }
        if (!lastSpace) sb.append(' ')
        return sb.toString()
    }

    private fun hit(trig: String, raw: String, padded: String): Boolean {
        val t = trig.trim().lowercase()
        if (t.isEmpty()) return false
        return if (t.all { it.isLetterOrDigit() || it == ' ' }) padded.contains(" $t ") else raw.contains(t)
    }

    private fun score(triggers: String, raw: String, padded: String): Int {
        var s = 0
        for (t0 in triggers.split(',')) {
            var t = t0.trim()
            var w = 3
            if (t.startsWith("!")) { w = 5; t = t.substring(1) }
            if (hit(t, raw, padded)) s += w
        }
        return s
    }

    private fun cleanName(s: String) = s.lowercase().replace(Regex("[^a-z0-9 ]"), "").trim()

    private fun toolScore(d: ToolDef, raw: String, padded: String): Int {
        val trig = BUILTIN[d.id] ?: Caps.customTools().firstOrNull { it.id == d.id }?.triggers.orEmpty()
        var s = score(trig, raw, padded)
        val parts = d.id.split('_')
        if (parts.all { padded.contains(" $it ") }) s += 2
        val title = cleanName(d.title)
        if (title.length >= 3 && padded.contains(" $title ")) s += 3
        if (d.id == "calc" && calcRe.containsMatchIn(raw) && !dateRe.containsMatchIn(raw)) s += 5
        if (d.id == "fetch_url" && urlRe.containsMatchIn(raw)) s += 5
        return s
    }

    private fun wordCount(t: String) = t.trim().split(Regex("\\s+")).count { it.isNotEmpty() }

    /** Chooses what to hand to the model for this message. [allowed] = tool ids the personality may use. */
    fun plan(text: String, allowed: Set<String>): Plan {
        val raw = text.lowercase()
        val padded = norm(text)
        var best: Skill? = null
        var bestScore = 2
        for (sk in Caps.skills()) {
            if (!sk.on) continue
            var sc = score(sk.triggers, raw, padded)
            val nm = cleanName(sk.name)
            if (nm.length >= 3 && padded.contains(" $nm ")) sc += 3
            if (sc > bestScore) { best = sk; bestScore = sc }
        }
        val pool = Tools.all.filter { it.id in allowed }
        val scored = pool.map { it to toolScore(it, raw, padded) }.filter { it.second >= 3 }.sortedByDescending { it.second }
        val chosen = LinkedHashMap<String, ToolDef>()
        best?.tools?.split(',')?.map { it.trim() }?.forEach { id ->
            if (id in allowed) pool.firstOrNull { it.id == id }?.let { chosen[id] = it }
        }
        scored.take(3).forEach { if (!chosen.containsKey(it.first.id)) chosen[it.first.id] = it.first }
        val forced = scored.firstOrNull()?.takeIf { it.second >= 5 && wordCount(text) <= 14 }?.first
        return Plan(best, chosen.values.take(4), forced)
    }

    /** Short line for the system prompt: which tools exist and the exact format. */
    fun menu(allowed: Set<String>): String {
        val list = Tools.all.filter { it.id in allowed }
        if (list.isEmpty()) return ""
        return "You can use tools: " + list.joinToString(", ") { it.id } +
            ". When the user's request needs one, reply with ONLY a block like " +
            "<function=NAME><parameter=KEY>VALUE</parameter></function> and nothing else. " +
            "The exact parameters are given with the request. Never invent a tool result."
    }

    /** The text that is really sent to the model: skill + tools + the user's words. */
    fun inject(userText: String, plan: Plan): String {
        if (plan.skill == null && plan.tools.isEmpty()) return userText
        val sb = StringBuilder()
        plan.skill?.let {
            sb.append("Skill (").append(it.name).append("): ").append(it.instructions.trim()).append("\n\n")
        }
        if (plan.tools.isNotEmpty()) {
            sb.append("Tools for this request. If one is needed, reply with ONLY a tool block and no other words:\n")
            plan.tools.forEach { sb.append(describe(it)) }
            sb.append("Format (replace the values with the user's real values):\n")
            sb.append(block(plan.tools[0])).append("\nIf no tool is needed, just answer normally.\n\n")
        }
        sb.append("User request:\n").append(userText)
        return sb.toString()
    }

    private fun describe(d: ToolDef): String {
        val keys = d.params.joinToString(", ") { it.key + if (it.optional) "?" else "" }
        return "- " + d.id + ": " + d.desc.take(90) + (if (keys.isNotEmpty()) " (params: $keys)" else "") + "\n"
    }

    /** Example values for a tool, taken from its usage JSON (or VALUE). */
    fun exampleArgs(d: ToolDef): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        try {
            val o = JSONObject(d.usage)
            val ks = o.keys()
            while (ks.hasNext() && out.size < 3) {
                val k = ks.next()
                out[k] = o.opt(k).toString().substringBefore('|')
            }
        } catch (_: Exception) { }
        if (out.isEmpty()) d.params.filter { !it.optional }.take(3).forEach { out[it.key] = "VALUE" }
        return out
    }

    private fun block(d: ToolDef): String {
        val sb = StringBuilder("<function=").append(d.id).append(">\n")
        exampleArgs(d).forEach { (k, v) -> sb.append("<parameter=").append(k).append(">").append(v).append("</parameter>\n") }
        sb.append("</function>")
        return sb.toString()
    }

    /** True when the model just copied the example values instead of using the user's. */
    fun copiedExample(d: ToolDef, args: JSONObject, userText: String): Boolean {
        val ex = exampleArgs(d)
        val req = d.params.filter { !it.optional }
        if (ex.isEmpty() || req.isEmpty()) return false
        return req.all { p ->
            val e = ex[p.key]
            val v = args.optString(p.key).trim()
            e != null && v.equals(e, true) && !userText.contains(e, true)
        }
    }

    /** Strict second attempt: shows only the one block the model must produce. */
    fun retryPrompt(d: ToolDef, userText: String): String {
        val sb = StringBuilder("Reply with ONLY this tool call and nothing else. Replace VALUE with the right value from the request:\n")
        sb.append("<function=").append(d.id).append(">\n")
        val keys = d.params.filter { !it.optional }.map { it.key }.ifEmpty { d.params.map { it.key }.take(1) }
        keys.forEach { sb.append("<parameter=").append(it).append(">VALUE</parameter>\n") }
        sb.append("</function>\n\nRequest: ").append(userText)
        return sb.toString()
    }

    // ---------------- deterministic fallback ----------------

    private fun stripLead(t: String, vararg leads: String): String {
        var s = t.trim()
        val low = s.lowercase()
        for (l in leads.sortedByDescending { it.length }) {
            val i = low.indexOf(l)
            if (i >= 0) { s = (s.substring(0, i) + " " + s.substring(i + l.length)).trim(); break }
        }
        return s.trim().trim('?', '.', '!', ':', '-', ' ').trim()
    }

    private val tailWords = setOf("today", "now", "aaj", "kya", "hai", "kaisa", "please", "plz", "tomorrow", "kal", "ka", "ki", "ke", "me", "mein", "in", "the")

    private fun cityFrom(t: String): String? {
        val pats = listOf(
            Regex("""(?:weather|mausam|temperature|forecast)\s+(?:in|of|at|for|ka|ki|ke)?\s*([A-Za-z][A-Za-z .'-]{1,28})""", RegexOption.IGNORE_CASE),
            Regex("""([A-Za-z][A-Za-z .'-]{1,28}?)\s+(?:ka|ki)\s+(?:mausam|weather)""", RegexOption.IGNORE_CASE),
            Regex("""\b(?:in|at|of|for)\s+([A-Za-z][A-Za-z .'-]{1,28})""", RegexOption.IGNORE_CASE),
        )
        for (p in pats) {
            val m = p.find(t) ?: continue
            val words = m.groupValues[1].trim().split(Regex("\\s+")).toMutableList()
            while (words.isNotEmpty() && words.last().lowercase() in tailWords) words.removeAt(words.lastIndex)
            while (words.isNotEmpty() && words.first().lowercase() in tailWords) words.removeAt(0)
            val c = words.joinToString(" ").trim()
            if (c.length >= 2) return c
        }
        return null
    }

    private val convRe = Regex("""(-?\d+(?:\.\d+)?)\s*°?\s*([A-Za-z]+)\s+(?:to|in|into|me)\s+°?([A-Za-z]+)""", RegexOption.IGNORE_CASE)

    /** Arguments the app can work out by itself. null = it cannot, so the model's answer is left alone. */
    fun fallbackArgs(d: ToolDef, text: String): JSONObject? {
        val t = text.trim()
        val o = JSONObject()
        when (d.id) {
            "calc" -> {
                val pct = Regex("""(\d+(?:\.\d+)?)\s*%\s*of\s*(\d+(?:\.\d+)?)""", RegexOption.IGNORE_CASE).find(t)
                if (pct != null) { o.put("expression", pct.value); return o }
                val e = Regex("""[0-9(][0-9+\-*/^%(). \t×÷x]*[0-9)]""").findAll(t)
                    .map { it.value.trim() }
                    .filter { Regex("""[+\-*/^%×÷x]""").containsMatchIn(it) }
                    .maxByOrNull { it.length } ?: return null
                o.put("expression", e)
            }
            "web_search" -> {
                val q = stripLead(t, "search for", "search", "google", "find online", "look up", "dhoondo", "talash karo", "talash")
                if (q.length < 2) return null
                o.put("query", q)
            }
            "wikipedia" -> {
                val q = stripLead(t, "wikipedia", "wiki", "about", "search")
                if (q.length < 2) return null
                o.put("query", q)
            }
            "weather" -> o.put("city", cityFrom(t) ?: return null)
            "news" -> {
                val q = stripLead(t, "latest news", "headlines", "news", "khabrein", "khabar", "akhbar", "about", "on")
                if (q.length >= 2) o.put("topic", q)
            }
            "fetch_url" -> o.put("url", urlRe.find(t)?.value ?: return null)
            "random" -> {
                val low = t.lowercase()
                val kind = when {
                    low.contains("password") || low.contains("paasword") -> "password"
                    Regex("\\bpin\\b").containsMatchIn(low) -> "pin"
                    low.contains("dice") -> "dice"
                    low.contains("coin") -> "coin"
                    else -> return null
                }
                o.put("kind", kind)
                Regex("\\b(\\d{1,2})\\b").find(low)?.let { if (kind == "password" || kind == "pin") o.put("length", it.groupValues[1].toInt()) }
            }
            "qr_make" -> {
                val q = stripLead(t, "qr code for", "qr code", "make qr", "qr banao", "qr")
                if (q.length < 2) return null
                o.put("text", q)
            }
            "notes" -> {
                val low = t.lowercase()
                if (low.contains("show") || low.contains("list") || low.contains("my notes") || low.contains("dikha")) {
                    o.put("action", "list")
                } else {
                    val q = stripLead(t, "take a note", "save a note", "note this", "remember this", "yaad rakho", "note kar lo", "remember")
                    if (q.length < 2) return null
                    o.put("action", "add"); o.put("text", q)
                }
            }
            "unit_convert" -> {
                val m = convRe.find(t) ?: return null
                o.put("value", m.groupValues[1]); o.put("from", m.groupValues[2]); o.put("to", m.groupValues[3])
            }
            "datetime", "qr_scan", "read_file" -> { }
            "encode", "clipboard", "speak", "write_file", "text_tools", "json_tool" -> return null
            else -> if (d.params.any { !it.optional }) return null
        }
        return o
    }
}
