package com.vethos.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.speech.RecognizerIntent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.vethos.app.R
import com.vethos.app.data.Chat
import com.vethos.app.data.ChatRepo
import com.vethos.app.data.Engine
import com.vethos.app.data.Msg
import com.vethos.app.data.Persona
import com.vethos.app.data.Personas
import com.vethos.app.data.Store
import com.vethos.app.cap.Caps
import com.vethos.app.cap.Compose
import com.vethos.app.cap.Ocr
import com.vethos.app.databinding.ActivityChatBinding
import com.vethos.app.net.Web
import com.vethos.app.lang.Speaker
import com.vethos.app.tools.Launchers
import com.vethos.app.tools.PermHelper
import com.vethos.app.tools.ToolCtx
import com.vethos.app.tools.ToolDef
import com.vethos.app.tools.ToolRunner
import com.vethos.app.tools.Tools
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.util.UUID

class ChatActivity : AppCompatActivity() {
    private lateinit var b: ActivityChatBinding
    private lateinit var chat: Chat
    private lateinit var persona: Persona
    private lateinit var adapter: ChatAdapter
    private var gen: Job? = null
    private var typer: Job? = null
    private var ready = false
    private var pendingSend: String? = null
    private var attached: Attach.Picked? = null
    private val perms = PermHelper(this)
    private val launchers = Launchers(this)
    private var busyWeb = false    // true while /research is searching and reading pages
    private var toolDepth = 0   // 0 = a tool result may be handed back to the model once
    private var plan: Compose.Plan? = null   // which skill / tools were given to the model for this message
    private var userText = ""                // what the user asked (used for validation and the fallback)
    private var retries = 1                  // one strict retry before the app does the tool itself

    // live typing state
    private val target = StringBuilder()
    private var shown = 0
    private var generating = false
    private var autoFollow = true

    private val speech = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == RESULT_OK && !t.isNullOrBlank()) {
            b.input.setText(t); b.input.setSelection(t.length)
        }
    }

    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) attachFile(uri)
    }

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) attachImage(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityChatBinding.inflate(layoutInflater)
        setContentView(b.root)

        val existing = ChatRepo.get(intent.getStringExtra("id"))
        chat = existing ?: Chat(UUID.randomUUID().toString(), "New chat", System.currentTimeMillis(), mutableListOf())
        persona = if (existing != null) {
            Personas.get(existing.persona) ?: Personas.current()
        } else {
            Personas.get(intent.getStringExtra("persona")) ?: Personas.current()
        }
        chat.persona = persona.id
        if (existing == null) Personas.selectedId = persona.id

        adapter = ChatAdapter(chat.msgs, ::copy, ::feedback, ::share, ::speakMsg) { regenerate() }
        val lm = LinearLayoutManager(this)
        b.rv.layoutManager = lm
        b.rv.adapter = adapter
        b.rv.itemAnimator = null
        b.rv.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(rv: RecyclerView, state: Int) {
                if (state == RecyclerView.SCROLL_STATE_DRAGGING) autoFollow = false
                else if (state == RecyclerView.SCROLL_STATE_IDLE && !rv.canScrollVertically(1)) autoFollow = true
            }
        })
        applyPersona()
        Blocks.onSave = { lang, code -> saveCode(lang, code) }

        b.btnBack.setOnClickListener { finish() }
        b.btnHistory.setOnClickListener { startActivity(Intent(this, HistoryActivity::class.java)) }
        b.btnMore.setOnClickListener { showOptions() }
        b.btnAttach.setOnClickListener {
            showSheet("Attach", listOf(
                SheetRow(R.drawable.ic_clip, "Document", "Text, code, .docx or PDF") { pickFile.launch(arrayOf("*/*")) },
                SheetRow(R.drawable.ic_search, "Photo", "Reads the text in the picture (English, Hindi)") { pickImage.launch("image/*") },
            ))
        }
        b.attachClose.setOnClickListener { attached = null; b.attachBar.visibility = View.GONE }
        b.btnMic.setOnClickListener { listen() }
        b.send.setOnClickListener { if (gen?.isActive == true) gen?.cancel() else send(null) }

        val preset = intent.getStringExtra("preset")?.takeIf { it.isNotEmpty() }
        if (preset != null) {
            if (intent.getBooleanExtra("autosend", false)) pendingSend = preset
            else { b.input.setText(preset); b.input.setSelection(preset.length) }
        }

        listOf("Help me plan my day", "Explain inflation in simple words", "Give me 5 ideas for a small online business")
            .forEach { q ->
                b.sugs.addView(TextView(this).apply {
                    text = q
                    setBackgroundResource(R.drawable.bg_chip_sug)
                    setTextColor(getColor(R.color.v_text))
                    textSize = 15f
                    elevation = dp(1).toFloat()
                    setPadding(dp(18), dp(12), dp(18), dp(12))
                    setOnClickListener { send(q) }
                }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(12) })
            }

        refreshHero()
        scrollBottom()
        loadModel()
    }

    private fun applyPersona() {
        b.title.text = persona.name
        b.heroTitle.text = persona.name
        b.heroSub.text = persona.desc
        val ic = Personas.icons[persona.ico.coerceIn(0, Personas.icons.lastIndex)]
        b.heroIcon.setImageResource(ic.res)
    }

    private fun refreshHero() {
        val empty = chat.msgs.isEmpty() && !adapter.thinking
        b.hero.visibility = if (empty) View.VISIBLE else View.GONE
        b.rv.visibility = if (empty) View.INVISIBLE else View.VISIBLE
    }

    private fun scrollBottom() = b.rv.post {
        if (adapter.itemCount > 0) b.rv.scrollToPosition(adapter.itemCount - 1)
    }

    private fun showBanner(text: String, onClick: (() -> Unit)?) {
        b.banner.text = text
        b.banner.visibility = View.VISIBLE
        b.banner.setOnClickListener { onClick?.invoke() }
    }

    private fun modelFile(): File? = Store.lastModel?.let { File(Store.modelsDir, it) }?.takeIf { it.exists() }

    private fun loadModel(force: Boolean = false, history: List<Msg> = chat.msgs) {
        val f = modelFile()
        if (f == null) {
            b.sub.text = "No model"
            showBanner("No model yet. Tap here to open the Library.") {
                startActivity(
                    Intent(this, MainActivity::class.java).putExtra("tab", 1)
                        .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                )
                finish()
            }
            return
        }
        b.sub.text = f.name.removeSuffix(".gguf")
        b.banner.visibility = View.GONE
        b.loading.visibility = View.VISIBLE
        ready = false
        val system = buildSystem(history)
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.Default) { Engine.load(this@ChatActivity, f.absolutePath, chat.id, system, force) }
                ready = true
                pendingSend?.let { pendingSend = null; send(it) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                showBanner("Could not load this model: " + (e.message ?: "unknown error"), null)
            } finally {
                b.loading.visibility = View.GONE
            }
        }
    }

    private fun buildSystem(history: List<Msg>): String {
        val sb = StringBuilder(persona.prompt.ifBlank { Store.systemPrompt })
        if (persona.lang.isNotBlank()) sb.append("\nAlways reply in ").append(persona.lang).append('.')
        val menu = Compose.menu(persona.allowedTools())
        if (menu.isNotEmpty()) sb.append("\n\n").append(menu)
        val best = Store.steer("best")
        if (best.isNotEmpty()) sb.append("\n\nExamples of answers the user liked:\n").append(best.joinToString("\n---\n"))
        val bad = Store.steer("bad")
        if (bad.isNotEmpty()) sb.append("\n\nAvoid answers like these (the user disliked them):\n").append(bad.joinToString("\n---\n"))
        val mem = Store.memory
        if (history.isNotEmpty() && mem > 0) {
            sb.append("\n\nEarlier in this conversation:\n")
            history.takeLast(mem).forEach {
                sb.append(if (it.role == "user") "User: " else "Assistant: ").append(Attach.display(it.en ?: it.text).take(400)).append('\n')
            }
        }
        // the tone goes last: small models follow the end of the prompt best
        val tone = persona.tone.ifBlank { Caps.activeToneText() }
        if (tone.isNotBlank()) sb.append("\n\nTone: ").append(tone).append('.')
        return sb.toString()
    }

    private fun listen() {
        try {
            speech.launch(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Store.voiceLang)
            )
        } catch (e: Exception) {
            toast("Voice input isn't available on this phone")
        }
    }

    private fun attachFile(uri: android.net.Uri) {
        lifecycleScope.launch {
            try {
                val p = withContext(Dispatchers.IO) { Attach.read(this@ChatActivity, uri) }
                attached = p
                b.attachName.text = p.name + if (p.truncated) "  (first ${Attach.MAX_CHARS} characters used)" else ""
                b.attachBar.visibility = View.VISIBLE
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                toast(e.message ?: "Could not read this file")
            }
        }
    }

    private fun attachImage(uri: android.net.Uri) {
        lifecycleScope.launch {
            try {
                toast("Reading the photo…")
                val text = Ocr.read(this@ChatActivity, uri).trim()
                if (text.isEmpty()) { toast("No text found in this photo"); return@launch }
                val cut = text.length > Attach.MAX_CHARS
                attached = Attach.Picked("Photo", if (cut) text.substring(0, Attach.MAX_CHARS) else text, cut)
                b.attachName.text = "Photo text (" + text.length + " characters)" + if (cut) " · first ${Attach.MAX_CHARS} used" else ""
                b.attachBar.visibility = View.VISIBLE
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                toast(e.message ?: "Could not read this photo")
            }
        }
    }

    private fun send(preset: String?) {
        val q = (preset ?: b.input.text.toString()).trim()
        val file = attached
        if (q.isEmpty() && file == null) return
        if (!ready) {
            if (b.loading.visibility == View.VISIBLE) { pendingSend = q; b.input.setText("") }
            else toast("Select a model first")
            return
        }
        if (gen?.isActive == true || busyWeb) return
        toolDepth = 0
        retries = 1
        b.input.setText("")
        attached = null
        b.attachBar.visibility = View.GONE
        val shownText = if (file != null) Attach.wrap(file, q) else q
        chat.msgs.add(Msg("user", shownText))
        if (chat.title == "New chat") chat.title = (if (q.isNotEmpty()) q else "File: " + file?.name).take(40)
        adapter.notifyItemInserted(chat.msgs.lastIndex)
        refreshHero(); scrollBottom()
        if (file == null && q.startsWith("/research", ignoreCase = true)) {
            val topic = q.substring(9).trim().ifBlank { clipboardText() }
            if (topic.isBlank()) replyLocal("Write the question after /research") else startResearch(topic)
            return
        }
        // pick the skill and tools that fit this message and hand only those to the model
        userText = q.ifEmpty { file?.name ?: "" }
        val p = Compose.plan(userText, persona.allowedTools())
        plan = p
        generate(Compose.inject(shownText, p))
    }

    /** Web research: search, read the best pages, then the model answers from them (sources are shown). */
    private fun startResearch(query: String) {
        val m = Msg("ai", "🔎 Searching the web…")
        chat.msgs.add(m)
        adapter.notifyItemInserted(chat.msgs.lastIndex)
        refreshHero(); scrollBottom()
        busyWeb = true
        lifecycleScope.launch {
            try {
                plan = null
                val en = query
                val res = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { Web.research(query, en) }
                m.text = "🔎 Sources\n" + res.sources
                adapter.notifyDataSetChanged()
                if (Store.keepHistory) ChatRepo.save(chat)
                busyWeb = false
                generate(res.prompt)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                m.text = "✖ " + (e.message ?: "The search failed")
                adapter.notifyDataSetChanged()
            } finally {
                busyWeb = false
            }
        }
    }

    /** An answer made by the app itself (translation, help), not by the model. */
    private fun replyLocal(text: String) {
        chat.msgs.add(Msg("ai", text))
        adapter.notifyItemInserted(chat.msgs.lastIndex)
        refreshHero(); scrollBottom()
        if (Store.keepHistory) ChatRepo.save(chat)
    }

    private fun clipboardText(): String {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val c = cm.primaryClip
        return if (c != null && c.itemCount > 0) c.getItemAt(0).coerceToText(this).toString().trim() else ""
    }

    private fun speakMsg(m: Msg) = Speaker.toggle(this, m.text)

    private fun generate(prompt: String) {
        adapter.thinking = true
        adapter.notifyItemInserted(chat.msgs.size)
        refreshHero(); scrollBottom(); setBusy(true)
        autoFollow = true
        target.setLength(0); shown = 0; generating = true
        val t0 = SystemClock.uptimeMillis()
        gen = lifecycleScope.launch {
            var ai: Msg? = null
            var tFirst = 0L
            var cancelled = false
            try {
                Engine.send(this@ChatActivity, prompt, Store.maxTokens).collect { tok ->
                    if (ai == null) {
                        tFirst = SystemClock.uptimeMillis()
                        Store.lastFirst = (tFirst - t0) / 1000f
                        val m = Msg("ai", "")
                        ai = m
                        adapter.thinking = false
                        adapter.streaming = true
                        chat.msgs.add(m)
                        adapter.notifyDataSetChanged()
                        startTyper()
                    }
                    target.append(tok)
                    ai!!.text = target.toString()
                }
                generating = false
                typer?.join() // let the typing animation finish
            } catch (e: CancellationException) {
                cancelled = true
                throw e
            } catch (e: Throwable) {
                toast("Error: " + (e.message ?: "generation failed"))
            } finally {
                generating = false
                typer?.cancel()
                ai?.text = target.toString()
                if (!cancelled && ai != null && tFirst > 0) {
                    val secs = (SystemClock.uptimeMillis() - tFirst) / 1000f
                    if (secs > 0.3f) Store.lastTps = (target.length / 4f) / secs
                }
                adapter.thinking = false
                adapter.streaming = false
                adapter.endLive()
                adapter.notifyDataSetChanged()
                setBusy(false)
                refreshHero()
                if (Store.keepHistory) ChatRepo.save(chat)
                scrollBottom()
                val done = ai
                if (!cancelled && done != null && !toolStep(done)) autoSpeak(done)
            }
        }
    }

    /** If the answer is a tool request (<tool>{...}</tool>), run the tool and show its result in the chat. */
    private fun saveCode(lang: String, code: String) {
        val ext = com.vethos.app.data.HtmlRun.extFor(lang)
        launchers.saveText("vethos_code_" + (System.currentTimeMillis() / 1000) + "." + ext, code) { ok, msg ->
            toast(if (ok) "Saved $msg" else msg)
        }
    }

    private fun autoSpeak(m: Msg) {
        if (Store.autoSpeak && m.text.isNotBlank()) Speaker.speak(this, m.text)
    }

    /** Checks the model's answer. Returns true when it was (or is being) handled as a tool request. */
    private fun toolStep(m: Msg): Boolean {
        val allowed = persona.allowedTools()
        val call = Tools.parse(m.text, allowed)
        if (call != null) {
            val def = Tools.get(call.name) ?: return false
            val args = Tools.normalize(def, call.args)
            val bad = Tools.missing(def, args).isNotEmpty() || Compose.copiedExample(def, args, userText)
            if (!bad) { runTool(m, def, args, call.before, call.after); return true }
            return recover(m, def)
        }
        // no tool block, but the app is sure this message needed one (and can fill it in itself)
        val f = plan?.forced
        if (f != null && toolDepth == 0 && Compose.fallbackArgs(f, userText) != null) return recover(m, f)
        return false
    }

    /** The model missed or garbled the tool call: one strict retry, then the app runs the tool itself. */
    private fun recover(m: Msg, def: ToolDef): Boolean {
        if (retries > 0 && ready) {
            retries--
            chat.msgs.remove(m)
            adapter.notifyDataSetChanged()
            refreshHero()
            val q = userText
            b.root.post { if (ready && gen?.isActive != true) generate(Compose.retryPrompt(def, q)) }
            return true
        }
        val fb = Compose.fallbackArgs(def, userText)
        if (fb != null) { runTool(m, def, fb, "", ""); return true }
        m.text = "⚠ I could not use " + def.title + " for this. Please say it again with the details."
        adapter.notifyDataSetChanged()
        if (Store.keepHistory) ChatRepo.save(chat)
        return true
    }

    private fun runTool(m: Msg, def: ToolDef, args: JSONObject, before: String, after: String) {
        val clean = listOf(before, after).filter { it.isNotBlank() }.joinToString("\n\n")
        fun show(status: String) {
            m.text = (if (clean.isEmpty()) "" else clean + "\n\n") + status
            adapter.notifyDataSetChanged()
            if (Store.keepHistory) ChatRepo.save(chat)
            scrollBottom()
        }
        show("⚙ " + def.title + "…")
        ToolRunner.run(ToolCtx(this, perms, launchers), def, args, false) { r ->
            show((if (r.ok) "✔ " else "✖ ") + r.text)
            // tools that return content (file, web, notes, QR...): hand it back to the model once so it can answer
            val data = r.data
            if (r.ok && data != null && toolDepth == 0) {
                toolDepth = 1
                plan = null
                b.root.post {
                    if (ready && gen?.isActive != true) {
                        generate("Result of the " + def.title + " tool:\n" + data.take(2500) +
                            "\n\nNow answer the user's request using this result. Do not call a tool again.")
                    }
                }
            }
        }
    }

    /** Reveals the received text a few characters per frame, with a blinking dot at the end. */
    private fun startTyper() {
        typer?.cancel()
        typer = lifecycleScope.launch {
            var lastShown = -1
            var lastOn = true
            while (true) {
                delay(22)
                val backlog = target.length - shown
                if (backlog > 0) shown += minOf(backlog, 1 + backlog / 10)
                if (!generating && shown >= target.length) break
                val on = shown < target.length || (SystemClock.uptimeMillis() / 450) % 2 == 0L
                if (shown != lastShown || on != lastOn) {
                    lastShown = shown; lastOn = on
                    adapter.updateLive(b.rv, Tools.hideLive(target.substring(0, shown)), on)
                    if (autoFollow && b.rv.canScrollVertically(1)) b.rv.scrollBy(0, 400)
                }
            }
        }
    }

    private fun setBusy(busy: Boolean) {
        b.send.setImageResource(if (busy) R.drawable.ic_stop else R.drawable.ic_send)
    }

    private fun copy(m: Msg) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("Vethos", m.text))
        toast("Copied")
    }

    private fun share(m: Msg) = shareText(m.text)

    private fun shareText(text: String) {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Share"))
    }

    private fun feedback(pos: Int, v: Int) {
        val m = chat.msgs.getOrNull(pos) ?: return
        m.fb = if (m.fb == v) 0 else v
        if (m.fb != 0) {
            val q = chat.msgs.take(pos).lastOrNull { it.role == "user" }?.text ?: ""
            Store.addSteer(if (v > 0) "best" else "bad", "Q: " + q.take(200) + "\nA: " + m.text.take(300))
            toast(if (v > 0) "Saved as a good answer" else "Saved as a bad answer")
        }
        adapter.notifyItemChanged(pos)
        if (Store.keepHistory) ChatRepo.save(chat)
    }

    private fun regenerate() {
        if (gen?.isActive == true || !ready) return
        toolDepth = 0
        retries = 1
        val lastAi = chat.msgs.lastOrNull() ?: return
        if (lastAi.role != "ai") return
        val userIdx = chat.msgs.indexOfLast { it.role == "user" }
        if (userIdx < 0) return
        val um = chat.msgs[userIdx]
        if (um.text.startsWith("/research", ignoreCase = true)) { toast("Send the command again"); return }
        val base = um.en ?: um.text
        userText = base.take(400)
        val p = Compose.plan(userText, persona.allowedTools())
        plan = p
        val prompt = Compose.inject(base, p)
        chat.msgs.removeAt(chat.msgs.lastIndex)
        adapter.notifyDataSetChanged()
        // The engine remembers the old answer, so reload it with the history before the last question.
        val history = chat.msgs.take(userIdx)
        val f = modelFile() ?: return
        b.loading.visibility = View.VISIBLE
        ready = false
        val system = buildSystem(history)
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.Default) { Engine.load(this@ChatActivity, f.absolutePath, chat.id, system, true) }
                ready = true
                b.loading.visibility = View.GONE
                generate(prompt)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                b.loading.visibility = View.GONE
                showBanner("Could not load this model: " + (e.message ?: "unknown error"), null)
            }
        }
    }

    private fun showOptions() {
        showSheet("Options", listOf(
            SheetRow(R.drawable.ic_plus, "New chat") {
                gen?.cancel()
                startActivity(Intent(this, ChatActivity::class.java))
                finish()
            },
            SheetRow(R.drawable.ic_chat, "Change personality") { showPersonas() },
            SheetRow(R.drawable.ic_speaker, if (Store.autoSpeak) "Read replies aloud: ON" else "Read replies aloud: OFF") {
                Store.autoSpeak = !Store.autoSpeak
                if (!Store.autoSpeak) Speaker.stop()
                toast(if (Store.autoSpeak) "Replies will be read aloud" else "Read aloud is off")
            },
            SheetRow(R.drawable.ic_share, "Export chat as text") { exportChat() },
            SheetRow(R.drawable.ic_trash, "Clear conversation") {
                confirm("Clear conversation?", "All messages in this chat will be removed.", "Clear") { clearChat() }
            },
        ))
    }

    private fun showPersonas() {
        showSheet("Personality", Personas.all().map { p ->
            SheetRow(Personas.icons[p.ico.coerceIn(0, Personas.icons.lastIndex)].res, p.name, p.desc, p.id == persona.id) {
                if (p.id != persona.id) {
                    gen?.cancel()
                    persona = p
                    chat.persona = p.id
                    Personas.selectedId = p.id
                    applyPersona()
                    loadModel(force = true)
                }
            }
        })
    }

    private fun exportChat() {
        if (chat.msgs.isEmpty()) { toast("Nothing to export yet"); return }
        shareText(chat.msgs.joinToString("\n\n") { (if (it.role == "user") "You: " else persona.name + ": ") + Attach.display(it.text) })
    }

    private fun clearChat() {
        gen?.cancel()
        chat.msgs.clear()
        chat.title = "New chat"
        adapter.notifyDataSetChanged()
        ChatRepo.delete(chat.id)
        refreshHero()
        loadModel(force = true, history = emptyList())
    }

    override fun onDestroy() {
        super.onDestroy()
        Speaker.stop()
        Blocks.onSave = null
    }

    override fun onStop() {
        super.onStop()
        if (chat.msgs.isNotEmpty() && Store.keepHistory) ChatRepo.save(chat)
    }
}
