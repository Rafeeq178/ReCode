package com.vethos.app.data

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.vethos.app.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Keeps model downloads alive when the app goes to the background and shows the progress in the
 * notification bar. It only watches Downloads.state; the download itself still runs inside Downloads.
 */
class DownloadService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var watcher: Job? = null
    private var lastRunning = setOf<String>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "Model downloads", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ServiceCompat.startForeground(
            this, ID, build("Downloading model...", 0, true),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )
        if (watcher?.isActive != true) {
            watcher = scope.launch { Downloads.state.collect { onState(it) } }
        }
        return START_NOT_STICKY
    }

    private fun onState(map: Map<String, Dl>) {
        val nm = getSystemService(NotificationManager::class.java)
        val running = map.values.filter { it.state == 0 }

        map.values.filter { it.state == 2 && it.name in lastRunning }.forEach { d ->
            val n = NotificationCompat.Builder(this, CH)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("Model ready")
                .setContentText(d.name)
                .setAutoCancel(true)
                .setContentIntent(openApp())
                .build()
            nm.notify(100 + (d.name.hashCode() and 0xFFFF), n)
        }
        lastRunning = running.map { it.name }.toSet()

        if (running.isEmpty()) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }
        val first = running.first()
        val text = if (running.size > 1) "${running.size} downloads running" else first.name
        val pct = if (first.total > 0) (first.done * 100 / first.total).toInt() else 0
        nm.notify(ID, build(text, pct, first.total <= 0))
    }

    private fun openApp(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, MainActivity::class.java).putExtra("tab", 1)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun build(text: String, pct: Int, indeterminate: Boolean): Notification =
        NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Vethos")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, pct, indeterminate)
            .setContentIntent(openApp())
            .build()

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val CH = "downloads"
        private const val ID = 7
    }
}
