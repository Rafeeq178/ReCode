package com.vethos.app.flow

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.content.Intent as AndroidIntent
import android.os.Build
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.vethos.app.R
import com.vethos.app.VethosApp
import com.vethos.app.ui.FlowRunActivity
import java.util.Calendar

/**
 * Time and phone-event triggers.
 *  - Time: Android alarms (not exact: they can be a few minutes late when the phone sleeps).
 *  - Events (charger, battery low, Wi-Fi, screen): watched while the Vethos process is alive.
 * When a trigger fires and Vethos is on screen the automation runs at once; otherwise Android does not allow
 * an app to open screens by itself, so a notification "Tap to run" is shown.
 */
object Triggers {
    const val ACTION_ALARM = "com.vethos.app.FLOW_ALARM"
    private const val CH = "vethos_automation"

    // ---------- re-arming everything ----------
    @Synchronized
    fun rearm(ctx: Context) {
        val app = ctx.applicationContext
        armAlarms(app)
        armEvents(app)
    }

    // ---------- time alarms ----------
    private fun pending(ctx: Context, flowId: String, nodeId: String): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java)
            .setAction(ACTION_ALARM)
            .setData(Uri.parse("vethos://flow/$flowId/$nodeId"))
            .putExtra("flow", flowId)
            .putExtra("node", nodeId)
        return PendingIntent.getBroadcast(ctx, (flowId + nodeId).hashCode(), i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun armAlarms(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val prefs = ctx.getSharedPreferences("vethos", 0)
        // cancel what was set before
        prefs.getStringSet("alarm_keys", emptySet())?.forEach { k ->
            val p = k.split('|')
            if (p.size == 2) am.cancel(pending(ctx, p[0], p[1]))
        }
        val keys = HashSet<String>()
        Flows.all().filter { it.enabled }.forEach { f ->
            f.nodes.filter { it.type == "time" }.forEach { n ->
                val at = nextTime(n.cfg)
                val pi = pending(ctx, f.id, n.id)
                if (canExact(am)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                keys.add(f.id + "|" + n.id)
            }
        }
        prefs.edit().putStringSet("alarm_keys", keys).apply()
    }

    /** Exact times need the "Alarms & reminders" access (Android 12+). */
    fun canExact(am: AlarmManager): Boolean = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()

    private fun nextTime(cfg: org.json.JSONObject): Long {
        val now = System.currentTimeMillis()
        if (cfg.optString("mode", "daily") == "interval") {
            val min = (cfg.optString("every", "30").toDoubleOrNull() ?: 30.0).coerceAtLeast(1.0)
            return now + (min * 60_000).toLong()
        }
        val hm = cfg.optString("time", "07:00").split(':')
        val h = hm.getOrNull(0)?.toIntOrNull() ?: 7
        val m = hm.getOrNull(1)?.toIntOrNull() ?: 0
        val c = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        if (c.timeInMillis <= now + 1000) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    // ---------- phone events ----------
    private var eventReceiver: BroadcastReceiver? = null
    private var netCb: ConnectivityManager.NetworkCallback? = null
    private var netSince = 0L
    private val lastFire = HashMap<String, Long>()

    private fun armEvents(ctx: Context) {
        eventReceiver?.let { try { ctx.unregisterReceiver(it) } catch (_: Throwable) { } }
        eventReceiver = null
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        netCb?.let { try { cm.unregisterNetworkCallback(it) } catch (_: Throwable) { } }
        netCb = null

        val wanted = HashSet<String>()
        Flows.all().filter { it.enabled }.forEach { f ->
            f.nodes.filter { it.type == "event" }.forEach { wanted.add(it.cfg.optString("event", "charging_on")) }
        }
        if (wanted.isEmpty()) return

        val filter = IntentFilter()
        if ("charging_on" in wanted) filter.addAction(Intent.ACTION_POWER_CONNECTED)
        if ("charging_off" in wanted) filter.addAction(Intent.ACTION_POWER_DISCONNECTED)
        if ("battery_low" in wanted) filter.addAction(Intent.ACTION_BATTERY_LOW)
        if ("screen_on" in wanted) filter.addAction(Intent.ACTION_SCREEN_ON)
        if (filter.countActions() > 0) {
            val r = object : BroadcastReceiver() {
                override fun onReceive(c: Context, i: Intent) {
                    val ev = when (i.action) {
                        Intent.ACTION_POWER_CONNECTED -> "charging_on"
                        Intent.ACTION_POWER_DISCONNECTED -> "charging_off"
                        Intent.ACTION_BATTERY_LOW -> "battery_low"
                        Intent.ACTION_SCREEN_ON -> "screen_on"
                        else -> return
                    }
                    onEvent(c, ev)
                }
            }
            ContextCompat.registerReceiver(ctx, r, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
            eventReceiver = r
        }
        if ("wifi_on" in wanted) {
            netSince = SystemClock.elapsedRealtime()
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    // Android reports a network that is already connected right after registering: ignore that
                    if (SystemClock.elapsedRealtime() - netSince > 3000) onEvent(ctx, "wifi_on")
                }
            }
            try {
                cm.registerNetworkCallback(
                    NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build(), cb
                )
                netCb = cb
            } catch (_: Throwable) { }
        }
    }

    private fun onEvent(ctx: Context, ev: String) {
        val now = SystemClock.elapsedRealtime()
        Flows.all().filter { it.enabled }.forEach { f ->
            f.nodes.filter { it.type == "event" && it.cfg.optString("event", "charging_on") == ev }.forEach { n ->
                val k = f.id + n.id
                if (now - (lastFire[k] ?: -10_000L) < 3000) return@forEach
                lastFire[k] = now
                fire(ctx, f.id, n.id, ev)
            }
        }
    }

    // ---------- firing ----------
    fun fire(ctx: Context, flowId: String, nodeId: String, input: String) {
        val f = Flows.get(flowId) ?: return
        if (!f.enabled) return
        if (VethosApp.isForeground) {
            FlowRunActivity.start(ctx, flowId, nodeId, input)
        } else if (FlowRunner.canHeadless(f)) {
            // no screen needed: run it by itself in the background
            try {
                ContextCompat.startForegroundService(
                    ctx, AndroidIntent(ctx, FlowService::class.java).putExtra("flow", flowId).putExtra("node", nodeId).putExtra("input", input)
                )
            } catch (_: Throwable) {
                notifyReady(ctx, f, nodeId, input)
            }
        } else {
            notifyReady(ctx, f, nodeId, input)
        }
    }

    private fun notifyReady(ctx: Context, f: Flow, nodeId: String, input: String) {
        try {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH, "Automations", NotificationManager.IMPORTANCE_DEFAULT))
            val open = PendingIntent.getActivity(
                ctx, f.id.hashCode(), FlowRunActivity.intent(ctx, f.id, nodeId, input), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(ctx, CH)
                .setSmallIcon(R.drawable.ic_chat)
                .setContentTitle("⚡ " + f.name)
                .setContentText("Tap to run this automation")
                .setAutoCancel(true)
                .setContentIntent(open)
                .build()
            nm.notify(f.id.hashCode(), n)
        } catch (_: Throwable) { }
    }
}

/** Time alarms and the phone restart both end here. */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        try {
            if (i.action == Triggers.ACTION_ALARM) {
                val f = i.getStringExtra("flow") ?: return
                val n = i.getStringExtra("node") ?: return
                Triggers.fire(ctx, f, n, "")
            }
            Triggers.rearm(ctx)   // sets the next time (tomorrow, or in N minutes), also after a restart
        } catch (_: Throwable) { }
    }
}
