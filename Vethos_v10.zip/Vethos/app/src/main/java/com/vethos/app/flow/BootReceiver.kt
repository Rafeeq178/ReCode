package com.vethos.app.flow

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** After a restart: set the automation alarms again. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        try { Triggers.rearm(ctx) } catch (_: Throwable) { }
    }
}
