package com.vethos.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.text.SpannableStringBuilder
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.vethos.app.R
import com.vethos.app.data.HtmlRun
import com.vethos.app.databinding.ViewCodeBinding

/**
 * Draws an AI answer: normal text + dark code blocks (```lang ... ```) with a "Copy" button on each block.
 * Works while the answer is still streaming (an unfinished code block is drawn as a code block too).
 */
object Blocks {
    /** Set by ChatActivity: saves a code block to a file the user picks (language, code). */
    var onSave: ((String, String) -> Unit)? = null

    sealed class Seg {
        class Text(val s: String) : Seg()
        class Code(val lang: String, val s: String) : Seg()
    }

    fun split(src: String): List<Seg> {
        val out = ArrayList<Seg>()
        var i = 0
        while (i < src.length) {
            val f = src.indexOf("```", i)
            if (f < 0) { addText(out, src.substring(i)); break }
            addText(out, src.substring(i, f))
            val afterFence = f + 3
            val nl = src.indexOf('\n', afterFence)
            if (nl < 0) { out.add(Seg.Code(src.substring(afterFence).trim(), "")); break }
            val lang = src.substring(afterFence, nl).trim()
            val end = src.indexOf("```", nl + 1)
            if (end < 0) {
                // still streaming: hide a half-typed closing fence
                out.add(Seg.Code(lang, src.substring(nl + 1).trimEnd('\n').trimEnd('`').trimEnd('\n')))
                break
            }
            out.add(Seg.Code(lang, src.substring(nl + 1, end).trimEnd('\n')))
            i = end + 3
        }
        return out
    }

    private fun addText(out: MutableList<Seg>, s: String) {
        val t = s.trim('\n')
        if (t.isNotBlank()) out.add(Seg.Text(t))
    }

    /** cursor: null = finished answer (no dot), true/false = streaming dot on/off. */
    fun bind(box: LinearLayout, src: String, cursor: Boolean?) {
        val ctx = box.context
        val segs = split(src).toMutableList()
        if (segs.isEmpty()) segs.add(Seg.Text(""))

        var same = box.childCount == segs.size
        if (same) {
            for (k in segs.indices) {
                val isCode = box.getChildAt(k).tag == "code"
                if ((segs[k] is Seg.Code) != isCode) { same = false; break }
            }
        }
        if (!same) {
            box.removeAllViews()
            segs.forEach { s -> box.addView(if (s is Seg.Code) makeCode(box) else makeText(ctx)) }
        }

        segs.forEachIndexed { k, s ->
            val v = box.getChildAt(k)
            val c = if (k == segs.lastIndex) cursor else null
            when (s) {
                is Seg.Code -> fillCode(v, s, c)
                is Seg.Text -> fillText(v as TextView, s, c)
            }
        }
    }

    private fun makeText(ctx: Context): TextView = TextView(ctx).apply {
        tag = "text"
        textSize = 16f
        setLineSpacing(0f, 1.2f)
        setTextColor(ctx.getColor(R.color.v_text))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun makeCode(box: LinearLayout): View {
        val b = ViewCodeBinding.inflate(LayoutInflater.from(box.context), box, false)
        b.root.tag = "code"
        b.copy.setOnClickListener {
            val raw = b.code.tag as? String ?: ""
            (box.context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("Vethos code", raw))
            b.copy.text = "Copied"
            b.copy.postDelayed({ b.copy.text = "Copy" }, 1500)
        }
        b.save.setOnClickListener { onSave?.invoke(b.lang.text.toString(), b.code.tag as? String ?: "") }
        b.run.setOnClickListener {
            val page = HtmlRun.prepare(b.lang.text.toString(), b.code.tag as? String ?: "")
            if (page != null) RunnerActivity.startHtml(box.context, page)
        }
        return b.root
    }

    private fun fillText(tv: TextView, s: Seg.Text, cursor: Boolean?) {
        val key = "t|" + cursor + "|" + s.s
        if (tv.getTag(R.id.seg_key) == key) return
        tv.setTag(R.id.seg_key, key)
        tv.text = if (cursor == null) Md.render(s.s) else Md.withCursor(tv.context, s.s, cursor)
    }

    private fun fillCode(v: View, s: Seg.Code, cursor: Boolean?) {
        val key = "c|" + cursor + "|" + s.lang + "|" + s.s
        if (v.getTag(R.id.seg_key) == key) return
        v.setTag(R.id.seg_key, key)
        val b = ViewCodeBinding.bind(v)
        b.lang.text = s.lang.ifEmpty { "code" }
        b.code.tag = s.s
        val streaming = cursor != null
        b.run.visibility = if (!streaming && HtmlRun.isRunnable(s.lang, s.s)) View.VISIBLE else View.GONE
        b.save.visibility = if (streaming) View.GONE else View.VISIBLE
        b.code.text = if (cursor == null) s.s else Md.addCursor(b.root.context, SpannableStringBuilder(s.s), cursor)
    }
}
