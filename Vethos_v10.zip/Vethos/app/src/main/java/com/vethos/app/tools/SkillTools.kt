package com.vethos.app.tools

import com.vethos.app.R
import com.vethos.app.data.Skills
import org.json.JSONObject

/** The one tool that loads a skill's instructions. It is not shown in the Phone tools list. */
object SkillTools {
    const val ID = "use_skill"

    val def: ToolDef by lazy {
        ToolDef(
            id = ID, title = "Use skill", icon = R.drawable.ic_book, sensitive = false,
            desc = "Load the steps of a saved skill",
            params = listOf(ToolParam("name", "Skill name")),
            usage = """{"name":"skill name"}""",
            run = { _, a, done -> done(load(a)) },
            headless = true,
        )
    }

    private fun load(a: JSONObject): ToolResult {
        val n = a.optString("name").ifBlank { a.optString("skill") }.trim()
        if (n.isEmpty()) return ToolResult(false, "Which skill?")
        val s = Skills.find(n) ?: return ToolResult(false, "No skill called “$n”")
        return ToolResult(true, "Skill: " + s.name, "Skill “" + s.name + "” steps:\n" + s.body)
    }
}
