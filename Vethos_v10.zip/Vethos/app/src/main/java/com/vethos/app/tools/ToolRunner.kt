package com.vethos.app.tools

import com.google.android.material.dialog.MaterialAlertDialogBuilder
import org.json.JSONObject

object ToolRunner {
    /**
     * Runs a tool. [onDone] is called exactly once, on the main thread.
     * [manual] = the user filled the form themselves, so no extra "Allow?" question.
     */
    fun run(c: ToolCtx, def: ToolDef, args: JSONObject, manual: Boolean, onDone: (ToolResult) -> Unit) {
        var fired = false
        val finish: (ToolResult) -> Unit = { r -> if (!fired) { fired = true; onDone(r) } }
        val go = {
            try {
                def.run(c, args, finish)
            } catch (e: Throwable) {
                finish(ToolResult(false, e.message ?: "Tool failed"))
            }
        }
        if (!manual && (def.askWhen?.invoke(args) ?: def.sensitive)) {
            if (!c.hasScreen) { finish(ToolResult(false, ToolCtx.NEEDS_SCREEN)); return }
            MaterialAlertDialogBuilder(c.act)
                .setTitle("Allow “${def.title}”?")
                .setMessage(describe(args))
                .setNegativeButton("Cancel") { _, _ -> finish(ToolResult(false, "Cancelled")) }
                .setPositiveButton("Allow") { _, _ -> go() }
                .setOnCancelListener { finish(ToolResult(false, "Cancelled")) }
                .show()
        } else {
            go()
        }
    }

    private fun describe(a: JSONObject): String {
        val sb = StringBuilder("The assistant wants to do this:\n")
        a.keys().forEach { k ->
            val v = a.opt(k)?.toString().orEmpty()
            if (v.isNotBlank()) sb.append('\n').append(k).append(": ").append(v)
        }
        return sb.toString()
    }
}
