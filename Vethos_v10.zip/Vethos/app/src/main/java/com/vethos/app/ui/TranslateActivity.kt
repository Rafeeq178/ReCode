package com.vethos.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.vethos.app.R
import com.vethos.app.databinding.ActivityTranslateBinding
import com.vethos.app.databinding.ItemRowBinding
import com.vethos.app.lang.Lang
import com.vethos.app.lang.Packs
import com.vethos.app.lang.Speaker
import kotlinx.coroutines.launch

/** Offline translator + manager for the downloadable language packs. */
class TranslateActivity : AppCompatActivity() {
    private lateinit var b: ActivityTranslateBinding
    private var from = "auto"
    private var to = "en"

    private val fromList = listOf("auto" to "Auto-detect", "roman" to "Roman Urdu / Hinglish") +
        listOf("en" to "English") + Lang.supported
    private val toList = listOf("en" to "English") + Lang.supported

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityTranslateBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnBack.setOnClickListener { finish() }
        showLangs()

        b.from.setOnClickListener {
            choose("Translate from", fromList.map { it.second }, fromList.indexOfFirst { it.first == from }.coerceAtLeast(0)) { i ->
                from = fromList[i].first
                showLangs()
            }
        }
        b.to.setOnClickListener {
            choose("Translate to", toList.map { it.second }, toList.indexOfFirst { it.first == to }.coerceAtLeast(0)) { i ->
                to = toList[i].first
                showLangs()
            }
        }
        b.swap.setOnClickListener {
            val oldTo = to
            val oldFrom = from
            if (oldFrom == "auto" || oldFrom == "roman") { toast("Pick a real language in 'from' to swap"); return@setOnClickListener }
            from = oldTo
            to = oldFrom
            showLangs()
        }
        b.go.setOnClickListener { run() }
        b.copy.setOnClickListener {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("Vethos", b.out.text.toString()))
            toast("Copied")
        }
        b.speak.setOnClickListener { Speaker.toggle(this, b.out.text.toString()) }
        renderPacks()
    }

    private fun showLangs() {
        b.from.text = fromList.firstOrNull { it.first == from }?.second ?: from
        b.to.text = toList.firstOrNull { it.first == to }?.second ?: to
    }

    private fun run() {
        val text = b.input.text.toString().trim()
        if (text.isEmpty()) { toast("Type some text first"); return }
        b.outBox.visibility = View.VISIBLE
        b.out.text = "…"
        lifecycleScope.launch {
            Lang.translate(this@TranslateActivity, text, from, to).fold(
                { b.out.text = it },
                { b.out.text = it.message ?: "Could not translate" },
            )
        }
    }

    private fun renderPacks() {
        b.packs.removeAllViews()
        Lang.supported.forEachIndexed { idx, (code, name) ->
            if (idx > 0) b.packs.addView(View(this).apply {
                setBackgroundColor(getColor(R.color.v_line))
            }, LinearLayout.LayoutParams(-1, 1).apply { marginStart = dp(16); marginEnd = dp(16) })
            val r = ItemRowBinding.inflate(layoutInflater, b.packs, false)
            r.title.text = name
            r.value.text = "…"
            r.value.visibility = View.VISIBLE
            r.chev.visibility = View.GONE
            b.packs.addView(r.root)
            lifecycleScope.launch { r.value.text = if (Packs.isReady(code)) "Downloaded ✔" else "Tap to download" }
            r.root.setOnClickListener {
                lifecycleScope.launch {
                    if (Packs.isReady(code)) {
                        confirm("Delete the $name pack?", "You can download it again later.", "Delete") {
                            lifecycleScope.launch {
                                Packs.delete(code)
                                r.value.text = "Tap to download"
                            }
                        }
                    } else {
                        r.value.text = "Downloading…"
                        val ok = Packs.download(code, false)
                        r.value.text = if (ok) "Downloaded ✔" else "Failed. Tap to retry"
                        if (!ok) toast("Download failed. Check your internet connection.")
                    }
                }
            }
        }
    }
}
