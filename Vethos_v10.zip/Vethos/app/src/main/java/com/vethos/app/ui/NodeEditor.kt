package com.vethos.app.ui

import android.app.TimePickerDialog
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.vethos.app.R
import com.vethos.app.data.MiniApps
import com.vethos.app.flow.FNode
import com.vethos.app.flow.Field
import com.vethos.app.flow.Kind
import com.vethos.app.flow.NodeSpecs
import com.vethos.app.tools.Tools
import org.json.JSONObject

/** The settings dialog of one node. */
object NodeEditor {
    fun show(act: AppCompatActivity, node: FNode, onSaved: () -> Unit) {
        val spec = NodeSpecs.get(node.type) ?: return
        val cfg = JSONObject(node.cfg.toString())
        val getters = ArrayList<() -> Unit>()
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(act.dp(22), act.dp(4), act.dp(22), act.dp(8))
        }

        fun label(parent: LinearLayout, t: String) {
            parent.addView(TextView(act).apply {
                text = t; textSize = 12.5f
                setTextColor(act.getColor(R.color.v_muted))
                setPadding(0, act.dp(12), 0, act.dp(4))
            })
        }

        fun pickRow(parent: LinearLayout, text: String, onClick: (TextView) -> Unit): TextView {
            val tv = TextView(act).apply {
                this.text = text; textSize = 15f
                setTextColor(act.getColor(R.color.v_text))
                setBackgroundResource(R.drawable.bg_chip)
                setPadding(act.dp(14), act.dp(13), act.dp(14), act.dp(13))
                gravity = Gravity.CENTER_VERTICAL
                isClickable = true; isFocusable = true
            }
            tv.setOnClickListener { onClick(tv) }
            parent.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            return tv
        }

        fun addField(parent: LinearLayout, f: Field, target: JSONObject) {
            label(parent, f.label)
            when (f.kind) {
                Kind.TEXT, Kind.NUMBER, Kind.MULTI -> {
                    val et = EditText(act).apply {
                        hint = f.hint
                        setText(target.optString(f.key, f.def))
                        inputType = when (f.kind) {
                            Kind.NUMBER -> InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                            Kind.MULTI -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                            else -> InputType.TYPE_CLASS_TEXT
                        }
                        if (f.kind == Kind.MULTI) { minLines = 3; maxLines = 8; gravity = Gravity.TOP }
                    }
                    parent.addView(et, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                    getters.add { target.put(f.key, et.text.toString().trim()) }
                }
                Kind.CHOICE -> {
                    val cur = target.optString(f.key, f.def)
                    pickRow(parent, f.options.firstOrNull { it.first == cur }?.second ?: f.options.firstOrNull()?.second ?: "") { tv ->
                        val now = target.optString(f.key, f.def)
                        act.choose(f.label, f.options.map { it.second }, f.options.indexOfFirst { it.first == now }.coerceAtLeast(0)) { i ->
                            target.put(f.key, f.options[i].first)
                            tv.text = f.options[i].second
                        }
                    }
                    if (!target.has(f.key) && f.options.isNotEmpty()) target.put(f.key, f.options.firstOrNull { it.first == cur }?.first ?: f.options[0].first)
                }
                Kind.TIME -> {
                    pickRow(parent, target.optString(f.key, f.def)) { tv ->
                        val hm = target.optString(f.key, f.def).split(':')
                        val h = hm.getOrNull(0)?.toIntOrNull() ?: 7
                        val m = hm.getOrNull(1)?.toIntOrNull() ?: 0
                        TimePickerDialog(act, { _, hh, mm ->
                            val v = "%02d:%02d".format(hh, mm)
                            target.put(f.key, v)
                            tv.text = v
                        }, h, m, true).show()
                    }
                    if (!target.has(f.key)) target.put(f.key, f.def)
                }
                Kind.APP -> {
                    val apps = MiniApps.all()
                    pickRow(parent, MiniApps.get(target.optString(f.key))?.name ?: "Choose a mini app") { tv ->
                        if (apps.isEmpty()) { act.toast("You have no mini apps yet. Save one from a chat first."); return@pickRow }
                        act.choose("Mini app", apps.map { it.name }, apps.indexOfFirst { it.id == target.optString(f.key) }.coerceAtLeast(0)) { i ->
                            target.put(f.key, apps[i].id)
                            tv.text = apps[i].name
                        }
                    }
                }
            }
        }

        if (node.type == "tool") {
            val tools = Tools.all
            val argsBox = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
            val argGetters = ArrayList<() -> Unit>()

            fun rebuild() {
                argsBox.removeAllViews()
                argGetters.clear()
                val def = Tools.get(cfg.optString("tool"))
                if (def == null) return
                val args = cfg.optJSONObject("args") ?: JSONObject().also { cfg.put("args", it) }
                if (def.params.isEmpty()) {
                    label(argsBox, "This tool needs no settings.")
                    return
                }
                def.params.forEach { p ->
                    label(argsBox, p.label + if (p.optional) " (optional)" else "")
                    val et = EditText(act).apply {
                        hint = p.hint
                        setText(args.optString(p.key))
                        inputType = InputType.TYPE_CLASS_TEXT
                    }
                    argsBox.addView(et, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                    argGetters.add { args.put(p.key, et.text.toString().trim()) }
                }
            }

            label(box, "Phone tool")
            pickRow(box, Tools.get(cfg.optString("tool"))?.title ?: "Choose a tool") { tv ->
                act.choose("Phone tool", tools.map { it.title }, tools.indexOfFirst { it.id == cfg.optString("tool") }.coerceAtLeast(0)) { i ->
                    cfg.put("tool", tools[i].id)
                    cfg.put("args", JSONObject())
                    tv.text = tools[i].title
                    rebuild()
                }
            }
            box.addView(argsBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            rebuild()
            getters.add { argGetters.forEach { it() } }
        } else {
            spec.fields.forEach { f ->
                // the Time node shows only the fields of the chosen repeat mode when it opens
                addField(box, f, cfg)
            }
            if (spec.fields.isEmpty()) label(box, "This node has no settings.")
        }

        if (node.type != "manual") {
            box.addView(TextView(act).apply {
                text = "Variables for text fields: {{input}} what started the flow, {{last}} the previous step, {{data}} extra data of the last tool, {{time}} the time now."
                textSize = 12f
                setTextColor(act.getColor(R.color.v_muted))
                setPadding(0, act.dp(16), 0, 0)
            })
        }

        MaterialAlertDialogBuilder(act)
            .setTitle(spec.title)
            .setView(ScrollView(act).apply { addView(box) })
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                getters.forEach { it() }
                node.cfg = cfg
                onSaved()
            }
            .show()
    }
}
