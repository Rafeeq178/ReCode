package com.vethos.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class MiniApp(val id: String, var name: String, var ts: Long)

/** Saved mini apps: one .html file per app (files/miniapps/<id>.html) plus a small index.json. */
object MiniApps {
    private val dir: File get() = File(Store.app.filesDir, "miniapps").apply { mkdirs() }
    private val index: File get() = File(dir, "index.json")

    fun all(): List<MiniApp> {
        try {
            if (!index.exists()) return emptyList()
            val a = JSONArray(index.readText())
            return List(a.length()) {
                val o = a.getJSONObject(it)
                MiniApp(o.getString("id"), o.optString("name", "Mini app"), o.optLong("ts", 0L))
            }.sortedByDescending { it.ts }
        } catch (e: Exception) {
            return emptyList()
        }
    }

    private fun write(list: List<MiniApp>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("ts", it.ts)) }
        index.writeText(a.toString())
    }

    fun get(id: String): MiniApp? = all().firstOrNull { it.id == id }

    fun html(id: String): String? = File(dir, "$id.html").takeIf { it.exists() }?.readText()

    fun size(id: String): Long = File(dir, "$id.html").let { if (it.exists()) it.length() else 0L }

    /** Creates a new mini app, or updates the one with [id]. */
    fun save(name: String, html: String, id: String? = null): MiniApp {
        val list = all().toMutableList()
        val existing = id?.let { i -> list.firstOrNull { it.id == i } }
        val app = existing ?: MiniApp("m" + System.currentTimeMillis(), name, 0L)
        app.name = name
        app.ts = System.currentTimeMillis()
        if (existing == null) list.add(app)
        File(dir, app.id + ".html").writeText(html)
        write(list)
        return app
    }

    fun rename(id: String, name: String) {
        val list = all()
        list.firstOrNull { it.id == id }?.name = name
        write(list)
    }

    fun delete(id: String) {
        File(dir, "$id.html").delete()
        write(all().filter { it.id != id })
    }
}
