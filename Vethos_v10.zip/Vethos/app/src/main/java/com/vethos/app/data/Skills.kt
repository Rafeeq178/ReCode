package com.vethos.app.data

import org.json.JSONArray
import org.json.JSONObject

/**
 * A skill is a short playbook (instructions) the assistant loads only when it needs it.
 * The system prompt only lists name + one line, so a small model keeps its context free.
 * The model loads the full text with the use_skill tool.
 */
data class Skill(val id: String, var name: String, var desc: String, var body: String, var on: Boolean = true)

object Skills {
    private val prefs get() = Store.app.getSharedPreferences("vethos", 0)
    private var cache: MutableList<Skill>? = null

    /** lower-case, letters/digits/underscore: the name the model types */
    fun slug(s: String): String = s.trim().lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_').ifEmpty { "skill" }

    private fun defaults() = mutableListOf(
        Skill("research", "research", "Answer questions that need fresh facts from the web",
            "1. Call web_search with 3-6 key words (add the year for recent things).\n" +
                "2. Call fetch_url on the best 1 or 2 links.\n" +
                "3. Answer only from what you read. Keep it short and list the links you used.\n" +
                "4. If the pages do not answer it, say so. Do not guess."),
        Skill("daily_brief", "daily_brief", "Morning summary: news and weather",
            "1. Call news (topic world, count 5).\n" +
                "2. Call weather for the user's city (ask once if you do not know it).\n" +
                "3. Reply with: Weather in one line, then 5 headlines as a short list."),
        Skill("summarize_page", "summarize_page", "Read a link and summarize it",
            "1. Call fetch_url with the link the user gave.\n" +
                "2. Reply with a 1 sentence summary, then 3-5 bullet points with the key facts.\n" +
                "3. Mention the page title."),
        Skill("explain_simply", "explain_simply", "Explain a hard topic in simple words",
            "1. If you are not sure about the facts, call wikipedia with the topic first.\n" +
                "2. Explain in simple words, as to a school student, with one everyday example.\n" +
                "3. End with a 1 line summary."),
    )

    fun all(): MutableList<Skill> {
        cache?.let { return it }
        val out = mutableListOf<Skill>()
        try {
            val raw = prefs.getString("skills", null)
            if (raw != null) {
                val a = JSONArray(raw)
                for (i in 0 until a.length()) out.add(fromJson(a.getJSONObject(i), a.getJSONObject(i).optString("id")))
            }
        } catch (_: Exception) { out.clear() }
        if (out.isEmpty() && !prefs.getBoolean("skills_seeded", false)) {
            out.addAll(defaults())
            prefs.edit().putBoolean("skills_seeded", true).apply()
        }
        cache = out
        if (prefs.getString("skills", null) == null) save()
        return out
    }

    private fun fromJson(o: JSONObject, id: String) = Skill(
        id.ifEmpty { slug(o.optString("name")) }, slug(o.optString("name", "skill")), o.optString("desc"),
        o.optString("body"), o.optBoolean("on", true),
    )

    private fun toJson(s: Skill, withId: Boolean) = JSONObject().apply {
        if (withId) put("id", s.id)
        put("name", s.name); put("desc", s.desc); put("body", s.body); put("on", s.on)
    }

    fun save() {
        val a = JSONArray()
        all().forEach { a.put(toJson(it, true)) }
        prefs.edit().putString("skills", a.toString()).apply()
    }

    fun find(nameOrId: String): Skill? {
        val k = slug(nameOrId)
        return all().firstOrNull { it.on && (it.id == k || it.name == k) }
    }

    fun add(name: String, desc: String, body: String): Skill {
        var n = slug(name)
        while (all().any { it.name == n || it.id == n }) n += "_2"
        val s = Skill(n, n, desc, body)
        all().add(s); save()
        return s
    }

    fun delete(id: String) {
        all().removeAll { it.id == id }
        save()
    }

    /** Skills an agent may use: "" none, "*" all, or comma separated ids. Only skills that are switched on. */
    fun allowed(spec: String): List<Skill> {
        if (spec.isBlank()) return emptyList()
        val ids = spec.split(',').map { it.trim() }.filter { it.isNotEmpty() }
        return all().filter { it.on && (spec == "*" || it.id in ids) }
    }

    /** One short block for the system prompt (names + one line each). */
    fun prompt(spec: String): String {
        val list = allowed(spec)
        if (list.isEmpty()) return ""
        val sb = StringBuilder("Skills are saved playbooks. When one matches the request, call use_skill with its name FIRST, then follow its steps.\nSkills:\n")
        list.forEach { sb.append("- ").append(it.name).append(": ").append(it.desc).append('\n') }
        return sb.toString().trimEnd()
    }

    fun exportJson(list: List<Skill>): String {
        val a = JSONArray()
        list.forEach { a.put(toJson(it, false)) }
        return JSONObject().put("vethos", "skills").put("version", 1).put("items", a).toString(2)
    }

    /** Adds skills from exported JSON (also a bare array or one object). Returns how many were new. */
    fun importJson(text: String): Int {
        val t = text.trim()
        val items = mutableListOf<JSONObject>()
        if (t.startsWith("[")) {
            val a = JSONArray(t)
            for (i in 0 until a.length()) items.add(a.getJSONObject(i))
        } else {
            val o = JSONObject(t)
            val a = o.optJSONArray("items")
            if (a != null) for (i in 0 until a.length()) items.add(a.getJSONObject(i)) else items.add(o)
        }
        var added = 0
        items.forEach { o ->
            if (o.optString("name").isBlank() || o.optString("body").isBlank()) return@forEach
            if (all().any { it.name == slug(o.optString("name")) && it.body == o.optString("body") }) return@forEach
            add(o.optString("name"), o.optString("desc"), o.optString("body")); added++
        }
        return added
    }
}
