package com.vethos.app.ui

import android.app.AlarmManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.vethos.app.net.Accounts
import com.vethos.app.net.Smtp
import com.vethos.app.tools.AppScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.vethos.app.R
import com.vethos.app.databinding.ActivityAutomationsBinding
import com.vethos.app.databinding.ItemToolBinding
import com.vethos.app.flow.Flow
import com.vethos.app.flow.Flows
import com.vethos.app.flow.NodeSpecs
import com.vethos.app.flow.Triggers

/** The list of automations (the n8n "workflows" page). */
class AutomationsActivity : AppCompatActivity() {
    private lateinit var b: ActivityAutomationsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityAutomationsBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnBack.setOnClickListener { finish() }
        b.btnNew.setOnClickListener {
            val f = Flows.create("My automation")
            open(f)
        }
        b.btnMail.setOnClickListener { mailDialog() }
        b.btnAlarm.setOnClickListener {
            val am = getSystemService(AlarmManager::class.java)
            if (Triggers.canExact(am)) {
                toast("Exact alarms are already allowed")
            } else if (Build.VERSION.SDK_INT >= 31) {
                try {
                    startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                } catch (_: Throwable) {
                    toast("Open Settings > Apps > Vethos > Alarms & reminders and allow it")
                }
            }
        }
        b.btnBattery.setOnClickListener {
            toast("Find Vethos in the list and choose “Don’t optimize” (unrestricted)")
            try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (_: Throwable) { }
        }
        b.btnExamples.setOnClickListener {
            showSheet("Examples", Flows.examples.map { ex ->
                SheetRow(R.drawable.ic_flask, ex.title, ex.desc) {
                    val f = Flows.add(ex.build())
                    toast("Added. Open it, then switch it on.")
                    render()
                    open(f)
                }
            })
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    /** The email account used by the Send email, Read emails and Post to Blogger steps. */
    private fun mailDialog() {
        val cur = Accounts.saved()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), 0)
        }
        fun field(hint: String, value: String, password: Boolean = false, number: Boolean = false): EditText {
            val et = EditText(this)
            et.hint = hint
            et.setText(value)
            et.inputType = when {
                password -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                number -> InputType.TYPE_CLASS_NUMBER
                else -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            }
            box.addView(et, LinearLayout.LayoutParams(-1, -2))
            return et
        }
        val addr = field("Email address", cur.address)
        val pass = field(if (Accounts.hasPassword()) "App password (empty = keep the saved one)" else "App password", "", password = true)
        val name = field("Your name (optional)", cur.name)
        val smtpHost = field("SMTP server", cur.smtpHost)
        val smtpPort = field("SMTP port (465 or 587)", cur.smtpPort.toString(), number = true)
        val imapHost = field("IMAP server", cur.imapHost)
        val imapPort = field("IMAP port", cur.imapPort.toString(), number = true)
        box.addView(TextView(this).apply {
            text = "Gmail: switch on 2-step verification, create an “App password” in your Google account and paste it here. " +
                "It is stored encrypted on this phone. For Blogger use the secret “post by email” address from Blogger > Settings."
            textSize = 12.5f
            setTextColor(getColor(R.color.v_muted))
            setPadding(0, dp(14), 0, dp(6))
        })
        fun save() {
            Accounts.save(
                addr.text.toString(), pass.text.toString().ifEmpty { null }, name.text.toString(),
                smtpHost.text.toString(), smtpPort.text.toString().toIntOrNull() ?: 465,
                imapHost.text.toString(), imapPort.text.toString().toIntOrNull() ?: 993,
            )
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Email account")
            .setView(ScrollView(this).apply { addView(box) })
            .setNegativeButton("Cancel", null)
            .setNeutralButton("Save & test") { _, _ -> save(); testMail() }
            .setPositiveButton("Save") { _, _ -> save(); toast("Saved") }
            .show()
    }

    private fun testMail() {
        val m = Accounts.mail()
        if (m == null) { toast("Fill in the email address and the app password"); return }
        toast("Sending a test email to yourself…")
        AppScope.scope.launch {
            val msg = withContext(Dispatchers.IO) {
                try {
                    Smtp.send(m, m.address, "Vethos test", "It works. This email was sent by Vethos.", false)
                    "✔ Test email sent to " + m.address
                } catch (e: Throwable) {
                    "✖ " + (e.message ?: e.javaClass.simpleName)
                }
            }
            MaterialAlertDialogBuilder(this@AutomationsActivity).setTitle("Email test").setMessage(msg).setPositiveButton("OK", null).show()
        }
    }

    private fun open(f: Flow) {
        startActivity(Intent(this, FlowEditorActivity::class.java).putExtra("id", f.id))
    }

    private fun rearm() { try { Triggers.rearm(this) } catch (_: Throwable) { } }

    private fun render() {
        b.list.removeAllViews()
        val all = Flows.all()
        b.empty.visibility = if (all.isEmpty()) View.VISIBLE else View.GONE
        all.forEach { f ->
            val r = ItemToolBinding.inflate(layoutInflater, b.list, false)
            r.icon.setImageResource(R.drawable.ic_flask)
            r.title.text = f.name
            val trig = f.triggers().firstOrNull()
            val tSpec = trig?.let { NodeSpecs.get(it.type) }
            r.sub.text = f.nodes.size.toString() + " nodes  ·  " +
                (if (trig == null) "no trigger" else (tSpec?.title ?: "") + ": " + (tSpec?.summary?.invoke(trig.cfg) ?: ""))
            r.sw.isChecked = f.enabled
            r.sw.setOnCheckedChangeListener { _, on ->
                f.enabled = on
                Flows.save()
                rearm()
            }
            r.root.setOnClickListener { open(f) }
            r.root.setOnLongClickListener { menu(f); true }
            b.list.addView(r.root)
        }
    }

    private fun menu(f: Flow) {
        showSheet(f.name, listOf(
            SheetRow(R.drawable.ic_play, "Run now") {
                val t = f.triggers().firstOrNull()
                if (t == null) toast("This automation has no trigger")
                else FlowRunActivity.start(this, f.id, t.id, if (t.type == "keyword") t.cfg.optString("phrase") else "")
            },
            SheetRow(R.drawable.ic_edit, "Edit") { open(f) },
            SheetRow(R.drawable.ic_copy, "Duplicate") { Flows.duplicate(f); render() },
            SheetRow(R.drawable.ic_pin, "Rename") {
                inputDialog("Rename automation", f.name, "Name") { n ->
                    f.name = n.trim().ifEmpty { f.name }
                    Flows.save()
                    render()
                }
            },
            SheetRow(R.drawable.ic_trash, "Delete") {
                confirm("Delete this automation?", f.name, "Delete") { Flows.delete(f.id); rearm(); render() }
            },
        ))
    }
}
