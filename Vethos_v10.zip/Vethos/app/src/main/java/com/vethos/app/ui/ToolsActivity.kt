package com.vethos.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.DialogInterface
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.vethos.app.R
import com.vethos.app.cap.Caps
import com.vethos.app.cap.CustomTool
import com.vethos.app.cap.Skill
import com.vethos.app.cap.Tone
import com.vethos.app.databinding.ItemToolBinding
import com.vethos.app.tools.Launchers
import com.vethos.app.tools.PermHelper
import com.vethos.app.tools.ToolCtx
import com.vethos.app.tools.ToolDef
import com.vethos.app.tools.ToolRunner
import com.vethos.app.tools.Tools
import org.json.JSONObject

/**
 * One screen for the three things you can give the model: Tools, Skills and Tone
 * (intent extra "mode" = tools | skills | tones). Create, edit, delete, switch on/off, export and import.
 */
class ToolsActivity : AppCompatActivity() {
    private var mode = "tools"
    private lateinit var list: LinearLayout
    private val perms = PermHelper(this)
    private val launchers = Launchers(this)

    private class Field(val label: String, val value: String, val multiline: Boolean = false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mode = intent.getStringExtra("mode") ?: "tools"

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(10))
        }
        head.addView(roundBtn(R.drawable.ic_back) { finish() }, LinearLayout.LayoutParams(dp(44), dp(44)))
        head.addView(TextView(this).apply {
            text = when (mode) { "skills" -> "Skills"; "tones" -> "Tone"; else -> "Tools" }
            setTextColor(getColor(R.color.v_text)); textSize = 26f; typeface = Typeface.DEFAULT_BOLD
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(14) })
        head.addView(roundBtn(R.drawable.ic_more) { showMore() }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(8) })
        head.addView(roundBtn(R.drawable.ic_plus) { addNew() }, LinearLayout.LayoutParams(dp(44), dp(44)))
        root.addView(head, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), 0, dp(16), dp(30))
        }
        col.addView(TextView(this).apply {
            text = intro()
            setTextColor(getColor(R.color.v_muted)); textSize = 14.5f
            setPadding(dp(4), 0, dp(4), dp(12))
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        scroll.addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        refresh()
    }

    private fun roundBtn(icon: Int, onClick: () -> Unit) = ImageView(this).apply {
        setBackgroundResource(R.drawable.bg_hbtn)
        elevation = dp(2).toFloat()
        setPadding(dp(12), dp(12), dp(12), dp(12))
        setImageResource(icon)
        imageTintList = ColorStateList.valueOf(getColor(R.color.v_text))
        setOnClickListener { onClick() }
    }

    private fun intro(): String = when (mode) {
        "skills" -> "A skill is a ready-made instruction. When your message matches its trigger words, the app hands it to the model by itself. Tap one to edit it. + makes a new skill."
        "tones" -> "Choose how the assistant should sound. Switch one on to use it in every chat (a personality's own tone wins). + makes a new tone."
        else -> "Tools the assistant can use. Tap a built-in tool to try it, tap one of yours to edit it (long-press to try it). The switch turns a tool off everywhere. + makes a new tool."
    }

    // ---------------- rows ----------------

    private fun refresh() {
        list.removeAllViews()
        when (mode) {
            "skills" -> Caps.skills().toList().forEach { s ->
                row(R.drawable.ic_flask, s.name, s.desc.ifBlank { s.instructions }, s.on, { on -> s.on = on; Caps.saveSkills() }, { editSkill(s) }, null)
            }
            "tones" -> Caps.tones().toList().forEach { t ->
                row(R.drawable.ic_chat, t.name, t.text, Caps.toneId == t.id, { on ->
                    if (on) Caps.toneId = t.id else if (Caps.toneId == t.id) Caps.toneId = ""
                    list.post { refresh() }
                }, { editTone(t) }, null)
            }
            else -> Tools.all.forEach { d ->
                val custom = Tools.isCustom(d.id)
                row(
                    d.icon,
                    d.title + (if (custom) "  (mine)" else "") + (if (d.sensitive) "  (asks first)" else ""),
                    d.desc, Tools.enabled(d.id),
                    { on -> Tools.setEnabled(d.id, on) },
                    { if (custom) editTool(d.id) else tryTool(d) },
                    { tryTool(d) },
                )
            }
        }
        if (list.childCount == 0) {
            list.addView(TextView(this).apply {
                text = "Nothing here yet. Tap + to add one."
                setTextColor(getColor(R.color.v_muted)); textSize = 15f
                setPadding(dp(4), dp(10), dp(4), dp(10))
            })
        }
    }

    private fun row(
        icon: Int, title: String, sub: String, on: Boolean,
        onSwitch: ((Boolean) -> Unit)?, onClick: () -> Unit, onLong: (() -> Unit)?,
    ) {
        val r = ItemToolBinding.inflate(layoutInflater, list, false)
        r.icon.setImageResource(icon)
        r.title.text = title
        r.sub.text = sub
        r.sub.maxLines = 2
        r.sub.ellipsize = TextUtils.TruncateAt.END
        if (onSwitch == null) {
            r.sw.visibility = View.GONE
        } else {
            r.sw.isChecked = on
            r.sw.setOnCheckedChangeListener { _, v -> onSwitch(v) }
        }
        r.root.setOnClickListener { onClick() }
        if (onLong != null) r.root.setOnLongClickListener { onLong(); true }
        list.addView(r.root)
    }

    // ---------------- forms ----------------

    private fun form(title: String, fields: List<Field>, onSave: (List<String>) -> String?, onDelete: (() -> Unit)?) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), 0)
        }
        val edits = fields.map { f ->
            box.addView(TextView(this).apply {
                text = f.label
                setTextColor(getColor(R.color.v_muted)); textSize = 13f
                setPadding(0, dp(10), 0, 0)
            })
            val et = EditText(this)
            et.setText(f.value)
            et.textSize = 15f
            if (f.multiline) {
                et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                et.minLines = 3; et.maxLines = 8; et.gravity = Gravity.TOP
            } else {
                et.inputType = InputType.TYPE_CLASS_TEXT
            }
            box.addView(et, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            et
        }
        val sv = ScrollView(this)
        sv.addView(box)
        val builder = MaterialAlertDialogBuilder(this).setTitle(title).setView(sv)
            .setNegativeButton("Cancel", null).setPositiveButton("Save", null)
        if (onDelete != null) builder.setNeutralButton("Delete", null)
        val dlg = builder.create()
        dlg.setOnShowListener {
            dlg.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                val err = onSave(edits.map { e -> e.text.toString().trim() })
                if (err == null) { dlg.dismiss(); refresh() } else toast(err)
            }
            if (onDelete != null) {
                dlg.getButton(DialogInterface.BUTTON_NEUTRAL).setOnClickListener {
                    confirm("Delete?", "This can't be undone.", "Delete") { onDelete(); dlg.dismiss(); refresh() }
                }
            }
        }
        dlg.show()
    }

    private fun addNew() {
        when (mode) {
            "skills" -> editSkill(null)
            "tones" -> editTone(null)
            else -> editTool(null)
        }
    }

    private fun editTool(id: String?) {
        val t: CustomTool? = if (id == null) null else Caps.customTools().firstOrNull { it.id == id }
        val del: (() -> Unit)? = if (t == null) null else ({ Caps.customTools().remove(t); Caps.saveTools() })
        form(
            if (t == null) "New tool" else "Edit tool",
            listOf(
                Field("Name", t?.title ?: ""),
                Field("What it does (the model reads this)", t?.desc ?: ""),
                Field("Type: http or prompt", t?.kind ?: "http"),
                Field("Parameters (comma separated, e.g. city,days)", t?.params ?: ""),
                Field("URL for http. Use {param} for values", t?.url ?: ""),
                Field("Method for http: GET or POST", t?.method ?: "GET"),
                Field("POST body, or the prompt text. Use {param}", t?.body ?: "", true),
                Field("Trigger words (comma). Put ! before a strong one", t?.triggers ?: ""),
            ),
            { v ->
                val kind = v[2].lowercase()
                val method = v[5].uppercase().ifEmpty { "GET" }
                val rawKeys = v[3].split(',').map { it.trim() }.filter { it.isNotEmpty() }
                if (v[0].isEmpty()) "Give the tool a name"
                else if (kind != "http" && kind != "prompt") "Type must be http or prompt"
                else if (kind == "http" && !v[4].startsWith("http")) "The URL must start with http"
                else if (kind == "http" && method != "GET" && method != "POST") "Method must be GET or POST"
                else if (kind == "prompt" && v[6].isEmpty()) "Write the prompt text"
                else if (Caps.keys(v[3]).size != rawKeys.size) "Parameter names can only use letters, digits and _"
                else {
                    if (t == null) {
                        Caps.customTools().add(CustomTool(Caps.uniqueToolId(v[0]), v[0], v[1], kind, v[4], method, v[3], v[6], v[7]))
                    } else {
                        t.title = v[0]; t.desc = v[1]; t.kind = kind; t.url = v[4]; t.method = method
                        t.params = v[3]; t.body = v[6]; t.triggers = v[7]
                    }
                    Caps.saveTools()
                    null
                }
            },
            del,
        )
    }

    private fun editSkill(s: Skill?) {
        val del: (() -> Unit)? = if (s == null) null else ({ Caps.skills().remove(s); Caps.saveSkills() })
        form(
            if (s == null) "New skill" else "Edit skill",
            listOf(
                Field("Name", s?.name ?: ""),
                Field("What it is for (short)", s?.desc ?: ""),
                Field("Trigger words (comma). Put ! before a strong one", s?.triggers ?: ""),
                Field("Instructions for the model", s?.instructions ?: "", true),
                Field("Tools it needs (optional, e.g. calc,web_search)", s?.tools ?: ""),
            ),
            { v ->
                if (v[0].isEmpty()) "Give the skill a name"
                else if (v[3].isEmpty()) "Write the instructions"
                else {
                    if (s == null) {
                        Caps.newSkill(v[0], v[1], v[2], v[3], v[4])
                    } else {
                        s.name = v[0]; s.desc = v[1]; s.triggers = v[2]; s.instructions = v[3]; s.tools = v[4]
                        Caps.saveSkills()
                    }
                    null
                }
            },
            del,
        )
    }

    private fun editTone(t: Tone?) {
        val del: (() -> Unit)? = if (t == null) null else ({
            if (Caps.toneId == t.id) Caps.toneId = ""
            Caps.tones().remove(t); Caps.saveTones()
        })
        form(
            if (t == null) "New tone" else "Edit tone",
            listOf(
                Field("Name", t?.name ?: ""),
                Field("How should it sound? (e.g. calm and short)", t?.text ?: "", true),
            ),
            { v ->
                if (v[0].isEmpty()) "Give the tone a name"
                else if (v[1].isEmpty()) "Describe the tone"
                else {
                    if (t == null) {
                        Caps.newTone(v[0], v[1])
                    } else {
                        t.name = v[0]; t.text = v[1]; Caps.saveTones()
                    }
                    null
                }
            },
            del,
        )
    }

    // ---------------- more menu ----------------

    private fun showMore() {
        showSheet("More", listOf(
            SheetRow(R.drawable.ic_copy, "Export all (copy to clipboard)") {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("Vethos", Caps.exportAll()))
                toast("Copied. Paste it anywhere to keep a backup.")
            },
            SheetRow(R.drawable.ic_dl, "Import (paste JSON)") {
                inputDialog("Paste exported JSON", "", "{ ... }", true) { txt ->
                    try { toast(Caps.importAll(txt)); refresh() } catch (e: Exception) { toast("Not valid: " + (e.message ?: "")) }
                }
            },
            SheetRow(R.drawable.ic_regen, "Reset skills and tones to defaults") {
                confirm("Reset?", "Skills and tones go back to the starter list. Your tools are not touched.", "Reset") {
                    Caps.resetDefaults(); refresh()
                }
            },
        ))
    }

    // ---------------- try a tool by hand ----------------

    private fun tryTool(d: ToolDef) {
        val ctx = ToolCtx(this, perms, launchers)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), 0)
        }
        val fields = d.params.map { p ->
            val et = EditText(this)
            et.hint = p.label + (if (p.optional) " (optional)" else "") + (if (p.hint.isNotEmpty()) " – " + p.hint else "")
            et.inputType = InputType.TYPE_CLASS_TEXT
            box.addView(et, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            et
        }
        fun go() {
            val args = JSONObject()
            d.params.forEachIndexed { i, p ->
                val v = fields[i].text.toString().trim()
                if (v.isNotEmpty()) args.put(p.key, v)
            }
            ToolRunner.run(ctx, d, args, true) { r ->
                if (r.text.length > 70 || r.text.contains('\n'))
                    MaterialAlertDialogBuilder(this).setTitle(d.title).setMessage(r.text).setPositiveButton("OK", null).show()
                else toast(r.text)
            }
        }
        if (d.params.isEmpty()) { go(); return }
        MaterialAlertDialogBuilder(this).setTitle(d.title).setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Run") { _, _ -> go() }
            .show()
    }
}
