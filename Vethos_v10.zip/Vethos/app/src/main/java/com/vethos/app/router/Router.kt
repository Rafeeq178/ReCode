package com.vethos.app.router

import com.vethos.app.data.Store
import com.vethos.app.tools.Tools
import org.json.JSONObject

/**
 * The smart router: understands short commands in English, Roman Urdu, Hindi and Urdu script and picks the tool itself,
 * so the model is not needed for "torch on", "volume kam karo", "whatsapp kholo", "weather in Lahore" ...
 * It only acts on SHORT, command-like messages. Everything else goes to the model as usual.
 */
object Router {
    /** [tool] = tool id (or null for research); [feed] = hand the result to the model so it can answer. */
    class Routed(val tool: String?, val args: JSONObject, val feed: Boolean = false, val research: String? = null, val note: String = "")

    private fun ws(vararg s: String) = s.toHashSet()

    // ---- words ----
    private val ON = ws("on", "chalu", "chaalu", "chalao", "chala", "jalao", "jala", "jalado", "start", "enable", "activate", "open", "kholo", "khol", "turn", "चालू", "जलाओ", "जला", "ऑन", "चलाओ", "آن", "چالو", "جلاؤ", "جلا", "روشن", "چلاؤ")
    private val OFF = ws("off", "band", "bandh", "bujha", "bujhao", "bujhado", "stop", "disable", "deactivate", "close", "kill", "बंद", "बुझा", "बुझाओ", "ऑफ", "آف", "بند", "بجھاؤ", "بجھا")
    private val FLASH = ws("flashlight", "flash", "torch", "tourch", "tarch", "torchlight", "flashlite", "roshni", "light", "टॉर्च", "टार्च", "फ्लैशलाइट", "लाइट", "ٹارچ", "فلیش", "لائٹ", "روشنی")
    private val VOLUME = ws("volume", "vol", "awaz", "awaaz", "aawaz", "sound", "आवाज", "वॉल्यूम", "آواز", "ساؤنڈ")
    private val UP = ws("up", "increase", "raise", "zyada", "zyadah", "ziada", "barhao", "badhao", "badha", "barha", "high", "loud", "tez", "full", "max", "maximum", "बढ़ाओ", "ज़्यादा", "ज्यादा", "بڑھاؤ", "زیادہ", "تیز")
    private val DOWN = ws("down", "decrease", "lower", "reduce", "kam", "ghatao", "ghata", "low", "halki", "dheema", "कम", "घटाओ", "کم", "گھٹاؤ")
    private val MUTE = ws("mute", "silent", "khamosh", "chup", "म्यूट", "میوٹ", "خاموش")
    private val UNMUTE = ws("unmute")
    private val BATTERY = ws("battery", "bettery", "batery", "charge", "charging", "बैटरी", "चार्ज", "بیٹری")
    private val NOT_BATTERY = ws("kharab", "problem", "drain", "backup", "life", "tips", "saver", "bachao", "improve", "issue", "kyun", "why", "replace")
    private val WIFI = ws("wifi", "wi-fi", "वाईफाई", "وائی")
    private val CAMERA = ws("camera", "cam", "selfie", "कैमरा", "کیمرا", "کیمرہ")
    private val PHOTO = ws("photo", "pic", "picture", "tasveer")
    private val SNAP = ws("kheencho", "khencho", "lo", "le", "click", "take", "kheench")
    private val VIDEO = ws("video", "record", "recording")
    private val CALL = ws("call", "dial", "ring", "कॉल", "फोन", "کال", "فون")
    private val MSG = ws("sms", "message", "msg", "text", "whatsapp", "wa", "whatsap", "watsapp")
    private val NAV = ws("navigate", "navigation", "directions", "direction", "route", "guide")
    private val WEATHER = ws("weather", "mausam", "mosam", "temperature", "मौसम", "موسم", "forecast")
    private val NEWS = ws("news", "khabar", "khabrein", "khabren", "khabrain", "headlines", "headline", "akhbar", "समाचार", "ख़बर", "खबर", "خبریں", "خبر")
    private val TOPICS = ws("pakistan", "world", "tech", "technology", "business", "sports", "sport", "science", "health", "entertainment")
    private val SEARCH = ws("search", "google", "lookup", "dhoondo", "dhundo", "dhoond", "talash", "सर्च", "ढूंढो", "سرچ", "ڈھونڈو")
    private val RESEARCH = ws("research", "investigate", "tehqeeq", "pata")
    private val SUMMARY = ws("summarize", "summarise", "summary", "read", "parho", "padho", "khulasa", "check", "explain", "dekho", "batao", "what", "kya", "tldr")
    private val QR = ws("qr", "qrcode", "barcode")
    private val MAKE = ws("banao", "bana", "make", "generate", "create", "naya", "new")
    private val SCAN = ws("scan", "padho", "read", "scanner")
    private val QUESTION = ws("what", "why", "how", "who", "which", "when", "where", "kya", "kyun", "kyu", "kaise", "kaun", "explain")
    private val APP_NOISE = ws("app", "application", "apps", "ko", "ka", "ki", "ke", "me", "mein", "mai", "mera", "meri", "mere", "my", "the", "a", "an", "to", "se", "hi", "ab", "abhi", "now", "please", "plz", "pls", "zara", "yaar", "yar", "bhai", "na", "ji", "jee", "jaldi", "just", "can", "could", "you", "would", "will", "aap", "tum", "mujhe", "karo", "kro", "kar", "kr", "do", "dena", "dijiye", "kijiye", "de", "dein", "sakte", "sakta", "skte", "ho", "hai", "hain", "phone", "mobile", "करो", "कर", "दो", "दें", "کرو", "کر", "دو", "دیں")
    private val ALIAS = mapOf(
        "yt" to "youtube", "fb" to "facebook", "insta" to "instagram", "wa" to "whatsapp", "whatsap" to "whatsapp", "watsapp" to "whatsapp",
        "playstore" to "play store", "setting" to "settings", "calc" to "calculator", "gallary" to "gallery", "chrom" to "chrome",
    )

    // ---- helpers ----
    private fun tokens(raw: String): List<String> =
        raw.lowercase()
            .replace(Regex("[,.!?;:\"“”'()\\[\\]]"), " ")
            .split(Regex("\\s+")).filter { it.isNotEmpty() }

    private fun args(vararg p: Pair<String, Any>): JSONObject {
        val o = JSONObject()
        p.forEach { o.put(it.first, it.second) }
        return o
    }

    private val urlRe = Regex("https?://\\S+", RegexOption.IGNORE_CASE)
    private val numberRe = Regex("\\+?\\d[\\d\\s\\-]{4,}\\d")

    fun route(raw: String, isApp: ((String) -> Boolean)? = null): Routed? {
        if (!Store.smartRouter) return null
        val text = raw.trim()
        if (text.isEmpty() || text.startsWith("/")) return null
        val all = tokens(text)
        if (all.isEmpty()) return null

        // 1) a link: read it
        urlRe.find(text)?.let { m ->
            val rest = tokens(text.replace(m.value, " "))
            if (rest.any { it in QR } && rest.any { it in MAKE }) return Routed("qr_make", args("text" to m.value))
            if (rest.size <= 6 && (rest.isEmpty() || rest.any { it in SUMMARY })) {
                return Routed("fetch_url", args("url" to m.value.trimEnd('.', ',', ')')), feed = true)
            }
            return null
        }
        if (all.size > 14) return null

        // 2) research with the internet
        if (all[0] in RESEARCH && all.size >= 2) {
            val q = all.drop(1).filter { it != "karo" && it != "kro" && it != "about" && it != "on" }.joinToString(" ")
            if (q.isNotEmpty()) return Routed(null, JSONObject(), research = q)
        }

        val aset = all.toHashSet()
        val core = all.filter { it !in APP_NOISE }
        val coreSet = core.toHashSet()

        // 3) call / sms / whatsapp with a number
        numberRe.find(text)?.let { m ->
            val num = m.value.replace(Regex("[\\s\\-]"), "")
            val before = tokens(text.substring(0, m.range.first))
            if (before.any { it in CALL } && before.none { it in MSG }) return Routed("call", args("number" to num))
            if (before.any { it in MSG }) {
                var rest = text.substring(m.range.last + 1).trim().trimStart(':', '-', ',', ' ')
                val lead = setOf("saying", "say", "that", "likho", "likh", "ki", "ko", "text", "message", "msg", "bhejo", "send", "ye", "yeh", "ke", "k")
                while (true) {
                    val first = rest.substringBefore(' ').lowercase()
                    if (rest.isNotEmpty() && first in lead) rest = rest.substringAfter(' ', "").trim() else break
                }
                if (rest.isEmpty()) return null
                val wa = before.any { it == "whatsapp" || it == "wa" || it == "whatsap" || it == "watsapp" }
                return if (wa) Routed("whatsapp", args("number" to num.trimStart('+'), "text" to rest))
                else Routed("sms", args("number" to num, "text" to rest))
            }
        }

        // 4) internet helpers
        if (aset.any { it in WEATHER } && all.size <= 6) {
            val skip = WEATHER + APP_NOISE + QUESTION + ws("hai", "kaisa", "kaisi", "kesa", "aaj", "today", "tomorrow", "kal", "now", "is", "the", "in", "of", "for", "ka", "ke", "ki", "mein", "me", "tell", "batao", "bata", "check", "show", "dikhao", "current")
            val city = all.filter { it !in skip }.joinToString(" ")
            return Routed("weather", args("city" to city))
        }
        if (aset.any { it in NEWS } && aset.contains("wikipedia")) return Routed("wikipedia", args("query" to "news"))
        if (aset.any { it in NEWS } && all.size <= 6) {
            val t = all.firstOrNull { it in TOPICS } ?: "world"
            return Routed("news", args("topic" to t))
        }
        if (all[0] == "wiki" || all[0] == "wikipedia") {
            val q = all.drop(1).joinToString(" ")
            return Routed("wikipedia", args("query" to q))
        }
        if (all[0] in SEARCH && all.size >= 2) {
            val q = all.drop(1).filter { it != "for" && it != "karo" && it != "kro" }.joinToString(" ")
            return Routed("web_search", args("query" to q))
        }
        run {
            val m = Regex("^(.+?)\\s+(?:search|google|dhoondo|dhundo|talash)(?:\\s+(?:karo|kro|kar do|kr do))?$", RegexOption.IGNORE_CASE).find(text.trim())
            if (m != null) return Routed("web_search", args("query" to m.groupValues[1].trim()))
        }

        // 5) short device commands
        if (core.size > 7) return null
        val isQuestion = core.any { it in QUESTION }

        if (aset.any { it in BATTERY } && aset.none { it in NOT_BATTERY } && all.size <= 7) return Routed("battery", JSONObject())
        if (aset.any { it in WIFI } && !isQuestion) return Routed("wifi", JSONObject())

        // flashlight
        val flashHit = coreSet.any { it in FLASH && it != "light" } ||
            (coreSet.contains("light") && core.size <= 4 && (coreSet.any { it in ON || it in OFF }) && aset.none { it == "mode" || it == "theme" || it == "night" })
        if (flashHit && !isQuestion) {
            val on = core.indexOfLast { it in ON && it != "turn" }
            val off = core.indexOfLast { it in OFF }
            return when {
                off > on -> Routed("flashlight", args("on" to false))
                on > off -> Routed("flashlight", args("on" to true))
                else -> Routed("flashlight", JSONObject())
            }
        }

        // "mute karo", "unmute"
        if (core.size <= 2 && (aset.any { it in MUTE } || aset.any { it in UNMUTE })) {
            return Routed("volume", args("action" to if (aset.any { it in UNMUTE }) "unmute" else "mute"))
        }

        // volume
        if (aset.any { it in VOLUME } && !isQuestion) {
            val num = Regex("\\d{1,3}").find(text)?.value?.toIntOrNull()
            return when {
                aset.any { it in UNMUTE } -> Routed("volume", args("action" to "unmute"))
                aset.any { it in MUTE } || (aset.any { it in OFF } && num == null) -> Routed("volume", args("action" to "mute"))
                num != null -> Routed("volume", args("action" to "set", "level" to num.coerceIn(0, 100)))
                aset.contains("max") || aset.contains("full") || aset.contains("maximum") -> Routed("volume", args("action" to "set", "level" to 100))
                aset.any { it in UP } -> Routed("volume", args("action" to "up"))
                aset.any { it in DOWN } -> Routed("volume", args("action" to "down"))
                else -> Routed("volume", JSONObject())
            }
        }

        // "video record karo", "record video"
        if (!isQuestion && coreSet.contains("video") && coreSet.any { it == "record" || it == "recording" || it == "banao" || it == "shoot" }) {
            return Routed("camera", args("mode" to "video"))
        }

        // camera
        if (!isQuestion && (coreSet.any { it in CAMERA } || (coreSet.any { it in PHOTO } && coreSet.any { it in SNAP }))) {
            val video = coreSet.any { it in VIDEO }
            return Routed("camera", args("mode" to if (video) "video" else "photo"))
        }

        // QR
        if (coreSet.any { it in QR } && !isQuestion) {
            if (coreSet.any { it in MAKE }) {
                val t = text.substringAfter(' ', "").split(' ').filter { it.lowercase() !in QR && it.lowercase() !in MAKE && it.lowercase() !in APP_NOISE && it.lowercase() != "for" && it.lowercase() != "of" }.joinToString(" ")
                return if (t.isBlank()) null else Routed("qr_make", args("text" to t))
            }
            return Routed("qr_scan", JSONObject())
        }

        // password / random
        if (coreSet.contains("password") || coreSet.contains("pass")) {
            if (coreSet.any { it in MAKE || it == "random" || it == "strong" || it == "generate" }) {
                val n = Regex("\\d{1,2}").find(text)?.value?.toIntOrNull() ?: 16
                return Routed("random", args("kind" to "password", "length" to n))
            }
        }
        if (coreSet.contains("pin") && coreSet.any { it in MAKE || it == "random" }) return Routed("random", args("kind" to "pin"))
        if (coreSet.any { it == "dice" || it == "die" || it == "ludo" } && coreSet.any { it == "roll" || it == "phenko" || it == "fenko" || it == "throw" || it == "dalo" }) return Routed("random", args("kind" to "dice"))
        if (coreSet.any { it == "coin" || it == "sikka" } && coreSet.any { it == "toss" || it == "flip" || it == "uchalo" || it == "phenko" }) return Routed("random", args("kind" to "coin"))

        // calculator
        calc(text)?.let { return Routed("calc", args("expression" to it)) }

        // navigation
        run {
            val t = text.trim()
            var m = Regex("^(?:navigate|navigation|directions?|route|take me|le chalo|le jao|guide me)\\s*(?:to|ko|tak|ka)?\\s+(.+)$", RegexOption.IGNORE_CASE).find(t)
            if (m == null) m = Regex("^(.+?)\\s+(?:ka|ki|ke)\\s+(?:rasta|raasta|route|direction|directions)$", RegexOption.IGNORE_CASE).find(t)
            if (m != null) {
                val place = m.groupValues[1].trim().trimEnd('.', '!', '?')
                if (place.isNotEmpty()) return Routed("navigate", args("place" to place))
            }
        }

        // open an app: "open whatsapp", "whatsapp kholo", "camera open karo"
        val openWords = ws("open", "launch", "start", "run", "kholo", "khol", "kholdo", "kholna", "chalao", "chala", "chalu", "khulao", "खोलो", "खोल", "चलाओ", "کھولو", "کھول", "چلاؤ", "open")
        if (!isQuestion && all.any { it in openWords }) {
            val nameTokens = all.filter { it !in openWords && it !in APP_NOISE }
            if (nameTokens.isNotEmpty() && nameTokens.size <= 3) {
                val name = nameTokens.joinToString(" ").let { ALIAS[it] ?: it }
                if (isApp != null && !isApp(name)) return null
                return Routed("open_app", args("name" to name))
            }
        }
        // just an app name that is a known short word: "whatsapp", "youtube"
        if (core.size == 1 && core[0] in setOf("whatsapp", "youtube", "gmail", "chrome", "instagram", "facebook", "settings", "maps", "gallery", "telegram", "tiktok", "snapchat")) {
            if (isApp != null && !isApp(core[0])) return null
            return Routed("open_app", args("name" to core[0]))
        }
        return null
    }

    /** "12*5", "calculate 20% of 500", "what is 12 plus 8" -> expression, otherwise null */
    private fun calc(text: String): String? {
        var t = text.trim().lowercase()
        val lead = Regex("^(?:what is|what's|calculate|calc|compute|solve|hisab|hisaab|kitna hota hai|kitne hote hain|=)\\s*").find(t)
        val hadLead = lead != null
        if (lead != null) t = t.substring(lead.range.last + 1)
        t = t.replace("multiplied by", "*").replace("divided by", "/").replace(" times ", "*").replace(" plus ", "+").replace(" minus ", "-")
            .replace("×", "*").replace("÷", "/").trim().trimEnd('?', '=', '.', ' ')
        if (t.isEmpty()) return null
        val ok = Regex("^[\\d\\s+\\-*/^().%,x]+(?:\\s*of\\s*[\\d.,]+)?$").matches(t)
        if (!ok) return null
        val hasOp = Regex("\\d\\s*[+\\-*/^%x]\\s*\\(?\\d|\\d\\s*%\\s*of").containsMatchIn(t)
        if (!hasOp) return null
        return t.replace(Regex("(?<=\\d)\\s*x\\s*(?=\\d)"), "*")
    }

    /** Which tool names the router can use (all must exist and be switched on). */
    fun usable(r: Routed): Boolean = r.tool == null || (Tools.get(r.tool) != null && Tools.enabled(r.tool))
}
