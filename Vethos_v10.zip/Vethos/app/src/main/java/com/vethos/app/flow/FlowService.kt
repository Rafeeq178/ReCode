package com.vethos.app.flow

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.vethos.app.R
import com.vethos.app.tools.AppScope
import com.vethos.app.tools.ToolCtx
import kotlinx.coroutines.launch

/**
 * Runs an automation by itself in the background (no screen): web, email, offline model, notifications.
 * Android shows a small "running" notification while it works.
 */
class FlowService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    private fun notif(text: String, ongoing: Boolean): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("vethos_flow_run", "Automations running", NotificationManager.IMPORTANCE_LOW))
        return NotificationCompat.Builder(this, "vethos_flow_run")
            .setSmallIcon(R.drawable.ic_chat)
            .setContentTitle("⚡ Vethos automation")
            .setContentText(text)
            .setOngoing(ongoing)
            .setAutoCancel(!ongoing)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val flow = Flows.get(intent?.getStringExtra("flow"))
        val node = intent?.getStringExtra("node") ?: ""
        val input = intent?.getStringExtra("input") ?: ""
        val n = notif((flow?.name ?: "Automation") + " is running…", true)
        if (Build.VERSION.SDK_INT >= 34) startForeground(4711, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(4711, n)
        if (flow == null) { stopSelf(startId); return START_NOT_STICKY }

        val wake = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "vethos:flow")
        try { wake.acquire(20 * 60 * 1000L) } catch (_: Throwable) { }

        AppScope.scope.launch {
            val ok = try {
                FlowRunner(ToolCtx(null, applicationContext, null, null)).run(flow, node, input)
            } catch (e: Throwable) {
                false
            }
            try { if (wake.isHeld) wake.release() } catch (_: Throwable) { }
            // leave a short result note
            val nm = getSystemService(NotificationManager::class.java)
            nm.notify(4712, notif(flow.name + (if (ok) ": done" else ": finished with errors. Open the editor and tap Log."), false))
            stopSelf(startId)
        }
        return START_NOT_STICKY
    }
}
