package com.vethos.app.tools

import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions

/** Activity-result launchers the tools need (QR scanner, file picker). Create as a property of the activity. */
class Launchers(act: ComponentActivity) {
    private var scanCb: ((String?) -> Unit)? = null
    private var pickCb: ((Uri?) -> Unit)? = null
    private var createCb: ((Uri?) -> Unit)? = null
    private val owner = act

    private val scanner = act.registerForActivityResult(ScanContract()) { r ->
        val c = scanCb
        scanCb = null
        c?.invoke(r?.contents)
    }

    private val picker = act.registerForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        val c = pickCb
        pickCb = null
        c?.invoke(u)
    }

    // "octet-stream" keeps the file name exactly as given (no .txt added to .html etc.)
    private val creator = act.registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { u ->
        val c = createCb
        createCb = null
        c?.invoke(u)
    }

    /** Asks the user where to save, then writes [text]. [cb] gets (success, message). */
    fun saveText(name: String, text: String, cb: (Boolean, String) -> Unit) {
        createCb = { uri ->
            if (uri == null) cb(false, "Cancelled")
            else try {
                owner.contentResolver.openOutputStream(uri, "wt")?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                cb(true, name)
            } catch (e: Exception) {
                cb(false, "Could not save the file")
            }
        }
        creator.launch(name)
    }

    fun scan(cb: (String?) -> Unit) {
        scanCb = cb
        scanner.launch(ScanOptions().apply {
            setPrompt("Point the camera at a QR code or barcode")
            setBeepEnabled(false)
            setOrientationLocked(false)
        })
    }

    fun pickFile(cb: (Uri?) -> Unit) {
        pickCb = cb
        picker.launch(arrayOf("*/*"))
    }
}
