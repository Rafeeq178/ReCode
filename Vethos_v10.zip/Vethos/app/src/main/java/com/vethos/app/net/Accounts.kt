package com.vethos.app.net

import com.vethos.app.data.Store

/** The email account used by the email and Blogger steps of an automation. */
object Accounts {
    class Mail(
        val address: String, val password: String, val name: String,
        val smtpHost: String, val smtpPort: Int, val imapHost: String, val imapPort: Int,
    )

    private val prefs get() = Store.app.getSharedPreferences("vethos", 0)

    fun mail(): Mail? {
        val addr = prefs.getString("mail_addr", "").orEmpty()
        val pass = Secrets.get("mail_pass")
        if (addr.isBlank() || pass.isBlank()) return null
        return Mail(
            addr, pass, prefs.getString("mail_name", "").orEmpty(),
            prefs.getString("smtp_host", "smtp.gmail.com").orEmpty(), prefs.getInt("smtp_port", 465),
            prefs.getString("imap_host", "imap.gmail.com").orEmpty(), prefs.getInt("imap_port", 993),
        )
    }

    fun saved(): Mail = Mail(
        prefs.getString("mail_addr", "").orEmpty(), "", prefs.getString("mail_name", "").orEmpty(),
        prefs.getString("smtp_host", "smtp.gmail.com").orEmpty(), prefs.getInt("smtp_port", 465),
        prefs.getString("imap_host", "imap.gmail.com").orEmpty(), prefs.getInt("imap_port", 993),
    )

    fun hasPassword(): Boolean = Secrets.get("mail_pass").isNotEmpty()

    fun save(addr: String, pass: String?, name: String, smtpHost: String, smtpPort: Int, imapHost: String, imapPort: Int) {
        prefs.edit()
            .putString("mail_addr", addr.trim()).putString("mail_name", name.trim())
            .putString("smtp_host", smtpHost.trim()).putInt("smtp_port", smtpPort)
            .putString("imap_host", imapHost.trim()).putInt("imap_port", imapPort)
            .apply()
        if (pass != null) Secrets.put("mail_pass", pass)   // null = keep the old password
    }
}
