package com.vethos.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.vethos.app.data.Chat
import com.vethos.app.data.ChatRepo
import com.vethos.app.databinding.ActivityHistoryBinding
import com.vethos.app.databinding.ItemHistoryBinding

class HistoryActivity : AppCompatActivity() {
    private lateinit var b: ActivityHistoryBinding
    private var items: List<Chat> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnBack.setOnClickListener { finish() }
        b.rv.layoutManager = LinearLayoutManager(this)
        b.rv.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun getItemCount() = items.size
            override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder =
                object : RecyclerView.ViewHolder(ItemHistoryBinding.inflate(LayoutInflater.from(p.context), p, false).root) {}
            override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) {
                val chat = items[pos]
                val r = ItemHistoryBinding.bind(h.itemView)
                r.title.text = chat.title
                r.sub.text = "${chat.msgs.size} messages - ${fmtDate(chat.ts)}"
                r.root.setOnClickListener {
                    startActivity(Intent(this@HistoryActivity, ChatActivity::class.java).putExtra("id", chat.id))
                }
                r.delete.setOnClickListener {
                    confirm("Delete chat?", "This can't be undone.", "Delete") { ChatRepo.delete(chat.id); refresh() }
                }
            }
        }
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        items = ChatRepo.sorted().filter { it.msgs.isNotEmpty() }
        b.rv.adapter?.notifyDataSetChanged()
        b.empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }
}
