package com.vethos.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.vethos.app.R
import com.vethos.app.VethosApp
import com.vethos.app.data.ChatRepo
import com.vethos.app.data.Store
import com.vethos.app.databinding.FragmentSettingsBinding
import com.vethos.app.databinding.ItemRowBinding
import com.vethos.app.databinding.ItemSliderBinding
import com.vethos.app.databinding.ItemToggleBinding

class SettingsFragment : Fragment() {
    private var _b: FragmentSettingsBinding? = null
    private val b get() = _b!!

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        FragmentSettingsBinding.inflate(i, c, false).also { _b = it }.root

    override fun onViewCreated(v: View, s: Bundle?) {
        wireMenu(b.btnMenu)
        build()
    }

    // ---------- small builders (everything is added to b.content, the list inside the ScrollView) ----------

    private fun profile() {
        val ctx = requireContext()
        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setBackgroundResource(R.drawable.bg_card)
            setPadding(ctx.dp(14), ctx.dp(14), ctx.dp(16), ctx.dp(14))
            elevation = ctx.dp(2).toFloat()
        }
        card.addView(TextView(ctx).apply {
            text = "V"; gravity = android.view.Gravity.CENTER
            setTextColor(ctx.getColor(R.color.white)); textSize = 22f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setBackgroundResource(R.drawable.bg_avatar)
        }, LinearLayout.LayoutParams(ctx.dp(54), ctx.dp(54)))
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(ctx).apply {
            text = "Vethos"; textSize = 18f; typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(ctx.getColor(R.color.v_text))
        })
        col.addView(TextView(ctx).apply {
            text = "Private · on-device AI"; textSize = 14f
            setTextColor(ctx.getColor(R.color.v_muted))
        })
        card.addView(col, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = ctx.dp(14) })
        card.addView(TextView(ctx).apply {
            text = "Local"; textSize = 13f; typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(ctx.getColor(R.color.white)); gravity = android.view.Gravity.CENTER
            setBackgroundResource(R.drawable.bg_pill_black)
            setPadding(ctx.dp(16), 0, ctx.dp(16), 0)
        }, LinearLayout.LayoutParams(-2, ctx.dp(34)))
        b.content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ctx.dp(6) })
    }

    private fun section(title: String): LinearLayout {
        val ctx = requireContext()
        b.content.addView(TextView(ctx).apply {
            text = title
            setTextColor(ctx.getColor(R.color.v_muted))
            textSize = 13.5f
            letterSpacing = 0.08f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(ctx.dp(6), ctx.dp(24), 0, ctx.dp(10))
        })
        return card()
    }

    private fun card(): LinearLayout {
        val ctx = requireContext()
        val c = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card)
            elevation = ctx.dp(1).toFloat()
        }
        b.content.addView(c, LinearLayout.LayoutParams(-1, -2))
        return c
    }

    private fun divider(card: LinearLayout) {
        val ctx = requireContext()
        if (card.childCount > 0) card.addView(View(ctx).apply {
            setBackgroundColor(ctx.getColor(R.color.v_line))
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1).apply {
            marginStart = ctx.dp(16); marginEnd = ctx.dp(16)
        })
    }

    private fun slider(card: LinearLayout, title: String, max: Int, start: Int, fmt: (Int) -> String, onChange: (Int) -> Unit) {
        divider(card)
        val r = ItemSliderBinding.inflate(layoutInflater, card, false)
        r.title.text = title
        r.seek.max = max
        r.seek.progress = start.coerceIn(0, max)
        r.value.text = fmt(r.seek.progress)
        r.seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                r.value.text = fmt(p)
                if (fromUser) onChange(p)
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        card.addView(r.root)
    }

    private fun toggle(card: LinearLayout, icon: Int, title: String, sub: String?, on: Boolean, onChange: (Boolean) -> Unit) {
        divider(card)
        val r = ItemToggleBinding.inflate(layoutInflater, card, false)
        r.icon.setImageResource(icon)
        r.icon.imageTintList = android.content.res.ColorStateList.valueOf(requireContext().getColor(R.color.v_text))
        r.title.text = title
        if (sub != null) { r.sub.text = sub; r.sub.visibility = View.VISIBLE }
        r.sw.isChecked = on
        r.sw.setOnCheckedChangeListener { _, v -> onChange(v) }
        r.root.setOnClickListener { r.sw.toggle() }
        card.addView(r.root)
    }

    /** A row that opens something (chevron) or, with [value], shows a dropdown-style pill. */
    private fun row(card: LinearLayout, icon: Int?, title: String, value: String?, onClick: () -> Unit): ItemRowBinding {
        divider(card)
        val r = ItemRowBinding.inflate(layoutInflater, card, false)
        if (icon != null) {
            r.icon.setImageResource(icon)
            r.icon.imageTintList = android.content.res.ColorStateList.valueOf(requireContext().getColor(R.color.v_text))
            r.icon.visibility = View.VISIBLE
        }
        r.title.text = title
        if (value != null) {
            r.value.text = value
            r.value.visibility = View.VISIBLE
            r.chev.visibility = View.GONE
        }
        r.root.setOnClickListener { onClick() }
        card.addView(r.root)
        return r
    }

    // ---------- the screen ----------

    private fun build() {
        val ctx = requireContext()
        b.content.removeAllViews()

        profile()

        val chat = section("CHAT PREFERENCES")
        slider(chat, "Creativity", 10, Store.creativity, { "%.1f".format(it / 10f) }) { Store.creativity = it }
        slider(chat, "Max reply length", 31, Store.maxTokens / 64 - 1, { ((it + 1) * 64).toString() }) { Store.maxTokens = (it + 1) * 64 }
        slider(chat, "Memory (messages)", 20, Store.memory, { it.toString() }) { Store.memory = it }
        slider(chat, "Repetition penalty", 20, (Store.repeatPenalty - 100) / 5, {
            "%.2f".format(1f + it * 0.05f).trimEnd('0').trimEnd('.')
        }) { Store.repeatPenalty = 100 + it * 5 }

        val hist = card()
        (hist.layoutParams as LinearLayout.LayoutParams).topMargin = ctx.dp(12)
        toggle(hist, R.drawable.ic_chat, "Keep chat history", null, Store.keepHistory) { Store.keepHistory = it }
        row(hist, R.drawable.ic_hist, "Chat history", null) { startActivity(Intent(ctx, HistoryActivity::class.java)) }
        row(hist, R.drawable.ic_chat, "My Offline Chatbots", null) { startActivity(Intent(ctx, PersonasActivity::class.java)) }


        val netSec = section("INTERNET")
        toggle(netSec, R.drawable.ic_search, "Offline mode", "Blocks every web tool: search, pages, weather, news, email", Store.offlineMode) { Store.offlineMode = it }

        val voice = section("VOICE AND SPEECH")
        toggle(voice, R.drawable.ic_speaker, "Read replies aloud", "The phone reads every answer by itself (also in the chat menu)", Store.autoSpeak) { Store.autoSpeak = it }
        slider(voice, "Speech speed", 15, ((Store.ttsRate - 0.5f) * 10f + 0.5f).toInt().coerceIn(0, 15), { "%.1fx".format(0.5f + it / 10f) }) { Store.ttsRate = 0.5f + it / 10f }
        val speed = section("SPEED")
        toggle(speed, R.drawable.ic_chip, "Multi-thread (faster)", "Uses more CPU cores · restarts a chat", Store.multiThread) { Store.multiThread = it }
        row(speed, null, "CPU threads", if (Store.threads == 0) "Auto" else Store.threads.toString()) { }.let { r ->
            r.root.setOnClickListener {
                val opts = listOf("Auto", "1", "2", "3", "4", "6", "8")
                val cur = opts.indexOf(if (Store.threads == 0) "Auto" else Store.threads.toString()).coerceAtLeast(0)
                ctx.choose("CPU threads", opts, cur) {
                    Store.threads = if (it == 0) 0 else opts[it].toInt()
                    r.value.text = opts[it]
                }
            }
        }
        toggle(speed, R.drawable.ic_play, "Preload model", "Loads at start so the first reply is faster", Store.preload) { Store.preload = it }
        toggle(speed, R.drawable.ic_ins, "GPU (experimental)", "Falls back to CPU if unsupported", Store.gpu) { Store.gpu = it }
        slider(speed, "Context size (more = more RAM)", 7, Store.ctxSize / 512 - 1, { ((it + 1) * 512).toString() }) { Store.ctxSize = (it + 1) * 512 }

        val general = section("GENERAL")
        val themes = listOf("System", "Light", "Dark")
        row(general, null, "Theme", themes[Store.theme]) { }.let { r ->
            r.root.setOnClickListener {
                ctx.choose("Theme", themes, Store.theme) { Store.theme = it; r.value.text = themes[it]; VethosApp.applyTheme() }
            }
        }
        val langs = listOf("English" to "en-US", "Urdu" to "ur-PK", "Hindi" to "hi-IN", "Arabic" to "ar-SA")
        row(general, null, "Voice language", langs.firstOrNull { it.second == Store.voiceLang }?.first ?: "English") { }.let { r ->
            r.root.setOnClickListener {
                val cur = langs.indexOfFirst { it.second == Store.voiceLang }.coerceAtLeast(0)
                ctx.choose("Voice language", langs.map { it.first }, cur) {
                    Store.voiceLang = langs[it].second
                    r.value.text = langs[it].first
                }
            }
        }
        row(general, R.drawable.ic_chip, "Models", null) { (activity as? MainActivity)?.select(1) }

        val more = card()
        (more.layoutParams as LinearLayout.LayoutParams).topMargin = ctx.dp(14)
        row(more, R.drawable.ic_plus, "Install app", null) { ctx.toast("Vethos is already installed on this phone") }
        row(more, R.drawable.ic_trash, "Delete all history", null) {
            ctx.confirm("Delete all history?", "All chats will be removed. This can't be undone.", "Delete") {
                ChatRepo.clear(); Store.clearSteer(); ctx.toast("History deleted")
            }
        }
        // red icon for the destructive row
        (more.getChildAt(more.childCount - 1) as View).findViewById<android.widget.ImageView>(R.id.icon)
            ?.imageTintList = android.content.res.ColorStateList.valueOf(ctx.getColor(R.color.v_danger))

        b.content.addView(TextView(ctx).apply {
            text = "Chats and models are saved on this device only."
            setTextColor(ctx.getColor(R.color.v_muted))
            textSize = 13.5f
            setPadding(ctx.dp(6), ctx.dp(14), 0, ctx.dp(10))
        })
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
