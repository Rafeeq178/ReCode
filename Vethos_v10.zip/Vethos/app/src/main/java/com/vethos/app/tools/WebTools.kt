package com.vethos.app.tools

import com.vethos.app.R
import com.vethos.app.data.Store
import com.vethos.app.net.Net
import com.vethos.app.net.Web
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** Internet tools. They work without a screen too, and "Offline mode" blocks all of them. */
object WebTools {
    private fun ok(t: String, data: String? = null) = ToolResult(true, t, data)
    private fun bad(t: String) = ToolResult(false, t)

    fun build(): List<ToolDef> = listOf(
        ToolDef(
            id = "web_search", title = "Web search", icon = R.drawable.ic_search, sensitive = false,
            desc = "Search the web (top results with links)",
            params = listOf(ToolParam("query", "Search for"), ToolParam("count", "How many results", "default 5", optional = true)),
            usage = """{"query":"search words"}""",
            run = { c, a, d -> webSearch(a, d) },
            headless = true,
        ),
        ToolDef(
            id = "fetch_url", title = "Read web page", icon = R.drawable.ic_search, sensitive = false,
            desc = "Open a link and read the text of the page",
            params = listOf(ToolParam("url", "Link", "https://…"), ToolParam("chars", "How much text", "default 3000", optional = true)),
            usage = """{"url":"https://..."}""",
            run = { c, a, d -> fetchUrl(a, d) },
            headless = true,
        ),
        ToolDef(
            id = "wikipedia", title = "Wikipedia", icon = R.drawable.ic_book, sensitive = false,
            desc = "Summary of a topic, or the latest Wikipedia news (query: news)",
            params = listOf(ToolParam("query", "Topic, or the word news")),
            usage = """{"query":"topic or news"}""",
            run = { c, a, d -> wikipedia(a, d) },
            headless = true,
        ),
        ToolDef(
            id = "weather", title = "Weather", icon = R.drawable.ic_search, sensitive = false,
            desc = "Weather of a city now and today's range",
            params = listOf(ToolParam("city", "City", "e.g. Lahore")),
            usage = """{"city":"city name"}""",
            run = { c, a, d -> weather(a, d) },
            headless = true,
        ),
        ToolDef(
            id = "news", title = "News headlines", icon = R.drawable.ic_search, sensitive = false,
            desc = "Latest headlines: world, pakistan, tech, business, sports, science, health",
            params = listOf(ToolParam("topic", "Topic or feed link", "default world", optional = true), ToolParam("count", "How many", "default 5", optional = true)),
            usage = """{"topic":"world|pakistan|tech|business|sports|science|health"}""",
            run = { c, a, d -> news(a, d) },
            headless = true,
        ),
    )

    /** Runs [block] on a background thread and gives the result back on the main thread. */
    private fun async(done: (ToolResult) -> Unit, block: () -> ToolResult) {
        AppScope.scope.launch {
            val r = withContext(Dispatchers.IO) {
                try {
                    block()
                } catch (e: Net.OfflineException) {
                    bad(e.message ?: "Offline mode is on")
                } catch (e: Throwable) {
                    bad("Could not do that: " + (e.message ?: e.javaClass.simpleName))
                }
            }
            done(r)
        }
    }

    private fun first(a: JSONObject, vararg keys: String): String {
        for (k in keys) {
            val v = a.optString(k).trim()
            if (v.isNotEmpty() && v != "null") return v
        }
        return ""
    }

    private fun webSearch(a: JSONObject, done: (ToolResult) -> Unit) {
        val q = first(a, "query", "q", "text", "search")
        if (q.isEmpty()) { done(bad("What should I search for?")); return }
        val n = (first(a, "count").toIntOrNull() ?: 5).coerceIn(1, 8)
        async(done) {
            val text = Web.format(Web.search(q, n))
            ok(text, "Web search results for “$q”:\n" + text.take(2600))
        }
    }

    private fun fetchUrl(a: JSONObject, done: (ToolResult) -> Unit) {
        val u = first(a, "url", "link", "page")
        if (!u.startsWith("http")) { done(bad("Give me a full link that starts with http")); return }
        val n = (first(a, "chars").toIntOrNull() ?: 3000).coerceIn(300, 8000)
        async(done) {
            val (title, text) = Web.readable(u, n)
            ok("Read: " + title.ifBlank { u } + " (" + text.length + " characters)", "Page “$title” ($u):\n$text")
        }
    }

    private fun wikipedia(a: JSONObject, done: (ToolResult) -> Unit) {
        val q = first(a, "query", "topic", "text", "title")
        async(done) {
            val t = if (q.isEmpty() || q.equals("news", true) || q.equals("latest", true)) Web.wikiNews() else Web.wikiSummary(q)
            ok(t, t.take(2600))
        }
    }

    private fun weather(a: JSONObject, done: (ToolResult) -> Unit) {
        val prefs = Store.app.getSharedPreferences("vethos", 0)
        var city = first(a, "city", "place", "location")
        if (city.isEmpty()) city = prefs.getString("weather_city", "").orEmpty()
        if (city.isEmpty()) { done(bad("Which city? For example: weather in Lahore")); return }
        async(done) {
            val t = Web.weather(city)
            prefs.edit().putString("weather_city", city).apply()
            ok(t, t)
        }
    }

    private fun news(a: JSONObject, done: (ToolResult) -> Unit) {
        val topic = first(a, "topic", "feed", "category", "query").ifEmpty { "world" }
        val n = (first(a, "count").toIntOrNull() ?: 5).coerceIn(1, 10)
        async(done) {
            val t = Web.rss(topic, n)
            ok(t, "Latest headlines ($topic):\n" + t.take(2600))
        }
    }
}
