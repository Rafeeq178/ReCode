package com.vethos.app.ui

import android.os.Bundle
import android.widget.SeekBar
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.vethos.app.R
import com.vethos.app.data.Persona
import com.vethos.app.data.Personas
import com.vethos.app.databinding.ActivityPersonasBinding
import com.vethos.app.databinding.DialogPersonaBinding
import com.vethos.app.databinding.ItemPersonaBinding
import com.vethos.app.tools.Tools

class PersonasActivity : AppCompatActivity() {
    private lateinit var b: ActivityPersonasBinding
    private var pendingExport: String? = null

    private val exportFile = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val text = pendingExport
        pendingExport = null
        if (uri != null && text != null) {
            try {
                contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
                toast("Exported")
            } catch (e: Exception) { toast("Could not save the file") }
        }
    }

    private val importFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val text = contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
                val n = Personas.importJson(text)
                toast(if (n > 0) "Imported $n personalit" + (if (n == 1) "y" else "ies") else "Nothing new to import")
                render()
            } catch (e: Exception) { toast("This is not a valid personalities file") }
        }
    }

    private val tones = listOf("Default", "Friendly", "Professional", "Short and direct", "Funny", "Calm and kind")
    private val langs = listOf("Auto (same as the user)", "English", "Hindi", "Roman Urdu", "Urdu")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityPersonasBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnMenu.setOnClickListener { finish() }
        b.btnNew.setOnClickListener { edit(null) }
        b.btnImport.setOnClickListener { importFile.launch(arrayOf("application/json", "text/*", "*/*")) }
        b.btnExport.setOnClickListener { export(Personas.all()) }
        render()
    }

    private fun export(list: List<Persona>) {
        pendingExport = Personas.exportJson(list)
        exportFile.launch(if (list.size == 1) list[0].name.replace(Regex("[^A-Za-z0-9_-]"), "_") + ".json" else "vethos_personalities.json")
    }

    private fun render() {
        b.list.removeAllViews()
        val card = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card)
        }
        Personas.all().forEachIndexed { idx, p ->
            val r = ItemPersonaBinding.inflate(layoutInflater, card, false)
            val ic = Personas.icons[p.ico.coerceIn(0, Personas.icons.lastIndex)]
            r.icon.setImageResource(ic.res)
            r.icon.imageTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.v_blue))
            r.title.text = p.name
            val nTools = p.allowedTools().size
            r.sub.text = p.desc + if (nTools > 0) "  ·  $nTools tools" else ""
            r.trail.setImageResource(R.drawable.ic_more)
            r.trail.setBackgroundResource(0)
            r.trail.imageTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.v_muted))
            r.trail.setPadding(dp(8), dp(8), dp(8), dp(8))
            r.trail.setOnClickListener { menu(p) }
            (r.root.layoutParams as android.widget.LinearLayout.LayoutParams).apply { topMargin = 0 }
            r.root.setBackgroundResource(0)
            r.root.setOnClickListener { edit(p) }
            r.root.setOnLongClickListener { menu(p); true }
            card.addView(r.root)
            if (idx < Personas.all().lastIndex) card.addView(android.view.View(this).apply {
                setBackgroundColor(getColor(R.color.v_line))
            }, android.widget.LinearLayout.LayoutParams(-1, 1).apply { marginStart = dp(76); marginEnd = dp(16) })
        }
        b.list.addView(card)
    }

    private fun menu(p: Persona) {
        showSheet(p.name, listOf(
            SheetRow(R.drawable.ic_edit, "Edit") { edit(p) },
            SheetRow(R.drawable.ic_copy, "Duplicate") { Personas.duplicate(p); render() },
            SheetRow(R.drawable.ic_share, "Export as JSON") { export(listOf(p)) },
            SheetRow(R.drawable.ic_trash, "Delete", if (Personas.all().size <= 1) "You need at least one personality" else null) {
                if (Personas.all().size > 1) confirm("Delete personality?", p.name, "Delete") { Personas.delete(p.id); render() }
            },
        ))
    }

    private fun toolsLabel(spec: String): String = when {
        spec == "*" -> "Tools: all (${Tools.all.size})"
        spec.isBlank() -> "Tools: none"
        else -> "Tools: " + spec.split(',').filter { it.isNotBlank() }.size + " selected"
    }

    private fun edit(p: Persona?) {
        val d = DialogPersonaBinding.inflate(layoutInflater)
        d.name.setText(p?.name ?: "")
        d.desc.setText(p?.desc ?: "")
        d.prompt.setText(p?.prompt ?: "")
        var tone = p?.tone ?: ""
        var lang = p?.lang ?: ""
        var toolSpec = p?.tools ?: ""
        var temp = p?.temp ?: 5

        fun refresh() {
            d.tone.text = "Tone: " + tone.ifEmpty { tones[0] }
            d.lang.text = "Language: " + lang.ifEmpty { langs[0] }
            d.tools.text = toolsLabel(toolSpec)
            d.tempLabel.text = "Creativity: %.1f".format(temp / 10f)
        }
        refresh()
        d.temp.progress = temp
        d.temp.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, v: Int, fromUser: Boolean) { temp = v; refresh() }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        d.tone.setOnClickListener {
            choose("Tone", tones, tones.indexOf(tone).coerceAtLeast(0)) { i -> tone = if (i == 0) "" else tones[i]; refresh() }
        }
        d.lang.setOnClickListener {
            choose("Reply language", langs, langs.indexOf(lang).coerceAtLeast(0)) { i -> lang = if (i == 0) "" else langs[i]; refresh() }
        }
        d.tools.setOnClickListener {
            val all = Tools.all
            val on = BooleanArray(all.size) { toolSpec == "*" || toolSpec.split(',').contains(all[it].id) }
            MaterialAlertDialogBuilder(this)
                .setTitle("Tools this personality may use")
                .setMultiChoiceItems(all.map { it.title }.toTypedArray(), on) { _, i, c -> on[i] = c }
                .setNegativeButton("Cancel", null)
                .setPositiveButton("OK") { _, _ ->
                    val ids = all.filterIndexed { i, _ -> on[i] }.map { it.id }
                    toolSpec = when {
                        ids.isEmpty() -> ""
                        ids.size == all.size -> "*"
                        else -> ids.joinToString(",")
                    }
                    refresh()
                }.show()
        }

        val dlg = MaterialAlertDialogBuilder(this)
            .setTitle(if (p == null) "New personality" else "Edit personality")
            .setView(d.root)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val name = d.name.text.toString().trim()
                val desc = d.desc.text.toString().trim()
                val prompt = d.prompt.text.toString().trim().ifEmpty { "You are a helpful assistant." }
                if (name.isEmpty()) { toast("Give it a name"); return@setPositiveButton }
                if (p == null) Personas.add(name, desc, prompt, temp, tone, lang, toolSpec)
                else {
                    p.name = name; p.desc = desc; p.prompt = prompt
                    p.temp = temp; p.tone = tone; p.lang = lang; p.tools = toolSpec
                    Personas.save()
                }
                render()
            }
        dlg.show()
    }
}
