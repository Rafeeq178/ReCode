package com.vethos.app.data

import android.content.Context
import org.json.JSONArray
import java.io.File

object Store {
    lateinit var app: Context
    fun init(c: Context) { app = c.applicationContext }

    private val prefs get() = app.getSharedPreferences("vethos", 0)

    val modelsDir: File get() = File(app.filesDir, "models").apply { mkdirs() }
    fun models(): List<File> =
        modelsDir.listFiles { f -> f.isFile && f.name.endsWith(".gguf") }?.sortedBy { it.name } ?: emptyList()

    /** Notification permission is asked only once */
    var askedNotif: Boolean
        get() = prefs.getBoolean("askedNotif", false)
        set(v) = prefs.edit().putBoolean("askedNotif", v).apply()

    var lastModel: String?
        get() = prefs.getString("lastModel", null)
        set(v) = prefs.edit().putString("lastModel", v).apply()

    var maxTokens: Int
        get() = prefs.getInt("maxTokens", 512)
        set(v) = prefs.edit().putInt("maxTokens", v).apply()

    var systemPrompt: String
        get() = prefs.getString("system", "You are Vethos, a helpful, concise assistant running offline on the user's phone.")!!
        set(v) = prefs.edit().putString("system", v).apply()

    /** 0 = system, 1 = light, 2 = dark */
    var theme: Int
        get() = prefs.getInt("theme", 0)
        set(v) = prefs.edit().putInt("theme", v).apply()

    var hfToken: String
        get() = prefs.getString("hfToken", "")!!
        set(v) = prefs.edit().putString("hfToken", v.trim()).apply()

    // ---- Chat preferences ----
    /** Creativity in tenths (0..10) */
    var creativity: Int
        get() = prefs.getInt("creativity", 5)
        set(v) = prefs.edit().putInt("creativity", v).apply()

    /** Repetition penalty x100 (100..200) */
    var repeatPenalty: Int
        get() = prefs.getInt("repeat", 110)
        set(v) = prefs.edit().putInt("repeat", v).apply()

    /** How many earlier messages are given back to the model as memory */
    var memory: Int
        get() = prefs.getInt("memory", 6)
        set(v) = prefs.edit().putInt("memory", v).apply()

    // ---- Internet ----
    /** ON = every web tool is blocked (the app never touches the internet by itself). */
    var offlineMode: Boolean
        get() = prefs.getBoolean("offlineMode", false)
        set(v) = prefs.edit().putBoolean("offlineMode", v).apply()

    var keepHistory: Boolean
        get() = prefs.getBoolean("keepHistory", true)
        set(v) = prefs.edit().putBoolean("keepHistory", v).apply()

    // ---- Speed ----
    var multiThread: Boolean
        get() = prefs.getBoolean("multiThread", true)
        set(v) = prefs.edit().putBoolean("multiThread", v).apply()

    /** 0 = auto */
    var threads: Int
        get() = prefs.getInt("threads", 0)
        set(v) = prefs.edit().putInt("threads", v).apply()

    var preload: Boolean
        get() = prefs.getBoolean("preload", true)
        set(v) = prefs.edit().putBoolean("preload", v).apply()

    var gpu: Boolean
        get() = prefs.getBoolean("gpu", false)
        set(v) = prefs.edit().putBoolean("gpu", v).apply()

    var ctxSize: Int
        get() = prefs.getInt("ctxSize", 512)
        set(v) = prefs.edit().putInt("ctxSize", v).apply()

    // ---- Voice and speech ----
    /** Read every finished answer aloud (phone text-to-speech). */
    var autoSpeak: Boolean
        get() = prefs.getBoolean("autoSpeak", false)
        set(v) = prefs.edit().putBoolean("autoSpeak", v).apply()

    /** Text-to-speech speed, 0.5 .. 2.0 */
    var ttsRate: Float
        get() = prefs.getFloat("ttsRate", 1.0f)
        set(v) = prefs.edit().putFloat("ttsRate", v).apply()

    var voiceLang: String
        get() = prefs.getString("voiceLang", "en-US")!!
        set(v) = prefs.edit().putString("voiceLang", v).apply()

    // ---- Insights ----
    var lastTps: Float
        get() = prefs.getFloat("lastTps", 0f)
        set(v) = prefs.edit().putFloat("lastTps", v).apply()

    var lastFirst: Float
        get() = prefs.getFloat("lastFirst", 0f)
        set(v) = prefs.edit().putFloat("lastFirst", v).apply()

    // Best / Bad answer examples (max 3 each) that steer future chats
    fun steer(kind: String): List<String> {
        val a = JSONArray(prefs.getString("steer_$kind", "[]"))
        return List(a.length()) { a.getString(it) }
    }
    fun addSteer(kind: String, text: String) {
        val l = (steer(kind) + text).takeLast(3)
        prefs.edit().putString("steer_$kind", JSONArray(l).toString()).apply()
    }
    fun clearSteer() = prefs.edit().remove("steer_best").remove("steer_bad").apply()
}
