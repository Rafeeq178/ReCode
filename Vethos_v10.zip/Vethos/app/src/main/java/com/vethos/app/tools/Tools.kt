package com.vethos.app.tools

import android.content.Context
import androidx.activity.ComponentActivity
import com.vethos.app.R
import com.vethos.app.data.Store
import org.json.JSONObject

/** text = what the user sees. data = optional content that is also given back to the model (file text, clipboard...). */
class ToolResult(val ok: Boolean, val text: String, val data: String? = null)

/** key = JSON argument name the model uses; label/hint = what the manual "Try" form shows. */
class ToolParam(val key: String, val label: String, val hint: String = "", val optional: Boolean = false)

/** Everything a tool needs to touch the phone. */
class ToolCtx(
    private val a: ComponentActivity?,
    /** works with or without a screen */
    val ctx: Context,
    private val p: PermHelper?,
    private val l: Launchers?,
) {
    /** normal use: a screen (activity) is open */
    constructor(act: ComponentActivity, perms: PermHelper, launch: Launchers) : this(act, act.applicationContext, perms, launch)

    val hasScreen: Boolean get() = a != null
    val act: ComponentActivity get() = a ?: throw IllegalStateException(NEEDS_SCREEN)
    val perms: PermHelper get() = p ?: throw IllegalStateException(NEEDS_SCREEN)
    val launch: Launchers get() = l ?: throw IllegalStateException(NEEDS_SCREEN)

    companion object {
        const val NEEDS_SCREEN = "This step needs the screen. Open Vethos and run it again."
    }
}

class ToolDef(
    val id: String,
    val title: String,
    val desc: String,
    val icon: Int,
    /** sensitive tools always ask "Allow?" before they run from a chat */
    val sensitive: Boolean,
    val params: List<ToolParam>,
    /** one compact line for the model's system prompt */
    val usage: String,
    val run: (ToolCtx, JSONObject, (ToolResult) -> Unit) -> Unit,
    /** if set, decides per call whether "Allow?" is asked (overrides [sensitive]) */
    val askWhen: ((JSONObject) -> Boolean)? = null,
    /** true = works in the background with no screen (automations that run by themselves) */
    val headless: Boolean = false,
)

class ToolCall(val name: String, val args: JSONObject, val before: String, val after: String)

/**
 * Tool registry. The model asks for a tool with
 *   <tool>{"name":"flashlight","args":{"on":true}}</tool>
 * The app finds that block, runs the tool and shows the result in the chat.
 */
object Tools {
    val all: List<ToolDef> by lazy { PhoneTools.build() + MoreTools.build() + WebTools.build() }

    fun get(id: String): ToolDef? =
        all.firstOrNull { it.id == id } ?: if (id == SkillTools.ID) SkillTools.def else null

    private val prefs get() = Store.app.getSharedPreferences("vethos", 0)

    /** Global switch (Phone tools screen). A tool that is switched off is never offered to the model. */
    fun enabled(id: String): Boolean = !prefs.getBoolean("tool_off_$id", false)
    fun setEnabled(id: String, on: Boolean) = prefs.edit().putBoolean("tool_off_$id", !on).apply()

    /**
     * The short instruction block added to the system prompt. Empty when no tool is allowed.
     * [xml] = LFM3 style  <tool_call><function=name><parameter=key>value</parameter></function></tool_call>
     * otherwise the older  <tool>{"name":...,"args":{...}}</tool>  line.
     */
    fun prompt(allowed: Set<String>, xml: Boolean = false): String {
        val list = allowed.mapNotNull { get(it) }
        if (list.isEmpty()) return ""
        val sb = StringBuilder()
        if (xml) {
            sb.append("You can use tools. To use a tool, reply with ONLY this block and nothing else:\n")
            sb.append("<tool_call>\n<function=TOOL_NAME>\n<parameter=ARG_NAME>\nVALUE\n</parameter>\n</function>\n</tool_call>\n")
            sb.append("Tools, written name(arguments) - what it does (? = optional argument):\n")
            list.forEach { d ->
                sb.append(d.id).append('(').append(d.params.joinToString(", ") { it.key + if (it.optional) "?" else "" })
                    .append(") - ").append(d.desc).append('\n')
            }
            sb.append("After a tool result arrives you may use another tool, or answer the user. For normal questions answer normally and do not use a tool.")
        } else {
            sb.append("You can control the phone. If the user asks for a phone action, reply with ONLY this one line and nothing else: ")
            sb.append("<tool>{\"name\":\"TOOL\",\"args\":{...}}</tool>\nTools:\n")
            list.forEach { sb.append(it.id).append(' ').append(it.usage).append('\n') }
            sb.append("For normal questions answer normally and do not use a tool.")
        }
        return sb.toString()
    }

    /** While an answer is still typing, hide the raw tool text. */
    fun hideLive(s: String): String {
        val i = listOf(s.indexOf("<tool>"), s.indexOf("<tool_call>"), s.indexOf("<function="))
            .filter { it >= 0 }.minOrNull() ?: return s
        return s.substring(0, i) + "⚙ Using a tool…"
    }

    private val fnRe = Regex("""<function=([\w.\-]+)>""")
    private val parRe = Regex("""(?s)<parameter=([\w.\-]+)>\s*(.*?)\s*</parameter>""")

    /** LFM3 / Qwen-coder style XML call. Returns null if the text has none. */
    private fun parseXml(text: String, allowed: Set<String>): ToolCall? {
        val fn = fnRe.find(text) ?: return null
        val name = fn.groupValues[1].trim().lowercase()
        if (name !in allowed) return null
        val endFn = text.indexOf("</function>", fn.range.last)
        val body = text.substring(fn.range.last + 1, if (endFn >= 0) endFn else text.length)
        val args = JSONObject()
        parRe.findAll(body).forEach { m -> args.put(m.groupValues[1], m.groupValues[2]) }
        var end = if (endFn >= 0) endFn + "</function>".length else text.length
        val endTag = text.indexOf("</tool_call>", end)
        if (endTag >= 0 && text.substring(end, endTag).isBlank()) end = endTag + "</tool_call>".length
        val open = text.lastIndexOf("<tool_call>", fn.range.first)
        val beforeEnd = if (open >= 0 && text.substring(open + 11, fn.range.first).isBlank()) open else fn.range.first
        return ToolCall(name, args, text.substring(0, beforeEnd).trim(), text.substring(end).trim())
    }

    /** Finds a tool request inside the model's answer. Returns null if there is none (or it is not allowed). */
    fun parse(text: String, allowed: Set<String>): ToolCall? {
        if (allowed.isEmpty()) return null
        parseXml(text, allowed)?.let { return it }
        var start = text.indexOf("<tool>")
        if (start < 0) start = text.indexOf("<tool_call>")
        val from: Int
        if (start >= 0) {
            from = start + (if (text.startsWith("<tool_call>", start)) 11 else 6)
        } else {
            val k = Regex("""\{\s*["']name["']""").find(text) ?: return null
            start = k.range.first
            from = start
        }
        val open = text.indexOf('{', from)
        if (open < 0) return null
        val close = matchBrace(text, open)
        if (close < 0) return null
        val obj = try { JSONObject(text.substring(open, close + 1)) } catch (_: Exception) { return null }
        val name = obj.optString("name").ifBlank { obj.optString("tool") }.trim().lowercase()
        if (name !in allowed) return null
        val args = obj.optJSONObject("args") ?: obj.optJSONObject("arguments") ?: obj.optJSONObject("parameters")
            ?: JSONObject().also { o ->
                obj.keys().forEach { k -> if (k != "name" && k != "tool") o.put(k, obj.get(k)) }
            }
        var end = close + 1
        val endTag = text.indexOf("</tool>", end)
        if (endTag >= 0 && text.substring(end, endTag).isBlank()) end = endTag + 7
        val endTag2 = text.indexOf("</tool_call>", end)
        if (endTag2 >= 0 && text.substring(end, endTag2).isBlank()) end = endTag2 + 12
        return ToolCall(name, args, text.substring(0, start).trim(), text.substring(end).trim())
    }

    private fun matchBrace(s: String, open: Int): Int {
        var depth = 0
        var inStr = false
        var q = ' '
        var esc = false
        for (i in open until s.length) {
            val c = s[i]
            if (inStr) {
                if (esc) esc = false
                else if (c == '\\') esc = true
                else if (c == q) inStr = false
                continue
            }
            when (c) {
                '"', '\'' -> { inStr = true; q = c }
                '{' -> depth++
                '}' -> { depth--; if (depth == 0) return i }
            }
        }
        return -1
    }
}
