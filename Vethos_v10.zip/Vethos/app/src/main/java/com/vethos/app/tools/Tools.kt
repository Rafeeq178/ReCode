package com.vethos.app.tools

import android.content.Context
import androidx.activity.ComponentActivity
import com.vethos.app.R
import com.vethos.app.data.Store
import org.json.JSONObject

/** text = what the user sees. data = optional content that is also given back to the model (file text, clipboard...). */
class ToolResult(val ok: Boolean, val text: String, val data: String? = null)

/** key = JSON argument name the model uses; label/hint = what the manual "Try" form shows. */
class ToolParam(val key: String, val label: String, val hint: String = "", val optional: Boolean = false)

/** Everything a tool needs to touch the phone. */
class ToolCtx(
    private val a: ComponentActivity?,
    /** works with or without a screen */
    val ctx: Context,
    private val p: PermHelper?,
    private val l: Launchers?,
) {
    /** normal use: a screen (activity) is open */
    constructor(act: ComponentActivity, perms: PermHelper, launch: Launchers) : this(act, act.applicationContext, perms, launch)

    val hasScreen: Boolean get() = a != null
    val act: ComponentActivity get() = a ?: throw IllegalStateException(NEEDS_SCREEN)
    val perms: PermHelper get() = p ?: throw IllegalStateException(NEEDS_SCREEN)
    val launch: Launchers get() = l ?: throw IllegalStateException(NEEDS_SCREEN)

    companion object {
        const val NEEDS_SCREEN = "This step needs the screen. Open Vethos and run it again."
    }
}

class ToolDef(
    val id: String,
    val title: String,
    val desc: String,
    val icon: Int,
    /** sensitive tools always ask "Allow?" before they run from a chat */
    val sensitive: Boolean,
    val params: List<ToolParam>,
    /** one compact line for the model's system prompt */
    val usage: String,
    val run: (ToolCtx, JSONObject, (ToolResult) -> Unit) -> Unit,
    /** if set, decides per call whether "Allow?" is asked (overrides [sensitive]) */
    val askWhen: ((JSONObject) -> Boolean)? = null,
    /** true = works in the background with no screen (automations that run by themselves) */
    val headless: Boolean = false,
)

class ToolCall(val name: String, val args: JSONObject, val before: String, val after: String)

/**
 * Tool registry. The model asks for a tool in its own native format (LFM3 / Qwen style):
 *   <function=calc>
 *   <parameter=expression>12*(3+4)</parameter>
 *   </function>
 * Older formats still work: <tool>{"name":"calc","args":{...}}</tool> and bare {"name":..., "arguments":{...}}.
 * The app finds the block, validates it, runs the tool and shows the result in the chat.
 */
object Tools {
    /** Tools that ship with the app. */
    val builtIn: List<ToolDef> by lazy { MoreTools.build() + ExtraTools.build() + WebTools.build() }

    /** Built-in tools plus the ones the user made in the Tools screen. */
    val all: List<ToolDef> get() = builtIn + CustomTools.defs()

    fun get(id: String): ToolDef? = all.firstOrNull { it.id == id }

    fun isCustom(id: String): Boolean = builtIn.none { it.id == id }

    private val prefs get() = Store.app.getSharedPreferences("vethos", 0)

    /** Global switch (Tools screen). A tool that is switched off is never offered to the model. */
    fun enabled(id: String): Boolean = !prefs.getBoolean("tool_off_$id", false)
    fun setEnabled(id: String, on: Boolean) = prefs.edit().putBoolean("tool_off_$id", !on).apply()

    /** While an answer is still typing, hide the raw tool block. */
    fun hideLive(s: String): String {
        var i = -1
        for (m in listOf("<tool_call>", "<function", "<tool>")) {
            val k = s.indexOf(m)
            if (k >= 0 && (i < 0 || k < i)) i = k
        }
        return if (i >= 0) s.substring(0, i) + "⚙ Using a tool…" else s
    }

    /** Finds a tool request inside the model's answer. Returns null if there is none (or it is not allowed). */
    fun parse(text: String, allowed: Set<String>): ToolCall? {
        if (allowed.isEmpty()) return null
        return parseNative(text, allowed) ?: parseJson(text, allowed)
    }

    // ---------- native: <function=name><parameter=key>value</parameter></function> ----------

    private val fnRe = Regex("""<function\s*=\s*["']?([A-Za-z0-9_.\-]+)["']?\s*>""")
    private val parRe = Regex("""<parameter\s*=\s*["']?([A-Za-z0-9_.\-]+)["']?\s*>""")

    private fun parseNative(text: String, allowed: Set<String>): ToolCall? {
        val m = fnRe.find(text) ?: return null
        val name = m.groupValues[1].trim().lowercase()
        if (name !in allowed) return null
        val bodyStart = m.range.last + 1
        val closeIdx = text.indexOf("</function>", bodyStart)
        val bodyEnd = if (closeIdx >= 0) closeIdx else text.length
        val body = text.substring(bodyStart, bodyEnd)
        val args = JSONObject()
        val ps = parRe.findAll(body).toList()
        ps.forEachIndexed { i, p ->
            val vs = p.range.last + 1
            val nextOpen = if (i + 1 < ps.size) ps[i + 1].range.first else body.length
            val close = body.indexOf("</parameter>", vs)
            val ve = if (close in vs..nextOpen) close else nextOpen
            args.put(p.groupValues[1], coerce(body.substring(vs, ve).trim()))
        }
        if (ps.isEmpty()) {
            val t = body.trim()
            if (t.startsWith("{")) {
                try {
                    val o = JSONObject(t)
                    o.keys().forEach { k -> args.put(k, o.get(k)) }
                } catch (_: Exception) { }
            }
        }
        var start = m.range.first
        val wrapOpen = text.lastIndexOf("<tool_call>", start)
        if (wrapOpen >= 0 && text.substring(wrapOpen + 11, start).isBlank()) start = wrapOpen
        var end = if (closeIdx >= 0) closeIdx + 11 else text.length
        val wrapClose = text.indexOf("</tool_call>", end)
        if (wrapClose >= 0 && text.substring(end, wrapClose).isBlank()) end = wrapClose + 12
        return ToolCall(name, args, text.substring(0, start).trim(), text.substring(minOf(end, text.length)).trim())
    }

    private fun coerce(v: String): Any {
        if (Regex("-?\\d{1,9}").matches(v)) return v.toInt()
        return v
    }

    // ---------- JSON formats ----------

    private fun parseJson(text: String, allowed: Set<String>): ToolCall? {
        var start = text.indexOf("<tool>")
        val from: Int
        if (start >= 0) {
            from = start + 6
        } else {
            val k = Regex("""\{\s*["']name["']""").find(text) ?: return null
            start = k.range.first
            from = start
        }
        val open = text.indexOf('{', from)
        if (open < 0) return null
        val close = matchBrace(text, open)
        if (close < 0) return null
        val obj = try { JSONObject(text.substring(open, close + 1)) } catch (_: Exception) { return null }
        val name = obj.optString("name").ifBlank { obj.optString("tool") }.trim().lowercase()
        if (name !in allowed) return null
        val args = obj.optJSONObject("args") ?: obj.optJSONObject("arguments") ?: obj.optJSONObject("parameters")
            ?: JSONObject().also { o ->
                obj.keys().forEach { k -> if (k != "name" && k != "tool") o.put(k, obj.get(k)) }
            }
        var end = close + 1
        val endTag = text.indexOf("</tool>", end)
        if (endTag >= 0 && text.substring(end, endTag).isBlank()) end = endTag + 7
        return ToolCall(name, args, text.substring(0, start).trim(), text.substring(end).trim())
    }

    private fun matchBrace(s: String, open: Int): Int {
        var depth = 0
        var inStr = false
        var q = ' '
        var esc = false
        for (i in open until s.length) {
            val c = s[i]
            if (inStr) {
                if (esc) esc = false
                else if (c == '\\') esc = true
                else if (c == q) inStr = false
                continue
            }
            when (c) {
                '"', '\'' -> { inStr = true; q = c }
                '{' -> depth++
                '}' -> { depth--; if (depth == 0) return i }
            }
        }
        return -1
    }

    // ---------- validation ----------

    /** Small models often use a wrong key name (expr instead of expression). If exactly one required value is missing and exactly one unknown key is present, move it. */
    fun normalize(d: ToolDef, args: JSONObject): JSONObject {
        val known = d.params.map { it.key }.toSet()
        val out = JSONObject()
        args.keys().forEach { k -> out.put(k, args.get(k)) }
        val missing = d.params.filter { !it.optional && out.optString(it.key).isBlank() }
        val stray = out.keys().asSequence().filter { it !in known }.toList()
        if (missing.size == 1 && stray.size == 1) out.put(missing[0].key, out.get(stray[0]))
        return out
    }

    /** Required parameters that are empty. Lenient on purpose: only reported when every required value is empty. */
    fun missing(d: ToolDef, args: JSONObject): List<String> {
        val req = d.params.filter { !it.optional }
        if (req.isEmpty()) return emptyList()
        return if (req.all { args.optString(it.key).isBlank() }) req.map { it.key } else emptyList()
    }
}
