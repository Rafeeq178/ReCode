package com.vethos.app.data

data class CatalogModel(val name: String, val desc: String, val size: String, val url: String, val file: String)

object Catalog {
    private const val HF = "https://huggingface.co/"
    val items = listOf(
        CatalogModel("LFM3 Omni 2B", "Liquid AI · tools-ready · 4 GB+ RAM (text only here)", "~1.0 GB",
            HF + "LiquidAI/LFM3-Omni-2B-GGUF/resolve/main/LFM3-Omni-2B-Q4_K_M.gguf", "LFM3-Omni-2B-Q4_K_M.gguf"),
        CatalogModel("SmolLM2 135M", "Fastest · tiny", "~100 MB",
            HF + "bartowski/SmolLM2-135M-Instruct-GGUF/resolve/main/SmolLM2-135M-Instruct-Q4_K_M.gguf", "SmolLM2-135M-Instruct-Q4_K_M.gguf"),
        CatalogModel("SmolLM2 360M", "Fast · small", "~250 MB",
            HF + "bartowski/SmolLM2-360M-Instruct-GGUF/resolve/main/SmolLM2-360M-Instruct-Q4_K_M.gguf", "SmolLM2-360M-Instruct-Q4_K_M.gguf"),
        CatalogModel("Qwen2.5 0.5B", "Balanced · multilingual", "~400 MB",
            HF + "Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_k_m.gguf", "qwen2.5-0.5b-instruct-q4_k_m.gguf"),
        CatalogModel("Llama 3.2 1B", "Smarter · slower", "~800 MB",
            HF + "bartowski/Llama-3.2-1B-Instruct-GGUF/resolve/main/Llama-3.2-1B-Instruct-Q4_K_M.gguf", "Llama-3.2-1B-Instruct-Q4_K_M.gguf"),
        CatalogModel("Qwen2.5 1.5B", "Balanced quality and speed", "~1.1 GB",
            HF + "Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf", "qwen2.5-1.5b-instruct-q4_k_m.gguf"),
        CatalogModel("Gemma 2 2B", "Strong writing, needs 6 GB+ RAM", "~1.6 GB",
            HF + "bartowski/gemma-2-2b-it-GGUF/resolve/main/gemma-2-2b-it-Q4_K_M.gguf", "gemma-2-2b-it-Q4_K_M.gguf"),
        CatalogModel("Llama 3.2 3B", "Best quality here, needs 8 GB RAM", "~2.0 GB",
            HF + "bartowski/Llama-3.2-3B-Instruct-GGUF/resolve/main/Llama-3.2-3B-Instruct-Q4_K_M.gguf", "Llama-3.2-3B-Instruct-Q4_K_M.gguf"),
    )
}
