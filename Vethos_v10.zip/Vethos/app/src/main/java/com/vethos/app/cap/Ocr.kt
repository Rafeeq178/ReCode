package com.vethos.app.cap

import android.content.Context
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.vethos.app.lang.await
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Reads the text in a photo on the phone (Google ML Kit, offline). English/Latin and Hindi (Devanagari). */
object Ocr {
    suspend fun read(ctx: Context, uri: Uri): String = withContext(Dispatchers.IO) {
        val image = InputImage.fromFilePath(ctx, uri)
        val latin = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val deva = TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
        try {
            val a = try { latin.process(image).await().text.trim() } catch (e: Exception) { "" }
            val b = try { deva.process(image).await().text.trim() } catch (e: Exception) { "" }
            val hindi = b.count { it.code in 0x0900..0x097F }
            if (hindi >= 3) b else if (a.isNotEmpty()) a else b
        } finally {
            try { latin.close() } catch (_: Exception) { }
            try { deva.close() } catch (_: Exception) { }
        }
    }
}
