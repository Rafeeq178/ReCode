package com.vethos.app.tools

import android.content.Context
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.InputStream

/** Reads the text layer of a PDF (PdfBox-Android). Scanned PDFs have no text layer, so they cannot be read. */
object PdfText {
    private var inited = false

    @Synchronized
    private fun init(ctx: Context) {
        if (!inited) {
            PDFBoxResourceLoader.init(ctx.applicationContext)
            inited = true
        }
    }

    /** Call from a background thread. Throws IllegalArgumentException with a readable message. */
    fun extract(ctx: Context, ins: InputStream, maxPages: Int = 30): String {
        init(ctx)
        val doc: PDDocument = try {
            PDDocument.load(ins)
        } catch (e: Throwable) {
            if (e.javaClass.simpleName.contains("InvalidPassword")) {
                throw IllegalArgumentException("This PDF is password protected")
            }
            throw IllegalArgumentException("Could not open this PDF")
        }
        try {
            val pages = doc.numberOfPages
            val st = PDFTextStripper()
            st.startPage = 1
            st.endPage = minOf(pages, maxPages)
            val text = st.getText(doc).trim()
            if (text.isEmpty()) {
                throw IllegalArgumentException("No text found in this PDF (it may be scanned images)")
            }
            return if (pages > maxPages) text + "\n...[only the first $maxPages pages were read]" else text
        } catch (e: IllegalArgumentException) {
            throw e
        } catch (e: Throwable) {
            throw IllegalArgumentException("Could not read the text of this PDF")
        } finally {
            try { doc.close() } catch (_: Throwable) { }
        }
    }
}
