package com.vethos.app.ui

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.vethos.app.R
import com.vethos.app.data.HtmlRun
import com.vethos.app.data.MiniApps
import com.vethos.app.databinding.ActivityRunnerBinding
import com.vethos.app.tools.Launchers
import com.vethos.app.tools.PermHelper
import com.vethos.app.tools.ToolCtx
import com.vethos.app.tools.ToolRunner
import com.vethos.app.tools.Tools
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File

/**
 * Runs HTML / CSS / JavaScript fully offline inside a WebView:
 *  - every network request is blocked (the page can only use its own code and data: URLs)
 *  - edit the code and run it again, full screen preview, console, save as mini app, export as .html
 *  - window.Vethos.tool("battery", {}) lets the page use the Vethos phone tools
 */
class RunnerActivity : AppCompatActivity() {
    private lateinit var b: ActivityRunnerBinding
    private val perms = PermHelper(this)
    private val launchers = Launchers(this)

    private var source = ""
    private var appId: String? = null
    private var appTitle = "Preview"
    private var fs = false
    private var bridgeOn = true
    private val logs = ArrayList<String>()
    private var errors = 0

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityRunnerBinding.inflate(layoutInflater)
        setContentView(b.root)

        var openEditor = intent.getBooleanExtra("edit", false)
        val id = intent.getStringExtra("app")
        if (id != null) {
            val app = MiniApps.get(id)
            val html = MiniApps.html(id)
            if (app == null || html == null) { toast("This mini app was not found"); finish(); return }
            appId = id
            appTitle = app.name
            source = html
        } else if (intent.getBooleanExtra("tmp", false)) {
            appTitle = intent.getStringExtra("title") ?: "Preview"
            source = File(filesDir, "run_tmp.html").takeIf { it.exists() }?.readText() ?: ""
        } else {
            appTitle = "New mini app"
            source = TEMPLATE
            openEditor = true
        }
        b.title.text = appTitle

        setupWeb()

        b.btnBack.setOnClickListener { finish() }
        b.btnCode.setOnClickListener { showEditor(b.editorBox.visibility != View.VISIBLE) }
        b.btnRun.setOnClickListener { rerun() }
        b.btnFs.setOnClickListener { setFullscreen(true) }
        b.btnExitFs.setOnClickListener { setFullscreen(false) }
        b.btnMore.setOnClickListener { more() }
        b.editorRun.setOnClickListener { rerun() }
        b.editorClose.setOnClickListener { showEditor(false) }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    b.editorBox.visibility == View.VISIBLE -> showEditor(false)
                    fs -> setFullscreen(false)
                    else -> finish()
                }
            }
        })

        if (openEditor) showEditor(true)
        load()
    }

    // ---------- web view ----------
    private fun base() = "https://" + (appId ?: "preview") + ".vethos.local/"

    private fun blocked() = WebResourceResponse(
        "text/plain", "utf-8", 403, "Blocked (offline)", emptyMap<String, String>(), ByteArrayInputStream(ByteArray(0))
    )

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWeb() {
        val w = b.web
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            blockNetworkLoads = true
            mediaPlaybackRequiresUserGesture = false
            useWideViewPort = true
            builtInZoomControls = false
            setSupportZoom(false)
            setGeolocationEnabled(false)
        }
        w.setBackgroundColor(Color.WHITE)
        w.addJavascriptInterface(Bridge(), "__VethosNative")
        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val u = request?.url ?: return null
                val s = u.scheme ?: return null
                if (s == "data" || s == "about" || s == "blob") return null
                // location.reload() asks for the base page again: serve it from memory
                if (request?.isForMainFrame == true && u.toString().substringBefore('#') == base()) {
                    return WebResourceResponse("text/html", "utf-8", ByteArrayInputStream(HtmlRun.withShim(source).toByteArray(Charsets.UTF_8)))
                }
                return blocked()
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url?.toString() ?: return true
                return !(u.startsWith(base()) && u.contains('#'))   // only in-page anchors
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                if (logs.size > 300) logs.removeAt(0)
                logs.add("[" + m.messageLevel() + "] " + m.message() + "  (line " + m.lineNumber() + ")")
                if (m.messageLevel() == ConsoleMessage.MessageLevel.ERROR) errors++
                return true
            }

            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
                MaterialAlertDialogBuilder(this@RunnerActivity).setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .setOnCancelListener { result.cancel() }.show()
                return true
            }

            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
                MaterialAlertDialogBuilder(this@RunnerActivity).setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .setNegativeButton("Cancel") { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }.show()
                return true
            }

            override fun onJsPrompt(view: WebView?, url: String?, message: String?, defaultValue: String?, result: JsPromptResult): Boolean {
                val et = EditText(this@RunnerActivity).apply { setText(defaultValue ?: "") }
                val box = FrameLayout(this@RunnerActivity).apply {
                    setPadding(dp(22), dp(8), dp(22), 0)
                    addView(et, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                }
                MaterialAlertDialogBuilder(this@RunnerActivity).setMessage(message).setView(box)
                    .setPositiveButton("OK") { _, _ -> result.confirm(et.text.toString()) }
                    .setNegativeButton("Cancel") { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }.show()
                return true
            }
        }
    }

    /** Always loads through loadDataWithBaseURL (never WebView.reload, which would hit the blocked network). */
    private fun load() {
        logs.clear()
        errors = 0
        b.web.loadDataWithBaseURL(base(), HtmlRun.withShim(source), "text/html", "utf-8", null)
    }

    private fun rerun() {
        if (b.editorBox.visibility == View.VISIBLE) {
            source = b.editor.text.toString()
            showEditor(false)
        }
        load()
    }

    // ---------- editor ----------
    private fun showEditor(on: Boolean) {
        b.editorBox.visibility = if (on) View.VISIBLE else View.GONE
        if (on) {
            b.editor.setText(source)
            b.editor.requestFocus()
        } else {
            getSystemService(InputMethodManager::class.java)?.hideSoftInputFromWindow(b.editor.windowToken, 0)
        }
    }

    // ---------- fullscreen ----------
    private fun setFullscreen(on: Boolean) {
        fs = on
        b.header.visibility = if (on) View.GONE else View.VISIBLE
        b.btnExitFs.visibility = if (on) View.VISIBLE else View.GONE
        val c = WindowCompat.getInsetsController(window, window.decorView)
        if (on) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    // ---------- menu ----------
    private fun more() {
        showSheet(appTitle, listOf(
            SheetRow(R.drawable.ic_check, if (appId == null) "Save as mini app" else "Save changes") { saveApp() },
            SheetRow(R.drawable.ic_dl, "Export as .html file") { export() },
            SheetRow(R.drawable.ic_code, "Console", if (errors > 0) "$errors error(s)" else logs.size.toString() + " message(s)") { showConsole() },
            SheetRow(R.drawable.ic_lock, "Phone tools for this page", if (bridgeOn) "On" else "Off", bridgeOn) {
                bridgeOn = !bridgeOn
                toast(if (bridgeOn) "Phone tools are on for this page" else "Phone tools are off for this page")
            },
        ))
    }

    private fun currentSource(): String =
        if (b.editorBox.visibility == View.VISIBLE) b.editor.text.toString() else source

    private fun saveApp() {
        source = currentSource()
        val id = appId
        if (id != null) {
            MiniApps.save(appTitle, source, id)
            toast("Saved")
            return
        }
        val start = if (appTitle == "Preview" || appTitle == "New mini app") "My mini app" else appTitle
        inputDialog("Save as mini app", start, "App name") { name ->
            val n = name.trim().ifEmpty { "My mini app" }
            val app = MiniApps.save(n, source)
            appId = app.id
            appTitle = n
            b.title.text = n
            toast("Saved in Mini apps")
        }
    }

    private fun export() {
        val file = appTitle.replace(Regex("[^A-Za-z0-9_-]"), "_").ifEmpty { "page" } + ".html"
        launchers.saveText(file, currentSource()) { ok, msg -> toast(if (ok) "Saved $msg" else msg) }
    }

    private fun showConsole() {
        val tv = TextView(this).apply {
            text = if (logs.isEmpty()) "Nothing logged yet.\n\nconsole.log(...) and JavaScript errors show up here." else logs.joinToString("\n")
            setTextIsSelectable(true)
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextColor(getColor(R.color.v_text))
            setPadding(dp(22), dp(8), dp(22), dp(8))
        }
        MaterialAlertDialogBuilder(this).setTitle("Console").setView(ScrollView(this).apply { addView(tv) })
            .setPositiveButton("Close", null)
            .setNeutralButton("Clear") { _, _ -> logs.clear(); errors = 0 }
            .show()
    }

    // ---------- JS bridge: window.Vethos ----------
    inner class Bridge {
        @JavascriptInterface
        fun call(name: String, argsJson: String, id: Int) {
            runOnUiThread { runTool(name, argsJson, id) }
        }

        @JavascriptInterface
        fun list(): String {
            val a = JSONArray()
            Tools.all.filter { Tools.enabled(it.id) }.forEach {
                a.put(JSONObject().put("name", it.id).put("title", it.title).put("desc", it.desc).put("args", it.usage))
            }
            return a.toString()
        }

        @JavascriptInterface
        fun toast(msg: String) {
            runOnUiThread { this@RunnerActivity.toast(msg) }
        }
    }

    private fun runTool(name: String, argsJson: String, id: Int) {
        fun reply(ok: Boolean, text: String, data: String?) {
            b.web.evaluateJavascript(
                "window.__vcb(" + id + "," + ok + "," + JSONObject.quote(text) + "," + JSONObject.quote(data ?: "") + ")", null
            )
        }
        val def = Tools.get(name.trim().lowercase())
        if (!bridgeOn) { reply(false, "Phone tools are switched off for this page", null); return }
        if (def == null || !Tools.enabled(def.id)) { reply(false, "Unknown or disabled tool: $name", null); return }
        val args = try { JSONObject(argsJson) } catch (e: Exception) { JSONObject() }
        ToolRunner.run(ToolCtx(this, perms, launchers), def, args, false) { r -> reply(r.ok, r.text, r.data) }
    }

    // ---------- life cycle ----------
    override fun onPause() { super.onPause(); b.web.onPause() }
    override fun onResume() { super.onResume(); b.web.onResume() }

    override fun onDestroy() {
        b.web.apply {
            stopLoading()
            removeJavascriptInterface("__VethosNative")
            (parent as? ViewGroup)?.removeView(this)
            destroy()
        }
        super.onDestroy()
    }

    companion object {
        /** Opens a code block (a full HTML page) in the runner. */
        fun startHtml(ctx: Context, html: String, title: String = "Preview") {
            File(ctx.filesDir, "run_tmp.html").writeText(html)
            ctx.startActivity(Intent(ctx, RunnerActivity::class.java).putExtra("tmp", true).putExtra("title", title))
        }

        fun startApp(ctx: Context, id: String, edit: Boolean = false) {
            ctx.startActivity(Intent(ctx, RunnerActivity::class.java).putExtra("app", id).putExtra("edit", edit))
        }

        fun startNew(ctx: Context) {
            ctx.startActivity(Intent(ctx, RunnerActivity::class.java))
        }

        private const val TEMPLATE = """<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>My mini app</title>
<style>
  body { font-family: sans-serif; padding: 20px; }
  button { padding: 12px 18px; font-size: 16px; border-radius: 12px; border: 0; background: #C9623F; color: #fff; }
</style>
</head>
<body>
  <h2>Hello from Vethos</h2>
  <p>Edit this code, then press Run.</p>
  <button onclick="check()">Battery</button>
  <p id="out"></p>
  <script>
    function check() {
      // Vethos.tool(name, args) uses the phone tools of the app
      Vethos.tool('battery').then(function (r) {
        document.getElementById('out').textContent = r.text;
      });
    }
  </script>
</body>
</html>"""
    }
}
