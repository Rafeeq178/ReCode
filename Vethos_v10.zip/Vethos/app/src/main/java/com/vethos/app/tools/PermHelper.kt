package com.vethos.app.tools

import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

/**
 * Asks for one runtime permission at a time. Create it as a property of the activity
 * (registerForActivityResult must run before the activity is STARTED).
 */
class PermHelper(private val act: ComponentActivity) {
    private var cb: ((Boolean) -> Unit)? = null
    private val launcher = act.registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        val c = cb
        cb = null
        c?.invoke(ok)
    }

    fun ensure(perm: String, onResult: (Boolean) -> Unit) {
        if (ContextCompat.checkSelfPermission(act, perm) == PackageManager.PERMISSION_GRANTED) {
            onResult(true)
            return
        }
        cb = onResult
        launcher.launch(perm)
    }
}
