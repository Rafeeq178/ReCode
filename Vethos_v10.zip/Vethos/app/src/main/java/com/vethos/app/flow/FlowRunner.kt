package com.vethos.app.flow

import android.content.Context
import com.vethos.app.data.Engine
import com.vethos.app.data.Store
import com.vethos.app.lang.Lang
import com.vethos.app.net.Accounts
import com.vethos.app.net.Imap
import com.vethos.app.net.Net
import com.vethos.app.net.Smtp
import com.vethos.app.net.Web
import com.vethos.app.tools.ToolCtx
import com.vethos.app.tools.ToolDef
import com.vethos.app.tools.ToolResult
import com.vethos.app.tools.ToolRunner
import com.vethos.app.tools.Think
import com.vethos.app.tools.Tools
import com.vethos.app.ui.RunnerActivity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONTokener
import org.json.JSONObject
import android.util.Base64
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume

/** Runs one automation: starts at a trigger node and follows the connections. */
class FlowRunner(private val ctx: ToolCtx) {
    companion object {
        const val IDLE = 0
        const val RUNNING = 1
        const val OK = 2
        const val ERROR = 3

        /** last log of every automation (shown by the editor's Log button) */
        val logs = HashMap<String, List<String>>()

        /** steps that need no screen: an automation made only of these can run by itself in the background */
        private val headlessTypes = setOf(
            "manual", "keyword", "time", "event", "if", "delay", "text", "set", "json", "translate", "ai",
            "http", "search", "fetch", "wiki", "rss", "weather", "telegram", "email_send", "email_read", "blogger",
        )

        fun canHeadless(flow: Flow): Boolean = flow.nodes.all { n ->
            n.type in headlessTypes || (n.type == "tool" && Tools.get(n.cfg.optString("tool"))?.headless == true)
        }
    }

    private class Out(val ok: Boolean, val text: String, val port: Int = 0, val data: String? = null)

    private val lines = ArrayList<String>()
    private var steps = 0

    private fun say(s: String) { lines.add(s) }

    /** Returns true when every step worked. */
    suspend fun run(flow: Flow, startId: String, input: String, onState: (String, Int) -> Unit = { _, _ -> }): Boolean {
        lines.clear()
        steps = 0
        val vars = HashMap<String, String>()
        vars["input"] = input
        vars["last"] = input
        vars["data"] = ""
        vars["time"] = SimpleDateFormat("HH:mm", Locale.US).format(Date())
        vars["date"] = SimpleDateFormat("d MMM yyyy", Locale.US).format(Date())
        val start = flow.node(startId)
        if (start == null) {
            say("✖ Start node not found")
            logs[flow.id] = lines.toList()
            return false
        }
        say("⚡ " + flow.name)
        val ok = try {
            exec(flow, start, vars, onState)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            say("✖ " + (e.message ?: "Failed"))
            false
        }
        say(if (ok) "Done" else "Finished with errors")
        logs[flow.id] = lines.toList()
        return ok
    }

    private suspend fun exec(flow: Flow, node: FNode, vars: HashMap<String, String>, onState: (String, Int) -> Unit): Boolean {
        if (++steps > 100) { say("✖ Stopped: more than 100 steps (is there a loop?)"); return false }
        val spec = NodeSpecs.get(node.type)
        val title = spec?.title ?: node.type
        onState(node.id, RUNNING)
        say("▶ $title")
        val r = try {
            runNode(node, vars)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            Out(false, e.message ?: "Failed")
        }
        if (!r.ok) {
            onState(node.id, ERROR)
            say("   ✖ " + r.text)
            return false
        }
        onState(node.id, OK)
        if (r.text.isNotBlank()) say("   ✔ " + r.text.replace('\n', ' ').take(140))
        vars["last"] = r.text
        if (r.data != null) vars["data"] = r.data
        var all = true
        for (e in flow.edges.filter { it.from == node.id && it.port == r.port }) {
            val next = flow.node(e.to) ?: continue
            if (!exec(flow, next, vars, onState)) all = false
        }
        return all
    }

    private val tplRe = Regex("\\{\\{\\s*(\\w+)\\s*\\}\\}")
    private fun tpl(s: String, vars: Map<String, String>) = tplRe.replace(s) { vars[it.groupValues[1]] ?: "" }

    private suspend fun runNode(node: FNode, vars: HashMap<String, String>): Out {
        val c = node.cfg
        when (node.type) {
            "manual", "keyword", "time", "event" -> return Out(true, vars["input"] ?: "")

            "text" -> return Out(true, tpl(c.optString("text"), vars))

            "delay" -> {
                val s = c.optString("seconds", "5").toDoubleOrNull() ?: 5.0
                delay((s.coerceIn(0.0, 600.0) * 1000).toLong())
                return Out(true, vars["last"] ?: "")
            }

            "if" -> {
                val left = tpl(c.optString("left", "{{last}}"), vars)
                val right = tpl(c.optString("right"), vars)
                val yes = when (c.optString("op", "contains")) {
                    "contains" -> left.contains(right, ignoreCase = true)
                    "equals" -> left.trim().equals(right.trim(), ignoreCase = true)
                    "not_empty" -> left.isNotBlank()
                    "empty" -> left.isBlank()
                    "starts_with" -> left.trim().startsWith(right.trim(), ignoreCase = true)
                    "regex" -> try { Regex(right).containsMatchIn(left) } catch (e: Exception) { false }
                    "greater", "less" -> {
                        val a = num(left)
                        val b = num(right)
                        if (a == null || b == null) false
                        else if (c.optString("op") == "greater") a > b else a < b
                    }
                    else -> false
                }
                say("   " + (if (yes) "yes" else "no"))
                return Out(true, vars["last"] ?: "", if (yes) 0 else 1)
            }

            "translate" -> {
                val text = tpl(c.optString("text", "{{last}}"), vars)
                val to = c.optString("to", "en")
                val r = Lang.translate(ctx.ctx, text, "auto", to)
                return r.fold({ Out(true, it) }, { Out(false, it.message ?: "Could not translate") })
            }

            "ai" -> {
                val prompt = tpl(c.optString("prompt"), vars)
                if (prompt.isBlank()) return Out(false, "The prompt is empty")
                return Out(true, askModel(prompt))
            }

            "mini_app" -> {
                val id = c.optString("app")
                if (id.isEmpty()) return Out(false, "Choose a mini app first")
                RunnerActivity.startApp(ctx.act, id)
                return Out(true, "Opened the mini app")
            }

            "set" -> {
                val name = c.optString("name").trim().replace(Regex("[^A-Za-z0-9_]"), "_")
                if (name.isEmpty()) return Out(false, "Give the value a name")
                val v = tpl(c.optString("value", "{{last}}"), vars)
                vars[name] = v
                return Out(true, v)
            }

            "json" -> {
                val v = jsonPick(vars["last"] ?: "", c.optString("path").trim())
                    ?: return Out(false, "Path not found: " + c.optString("path"))
                return Out(true, v)
            }

            "http" -> {
                val url = tpl(c.optString("url"), vars).trim()
                if (url.isEmpty()) return Out(false, "The URL is empty")
                val headers = LinkedHashMap<String, String>()
                tpl(c.optString("headers"), vars).lines().forEach { l ->
                    val i = l.indexOf(':')
                    if (i > 0) headers[l.substring(0, i).trim()] = l.substring(i + 1).trim()
                }
                val user = tpl(c.optString("user"), vars)
                if (user.isNotEmpty()) {
                    headers["Authorization"] = "Basic " + Base64.encodeToString((user + ":" + tpl(c.optString("pass"), vars)).toByteArray(), Base64.NO_WRAP)
                }
                val body = tpl(c.optString("body"), vars).ifBlank { null }
                val method = c.optString("method", "GET")
                val r = withContext(Dispatchers.IO) { Net.request(method, url, headers, body) }
                vars["status"] = r.code.toString()
                if (r.code >= 400) return Out(false, "HTTP " + r.code + ": " + r.body.take(200))
                return Out(true, r.body.trim().take(20000))
            }

            "search" -> {
                val q = tpl(c.optString("query", "{{last}}"), vars).trim()
                if (q.isEmpty()) return Out(false, "Nothing to search for")
                val n = (c.optString("count", "5").toIntOrNull() ?: 5).coerceIn(1, 10)
                return Out(true, withContext(Dispatchers.IO) { Web.format(Web.search(q, n)) })
            }

            "fetch" -> {
                val u = tpl(c.optString("url", "{{last}}"), vars).trim()
                if (!u.startsWith("http")) return Out(false, "The link must start with http")
                val n = (c.optString("chars", "3000").toIntOrNull() ?: 3000).coerceIn(300, 20000)
                val page = withContext(Dispatchers.IO) { Web.readable(u, n) }
                vars["title"] = page.first
                return Out(true, page.second)
            }

            "wiki" -> {
                val news = c.optString("mode", "summary") == "news"
                val q = tpl(c.optString("query"), vars).trim()
                if (!news && q.isEmpty()) return Out(false, "Which topic?")
                return Out(true, withContext(Dispatchers.IO) { if (news) Web.wikiNews() else Web.wikiSummary(q) })
            }

            "rss" -> {
                val feed = tpl(c.optString("feed", "world"), vars).trim().ifEmpty { "world" }
                val n = (c.optString("count", "5").toIntOrNull() ?: 5).coerceIn(1, 20)
                return Out(true, withContext(Dispatchers.IO) { Web.rss(feed, n) })
            }

            "weather" -> {
                val city = tpl(c.optString("city"), vars).trim()
                if (city.isEmpty()) return Out(false, "Which city?")
                return Out(true, withContext(Dispatchers.IO) { Web.weather(city) })
            }

            "telegram" -> {
                val token = tpl(c.optString("token"), vars).trim()
                val chat = tpl(c.optString("chat"), vars).trim()
                val text = tpl(c.optString("text", "{{last}}"), vars)
                if (token.isEmpty() || chat.isEmpty()) return Out(false, "Set the bot token and the chat id")
                val form = "chat_id=" + URLEncoder.encode(chat, "UTF-8") + "&text=" + URLEncoder.encode(text.take(4000), "UTF-8")
                val r = withContext(Dispatchers.IO) {
                    Net.request("POST", "https://api.telegram.org/bot" + token + "/sendMessage", emptyMap(), form)
                }
                if (r.code >= 400) return Out(false, "Telegram: HTTP " + r.code + " " + r.body.take(160))
                return Out(true, "Message sent on Telegram")
            }

            "email_send", "blogger" -> {
                val m = Accounts.mail() ?: return Out(false, "Set your email account first: Automations > Email account")
                val to = tpl(c.optString("to"), vars).trim()
                val subject = tpl(c.optString(if (node.type == "blogger") "title" else "subject"), vars).trim()
                val body = tpl(c.optString("body"), vars)
                if (to.isEmpty()) return Out(false, "The email address is empty")
                val html = node.type == "blogger" || body.contains("<")
                withContext(Dispatchers.IO) { Smtp.send(m, to, subject.ifEmpty { "(no subject)" }, body, html) }
                return Out(true, if (node.type == "blogger") "Sent to Blogger (post by email)" else "Email sent to $to")
            }

            "email_read" -> {
                val m = Accounts.mail() ?: return Out(false, "Set your email account first: Automations > Email account")
                val n = (c.optString("count", "5").toIntOrNull() ?: 5).coerceIn(1, 20)
                val unread = c.optString("only", "unread") == "unread"
                return Out(true, withContext(Dispatchers.IO) { Imap.latest(m, n, unread) })
            }

            "tool" -> {
                val def = Tools.get(c.optString("tool")) ?: return Out(false, "Choose a tool first")
                if (!Tools.enabled(def.id)) return Out(false, def.title + " is switched off in Phone tools")
                val args = JSONObject()
                c.optJSONObject("args")?.let { a ->
                    a.keys().forEach { k ->
                        val v = tpl(a.optString(k), vars).trim()
                        if (v.isNotEmpty()) args.put(k, v)
                    }
                }
                val r = callTool(def, args)
                return Out(r.ok, r.text, 0, r.data ?: "")
            }
        }
        return Out(false, "Unknown step: " + node.type)
    }

    /** a.b.0.c style path into JSON text */
    private fun jsonPick(text: String, path: String): String? {
        var cur: Any? = try { JSONTokener(text.trim()).nextValue() } catch (e: Exception) { return null }
        if (path.isEmpty()) return cur?.toString()
        for (part in path.split('.')) {
            val node = cur
            cur = when (node) {
                is JSONObject -> if (node.has(part)) node.get(part) else return null
                is JSONArray -> {
                    val i = part.toIntOrNull() ?: return null
                    if (i in 0 until node.length()) node.get(i) else return null
                }
                else -> return null
            }
        }
        return if (cur == null || cur == JSONObject.NULL) "" else cur.toString()
    }

    private fun num(s: String): Double? =
        Regex("-?\\d+(\\.\\d+)?").find(s)?.value?.toDoubleOrNull()

    private suspend fun callTool(def: ToolDef, args: JSONObject): ToolResult = suspendCancellableCoroutine { cont ->
        ToolRunner.run(ctx, def, args, false) { r -> if (cont.isActive) cont.resume(r) }
    }

    /** One question to the offline model (English first, like the chat). Loads the last used model if needed. */
    private suspend fun askModel(prompt: String): String {
        val en = Lang.prepare(ctx.ctx, prompt).text
        if (Engine.loadedPath == null) {
            val f = Store.lastModel?.let { File(Store.modelsDir, it) }?.takeIf { it.exists() }
                ?: throw IllegalStateException("No model yet. Download one in the Library first.")
            say("   loading the model…")
            withContext(Dispatchers.Default) {
                Engine.load(ctx.ctx, f.absolutePath, "automation", "You are a helpful assistant inside a phone automation. Answer briefly.")
            }
        }
        val sb = StringBuilder()
        val thinks = Think.implicitOpen(Store.lastModel)
        Engine.send(ctx.ctx, en, if (thinks) maxOf(Store.maxTokens, 1536) else Store.maxTokens).collect { sb.append(it) }
        return Think.finish(sb.toString(), thinks)
    }
}
