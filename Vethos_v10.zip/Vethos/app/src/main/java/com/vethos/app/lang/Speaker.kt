package com.vethos.app.lang

import android.content.Context
import android.speech.tts.TextToSpeech
import com.vethos.app.data.Store
import java.util.Locale

/** Reads text aloud with the phone's own text-to-speech engine (offline when the voice is installed). */
object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: Pair<String, Locale>? = null

    private fun localeFor(text: String): Locale {
        for (ch in text) {
            val c = ch.code
            if (c in 0x0900..0x097F) return Locale("hi", "IN")
            if (c in 0x0600..0x06FF) return Locale("ur", "PK")
        }
        return Locale.US
    }

    private fun clean(s: String): String = s
        .replace(Regex("```[\\s\\S]*?```"), " code block ")
        .replace(Regex("[*_#`>|]"), "")
        .replace(Regex("\\s+"), " ")
        .trim()
        .take(3500)

    fun isSpeaking(): Boolean = try { tts?.isSpeaking == true } catch (_: Throwable) { false }

    fun stop() { try { tts?.stop() } catch (_: Throwable) { } }

    /** Starts reading; if it is already reading, stops instead. */
    fun toggle(ctx: Context, text: String) {
        if (isSpeaking()) { stop(); return }
        speak(ctx, text)
    }

    fun speak(ctx: Context, text: String) {
        val t = clean(text)
        if (t.isEmpty()) return
        val loc = localeFor(t)
        if (tts == null) {
            pending = t to loc
            tts = TextToSpeech(ctx.applicationContext) { st ->
                ready = st == TextToSpeech.SUCCESS
                val p = pending
                pending = null
                if (ready && p != null) say(p.first, p.second)
            }
            return
        }
        if (!ready) { pending = t to loc; return }
        say(t, loc)
    }

    private fun say(text: String, loc: Locale) {
        val e = tts ?: return
        val r = e.setLanguage(loc)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) e.setLanguage(Locale.getDefault())
        try { e.setSpeechRate(Store.ttsRate.coerceIn(0.5f, 2.0f)) } catch (_: Throwable) { }
        e.speak(text, TextToSpeech.QUEUE_FLUSH, null, "vethos")
    }
}
