package com.vethos.app.ui

import android.app.ActivityManager
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.fragment.app.Fragment
import com.vethos.app.data.Engine
import com.vethos.app.data.Store
import com.vethos.app.databinding.FragmentInsightsBinding
import com.vethos.app.databinding.ItemStatBinding

class InsightsFragment : Fragment() {
    private var _b: FragmentInsightsBinding? = null
    private val b get() = _b!!

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        FragmentInsightsBinding.inflate(i, c, false).also { _b = it }.root

    override fun onViewCreated(v: View, s: Bundle?) = wireMenu(b.btnMenu)

    override fun onResume() {
        super.onResume()
        val ctx = requireContext()
        val loaded = Engine.loadedPath != null
        b.engineSub.text = if (loaded) "Active & optimal" else "Idle · no model loaded"
        b.engineBadge.text = if (loaded) "● LIVE" else "IDLE"

        val tps = Store.lastTps
        b.tps.text = "%02d".format(tps.toInt())
        b.tpsBar.progress = (tps / 30f * 1000).toInt().coerceIn(0, 1000)

        val mem = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mem)
        val gb = (mem.totalMem / 1073741824.0).toInt().coerceAtLeast(1)
        val cores = Runtime.getRuntime().availableProcessors()
        val threads = if (Store.threads > 0) Store.threads else if (Store.multiThread) (cores / 2).coerceAtLeast(1) else 1
        val models = Store.models()

        b.row1.removeAllViews(); b.row2.removeAllViews(); b.row3.removeAllViews()
        stat(b.row1, "RAM (APPROX)", "≥ $gb GB", false)
        stat(b.row1, "CPU CORES", cores.toString(), true)
        stat(b.row2, "THREADS", threads.toString(), false)
        stat(b.row2, "MODE", if (Store.multiThread) "Multi-thread" else "Single-thread", true)
        stat(b.row3, "LOAD · 1ST TOKEN", if (Store.lastFirst > 0) "%.1f s".format(Store.lastFirst) else "–", false)
        stat(b.row3, "SAVED IN APP", fmtSize(models.sumOf { it.length() }), true)
    }

    private fun stat(parent: LinearLayout, label: String, value: String, second: Boolean) {
        val s = ItemStatBinding.inflate(layoutInflater, parent, false)
        s.label.text = label
        s.value.text = value
        (s.root.layoutParams as LinearLayout.LayoutParams).apply {
            if (second) marginStart = requireContext().dp(6) else marginEnd = requireContext().dp(6)
        }
        parent.addView(s.root)
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
