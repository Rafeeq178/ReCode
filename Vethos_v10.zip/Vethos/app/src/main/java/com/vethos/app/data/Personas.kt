package com.vethos.app.data

import android.graphics.Color
import com.vethos.app.R
import com.vethos.app.tools.Tools
import org.json.JSONArray
import org.json.JSONObject

/**
 * temp = creativity in tenths (0..10); tone / lang = "" means automatic;
 * tools = "" none, "*" all, or comma separated tool ids.
 */
data class Persona(
    val id: String, var name: String, var desc: String, var prompt: String, var ico: Int,
    var temp: Int = 5, var tone: String = "", var lang: String = "", var tools: String = "",
) {
    /** Tool ids this personality may use right now (also switched on in the Phone tools screen). */
    fun allowedTools(): Set<String> {
        val ids = if (tools == "*") Tools.all.map { it.id } else tools.split(',').map { it.trim() }.filter { it.isNotEmpty() }
        return ids.filter { Tools.get(it) != null && Tools.enabled(it) }.toSet()
    }
}

class PIcon(val res: Int, val tint: Int)

object Personas {
    val icons = listOf(
        PIcon(R.drawable.ic_chat, Color.parseColor("#0E9AA7")),
        PIcon(R.drawable.ic_code, Color.parseColor("#7C5CFA")),
        PIcon(R.drawable.ic_heart, Color.parseColor("#16A34A")),
        PIcon(R.drawable.ic_book, Color.parseColor("#C9623F")),
        PIcon(R.drawable.ic_hash, Color.parseColor("#C9623F")),
        PIcon(R.drawable.ic_dollar, Color.parseColor("#C9623F")),
        PIcon(R.drawable.ic_flask, Color.parseColor("#C9623F")),
        PIcon(R.drawable.ic_edit, Color.parseColor("#C9623F")),
    )

    private val prefs get() = Store.app.getSharedPreferences("vethos", 0)
    private var cache: MutableList<Persona>? = null

    private fun defaults() = mutableListOf(
        Persona("general", "General Assistant", "Everyday questions, ideas and planning",
            "You are Vethos, a helpful, concise assistant running offline on the user's phone. Answer everyday questions clearly and help with ideas and planning.", 0, 5, "", "", "*"),
        Persona("coder", "Coder", "Debugging, code and architecture",
            "You are an expert software engineer. Help with debugging, writing clean code and designing software. Give short explanations and put code in code blocks.", 1),
        Persona("doctor", "Doctor", "General health information",
            "You give general health information in simple words. You are not a doctor: remind the user to see a medical professional for diagnosis or emergencies.", 2),
        Persona("teacher", "Teacher", "Study help, notes and exam prep",
            "You are a patient teacher. Explain topics step by step, give simple examples, and help with notes and exam preparation.", 3),
        Persona("math", "Math Mentor", "Step-by-step problem solving",
            "You are a math mentor. Solve problems step by step, show your working, and check the answer at the end.", 4),
        Persona("finance", "Finance Pro", "Money, budgets and business basics",
            "You explain money, budgeting and business basics clearly. Give practical tips and mention that this is general information, not financial advice.", 5),
        Persona("research", "Research Pal", "Science and deep dives",
            "You are a curious research assistant. Explain science and complex topics in depth, in clear language, and say when you are unsure.", 6),
        Persona("writer", "Writer", "Writing, editing and rewriting",
            "You are a skilled writer and editor. Help write, rewrite and summarise text while keeping the user's tone.", 7),
    )

    fun all(): MutableList<Persona> {
        cache?.let { return it }
        val out = mutableListOf<Persona>()
        try {
            val raw = prefs.getString("personas", null)
            if (raw != null) {
                val a = JSONArray(raw)
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    out.add(fromJson(o, o.getString("id")))
                }
            }
        } catch (_: Exception) { out.clear() }
        if (out.isEmpty()) out.addAll(defaults())
        cache = out
        seed(out)
        seed10(out)
        return out
    }

    /** One-time upgrade for v4: add the Translator personality and let General Assistant use tools. */
    private fun seed(list: MutableList<Persona>) {
        if (prefs.getBoolean("seed_v4", false)) return
        list.firstOrNull { it.id == "general" }?.let { if (it.tools.isEmpty()) it.tools = "*" }
        prefs.edit().putBoolean("seed_v4", true).apply()
        save()
    }

    /** v10: the old Translator personality is removed together with the translator feature. */
    private fun seed10(list: MutableList<Persona>) {
        if (prefs.getBoolean("seed_v10", false)) return
        if (list.size > 1) list.removeAll { it.id == "translator" }
        prefs.edit().putBoolean("seed_v10", true).apply()
        save()
    }

    private fun fromJson(o: JSONObject, id: String) = Persona(
        id, o.optString("name", "Personality"), o.optString("desc"), o.optString("prompt"),
        o.optInt("ico", 0), o.optInt("temp", 5).coerceIn(0, 10),
        o.optString("tone"), o.optString("lang"), o.optString("tools"),
    )

    private fun toJson(p: Persona, withId: Boolean) = JSONObject().apply {
        if (withId) put("id", p.id)
        put("name", p.name); put("desc", p.desc); put("prompt", p.prompt); put("ico", p.ico)
        put("temp", p.temp); put("tone", p.tone); put("lang", p.lang); put("tools", p.tools)
    }

    fun get(id: String?): Persona? = if (id.isNullOrEmpty()) null else all().firstOrNull { it.id == id }

    var selectedId: String
        get() = prefs.getString("persona", "general")!!
        set(v) = prefs.edit().putString("persona", v).apply()

    fun current(): Persona = get(selectedId) ?: all().first()

    fun save() {
        val a = JSONArray()
        all().forEach { a.put(toJson(it, true)) }
        prefs.edit().putString("personas", a.toString()).apply()
    }

    private var counter = 0
    private fun newId() = "p" + System.currentTimeMillis() + "_" + (counter++)

    fun duplicate(p: Persona): Persona {
        val c = p.copy(id = newId(), name = p.name + " copy")
        val i = all().indexOfFirst { it.id == p.id }
        all().add(if (i >= 0) i + 1 else all().size, c)
        save()
        return c
    }

    // ---- JSON export / import ----
    fun exportJson(list: List<Persona>): String {
        val a = JSONArray()
        list.forEach { a.put(toJson(it, false)) }
        return JSONObject().put("vethos", "personalities").put("version", 1).put("items", a).toString(2)
    }

    /** Adds personalities from exported JSON (also accepts a bare array or a single object). Returns how many were new. */
    fun importJson(text: String): Int {
        val t = text.trim()
        val items = mutableListOf<JSONObject>()
        if (t.startsWith("[")) {
            val a = JSONArray(t)
            for (i in 0 until a.length()) items.add(a.getJSONObject(i))
        } else {
            val o = JSONObject(t)
            val a = o.optJSONArray("items")
            if (a != null) for (i in 0 until a.length()) items.add(a.getJSONObject(i)) else items.add(o)
        }
        var added = 0
        items.forEach { o ->
            if (o.optString("name").isBlank() || o.optString("prompt").isBlank()) return@forEach
            val p = fromJson(o, newId())
            if (all().any { it.name == p.name && it.prompt == p.prompt }) return@forEach
            all().add(p); added++
        }
        if (added > 0) save()
        return added
    }

    fun add(name: String, desc: String, prompt: String, temp: Int = 5, tone: String = "", lang: String = "", tools: String = ""): Persona {
        val p = Persona(newId(), name, desc, prompt, all().size % icons.size, temp, tone, lang, tools)
        all().add(p); save()
        return p
    }

    fun delete(id: String) {
        if (all().size <= 1) return
        all().removeAll { it.id == id }
        if (selectedId == id) selectedId = all().first().id
        save()
    }
}
