package com.vethos.app.net

import android.util.Base64
import java.io.BufferedInputStream
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

private fun b64(s: String) = Base64.encodeToString(s.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)

/** A small SMTP client (port 465 = SSL, 587 = STARTTLS). Gmail needs an "App password". */
object Smtp {
    fun send(m: Accounts.Mail, to: String, subject: String, body: String, html: Boolean) {
        Net.check()
        val recipients = to.split(',', ';', ' ').map { it.trim() }.filter { it.contains('@') }
        if (recipients.isEmpty()) throw IOException("The email address is missing")
        val factory = SSLSocketFactory.getDefault() as SSLSocketFactory
        var sock: Socket = if (m.smtpPort == 465) factory.createSocket(m.smtpHost, m.smtpPort) else Socket(m.smtpHost, m.smtpPort)
        sock.soTimeout = 25_000
        var r = BufferedReader(InputStreamReader(sock.getInputStream(), Charsets.ISO_8859_1))
        var w = BufferedWriter(OutputStreamWriter(sock.getOutputStream(), Charsets.ISO_8859_1))

        fun out(line: String) { w.write(line + "\r\n"); w.flush() }
        fun reply(): Pair<Int, String> {
            val sb = StringBuilder()
            var code = 0
            while (true) {
                val l = r.readLine() ?: throw IOException("The mail server closed the connection")
                sb.append(l).append('\n')
                code = l.take(3).toIntOrNull() ?: 0
                if (l.length < 4 || l[3] != '-') break
            }
            return code to sb.toString().trim()
        }
        fun expect(what: String, vararg ok: Int) {
            val (c, t) = reply()
            if (c !in ok) throw IOException("$what failed: $t")
        }

        try {
            expect("Connect", 220)
            out("EHLO vethos.app"); expect("EHLO", 250)
            if (m.smtpPort != 465) {
                out("STARTTLS"); expect("STARTTLS", 220)
                val ssl = factory.createSocket(sock, m.smtpHost, m.smtpPort, true) as SSLSocket
                ssl.soTimeout = 25_000
                ssl.startHandshake()
                sock = ssl
                r = BufferedReader(InputStreamReader(ssl.getInputStream(), Charsets.ISO_8859_1))
                w = BufferedWriter(OutputStreamWriter(ssl.getOutputStream(), Charsets.ISO_8859_1))
                out("EHLO vethos.app"); expect("EHLO", 250)
            }
            out("AUTH LOGIN"); expect("Login", 334)
            out(b64(m.address)); expect("Login", 334)
            out(b64(m.password)); expect("Login (wrong address or app password?)", 235)
            out("MAIL FROM:<" + m.address + ">"); expect("Sender", 250)
            for (rc in recipients) { out("RCPT TO:<$rc>"); expect("Recipient $rc", 250, 251) }
            out("DATA"); expect("DATA", 354)

            val date = SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss Z", Locale.US).format(Date())
            val from = if (m.name.isBlank()) m.address else "=?UTF-8?B?" + b64(m.name) + "?= <" + m.address + ">"
            val subj = if (subject.all { it.code < 128 }) subject else "=?UTF-8?B?" + b64(subject) + "?="
            val msg = StringBuilder()
            msg.append("From: ").append(from).append("\r\n")
            msg.append("To: ").append(recipients.joinToString(", ")).append("\r\n")
            msg.append("Subject: ").append(subj).append("\r\n")
            msg.append("Date: ").append(date).append("\r\n")
            msg.append("MIME-Version: 1.0\r\n")
            msg.append("Content-Type: ").append(if (html) "text/html" else "text/plain").append("; charset=UTF-8\r\n")
            msg.append("Content-Transfer-Encoding: base64\r\n\r\n")
            Base64.encodeToString(body.toByteArray(Charsets.UTF_8), Base64.NO_WRAP).chunked(76).forEach { msg.append(it).append("\r\n") }
            msg.append(".\r\n")
            w.write(msg.toString()); w.flush()
            expect("Sending", 250)
            try { out("QUIT") } catch (_: Exception) { }
        } finally {
            try { sock.close() } catch (_: Exception) { }
        }
    }
}

/** A small IMAP client (SSL, port 993) that only reads headers of the newest emails. */
object Imap {
    private fun decodeWords(s: String): String {
        val joined = s.replace(Regex("\\?=\\s+=\\?"), "?==?")   // neighbours are one word
        return Regex("=\\?([^?]+)\\?([bBqQ])\\?([^?]*)\\?=").replace(joined) { m ->
            val cs = try { charset(m.groupValues[1]) } catch (_: Exception) { Charsets.UTF_8 }
            try {
                if (m.groupValues[2].equals("b", true)) String(Base64.decode(m.groupValues[3], Base64.DEFAULT), cs)
                else {
                    val q = m.groupValues[3].replace('_', ' ')
                    val bytes = java.io.ByteArrayOutputStream()
                    var i = 0
                    while (i < q.length) {
                        if (q[i] == '=' && i + 2 < q.length + 1 && i + 3 <= q.length) {
                            bytes.write(q.substring(i + 1, i + 3).toInt(16)); i += 3
                        } else { bytes.write(q[i].code); i++ }
                    }
                    String(bytes.toByteArray(), cs)
                }
            } catch (_: Exception) { m.value }
        }
    }

    private fun quote(s: String) = "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\""

    /** Text list of the newest emails. [unreadOnly] = only the ones not read yet. */
    fun latest(m: Accounts.Mail, count: Int, unreadOnly: Boolean): String {
        Net.check()
        val sock = (SSLSocketFactory.getDefault() as SSLSocketFactory).createSocket(m.imapHost, m.imapPort)
        sock.soTimeout = 25_000
        val ins = BufferedInputStream(sock.getInputStream())
        val out = sock.getOutputStream()
        var tag = 0

        fun line(): String {
            val sb = StringBuilder()
            while (true) {
                val b = ins.read()
                if (b < 0) throw IOException("The mail server closed the connection")
                if (b == '\n'.code) break
                if (b != '\r'.code) sb.append(b.toChar())
            }
            return sb.toString()
        }

        fun cmd(c: String): List<String> {
            val t = "a" + (++tag)
            out.write("$t $c\r\n".toByteArray(Charsets.ISO_8859_1)); out.flush()
            val lines = ArrayList<String>()
            while (true) {
                var l = line()
                val lit = Regex("\\{(\\d+)\\}$").find(l)
                if (lit != null) {
                    val n = lit.groupValues[1].toInt()
                    val buf = ByteArray(n)
                    var got = 0
                    while (got < n) {
                        val k = ins.read(buf, got, n - got)
                        if (k < 0) break
                        got += k
                    }
                    l = l + "\n" + String(buf, 0, got, Charsets.ISO_8859_1)
                }
                if (l.startsWith("$t ")) {
                    if (!l.startsWith("$t OK")) throw IOException("Mail server: " + l.substringAfter(' '))
                    return lines
                }
                lines.add(l)
            }
        }

        try {
            line()   // greeting
            cmd("LOGIN " + quote(m.address) + " " + quote(m.password))
            cmd("EXAMINE INBOX")
            val found = cmd(if (unreadOnly) "SEARCH UNSEEN" else "SEARCH ALL")
                .firstOrNull { it.startsWith("* SEARCH") }?.removePrefix("* SEARCH")?.trim().orEmpty()
            val ids = found.split(' ').mapNotNull { it.toIntOrNull() }
            if (ids.isEmpty()) return if (unreadOnly) "No unread emails." else "The inbox is empty."
            val sb = StringBuilder()
            sb.append(if (unreadOnly) ids.size.toString() + " unread email(s). Newest:\n" else "Newest emails:\n")
            var n = 0
            for (id in ids.takeLast(count).reversed()) {
                val resp = cmd("FETCH $id (BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE)])").joinToString("\n")
                val unfolded = resp.replace(Regex("\r?\n[ \t]+"), " ")
                fun field(name: String) = Regex("(?im)^$name:\\s*(.*)$").find(unfolded)?.groupValues?.get(1)?.trim().orEmpty()
                n++
                sb.append(n).append(". From: ").append(decodeWords(field("From")))
                    .append("\n   Subject: ").append(decodeWords(field("Subject")))
                    .append("\n   ").append(field("Date")).append('\n')
            }
            return sb.toString().trim()
        } finally {
            try { cmd("LOGOUT") } catch (_: Exception) { }
            try { sock.close() } catch (_: Exception) { }
        }
    }
}
