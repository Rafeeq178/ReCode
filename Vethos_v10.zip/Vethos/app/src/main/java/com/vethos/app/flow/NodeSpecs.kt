package com.vethos.app.flow

import com.vethos.app.data.MiniApps
import com.vethos.app.lang.Lang
import org.json.JSONObject

enum class Kind { TEXT, MULTI, NUMBER, CHOICE, TIME, APP }

/** key = name in the node's settings; options = (value, label) pairs for CHOICE. */
class Field(
    val key: String,
    val label: String,
    val kind: Kind,
    val hint: String = "",
    val options: List<Pair<String, String>> = emptyList(),
    val def: String = "",
)

class NodeSpec(
    val type: String,
    val title: String,
    val group: String,
    val color: Int,
    val fields: List<Field>,
    val summary: (JSONObject) -> String,
    val outputs: Int = 1,
    val isTrigger: Boolean = false,
)

object NodeSpecs {
    const val TRIGGER = 0xFFE8A33D.toInt()
    const val LOGIC = 0xFF8E6FD8.toInt()
    const val ACTION = 0xFF3FA37A.toInt()
    const val AI = 0xFFC9623F.toInt()
    const val TEXTC = 0xFF3B82C4.toInt()
    const val NET = 0xFF2BA3B8.toInt()

    val events = listOf(
        "charging_on" to "Charger connected",
        "charging_off" to "Charger disconnected",
        "battery_low" to "Battery low",
        "wifi_on" to "Wi-Fi connected",
        "screen_on" to "Screen turned on",
    )

    val ops = listOf(
        "contains" to "contains", "equals" to "equals", "not_empty" to "is not empty", "empty" to "is empty",
        "greater" to "is greater than", "less" to "is less than",
        "starts_with" to "starts with", "regex" to "matches regex",
    )

    private fun cut(s: String, n: Int) = if (s.length > n) s.take(n) + "…" else s

    val all: List<NodeSpec> = listOf(
        NodeSpec("manual", "Manual start", "Triggers", TRIGGER, emptyList(), { "Starts with the ▶ button" }, isTrigger = true),
        NodeSpec("keyword", "Chat phrase", "Triggers", TRIGGER, listOf(
            Field("phrase", "When my chat message contains", Kind.TEXT, "e.g. torch on"),
            Field("model", "Also let the model answer?", Kind.CHOICE, "", listOf("no" to "No, only run this", "yes" to "Yes, answer too"), "no"),
        ), { "“" + it.optString("phrase") + "”" }, isTrigger = true),
        NodeSpec("time", "Time", "Triggers", TRIGGER, listOf(
            Field("mode", "Repeat", Kind.CHOICE, "", listOf("daily" to "Every day at a time", "interval" to "Every N minutes"), "daily"),
            Field("time", "Time of day", Kind.TIME, "", emptyList(), "07:00"),
            Field("every", "Every (minutes)", Kind.NUMBER, "15 or more is best", emptyList(), "30"),
        ), {
            if (it.optString("mode", "daily") == "daily") "Every day " + it.optString("time", "07:00")
            else "Every " + it.optString("every", "30") + " min"
        }, isTrigger = true),
        NodeSpec("event", "Phone event", "Triggers", TRIGGER, listOf(
            Field("event", "When", Kind.CHOICE, "", events, "charging_on"),
        ), { j -> events.firstOrNull { it.first == j.optString("event", "charging_on") }?.second ?: "Event" }, isTrigger = true),

        NodeSpec("if", "If", "Logic", LOGIC, listOf(
            Field("left", "Value", Kind.TEXT, "", emptyList(), "{{last}}"),
            Field("op", "Condition", Kind.CHOICE, "", ops, "contains"),
            Field("right", "Compare with", Kind.TEXT, "text or number"),
        ), { j ->
            cut(j.optString("left", "{{last}}") + " " + (ops.firstOrNull { it.first == j.optString("op", "contains") }?.second ?: "") + " " + j.optString("right"), 34)
        }, outputs = 2),
        NodeSpec("json", "Pick from JSON", "Logic", LOGIC, listOf(
            Field("path", "Path", Kind.TEXT, "e.g. items.0.title"),
        ), { cut(it.optString("path"), 34) }),
        NodeSpec("set", "Save value", "Logic", LOGIC, listOf(
            Field("name", "Name", Kind.TEXT, "then use {{name}} later"),
            Field("value", "Value", Kind.MULTI, "", emptyList(), "{{last}}"),
        ), { "{{" + it.optString("name") + "}}" }),
        NodeSpec("delay", "Wait", "Logic", LOGIC, listOf(
            Field("seconds", "Seconds", Kind.NUMBER, "", emptyList(), "5"),
        ), { "Wait " + it.optString("seconds", "5") + " s" }),

        NodeSpec("tool", "Phone tool", "Actions", ACTION, emptyList(), { j ->
            val t = com.vethos.app.tools.Tools.get(j.optString("tool"))
            if (t == null) "Choose a tool" else {
                val a = j.optJSONObject("args")
                val first = t.params.firstOrNull()?.let { a?.optString(it.key).orEmpty() }.orEmpty()
                cut(t.title + if (first.isNotBlank()) ": $first" else "", 34)
            }
        }),
        NodeSpec("ai", "Ask the model", "Actions", AI, listOf(
            Field("prompt", "Prompt", Kind.MULTI, "Variables: {{input}} {{last}} {{data}}", emptyList(), "Summarize this in one line: {{last}}"),
        ), { cut(it.optString("prompt"), 34) }),
        NodeSpec("translate", "Translate", "Actions", TEXTC, listOf(
            Field("text", "Text", Kind.TEXT, "", emptyList(), "{{last}}"),
            Field("to", "Translate to", Kind.CHOICE, "", listOf("en" to "English") + Lang.supported, "en"),
        ), { "→ " + Lang.name(it.optString("to", "en")) }),
        NodeSpec("text", "Set text", "Actions", TEXTC, listOf(
            Field("text", "Text", Kind.MULTI, "Variables: {{input}} {{last}} {{data}} {{time}}", emptyList(), "{{last}}"),
        ), { cut(it.optString("text"), 34) }),
        NodeSpec("mini_app", "Open mini app", "Actions", ACTION, listOf(
            Field("app", "Mini app", Kind.APP),
        ), { j -> MiniApps.get(j.optString("app"))?.name ?: "Choose a mini app" }),

        // ---------- internet ----------
        NodeSpec("http", "HTTP request", "Internet", NET, listOf(
            Field("method", "Method", Kind.CHOICE, "", listOf("GET" to "GET", "POST" to "POST", "PUT" to "PUT", "DELETE" to "DELETE"), "GET"),
            Field("url", "URL", Kind.TEXT, "https://..."),
            Field("headers", "Headers", Kind.MULTI, "one per line, e.g. Authorization: Bearer abc"),
            Field("body", "Body", Kind.MULTI, "JSON or text (for POST / PUT)"),
            Field("user", "User (basic login)", Kind.TEXT, "optional"),
            Field("pass", "Password (basic login)", Kind.TEXT, "optional"),
        ), { cut(it.optString("method", "GET") + " " + it.optString("url"), 34) }),
        NodeSpec("search", "Web search", "Internet", NET, listOf(
            Field("query", "Search for", Kind.TEXT, "", emptyList(), "{{last}}"),
            Field("count", "How many results", Kind.NUMBER, "", emptyList(), "5"),
        ), { cut(it.optString("query"), 34) }),
        NodeSpec("fetch", "Read web page", "Internet", NET, listOf(
            Field("url", "Link", Kind.TEXT, "", emptyList(), "{{last}}"),
            Field("chars", "How much text", Kind.NUMBER, "", emptyList(), "3000"),
        ), { cut(it.optString("url"), 34) }),
        NodeSpec("wiki", "Wikipedia", "Internet", NET, listOf(
            Field("mode", "What", Kind.CHOICE, "", listOf("summary" to "Summary of a topic", "news" to "Latest news (In the news)"), "summary"),
            Field("query", "Topic", Kind.TEXT, "for the summary"),
        ), { if (it.optString("mode", "summary") == "news") "Latest news" else cut(it.optString("query"), 34) }),
        NodeSpec("rss", "News / RSS", "Internet", NET, listOf(
            Field("feed", "Topic or feed link", Kind.TEXT, "world, pakistan, tech, business, sports, science, health, or a feed URL", emptyList(), "world"),
            Field("count", "How many items", Kind.NUMBER, "", emptyList(), "5"),
        ), { cut(it.optString("feed", "world"), 34) }),
        NodeSpec("weather", "Weather", "Internet", NET, listOf(
            Field("city", "City", Kind.TEXT, "e.g. Lahore"),
        ), { cut(it.optString("city"), 34) }),
        NodeSpec("telegram", "Telegram message", "Internet", NET, listOf(
            Field("token", "Bot token", Kind.TEXT, "from @BotFather"),
            Field("chat", "Chat id", Kind.TEXT, "number"),
            Field("text", "Message", Kind.MULTI, "", emptyList(), "{{last}}"),
        ), { cut(it.optString("text"), 34) }),

        // ---------- email ----------
        NodeSpec("email_send", "Send email", "Email", NET, listOf(
            Field("to", "To", Kind.TEXT, "name@example.com"),
            Field("subject", "Subject", Kind.TEXT),
            Field("body", "Message", Kind.MULTI, "", emptyList(), "{{last}}"),
        ), { cut("To " + it.optString("to"), 34) }),
        NodeSpec("email_read", "Read emails", "Email", NET, listOf(
            Field("only", "Which", Kind.CHOICE, "", listOf("unread" to "Only unread", "all" to "Newest of all"), "unread"),
            Field("count", "How many", Kind.NUMBER, "", emptyList(), "5"),
        ), { if (it.optString("only", "unread") == "unread") "Unread emails" else "Newest emails" }),
        NodeSpec("blogger", "Post to Blogger", "Email", NET, listOf(
            Field("to", "Blogger post-by-email address", Kind.TEXT, "from Blogger > Settings > Email"),
            Field("title", "Post title", Kind.TEXT, "", emptyList(), "My post"),
            Field("body", "Post (HTML or text)", Kind.MULTI, "", emptyList(), "{{last}}"),
        ), { cut(it.optString("title"), 34) }),
    )

    fun get(type: String): NodeSpec? = all.firstOrNull { it.type == type }

    /** Default settings for a new node. */
    fun defaults(type: String): JSONObject {
        val o = JSONObject()
        get(type)?.fields?.forEach { if (it.def.isNotEmpty()) o.put(it.key, it.def) }
        return o
    }
}
