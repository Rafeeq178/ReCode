package com.vethos.app.ui

import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.vethos.app.R
import com.vethos.app.data.Skill
import com.vethos.app.data.Skills
import com.vethos.app.databinding.ActivitySkillsBinding
import com.vethos.app.databinding.ItemToggleBinding

/** Skills = saved playbooks the assistant loads on demand (use_skill tool). Add, edit, switch off, import / export. */
class SkillsActivity : AppCompatActivity() {
    private lateinit var b: ActivitySkillsBinding
    private var pendingExport: String? = null

    private val exportFile = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val text = pendingExport
        pendingExport = null
        if (uri != null && text != null) {
            try {
                contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
                toast("Exported")
            } catch (e: Exception) { toast("Could not save the file") }
        }
    }

    private val importFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val text = contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
                val n = Skills.importJson(text)
                toast(if (n > 0) "Imported $n skill" + (if (n == 1) "" else "s") else "Nothing new to import")
                render()
            } catch (e: Exception) { toast("This is not a valid skills file") }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySkillsBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnBack.setOnClickListener { finish() }
        b.btnNew.setOnClickListener { edit(null) }
        b.btnImport.setOnClickListener { importFile.launch(arrayOf("application/json", "text/*", "*/*")) }
        b.btnExport.setOnClickListener { export(Skills.all()) }
        render()
    }

    private fun export(list: List<Skill>) {
        if (list.isEmpty()) { toast("No skills to export"); return }
        pendingExport = Skills.exportJson(list)
        exportFile.launch(if (list.size == 1) list[0].name + ".json" else "vethos_skills.json")
    }

    private fun render() {
        b.list.removeAllViews()
        val all = Skills.all()
        if (all.isEmpty()) {
            b.list.addView(TextView(this).apply {
                text = "No skills yet. Tap “New skill”."
                setTextColor(getColor(R.color.v_muted)); textSize = 15f
                setPadding(dp(6), dp(16), 0, 0)
            })
            return
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card)
        }
        all.forEachIndexed { idx, s ->
            val r = ItemToggleBinding.inflate(layoutInflater, card, false)
            r.icon.setImageResource(R.drawable.ic_book)
            r.icon.imageTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.v_blue))
            r.title.text = s.name
            r.sub.text = s.desc
            r.sub.visibility = if (s.desc.isBlank()) View.GONE else View.VISIBLE
            r.sw.isChecked = s.on
            r.sw.setOnCheckedChangeListener { _, v -> s.on = v; Skills.save() }
            r.root.setOnClickListener { edit(s) }
            r.root.setOnLongClickListener { menu(s); true }
            card.addView(r.root)
            if (idx < all.lastIndex) card.addView(View(this).apply {
                setBackgroundColor(getColor(R.color.v_line))
            }, LinearLayout.LayoutParams(-1, 1).apply { marginStart = dp(52); marginEnd = dp(16) })
        }
        b.list.addView(card)
    }

    private fun menu(s: Skill) {
        showSheet(s.name, listOf(
            SheetRow(R.drawable.ic_edit, "Edit") { edit(s) },
            SheetRow(R.drawable.ic_share, "Export as JSON") { export(listOf(s)) },
            SheetRow(R.drawable.ic_trash, "Delete") {
                confirm("Delete skill?", s.name, "Delete") { Skills.delete(s.id); render() }
            },
        ))
    }

    private fun edit(s: Skill?) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), 0)
        }
        val name = EditText(this).apply {
            hint = "Name, one word (e.g. research)"; setSingleLine(true); setText(s?.name ?: "")
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        }
        val desc = EditText(this).apply {
            hint = "When to use it (one line)"; setSingleLine(true); setText(s?.desc ?: "")
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        val body = EditText(this).apply {
            hint = "Steps, e.g.\n1. Call web_search with key words\n2. Call fetch_url on the best link\n3. Answer with the link"
            minLines = 6; maxLines = 12; gravity = Gravity.TOP; setText(s?.body ?: "")
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        box.addView(name)
        box.addView(desc, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        box.addView(body, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        val sv = ScrollView(this).apply { addView(box) }
        MaterialAlertDialogBuilder(this)
            .setTitle(if (s == null) "New skill" else "Edit skill")
            .setView(sv)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val n = name.text.toString().trim()
                val d = desc.text.toString().trim()
                val t = body.text.toString().trim()
                if (n.isEmpty() || t.isEmpty()) { toast("Give it a name and the steps"); return@setPositiveButton }
                if (s == null) Skills.add(n, d, t)
                else { s.name = Skills.slug(n); s.desc = d; s.body = t; Skills.save() }
                render()
            }.show()
    }
}
