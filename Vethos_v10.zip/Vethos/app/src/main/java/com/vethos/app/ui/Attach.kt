package com.vethos.app.ui

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.zip.ZipInputStream

/** Reads a picked file (text, code, .docx, PDF) so its content can be sent to the model with the question. */
object Attach {
    /** Offline models have a small context, so only the first part of a file is used. */
    const val MAX_CHARS = 6000
    private const val MAX_BYTES = 2_000_000

    class Picked(val name: String, val text: String, val truncated: Boolean)

    private val unsupported = setOf(
        "png", "jpg", "jpeg", "gif", "webp", "bmp", "heic", "mp3", "wav", "m4a", "mp4", "mkv", "avi",
        "zip", "rar", "7z", "apk", "gguf", "exe", "bin", "doc", "xls", "xlsx", "ppt", "pptx"
    )

    fun read(ctx: Context, uri: Uri): Picked {
        val r = ctx.contentResolver
        var name = "file"
        r.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) c.getString(i)?.let { name = it }
            }
        }
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext in unsupported) {
            throw IllegalArgumentException("Offline model can't read .$ext files. Use text, code, .docx or PDF files.")
        }
        val ins = r.openInputStream(uri) ?: throw IllegalArgumentException("Could not open this file")
        var full = ""
        var cut = false
        ins.use {
            if (ext == "docx") {
                full = readDocx(it)
            } else if (ext == "pdf") {
                full = com.vethos.app.tools.PdfText.extract(ctx, it)
            } else {
                val bytes = readCapped(it, MAX_BYTES)
                val head = minOf(bytes.size, 4096)
                for (k in 0 until head) {
                    if (bytes[k].toInt() == 0) throw IllegalArgumentException("This looks like a binary file, not text")
                }
                if (bytes.size >= MAX_BYTES) cut = true
                full = String(bytes, Charsets.UTF_8)
            }
        }
        val text = full.trim()
        if (text.isEmpty()) throw IllegalArgumentException("This file is empty")
        if (text.length > MAX_CHARS) cut = true
        val body = if (text.length > MAX_CHARS) text.substring(0, MAX_CHARS) + "\n...[file cut here]" else text
        return Picked(name, body, cut)
    }

    private fun readCapped(ins: InputStream, cap: Int): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(16 * 1024)
        var total = 0
        while (total < cap) {
            val n = ins.read(buf, 0, minOf(buf.size, cap - total))
            if (n < 0) break
            out.write(buf, 0, n)
            total += n
        }
        return out.toByteArray()
    }

    private fun readDocx(ins: InputStream): String {
        ZipInputStream(ins).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (e.name == "word/document.xml") {
                    val xml = String(readCapped(z, 8_000_000), Charsets.UTF_8)
                    return xml.replace("</w:p>", "\n").replace("<w:tab/>", "\t").replace("<w:br/>", "\n")
                        .replace(Regex("<[^>]+>"), "")
                        .replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
                        .replace("&apos;", "'").replace("&amp;", "&")
                }
                e = z.nextEntry
            }
        }
        throw IllegalArgumentException("Could not read this .docx file")
    }

    /** The text that goes to the model (and is saved in the chat). */
    fun wrap(p: Picked, question: String): String {
        val ask = question.ifBlank { "Summarize this file and point out any problems." }
        return "Attached file: ${p.name}\n<<<FILE\n${p.text}\nFILE>>>\n\n$ask"
    }

    private val shown = Regex("^Attached file: (.+)\n<<<FILE\n[\\s\\S]*?\nFILE>>>\n\n")

    /** What the user sees in the chat bubble: file name + their question, not the whole file. */
    fun display(t: String): String {
        val m = shown.find(t) ?: return t
        return "\uD83D\uDCCE " + m.groupValues[1] + "\n\n" + t.substring(m.range.last + 1)
    }
}
