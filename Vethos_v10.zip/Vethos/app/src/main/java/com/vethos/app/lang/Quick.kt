package com.vethos.app.lang

/** Slash commands typed in the chat box: /summarize, /hashtags, /title, /meaning, /translate, /help */
object Quick {
    class Cmd(val kind: String, val arg: String)

    private val aliases = mapOf(
        "summarize" to "summarize", "summary" to "summarize", "tldr" to "summarize",
        "hashtags" to "hashtags", "hashtag" to "hashtags", "tags" to "hashtags",
        "title" to "title", "titles" to "title",
        "meaning" to "meaning", "define" to "meaning", "dict" to "meaning", "word" to "meaning",
        "translate" to "translate", "tr" to "translate",
        "research" to "research", "investigate" to "research",
        "search" to "websearch", "web" to "websearch", "google" to "websearch",
        "help" to "help",
    )

    fun parse(text: String): Cmd? {
        val t = text.trim()
        if (!t.startsWith("/") || t.length < 2) return null
        val name = t.substring(1).substringBefore(' ').substringBefore('\n').lowercase()
        val kind = aliases[name] ?: return null
        val arg = t.substring(1 + name.length).trim()
        return Cmd(kind, arg)
    }

    /** The English instruction that is sent to the model; {text} is replaced by the (English) text. */
    fun template(kind: String): String = when (kind) {
        "summarize" -> "Summarize the following text in a few short bullet points.\n\n{text}"
        "hashtags" -> "Write one short title and 8 relevant hashtags for the following text.\n\n{text}"
        "title" -> "Write 5 short, catchy title options for the following text.\n\n{text}"
        "meaning" -> "Explain the meaning of this word or phrase in simple English. Give the meaning, one example sentence and two synonyms.\n\n{text}"
        else -> "{text}"
    }

    /** "/translate hindi good morning" -> ("hi", "good morning"); no language word -> English. */
    fun splitLang(arg: String): Pair<String, String> {
        val first = arg.substringBefore(' ').trim()
        val code = Lang.codeFor(first)
        return if (code != null && arg.contains(' ')) code to arg.substringAfter(' ').trim()
        else if (code != null) code to ""
        else "en" to arg
    }

    val helpText = "Quick commands\n" +
        "/summarize [text]\n/hashtags [text]\n/title [text]\n/meaning [word]\n/translate [language] [text]\n" +
        "/research [question]  (searches the web, reads pages, answers with sources)\n/search [words]  (web results)\n\n" +
        "Phone commands work in plain words too: torch on, volume kam karo, open whatsapp, weather in Lahore, news.\n\n" +
        "Leave the text empty to use what is on your clipboard. Write in any language: the model always gets English."
}
