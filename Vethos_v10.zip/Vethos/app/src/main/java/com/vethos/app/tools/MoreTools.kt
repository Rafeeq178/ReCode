package com.vethos.app.tools

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.PersistableBundle
import android.provider.MediaStore
import android.util.Base64
import android.widget.ImageView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import androidx.lifecycle.lifecycleScope
import com.vethos.app.R
import com.vethos.app.lang.Speaker
import kotlinx.coroutines.launch
import com.vethos.app.ui.Attach
import com.vethos.app.ui.MainActivity
import org.json.JSONObject
import java.net.URLDecoder
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom

/** Built-in tools: calculator, random/password, encode/hash, clipboard, QR, files, read aloud. */
object MoreTools {
    private fun ok(t: String, data: String? = null) = ToolResult(true, t, data)
    private fun bad(t: String) = ToolResult(false, t)

    fun build(): List<ToolDef> = listOf(
        ToolDef(
            id = "calc", title = "Calculator", icon = R.drawable.ic_dollar, sensitive = false,
            desc = "Calculate: + - * / ^ % ( ), sqrt, sin, log, pi, \"20% of 500\"",
            params = listOf(ToolParam("expression", "Expression", "e.g. (12+8)*3")),
            usage = """{"expression":"(12+8)*3"}""",
            run = { c, a, d -> calc(c, a, d) },
            headless = true,
        ),
        ToolDef(
            id = "random", title = "Random / password", icon = R.drawable.ic_regen, sensitive = false,
            desc = "Password, PIN, random number, dice or coin (password is copied)",
            params = listOf(
                ToolParam("kind", "password / pin / number / dice / coin", "default password", optional = true),
                ToolParam("length", "Length", "for password / pin", optional = true),
                ToolParam("min", "Min", "for number", optional = true),
                ToolParam("max", "Max", "for number", optional = true),
            ),
            usage = """{"kind":"password|pin|number|dice|coin","length":16,"min":1,"max":100}""",
            run = { c, a, d -> random(c, a, d) },
            headless = true,
        ),
        ToolDef(
            id = "encode", title = "Hash / Base64", icon = R.drawable.ic_hash, sensitive = false,
            desc = "Base64, URL, hex encode/decode and MD5 / SHA hashes",
            params = listOf(
                ToolParam("op", "Operation", "base64_encode, base64_decode, md5, sha1, sha256, sha512, url_encode, url_decode, hex_encode, hex_decode"),
                ToolParam("text", "Text"),
            ),
            usage = """{"op":"base64_encode|base64_decode|md5|sha1|sha256|sha512|url_encode|url_decode|hex_encode|hex_decode","text":"..."}""",
            run = { c, a, d -> encode(c, a, d) },
            headless = true,
        ),
        ToolDef(
            id = "clipboard", title = "Clipboard", icon = R.drawable.ic_copy, sensitive = false,
            desc = "Read the clipboard (asks first) or copy text to it",
            params = listOf(
                ToolParam("action", "read or write"),
                ToolParam("text", "Text to copy", "only for write", optional = true),
            ),
            usage = """{"action":"read|write","text":"text to copy"}""",
            run = { c, a, d -> clipboard(c, a, d) },
            askWhen = { a -> !isWrite(a) },
        ),
        ToolDef(
            id = "qr_make", title = "QR code maker", icon = R.drawable.ic_code, sensitive = false,
            desc = "Make a QR code from text or a link, shown on screen",
            params = listOf(ToolParam("text", "Text or link")),
            usage = """{"text":"text or link"}""",
            run = { c, a, d -> qrMake(c, a, d) },
        ),
        ToolDef(
            id = "qr_scan", title = "QR scanner", icon = R.drawable.ic_search, sensitive = false,
            desc = "Scan a QR code or barcode with the camera (works offline)",
            params = emptyList(),
            usage = "{}",
            run = { c, a, d -> qrScan(c, a, d) },
        ),
        ToolDef(
            id = "read_file", title = "Read file", icon = R.drawable.ic_clip, sensitive = false,
            desc = "Pick a text / code / .docx / PDF file and let the assistant read it",
            params = emptyList(),
            usage = "{}",
            run = { c, a, d -> readFile(c, a, d) },
        ),
        ToolDef(
            id = "write_file", title = "Save to file", icon = R.drawable.ic_dl, sensitive = false,
            desc = "Save text or code into a file (you choose where)",
            params = listOf(ToolParam("name", "File name", "e.g. notes.txt"), ToolParam("text", "Content")),
            usage = """{"name":"notes.txt","text":"content"}""",
            run = { c, a, d -> writeFile(c, a, d) },
        ),
        ToolDef(
            id = "speak", title = "Read aloud", icon = R.drawable.ic_mic, sensitive = false,
            desc = "Read a text aloud (phone text-to-speech)",
            params = listOf(ToolParam("text", "Text")),
            usage = """{"text":"text to read"}""",
            run = { c, a, d -> speak(c, a, d) },
            headless = true,
        ),
    )

    private fun argBool(a: JSONObject, key: String): Boolean? {
        if (!a.has(key) || a.isNull(key)) return null
        val v = a.opt(key)
        if (v is Boolean) return v
        return when (v.toString().trim().lowercase()) {
            "true", "on", "1", "yes", "haan", "ha", "chalu", "start" -> true
            "false", "off", "0", "no", "nahi", "band", "stop" -> false
            else -> null
        }
    }

    private fun firstArg(a: JSONObject, vararg keys: String): String {
        for (k in keys) {
            val v = a.optString(k).trim()
            if (v.isNotEmpty() && v != "null") return v
        }
        return ""
    }

    private fun isWrite(a: JSONObject): Boolean {
        val act = a.optString("action").trim().lowercase()
        return act in setOf("write", "copy", "set", "save")
    }

    // ---------- 73. calculator ----------
    private fun calc(c: ToolCtx, a: JSONObject, done: (ToolResult) -> Unit) {
        val raw = firstArg(a, "expression", "expr", "input", "text", "query")
        if (raw.isEmpty()) { done(bad("Give me something to calculate")); return }
        var e = raw.lowercase().replace("×", "*").replace("÷", "/").replace("**", "^")
            .replace(",", "").replace("=", "").replace("?", "").trim()
        e = Regex("""(\d+(?:\.\d+)?)\s*%\s*of\s*""").replace(e) { "(" + it.groupValues[1] + "/100)*" }
        e = Regex("""(?<=\d)\s*x\s*(?=\d)""").replace(e, "*")
        try {
            val v = Calc(e).parse()
            if (v.isNaN() || v.isInfinite()) { done(bad("Cannot calculate that (division by zero?)")); return }
            done(ok("$raw = " + fmt(v)))
        } catch (ex: Exception) {
            done(bad("Could not calculate: " + (ex.message ?: raw)))
        }
    }

    private fun fmt(v: Double): String {
        val bd = java.math.BigDecimal(v).round(java.math.MathContext(12)).stripTrailingZeros()
        return if (bd.scale() < -9 || bd.precision() - bd.scale() > 15) bd.toString() else bd.toPlainString()
    }

    /** Small safe expression parser: + - * / ^ mod, postfix %, parentheses, a few functions. */
    private class Calc(private val s: String) {
        private var i = 0

        fun parse(): Double {
            val v = expr()
            if (peek() != '\u0000') throw IllegalArgumentException("Unexpected '" + s[i] + "'")
            return v
        }

        private fun peek(): Char {
            while (i < s.length && s[i] == ' ') i++
            return if (i < s.length) s[i] else '\u0000'
        }

        private fun expr(): Double {
            var v = term()
            while (true) {
                val c = peek()
                if (c == '+') { i++; v += term() }
                else if (c == '-') { i++; v -= term() }
                else break
            }
            return v
        }

        private fun term(): Double {
            var v = unary()
            while (true) {
                val c = peek()
                if (c == '*') { i++; v *= unary() }
                else if (c == '/') { i++; v /= unary() }
                else if (c == '%') { i++; v %= unary() }   // only reached when % is followed by a number
                else break
            }
            return v
        }

        private fun unary(): Double {
            val c = peek()
            if (c == '-') { i++; return -unary() }
            if (c == '+') { i++; return unary() }
            return power()
        }

        private fun power(): Double {
            val base = postfix()
            if (peek() == '^') { i++; return Math.pow(base, unary()) }
            return base
        }

        private fun postfix(): Double {
            var v = primary()
            while (peek() == '%' && percentAhead()) { i++; v /= 100.0 }
            return v
        }

        /** "50%" is a percent sign, "10 % 3" is modulo (an operand follows). */
        private fun percentAhead(): Boolean {
            var j = i + 1
            while (j < s.length && s[j] == ' ') j++
            return !(j < s.length && (s[j].isLetterOrDigit() || s[j] == '(' || s[j] == '.'))
        }

        private fun primary(): Double {
            val c = peek()
            if (c == '(') {
                i++
                val v = expr()
                if (peek() != ')') throw IllegalArgumentException("Missing )")
                i++
                return v
            }
            if (c.isDigit() || c == '.') return number()
            if (c.isLetter()) {
                val st = i
                while (i < s.length && s[i].isLetter()) i++
                val name = s.substring(st, i)
                if (name == "pi") return Math.PI
                if (name == "e") return Math.E
                if (peek() != '(') throw IllegalArgumentException("Unknown word '$name'")
                i++
                val arg = expr()
                if (peek() != ')') throw IllegalArgumentException("Missing )")
                i++
                return fn(name, arg)
            }
            throw IllegalArgumentException("Unexpected input")
        }

        private fun number(): Double {
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (i + 1 < s.length && s[i] == 'e' &&
                (s[i + 1].isDigit() || ((s[i + 1] == '+' || s[i + 1] == '-') && i + 2 < s.length && s[i + 2].isDigit()))
            ) {
                i += 2
                while (i < s.length && s[i].isDigit()) i++
            }
            return s.substring(st, i).toDouble()
        }

        private fun fn(name: String, x: Double): Double = when (name) {
            "sqrt" -> Math.sqrt(x)
            "cbrt" -> Math.cbrt(x)
            "sin" -> Math.sin(x)
            "cos" -> Math.cos(x)
            "tan" -> Math.tan(x)
            "asin" -> Math.asin(x)
            "acos" -> Math.acos(x)
            "atan" -> Math.atan(x)
            "log" -> Math.log10(x)
            "ln" -> Math.log(x)
            "exp" -> Math.exp(x)
            "abs" -> Math.abs(x)
            "round" -> Math.rint(x)
            "floor" -> Math.floor(x)
            "ceil" -> Math.ceil(x)
            else -> throw IllegalArgumentException("Unknown function '$name'")
        }
    }

    // ---------- 79. random / password ----------
    private val rng = SecureRandom()

    private fun random(c: ToolCtx, a: JSONObject, done: (ToolResult) -> Unit) {
        val kind = a.optString("kind").trim().lowercase().ifEmpty { "password" }
        when {
            kind.startsWith("pass") -> {
                val n = a.optInt("length", 16).coerceIn(4, 64)
                val symbols = argBool(a, "symbols") ?: true
                val sets = mutableListOf("abcdefghijklmnopqrstuvwxyz", "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "0123456789")
                if (symbols) sets.add("!@#$%^&*()-_=+?")
                val all = sets.joinToString("")
                val chars = MutableList(n) { all[rng.nextInt(all.length)] }
                // make sure every kind of character is present
                sets.forEachIndexed { k, set -> if (k < n) chars[k] = set[rng.nextInt(set.length)] }
                chars.shuffle(rng)
                val pw = chars.joinToString("")
                copy(c, "password", pw, sensitive = true)
                done(ok("Password ($n characters): $pw\nCopied to the clipboard."))
            }
            kind.startsWith("pin") -> {
                val n = a.optInt("length", 4).coerceIn(3, 12)
                val pin = (1..n).joinToString("") { rng.nextInt(10).toString() }
                done(ok("PIN: $pin"))
            }
            kind.startsWith("dice") || kind.startsWith("die") -> done(ok("Dice: " + (rng.nextInt(6) + 1)))
            kind.startsWith("coin") -> done(ok("Coin: " + if (rng.nextBoolean()) "Heads" else "Tails"))
            else -> {
                var lo = a.optLong("min", 1)
                var hi = a.optLong("max", 100)
                if (lo > hi) { val t = lo; lo = hi; hi = t }
                val span = hi - lo + 1
                val v = lo + (rng.nextDouble() * span).toLong().coerceAtMost(span - 1)
                done(ok("Random number between $lo and $hi: $v"))
            }
        }
    }

    private fun copy(c: ToolCtx, label: String, text: String, sensitive: Boolean) {
        val cm = c.ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        if (sensitive && Build.VERSION.SDK_INT >= 33) {
            clip.description.extras = PersistableBundle().apply { putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true) }
        }
        cm.setPrimaryClip(clip)
    }

    // ---------- 80. hash / base64 ----------
    private fun encode(c: ToolCtx, a: JSONObject, done: (ToolResult) -> Unit) {
        val op = a.optString("op").lowercase().replace(Regex("[^a-z0-9]"), "")
        val text = firstArg(a, "text", "input", "data")
        if (text.isEmpty()) { done(bad("Give me the text")); return }
        fun digest(alg: String) = MessageDigest.getInstance(alg).digest(text.toByteArray())
            .joinToString("") { "%02x".format(it) }
        try {
            val out = when {
                op.contains("sha512") -> digest("SHA-512")
                op.contains("sha256") -> digest("SHA-256")
                op.contains("sha1") -> digest("SHA-1")
                op.contains("md5") -> digest("MD5")
                op.contains("base64") && op.contains("dec") ->
                    String(Base64.decode(text.trim(), Base64.DEFAULT), Charsets.UTF_8)
                op.contains("base64") -> Base64.encodeToString(text.toByteArray(), Base64.NO_WRAP)
                op.startsWith("url") && op.contains("dec") -> URLDecoder.decode(text, "UTF-8")
                op.startsWith("url") -> URLEncoder.encode(text, "UTF-8")
                op.startsWith("hex") && op.contains("dec") -> {
                    val h = text.replace(" ", "")
                    String(ByteArray(h.length / 2) { h.substring(it * 2, it * 2 + 2).toInt(16).toByte() }, Charsets.UTF_8)
                }
                op.startsWith("hex") -> text.toByteArray().joinToString("") { "%02x".format(it) }
                else -> {
                    done(bad("Unknown operation. Use base64_encode, base64_decode, md5, sha1, sha256, sha512, url_encode, url_decode, hex_encode or hex_decode."))
                    return
                }
            }
            done(ok(out.take(2000)))
        } catch (e: Exception) {
            done(bad("Could not convert: this text is not valid for that operation"))
        }
    }

    // ---------- 69. clipboard ----------
    private fun clipboard(c: ToolCtx, a: JSONObject, done: (ToolResult) -> Unit) {
        val cm = c.act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        if (isWrite(a)) {
            val text = firstArg(a, "text", "content", "value")
            if (text.isEmpty()) { done(bad("What should I copy?")); return }
            copy(c, "Vethos", text, sensitive = false)
            done(ok("Copied to the clipboard (${text.length} characters)"))
            return
        }
        val clip = cm.primaryClip
        val t = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(c.act).toString() else ""
        if (t.isBlank()) { done(bad("The clipboard is empty")); return }
        val shown = if (t.length > 300) t.take(300) + "…" else t
        done(ok("Clipboard (${t.length} characters): $shown", data = "Clipboard text:\n" + t.take(1500)))
    }

    // ---------- 71. QR maker ----------
    private fun qrMake(c: ToolCtx, a: JSONObject, done: (ToolResult) -> Unit) {
        val text = firstArg(a, "text", "url", "link", "data")
        if (text.isEmpty()) { done(bad("What should the QR code contain?")); return }
        val size = 768
        val bmp: Bitmap = try {
            val hints = mapOf<EncodeHintType, Any>(EncodeHintType.MARGIN to 1, EncodeHintType.CHARACTER_SET to "UTF-8")
            val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, hints)
            val px = IntArray(size * size)
            for (y in 0 until size) for (x in 0 until size) px[y * size + x] = if (m.get(x, y)) Color.BLACK else Color.WHITE
            Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888)
        } catch (e: Exception) {
            done(bad("This text is too long for a QR code"))
            return
        }
        val iv = ImageView(c.act).apply {
            setImageBitmap(bmp)
            setBackgroundColor(Color.WHITE)
            adjustViewBounds = true
            setPadding(24, 24, 24, 24)
        }
        MaterialAlertDialogBuilder(c.act)
            .setTitle("QR code")
            .setMessage(if (text.length > 80) text.take(80) + "…" else text)
            .setView(iv)
            .setNegativeButton("Close", null)
            .setPositiveButton("Save to gallery") { _, _ ->
                try {
                    val v = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, "vethos_qr_" + System.currentTimeMillis() + ".png")
                        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Vethos")
                    }
                    val uri = c.act.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
                    if (uri != null) c.act.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    android.widget.Toast.makeText(c.act, "Saved in Pictures/Vethos", android.widget.Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    android.widget.Toast.makeText(c.act, "Could not save", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
            .show()
        done(ok("QR code is on your screen (you can save it to the gallery)."))
    }

    // ---------- 72. QR scan ----------
    private fun qrScan(c: ToolCtx, a: JSONObject, done: (ToolResult) -> Unit) {
        c.launch.scan { text ->
            if (text.isNullOrEmpty()) done(bad("Scan cancelled"))
            else done(ok("Scanned: " + text.take(500), data = "Scanned QR/barcode text:\n" + text.take(1500)))
        }
    }

    // ---------- 59. read file ----------
    private fun readFile(c: ToolCtx, a: JSONObject, done: (ToolResult) -> Unit) {
        c.launch.pickFile { uri ->
            if (uri == null) { done(bad("No file chosen")); return@pickFile }
            // PDFs can take a moment, so read off the main thread
            Thread {
                val r = try {
                    val p = Attach.read(c.act, uri)
                    val note = if (p.text.length > 1500) " (the assistant gets the first 1500 characters)" else ""
                    ok("Read ${p.name}$note", data = "File ${p.name}:\n" + p.text.take(1500))
                } catch (e: Throwable) {
                    bad(e.message ?: "Could not read this file")
                }
                c.act.runOnUiThread { done(r) }
            }.start()
        }
    }

    // ---------- 55. text to speech ----------
    private fun speak(c: ToolCtx, a: JSONObject, done: (ToolResult) -> Unit) {
        val text = firstArg(a, "text", "message", "content")
        if (text.isEmpty()) { done(bad("What should I read?")); return }
        Speaker.speak(c.ctx, text)
        done(ok("Reading aloud…"))
    }

    // ---------- 60. write file ----------
    private fun writeFile(c: ToolCtx, a: JSONObject, done: (ToolResult) -> Unit) {
        val text = firstArg(a, "text", "content", "data", "code")
        if (text.isEmpty()) { done(bad("There is nothing to save")); return }
        val name = firstArg(a, "name", "filename", "file").replace(Regex("[\\/:*?\"<>|]"), "_").ifEmpty { "vethos_note.txt" }
        c.launch.saveText(name, text) { ok, msg ->
            done(if (ok) ToolResult(true, "Saved $msg (${text.length} characters)") else ToolResult(false, msg))
        }
    }
}
