package com.vethos.app.tools

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** A scope that lives as long as the app (for tools that must finish even if no screen is open). */
object AppScope {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
}
