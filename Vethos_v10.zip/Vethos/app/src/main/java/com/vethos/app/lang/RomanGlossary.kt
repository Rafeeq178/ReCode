package com.vethos.app.lang

/**
 * Built-in Roman Urdu / Hinglish -> English word list. Instant, fully offline, no download.
 * It is word by word (rough), so the model also receives the original text next to it.
 *
 * Format: variant,variant=english   (several words on the left make a phrase; empty right side = drop the word;
 * a leading ! marks a word that is also normal English, so it does not count when detecting Roman Urdu)
 */
object RomanGlossary {
    private val words = HashMap<String, String>()
    private val ambiguous = HashSet<String>()
    private val phrases = ArrayList<Pair<List<String>, String>>()

    private const val DATA = """
# ---- pronouns ----
!main,mai,mei,maiN=I
mein,meN=in
!me=in
maine,mene,maene=I
mujhe,mujhay,mujhy,mjhe,mje,mujhko,mjhko=me
mera,meri,mere,mra,mri,mre=my
hum,ham=we
hamara,hamari,hamare,humara,humari,humare=our
hamen,humein,hamein,humen=us
tum,tm=you
tumhara,tumhari,tumhare,tumhain,tera,teri,tere=your
tumhe,tumhen,tujhe,tujhay=you
!tu=you
aap,ap=you
aapka,aapki,aapke,apka,apki,apke=your
aapko,apko=you
wo,woh,vo,voh=that
ye,yeh,yah,yei=this
!is=this
!us=that
isko,isay,isse,isy=this
usko,usay,usse,usy=that
iska,iski,iske=its
uska,uski,uske=his/her
unka,unki,unke,inka,inki,inke=their
unhe,unhen,unko,inhe,inhen,inko=them
khud=self
apna,apni,apne=own
koi=any
kuch=some
sab=all
saara,saari,sare=all
dono=both
# ---- question words ----
kya,kia,kyaa=what
kyun,kyu,kyon,kiyun=why
kyunke,kyunki,kiunke,kiunki=because
kaise,kese,kaisay,kesay,kaisi,kaisa=how
kahan,kahaan,kidhar,kidr=where
kab=when
kitna,kitni,kitne,ktna,ktni=how much
kaun,kon=who
kaunsa,konsa,kaunsi,konsi,kaunse,konse=which
kis=which
kisne=who
kisko=whom
kis liye,kisliye,kisliay=why
# ---- verbs: do / make / give / take ----
kar,kr,karo,kro,kijiye,kijye,kare,karen,karein=do
karna,krna,karni,krni,karne,krne=to do
kiya,kiye=did
karta,karti,karte,krta,krti,krte=does
karunga,karungi,krunga,krungi=will do
kar do,kr do,kar dein,kar den,kar dena,kar dijiye=do
kar sakta,kar sakti,kar sakte,kr skta,kr skti,kr skte,kar skta,kar skte=can do
kar sakte ho,kar skte ho,kar sakti ho,kar sakta hai=can you
kar raha,kar rahi,kar rahe,kr rha,kr rhi,kr rhe=doing
kya kar rahe ho,kya kar raha hai,kya kr rhe ho,kya kar rahi ho=what are you doing
banao,bnao,bana,banana,bnana,banaye,banaen=make
bana do,bnao,bana den,bana dein,bna do=make
de,dena,dijiye,dijye,dedo,de do,de dein=give
!do=do
le,!lo,lena,leejiye,lelo,le lo=take
liya,li,liye,liay=took
diya,di,diye,dia=gave
# ---- verbs: movement / senses ----
ja,jao,jana,jaana,jaiye,jaye=go
gaya,gayi,gaye,gya,gyi,gye=went
aa,aao,aana,aaiye,aaye=come
aaya,aayi,aya,ayi=came
dekh,dekho,dekhna,dekhiye,dekhein=look
dekha,dekhi,dekhe=saw
!sun,suno,sunna,suniye=listen
suna,suni,sune=heard
sunao,suna do,suna den=tell me
bol,bolo,bolna,boliye=say
bola,boli,bole=said
kaho,kehna,kehte,kehta,kehti,kahiye=say
kaha,kahi=said
bata,batao,batana,bataiye,bataen,btao,bta,btana=tell
bata do,bta do,bata dein,bata den,batado=tell
bataya,batayi=told
puch,pucho,puchna,puchiye=ask
pucha,puchi=asked
likh,likho,likhna,likhiye,likhein=write
likh do,likh den,likh dein=write
likha,likhi,likhe=wrote
parh,padh,parho,padho,parhna,padhna,parhiye=read
parh do,padh do,parh dein,padh dein=read
parha,padha,parhi,padhi=read
samajh,samjho,samajhna,samajhiye,samjh=understand
samajh aya,samajh aaya,samajh ayi,samajh aayi=understood
samjha,samjhi=understood
samjhao,samjhana,samjhaiye,smjhao=explain
samjha do,samjha den,samjha dein,smjha do=explain
sikh,seekh,sikho,seekho,sikhna,seekhna=learn
sikhao,seekhao,sikhana=teach
chal,chalo,chalna,chaliye=go
chalte hain,chalte hain,chalen,chalein=let's go
chalao,chala,chalana,chalaiye=run
ruk,ruko,rukna,rukiye=stop
roko,rok,rokna=stop
khol,kholo,kholna,kholiye=open
khol do,khol den,khol dein=open
khola,kholi=opened
band,bnd=off
band karo,band kro,band kar do,band kr do,bnd karo,band kar den=turn off
chalu karo,chalu kro,chalu kar do,chalu kr do,on karo,on kro,on kar do,on kr do=turn on
off karo,off kro,off kar do,off kr do=turn off
start karo,start kro,shuru karo,shuru kro,shuru kar do=start
stop karo,stop kro=stop
chalu,chaloo=on
shuru=start
khatam=finish
pura,poora,pora=complete
bhej,bhejo,bhejna,bhejiye=send
bhej do,bhej den,bhej dein=send
bheja,bheji,bheje=sent
dikha,dikhao,dikhana,dikhaiye=show
dikha do,dikha den,dikha dein=show
dikhao mujhe=show me
mujhe dikhao,mujhe dikha do=show me
mujhe batao,mujhe bata do,mujhe btao=tell me
mujhe chahiye,mujhe chahie,mjhe chahiye=I need
mujhe pata hai,mjhe pata hai=I know
mujhe pata nahi,mujhe nahi pata,mjhe nahi pata,mujhe pta nhi=I don't know
mujhe samajh nahi aya,mujhe samajh nahi aaya,samajh nahi aa raha,mujhe samajh nahi aa raha=I don't understand
dhoond,dhundo,dhoondo,dhoondna,dhundna,talash,dhund=search
talash karo,dhoondo,dhundo=search
mil,milna,miliye=get
mila,mili,mile=got
khana,khaana=food
khaya,khayi=ate
kha,khao,khaiye=eat
!pi,pio,pina,peena=drink
piya=drank
sona=sleep
soya,soyi=slept
uth,utho,uthna=get up
uthao,uthana=pick up
baith,baitho,baithna=sit
rakh,rakho,rakhna,rakhiye=keep
rakha,rakhi=kept
hata,hatao,hatana,hatado,hata do=remove
mita,mitao,mitana,mita do,mitado=delete
jodo,jodna,jod do,jorna=add
ghatao,ghatana=reduce
badlo,badal,badalna,badal do,badlen=change
dalo,daalo,dal,dalna,daal do=put
nikalo,nikal,nikalna,nikal do=take out
yaad,yad=memory
yaad dilao,yaad dila do,yaad dilana,yad dilao=remind me
yaad hai,yad hai=remember
yaad nahi,yad nahi=don't remember
yaad rakho=remember
chahiye,chahie,chahiyen,chahye=need
chahta,chahti,chahte,chahta hoon,chahti hoon,chahta hun=want
sakta,sakti,sakte,skta,skti,skte,sakta hoon,sakti hoon=can
pata,pta=know
maloom,malum=known
janta,jante,janti,jaanta,jaanti=know
ho sakta hai,ho skta hai=possible
ho jayega,ho jaega,ho jaye ga=will be done
ho gaya,ho gya,ho gayi,ho gai=done
ho=be
hu,hoon=
hoga,hogi,honge=will be
hota,hoti,hote=usually
hua,hui,hue,hwa=happened
tha,thi,thay=was
hai,hain,hy,h,hein=
raha,rahi,rahe,rha,rhi,rhe=
kya ho raha hai,kya ho rha hai=what is happening
kya chal raha hai,kya chal rha hai=what is going on
kya hal hai,kya haal hai,kese ho,kaise ho,kaisay ho,kya haal,aap kaise hain,aap kese hain=how are you
theek hai,thik hai,theek he,thk hai,thik h=okay
theek nahi,thik nahi=not okay
theek,thik,thk=fine
theek karo,thik karo,theek kar do,thik kar do=fix
set karo,set kro,set kar do=set
laga,lagao,lagana,laga do,laga den,laga dein,lga do=set
sikha,sikhaye,sikhaen,sikha do,sikha den=teach
sa,si=
# ---- numbers ----
ek=one
teen=three
char=four
paanch,panch=five
saat=seven
aath=eight
nau=nine
das,dus=ten
sau=hundred
hazaar,hazar=thousand
lakh=hundred thousand
# ---- connectors / particles ----
ka,ki,ke=of
ko=to
se,sy=from
ne=
!par,pe=on
!per=on
tak=until
mein se=from
ke liye,k liye,ke lye,k lye,kay liye=for
liye,lie,lye=for
ke baad,k baad,kay baad=after
se pehle,se pahle,sy pehle=before
ke bina,k bina=without
ke saath,k sath,k saath,ke sath=with
ke bare mein,ke baare mein,ke bare me,ke baray mein,k bare me=about
ki tarah,ki trah=like
jaisa,jaisi,jaise=like
sath,saath=with
bina=without
baad=after
pehle,pahle,pehly=before
phir,fir,phr=then
phir se,fir se=again
dobara,dubara,dobarah=again
bar bar,baar baar=repeatedly
ek baar,ek bar=once
do baar,do bar=twice
pehli baar,pehli bar=first time
!to=then
aur,or,aor=and
!or=and
ya,ya phir=or
lekin,magar,lkn,mgr=but
agar,agr=if
isliye,is liye,isi liye=so
jab=when
tab=then
jab tak=until
jahan,jaha=where
jitna,jitni,jitne=as much as
sirf,srf,sirf=only
bhi,bh=also
abhi bhi=still
bas,bs=just
hi,hee=
!hi=
!na=
nahi,nahin,nai,nhi,nh,nahiin=not
nahi karo,nahi kro,mat karo,mat kro,mat=don't
haan,han,!ha,jee,ji,ji haan,jee haan,haa=yes
zaroor,zarur,zaror=sure
shayad,shyd=maybe
pakka=sure
bilkul,bilkl=exactly
bohat,bahut,boht,bhot,bohut,bht=very
bohat acha,bahut acha,bohat achi,bahut achi,boht acha=very good
bahut zyada,bohat zyada=too much
thora,thoda,thori,thodi=a little
thora sa,thoda sa,thori si,thodi si=a little
thori der,thodi der=a little while
ek minute,ek min=one minute
zara,zra=please
zyada,ziada,zyadah,ziyada=more
kam=less
mazeed,mazid=more
kuch aur,kuch or=something else
aur batao,or batao,aur btao=tell me more
thora aur,thoda aur,thoda or=a bit more
kuch nahi,kuch nhi=nothing
kuch bhi=anything
sab kuch=everything
koi nahi,koi nhi=nobody
kahin nahi,kahin nhi=nowhere
kahin=somewhere
abhi nahi,abhi nhi=not now
kabhi nahi,kabhi nhi=never
kabhi=sometimes
hamesha,humesha,hmesha=always
roz,rooz,rozana=daily
har roz,har din,hr roz,roz roz=every day
roz subah,har subah=every morning
roz shaam,har shaam=every evening
roz raat,har raat=every night
har=every
jaldi,jldi,jaldi se=quickly
dheere,dhere,aahista=slowly
# ---- time ----
abhi,abi=now
ab=now
is waqt,is wqt,iss waqt=right now
abhi ke abhi=right now
ab tak=until now
aaj,aj=today
aaj ka,aj ka=today's
aaj kal,aj kal=these days
kal=tomorrow/yesterday
kal ka,kal ki=tomorrow's
parson,parso=the day after tomorrow
din=day
raat,rat=night
subah,subha,subh=morning
dopahar,dopehar=afternoon
shaam,sham=evening
waqt,waqat,wqt,samay=time
kitne baje,kitne bje=what time
kitna waqt,kitna wqt=how much time
kitni der=how long
baje,bje=o'clock
hafta,haftay,hafte=week
mahina,mahine,maheena=month
saal,sal=year
ghanta,ghante,ghanta=hour
!min=minute
# ---- places / things / people ----
ghar=home
dukan,dukaan=shop
jagah=place
raasta,rasta=route
shehar,sheher=city
gaari,gadi,gari=car
paisa,paise,rupay,rupaye,rupee,rupees=money
dost=friend
bhai=brother
behan,bahen,bhen=sister
ammi,ami,maa=mother
abbu,abu,baap=father
bachcha,bacha,bachay,bache,bachchay=child
insaan,insan=person
!log=people
aadmi,admi=man
aurat=woman
larka,ladka=boy
larki,ladki=girl
mausam=weather
pani=water
chai=tea
roti=bread
khabar,khabrein,khabren,khabrain=news
sawal,swal=question
jawab,jawaab,jawb=answer
matlab,mtlb=meaning
iska matlab kya hai,is ka matlab kya hai,iska mtlb kya hai,iska matlab kya=what does this mean
matlab kya hai,mtlb kya hai=what does it mean
lafz,lafaz,alfaz=word
kahani,kahaani=story
kitab,kitaab=book
tasveer,tasvir=picture
awaaz,awaz,aawaz=voice
gaana,gana,gane,gaane=song
zubaan,zabaan,zaban,zuban,bhasha=language
baat,baatein,baten=talk
kaam,kam kaam=work
cheez,chiz,cheezen=thing
naam,nam=name
masla,masla,maslay,masail=problem
hal=solution
tareeqa,tariqa,tarika=method
wajah,waja=reason
madad,madat=help
zaroorat,zarurat=need
mushkil,mushkill=difficult
asan,aasan,asaan=easy
sach=truth
jhoot,jhut=lie
khulasa,khulasah=summary
mukhtasar,mukhtsar=brief
short mein,short me=in short
tarjuma,tarjama,trjuma=translation
tarjuma karo,tarjuma kro,tarjuma kar do=translate
translate karo,translate kro,translate kar do=translate
english mein,english me=in English
urdu mein,urdu me=in Urdu
hindi mein,hindi me=in Hindi
roman urdu mein,roman urdu me=in Roman Urdu
# ---- adjectives ----
acha,accha,achha,achi,achay,ache,achcha=good
bura,buri,bure=bad
bara,bada,badi,bade,barhi,bari,barey=big
chota,chhota,choti,chhoti,chote=small
naya,nayi,naye,nai=new
purana,purani,purane=old
lamba,lambi,lambe=long
tez=fast
sust=slow
garam=hot
thanda,thandi=cold
saaf,saf=clean
ganda,gandi=dirty
sasta,sasti=cheap
mehnga,mehngi,mahnga=expensive
khali=empty
bhara,bhari=full
sahi,sahih=correct
galat,ghalat=wrong
# ---- places in space ----
yahan,yaha=here
wahan,waha=there
idhar=here
udhar=there
andar=inside
bahar=outside
upar=above
neeche,niche=below
saamne,samne=in front
peeche,pichhe=behind
qareeb,kareeb=near
door,dur=far
# ---- greetings and politeness ----
salam,salaam,assalam o alaikum,assalamualaikum,asalam o alaikum,assalamu alaikum=hello
khuda hafiz,allah hafiz,khudahafiz=goodbye
shukriya,shukria,meherbani,mehrbani,shukriyah=thank you
maaf karna,maaf kijiye,maafi=sorry
meherbani karke,mehrbani karke,plz,plzz,pls=please
# ---- phone / tech words people write in Roman Urdu ----
torch,tourch=flashlight
roshni=light
awaz kam,awaaz kam,awaz kam karo=volume down
awaz zyada,awaaz zyada,awaz barhao,awaz badhao=volume up
awaz band,awaaz band=mute
kitni battery,battery kitni,battery kitni hai=how much battery
battery ki halat=battery status
halat=condition
zaroori=important
dobara karo,dobara kro=do it again
koshish,koshish karo=try
tarjumani=translation
call karo,call kro,call kar do=call
message karo,msg karo,message kro=send a message
"""

    init {
        DATA.lines().forEach { raw ->
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#") || !line.contains('=')) return@forEach
            val left = line.substringBefore('=')
            val right = line.substringAfter('=').trim()
            left.split(',').forEach { v0 ->
                var v = v0.trim().lowercase()
                var amb = false
                if (v.startsWith("!")) { amb = true; v = v.substring(1) }
                if (v.isEmpty()) return@forEach
                if (v.contains(' ')) {
                    phrases.add(v.split(' ').filter { it.isNotEmpty() } to right)
                } else {
                    words[v] = right
                    if (amb) ambiguous.add(v)
                }
            }
        }
        phrases.sortByDescending { it.first.size }
    }

    private val wordRe = Regex("[A-Za-z0-9']+")

    private fun tokens(text: String): List<String> = wordRe.findAll(text).map { it.value.lowercase() }.toList()

    /** True when the text looks like Roman Urdu / Hinglish written in English letters. */
    fun isRoman(text: String): Boolean {
        val t = tokens(text)
        if (t.isEmpty()) return false
        val hits = t.count { it in words && it !in ambiguous }
        val phraseHit = phrases.any { p -> containsPhrase(t, p.first) && p.first.any { it !in ambiguous && it in words } }
        if (hits >= 3) return true
        return hits >= 1 && (hits.toFloat() / t.size >= 0.3f || phraseHit)
    }

    private fun containsPhrase(t: List<String>, p: List<String>): Boolean {
        if (p.size > t.size) return false
        for (i in 0..t.size - p.size) {
            var ok = true
            for (j in p.indices) if (t[i + j] != p[j]) { ok = false; break }
            if (ok) return true
        }
        return false
    }

    private class Part(val word: Boolean, val text: String)

    fun toEnglish(text: String): String {
        // split into words and the separators between them
        val parts = ArrayList<Part>()
        var last = 0
        for (m in wordRe.findAll(text)) {
            if (m.range.first > last) parts.add(Part(false, text.substring(last, m.range.first)))
            parts.add(Part(true, m.value))
            last = m.range.last + 1
        }
        if (last < text.length) parts.add(Part(false, text.substring(last)))

        val out = StringBuilder()
        var i = 0
        while (i < parts.size) {
            val p = parts[i]
            if (!p.word) { out.append(p.text); i++; continue }
            // longest phrase first (words separated only by spaces)
            var matched = false
            for ((ph, en) in phrases) {
                var k = i
                var ok = true
                for ((n, w) in ph.withIndex()) {
                    if (k >= parts.size || !parts[k].word || parts[k].text.lowercase() != w) { ok = false; break }
                    if (n < ph.size - 1) {
                        val sep = parts.getOrNull(k + 1)
                        if (sep == null || sep.word || sep.text.isBlank().not()) { ok = false; break }
                        k += 2
                    }
                }
                if (ok) {
                    if (en.isNotEmpty()) out.append(en) else dropTrailingSpace(out)
                    i = k + 1
                    matched = true
                    break
                }
            }
            if (matched) continue
            val en = words[p.text.lowercase()]
            when {
                en == null -> out.append(p.text)
                en.isEmpty() -> dropTrailingSpace(out)
                else -> out.append(en)
            }
            i++
        }
        return out.toString().replace(Regex("[ \t]{2,}"), " ").replace(Regex(" +([,.!?])"), "$1").trim()
            .replaceFirstChar { it.uppercase() }
    }

    private fun dropTrailingSpace(sb: StringBuilder) {
        // a dropped word leaves its neighbours' spaces: remove one of them later (handled by the double-space cleanup)
    }
}
