package com.vethos.app.net

import com.vethos.app.data.Store
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.Charset

/** The one place the app talks to the internet (plain HttpURLConnection). Blocked completely by "Offline mode". */
object Net {
    class OfflineException : IOException("Offline mode is on. Switch it off in Settings to use the internet.")
    class Resp(val code: Int, val body: String, val url: String)

    const val UA = "Mozilla/5.0 (Linux; Android 12; Vethos) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"

    fun check() {
        if (Store.offlineMode) throw OfflineException()
    }

    /** Blocking: call it from a background thread. Follows redirects. */
    fun request(
        method: String,
        url: String,
        headers: Map<String, String> = emptyMap(),
        body: String? = null,
        maxBytes: Int = 2_000_000,
        timeoutMs: Int = 20_000,
    ): Resp {
        check()
        var current = url
        var m = method.uppercase()
        var payload = body
        for (hop in 0..5) {
            val u = URL(current)
            if (u.protocol != "https" && u.protocol != "http") throw IOException("Only http and https links work")
            val c = u.openConnection() as HttpURLConnection
            try {
                c.instanceFollowRedirects = false
                c.connectTimeout = timeoutMs
                c.readTimeout = timeoutMs
                c.requestMethod = m
                c.setRequestProperty("User-Agent", UA)
                headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
                if (payload != null && m != "GET" && m != "HEAD") {
                    val bytes = payload.toByteArray(Charsets.UTF_8)
                    if (c.getRequestProperty("Content-Type") == null) {
                        val t = payload.trimStart()
                        c.setRequestProperty("Content-Type", if (t.startsWith("{") || t.startsWith("[")) "application/json" else "application/x-www-form-urlencoded")
                    }
                    c.doOutput = true
                    c.outputStream.use { it.write(bytes) }
                }
                val code = c.responseCode
                if (code in 301..308 && code != 304) {
                    val loc = c.getHeaderField("Location")
                    if (loc != null) {
                        current = URL(u, loc).toString()
                        if (code in 301..303) { m = "GET"; payload = null }
                        continue
                    }
                }
                val stream = if (code >= 400) c.errorStream else c.inputStream
                val text = if (stream == null) "" else read(stream, maxBytes, charsetOf(c.contentType))
                return Resp(code, text, current)
            } finally {
                c.disconnect()
            }
        }
        throw IOException("Too many redirects")
    }

    private fun charsetOf(contentType: String?): Charset {
        val cs = contentType?.substringAfter("charset=", "")?.substringBefore(';')?.trim()?.trim('"')
        return try { if (cs.isNullOrEmpty()) Charsets.UTF_8 else Charset.forName(cs) } catch (_: Exception) { Charsets.UTF_8 }
    }

    private fun read(s: InputStream, max: Int, cs: Charset): String {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        s.use {
            while (out.size() < max) {
                val n = it.read(buf)
                if (n < 0) break
                out.write(buf, 0, n)
            }
        }
        return String(out.toByteArray(), cs)
    }
}
