plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    // llama.cpp loads its CPU backends (.so) from nativeLibraryDir, so they must be extracted on install
    packaging { jniLibs { useLegacyPackaging = true } }
    namespace = "com.vethos.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.vethos.app"
        minSdk = 29          // Android 10+ (lib is patched down from 33 by CI / setup.sh)
        targetSdk = 35
        versionCode = 10
        versionName = "10.0.0"
        ndk { abiFilters += listOf("arm64-v8a") }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { viewBinding = true }
}

dependencies {
    implementation(project(":lib"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.fragment:fragment-ktx:1.8.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    // QR scanner (offline, uses the camera) and QR code maker
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")
    implementation("com.google.zxing:core:3.5.3")
    // reads the text of PDF files (offline)
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
    // reads the text in photos (offline OCR): Latin + Devanagari (Hindi)
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.mlkit:text-recognition-devanagari:16.0.1")
    implementation("com.google.android.gms:play-services-tasks:18.2.0")
    // readable text of web pages, search results and RSS feeds
    implementation("org.jsoup:jsoup:1.17.2")
}
