pluginManagement {
    repositories { google(); mavenCentral(); gradlePluginPortal() }
}
dependencyResolutionManagement {
    repositories { google(); mavenCentral() }
}
rootProject.name = "Vethos"
include(":app")
// llama.cpp's Android AI-chat library (cloned by setup.sh)
include(":lib")
project(":lib").projectDir = file("llama.cpp/examples/llama.android/lib")
