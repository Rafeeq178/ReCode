package com.androidharness.app.ui.chat

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SlashCommandsTest {
    @Test fun `auto compact aliases stay local and preserve the full amount`() {
        for (command in listOf("/autocompact", "/auto-compact", "/auto_compact", "/auto compact")) {
            val result = resolve("$command 1 million")
            assertEquals(SlashCommands.Kind.AUTO_COMPACT, result.kind)
            assertEquals("1 million", result.autoCompactArgument)
            assertFalse(result.startsAgent)
            assertNull(result.agentText)
        }
        assertEquals("", resolve("/autocompact").autoCompactArgument)
        assertEquals("default", resolve("/autocompact default").autoCompactArgument)
    }

    @Test fun `picking auto compact leaves the composer ready for a threshold`() {
        assertEquals(SlashCommands.Pick.Insert("/autocompact "), SlashCommands.pickAction(
            "/autocompact", "/auto", SlashCommands.Kind.AUTO_COMPACT))
    }


    private val skills = setOf("git", "systematic-debugging")
    private val snippets = mapOf("review" to "Review this: \$ARG")

    private fun resolve(input: String) = SlashCommands.resolve(
        input = input,
        skillNames = skills,
        snippetBodies = snippets,
        skillContent = { name -> if (name in skills) "# $name\nDo the work." else null },
    )

    @Test
    fun `local commands never start an agent turn`() {
        for (cmd in listOf("/clear", "/compact", "/cost", "/skills", "/env")) {
            val result = resolve(cmd)
            assertNull("$cmd should stay local", result.agentText)
            assertFalse(result.startsAgent)
        }
        assertEquals(SlashCommands.Kind.COST, resolve("/cost").kind)
        assertEquals(SlashCommands.Kind.SKILLS, resolve("/skills").kind)
        assertEquals(SlashCommands.Kind.ENV, resolve("/env").kind)
    }

    @Test
    fun `init expands to the workspace prompt`() {
        val result = resolve("/init")
        assertEquals(SlashCommands.Kind.INIT, result.kind)
        assertTrue(result.startsAgent)
        assertTrue(result.agentText!!.contains("AGENTS.md"))
    }

    @Test
    fun `doctor expands to the harness self-test battery prompt`() {
        val result = resolve("/doctor")
        assertEquals(SlashCommands.Kind.DOCTOR, result.kind)
        assertTrue(result.startsAgent)
        assertTrue(result.agentText!!.contains("Harness Doctor"))
        assertTrue(result.agentText!!.contains("FILE CRUD & UNICODE"))
        assertTrue(result.agentText!!.contains("SANDBOX BOUNDARIES"))
    }

    @Test
    fun `skill with instruction expands instead of queuing the raw slash text`() {
        val result = resolve("/git commit this")
        assertEquals(SlashCommands.Kind.SKILL, result.kind)
        assertTrue(result.startsAgent)
        assertTrue(result.agentText!!.contains("invoked the \"git\" skill"))
        assertTrue(result.agentText!!.contains("commit this"))
        assertFalse(result.agentText!!.startsWith("/git"))
    }

    @Test
    fun `snippet substitutes the argument`() {
        val result = resolve("/review the login flow")
        assertEquals(SlashCommands.Kind.SNIPPET, result.kind)
        assertEquals("Review this: the login flow", result.agentText)
    }

    @Test
    fun `unknown command is an error and does not start a run`() {
        val result = resolve("/nope")
        assertEquals(SlashCommands.Kind.UNKNOWN, result.kind)
        assertNull(result.agentText)
        assertTrue(result.error!!.contains("/nope"))
    }

    @Test
    fun `running agent queues expanded skill text instead of cancelling`() {
        val expanded = resolve("/git fix crash").agentText!!
        val target = SlashCommands.dispatchTarget(isRunning = true, agentText = expanded)
        assertEquals(SlashCommands.Dispatch.QUEUE, target.mode)
        assertEquals(expanded, target.text)
    }

    @Test
    fun `idle agent starts a new run with expanded text`() {
        val expanded = resolve("/init").agentText!!
        val target = SlashCommands.dispatchTarget(isRunning = false, agentText = expanded)
        assertEquals(SlashCommands.Dispatch.START, target.mode)
        assertEquals(expanded, target.text)
    }

    @Test
    fun `picking a bare skill attaches a badge instead of sending`() {
        val action = SlashCommands.pickAction(
            entryCommand = "/git",
            typedQuery = "/git",
            kind = SlashCommands.Kind.SKILL,
        )
        assertEquals(SlashCommands.Pick.AttachSkill("git", ""), action)
    }

    @Test
    fun `picking a skill after typing an instruction keeps the leftover in the box`() {
        val action = SlashCommands.pickAction(
            entryCommand = "/git",
            typedQuery = "/git fix the crash",
            kind = SlashCommands.Kind.SKILL,
        )
        assertEquals(SlashCommands.Pick.AttachSkill("git", "fix the crash"), action)
    }

    @Test
    fun `picking a skill from a partial query attaches the full name`() {
        val action = SlashCommands.pickAction(
            entryCommand = "/git",
            typedQuery = "/g",
            kind = SlashCommands.Kind.SKILL,
        )
        assertEquals(SlashCommands.Pick.AttachSkill("git", ""), action)
    }

    @Test
    fun `send payload prefixes the attached skill and keeps the typed note`() {
        assertEquals("/git", SlashCommands.composeSend("git", ""))
        assertEquals("/git fix the crash", SlashCommands.composeSend("git", "fix the crash"))
        assertEquals("hello", SlashCommands.composeSend(null, "hello"))
    }

    @Test
    fun `picking a local command sends immediately`() {
        val action = SlashCommands.pickAction(
            entryCommand = "/cost",
            typedQuery = "/co",
            kind = SlashCommands.Kind.COST,
        )
        assertEquals(SlashCommands.Pick.Send("/cost"), action)
    }

    @Test
    fun `plan expands to the plan skill invocation`() {
        val result = resolve("/plan add offline mode")
        assertEquals(SlashCommands.Kind.PLAN, result.kind)
        assertTrue(result.startsAgent)
        // Standard skill-invocation header with the plan skill loaded…
        assertTrue(result.agentText!!.contains("invoked the \"plan\" skill"))
        // …plus the user's instruction appended.
        assertTrue(result.agentText!!.contains("add offline mode"))
    }

    @Test
    fun `plan falls back to built-in instructions without a plan skill`() {
        val result = resolve("/plan")  // "plan" not in the fake skill set
        assertTrue(result.startsAgent)
        assertTrue(result.agentText!!.contains("invoked the \"plan\" skill"))
        assertTrue(result.agentText!!.contains("implementation plan"))
    }

    @Test
    fun `plan uses the real skill content when one exists`() {
        val custom = SlashCommands.resolve(
            input = "/plan ship it",
            skillNames = setOf("git", "systematic-debugging", "plan"),
            snippetBodies = snippets,
            skillContent = { name -> if (name == "plan") "# CUSTOM PLAN PROCEDURE" else null },
        )
        assertTrue(custom.agentText!!.contains("CUSTOM PLAN PROCEDURE"))
        assertTrue(custom.agentText!!.contains("ship it"))
    }

    @Test
    fun `btw stays local and carries the side question`() {
        val result = resolve("/btw why did it pick Room?")
        assertEquals(SlashCommands.Kind.BTW, result.kind)
        assertFalse(result.startsAgent)
        assertEquals("why did it pick Room?", result.sideQuestion)
        assertEquals("", resolve("/btw").sideQuestion)
    }

    @Test
    fun `btw is recognised on any whitespace and in any case`() {
        assertTrue(SlashCommands.isSideQuestion("/btw what changed"))
        assertTrue(SlashCommands.isSideQuestion("  /BTW\nwhat changed"))
        assertTrue(SlashCommands.isSideQuestion("/btw"))
        assertFalse(SlashCommands.isSideQuestion("/btwx"))
        assertFalse(SlashCommands.isSideQuestion("btw what changed"))
        assertEquals("multi\nline", resolve("/btw\nmulti\nline").sideQuestion)
    }

    @Test
    fun `picking btw waits for the question`() {
        assertEquals(SlashCommands.Pick.Insert("/btw "), SlashCommands.pickAction("/btw", "/bt", SlashCommands.Kind.BTW))
    }
}
