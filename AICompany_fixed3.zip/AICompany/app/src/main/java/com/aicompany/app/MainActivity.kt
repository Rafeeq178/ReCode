package com.aicompany.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.aicompany.app.ui.CrashReportScreen
import com.aicompany.app.ui.nav.AppNav
import com.aicompany.app.ui.theme.AICompanyTheme
import com.aicompany.app.util.CrashReporter
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val lastCrash = CrashReporter.read(this)
        setContent {
            AICompanyTheme {
                Surface(modifier = Modifier, color = androidx.compose.material3.MaterialTheme.colorScheme.background) {
                    var report by remember { mutableStateOf(lastCrash) }
                    val shown = report
                    if (shown != null) {
                        CrashReportScreen(shown) {
                            CrashReporter.clear(this@MainActivity)
                            report = null
                        }
                    } else {
                        AppNav()
                    }
                }
            }
        }
    }
}
