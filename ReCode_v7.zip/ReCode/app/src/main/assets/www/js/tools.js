/* ReCode - Phase 1: tool registry, tool parser and tool executor.
   Tools only ever touch the open project (RC.store.files). There is no disk access, so nothing can leave the project.
   Every tool declares: name, description, params, perm (read|write|delete|exec), run(args, ctx) -> string, and is
   executed through T.exec() which validates, checks the policy gate, runs, and never throws. */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var U = RC.u;

  // Default policy until the Phase 2 permission manager replaces RC.tools.gate.
  // allow | ask | deny. "ask" is treated as deny here because there is no dialog yet.
  var policy = { read: 'allow', write: 'allow', delete: 'deny', exec: 'allow' };

  function St() { return RC.store; }
  function files() { return St().files; }
  function fail(m) { var e = new Error(m); e.tool = true; return e; }

  /** project-relative, validated path. Throws if it could leave the project or is malformed. */
  function path(p, opts) {
    var raw = String(p == null ? '' : p).trim().replace(/^["'`]|["'`]$/g, '');
    if (!raw) throw fail('Missing path.');
    if (/^([a-z]:|\/|~)/i.test(raw) || /(^|[\\/])\.\.([\\/]|$)/.test(raw)) throw fail('Path "' + raw + '" is outside the project. Use a simple relative path like src/app.js.');
    var n = U.normPath(raw);
    if (!n) throw fail('Missing path.');
    if (!(opts && opts.dir) && !U.validPath(n)) throw fail('Invalid file name "' + n + '". Use letters, digits, - _ . and / with a file extension.');
    return n;
  }
  function must(p) {
    var n = path(p);
    if (files()[n] === undefined) {
      var near = Object.keys(files()).filter(function (x) { return U.base(x).toLowerCase() === U.base(n).toLowerCase(); });
      throw fail('No such file: ' + n + (near.length ? '. Did you mean ' + near[0] + '?' : '. Use list_files to see the files.'));
    }
    return n;
  }
  function num(v, d) { v = parseInt(v, 10); return isNaN(v) ? d : v; }
  function lineCount(s) { return s === '' ? 0 : s.split('\n').length; }
  function globRe(g) {
    var s = String(g).replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*\*/g, '\u0000').replace(/\*/g, '[^/]*').replace(/\?/g, '[^/]').replace(/\u0000/g, '.*');
    return new RegExp('^' + s + '$', 'i');
  }

  // ------------------------------------------------------------------ syntax checkers (no dependencies)
  function balance(code, pairs) {
    // strip strings/comments crudely, then compare bracket depth
    var s = code.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/[^\n]*/g, '').replace(/"(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*'|`(?:\\.|[^`\\])*`/g, '""');
    var st = [], line = 1, close = { ')': '(', ']': '[', '}': '{' };
    for (var i = 0; i < s.length; i++) {
      var c = s[i];
      if (c === '\n') line++;
      else if (c === '(' || c === '[' || c === '{') st.push({ c: c, line: line });
      else if (close[c]) { var t = st.pop(); if (!t || t.c !== close[c]) return 'Unexpected "' + c + '" near line ' + line; }
    }
    return st.length ? 'Unclosed "' + st[st.length - 1].c + '" opened near line ' + st[st.length - 1].line : '';
  }
  function checkOne(p, code) {
    var e = U.ext(p), msg = '';
    if (e === 'js' || e === 'mjs') {
      try { new Function(code); } catch (x) {
        if (/import|export|await/.test(String(x.message)) && /^\s*(import|export)\b/m.test(code)) { try { new Function('return async()=>{' + code.replace(/^\s*(import|export)[^\n]*\n?/gm, '') + '}'); } catch (y) { msg = y.message; } }
        else msg = x.message;
      }
    } else if (e === 'json') {
      try { JSON.parse(code); } catch (x) { msg = x.message; }
    } else if (e === 'css') {
      msg = balance(code);
      var o = (code.match(/\/\*/g) || []).length, c = (code.match(/\*\//g) || []).length;
      if (!msg && o !== c) msg = 'Unclosed comment';
    } else if (e === 'html' || e === 'htm') {
      var voidT = /^(area|base|br|col|embed|hr|img|input|link|meta|param|source|track|wbr|!doctype)$/i, st = [], re = /<(\/?)([a-z][a-z0-9-]*|!doctype)\b[^>]*?(\/?)>/gi, m;
      var body = code.replace(/<!--[\s\S]*?-->/g, '').replace(/<(script|style)\b[^>]*>[\s\S]*?<\/\1>/gi, function (x, t) { return '<' + t + '></' + t + '>'; });
      while ((m = re.exec(body))) {
        var tag = m[2].toLowerCase();
        if (voidT.test(tag) || m[3]) continue;
        if (m[1]) { var top = st.pop(); if (top !== tag) { msg = 'Closing </' + tag + '> does not match ' + (top ? '<' + top + '>' : 'any open tag'); break; } }
        else st.push(tag);
      }
      if (!msg && st.length && !/^(html|body|head|p|li)$/.test(st[st.length - 1])) msg = 'Unclosed <' + st[st.length - 1] + '>';
      if (!msg) {
        var scripts = code.match(/<script\b(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/gi) || [];
        for (var i = 0; i < scripts.length && !msg; i++) {
          var inner = scripts[i].replace(/^<script[^>]*>|<\/script>$/gi, '');
          if (inner.trim()) { try { new Function(inner); } catch (x) { msg = 'Inline <script> ' + x.message; } }
        }
      }
    } else if (e === 'py') {
      msg = balance(code.replace(/#[^\n]*/g, ''));
      if (!msg && /^\t+ +| +\t+/m.test(code)) msg = 'Mixed tabs and spaces in indentation';
    } else return null; // unknown type: not checked
    return msg;
  }

  // ------------------------------------------------------------------ test harness (runs *.test.js / test*.js in the sandbox)
  var HARNESS = '(function(){var p=0,f=0;window.assert=function(c,m){if(!c)throw new Error(m||"assertion failed")};' +
    'window.assertEqual=function(a,b,m){if(JSON.stringify(a)!==JSON.stringify(b))throw new Error((m||"not equal")+": got "+JSON.stringify(a)+", expected "+JSON.stringify(b))};' +
    'window.test=function(n,fn){try{fn();p++;console.log("T:PASS "+n)}catch(e){f++;console.log("T:FAIL "+n+": "+(e&&e.message||e))}};' +
    'window.addEventListener("load",function(){setTimeout(function(){console.log("T:DONE "+p+" "+f)},50)})})();';
  function testFiles() { return Object.keys(files()).filter(function (n) { return /(^|\/)(test[\w.-]*|[\w.-]+\.test|[\w.-]+_test)\.m?js$/i.test(n); }); }

  // ------------------------------------------------------------------ the tools
  var reg = {};
  function def(t) { reg[t.name] = t; }

  def({
    name: 'read_file', perm: 'read', params: 'path, [start_line], [end_line]',
    description: 'Read a file (large files: give a line range).',
    run: function (a) {
      var p = must(a.path), c = files()[p], lines = c.split('\n'), s = Math.max(1, num(a.start_line, 1)), e = num(a.end_line, 0);
      if (!e && c.length > 3500 && !a.start_line) e = Math.min(lines.length, 120);
      if (!e) return '--- ' + p + ' (' + lines.length + ' lines) ---\n' + c;
      e = Math.min(lines.length, e);
      return '--- ' + p + ' lines ' + s + '-' + e + ' of ' + lines.length + (e < lines.length ? ' (use start_line/end_line for more)' : '') + ' ---\n' +
        lines.slice(s - 1, e).map(function (l, i) { return (s + i) + ': ' + l; }).join('\n');
    }
  });
  def({
    name: 'write_file', perm: 'write', params: 'path, content',
    description: 'Create a file or replace it completely with content.',
    run: function (a, ctx) {
      var p = path(a.path), content = a.content;
      if (content == null || (!String(content).trim() && !a.allow_empty)) throw fail('No content given for ' + p + '. Put the full file in a code block after the TOOL line.');
      var existed = files()[p] !== undefined;
      return St().putFile(p, String(content)).then(function () {
        ctx.touch(p);
        return (existed ? 'Replaced ' : 'Created ') + p + ' (' + lineCount(String(content)) + ' lines, ' + U.bytes(String(content).length) + ').';
      });
    }
  });
  def({
    name: 'edit_file', perm: 'write', params: 'path, old_text, new_text, [replace_all]',
    description: 'Replace exact text in a file. old_text must match exactly and be unique (or set replace_all).',
    run: function (a, ctx) {
      var p = must(a.path), c = files()[p], o = a.old_text == null ? a.search : a.old_text, n = a.new_text == null ? (a.replace == null ? '' : a.replace) : a.new_text;
      if (o == null || o === '') throw fail('old_text is empty. Give the exact existing text to replace.');
      o = String(o); n = String(n);
      var idx = c.indexOf(o);
      if (idx < 0) { // tolerate whitespace differences at line ends / indentation
        var re = new RegExp(o.split('\n').map(function (l) { return l.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\s+/g, '\\s+'); }).filter(Boolean).join('\\s*\\n\\s*'));
        var mm = o.trim() ? re.exec(c) : null;
        if (!mm) throw fail('old_text was not found in ' + p + '. Use read_file to copy the exact text.');
        o = mm[0]; idx = mm.index;
      }
      var count = c.split(o).length - 1;
      if (count > 1 && !(a.replace_all === true || /^(true|yes|1|all)$/i.test(String(a.replace_all)))) throw fail('old_text appears ' + count + ' times in ' + p + '. Add more surrounding lines to make it unique, or set replace_all.');
      var out = count > 1 ? c.split(o).join(n) : c.slice(0, idx) + n + c.slice(idx + o.length);
      return St().putFile(p, out).then(function () { ctx.touch(p); return 'Edited ' + p + ' (' + count + ' replacement' + (count > 1 ? 's' : '') + ', now ' + lineCount(out) + ' lines).'; });
    }
  });
  def({
    name: 'delete_file', perm: 'delete', params: 'path',
    description: 'Delete a file (or every file under a folder path ending in /).',
    run: function (a, ctx) {
      var raw = String(a.path || '').trim();
      if (/\/$/.test(raw)) {
        var d = path(raw, { dir: true }) + '/', list = Object.keys(files()).filter(function (x) { return x.indexOf(d) === 0; });
        if (!list.length) throw fail('Folder is empty or does not exist: ' + d);
        return Promise.all(list.map(function (x) { return St().delFile(x); })).then(function () { list.forEach(ctx.touch); return 'Deleted ' + list.length + ' file(s) in ' + d; });
      }
      var p = must(raw);
      return St().delFile(p).then(function () { ctx.touch(p); return 'Deleted ' + p + '.'; });
    }
  });
  def({
    name: 'list_files', perm: 'read', params: '[folder]',
    description: 'List project files with sizes.',
    run: function (a) {
      var pre = a.folder || a.path ? path(a.folder || a.path, { dir: true }).replace(/\/?$/, '/') : '';
      var l = St().fileList().filter(function (x) { return x.indexOf(pre) === 0; });
      if (!l.length) return pre ? 'No files in ' + pre : 'The project is empty.';
      return l.length + ' file(s):\n' + l.map(function (x) { return x + '  (' + lineCount(files()[x]) + ' lines, ' + U.bytes(files()[x].length) + ')'; }).join('\n');
    }
  });
  def({
    name: 'search_files', perm: 'read', params: 'pattern',
    description: 'Find files by name (substring or glob like *.css, src/**).',
    run: function (a) {
      var q = String(a.pattern || a.query || a.name || '').trim();
      if (!q) throw fail('Missing pattern.');
      var re = /[*?]/.test(q) ? globRe(q.indexOf('/') < 0 ? '**' + q : q) : null, ql = q.toLowerCase();
      var l = St().fileList().filter(function (x) { return re ? re.test(x) : x.toLowerCase().indexOf(ql) >= 0; });
      return l.length ? l.length + ' match(es):\n' + l.join('\n') : 'No file name matches "' + q + '".';
    }
  });
  def({
    name: 'search_text', perm: 'read', params: 'pattern, [path]',
    description: 'Search file contents (regex or plain text), shows file:line: text.',
    run: function (a) {
      var q = String(a.pattern || a.query || a.text || ''), g = a.path || a.glob || a.include || '';
      if (!q) throw fail('Missing pattern.');
      var re; try { re = new RegExp(q, 'i'); } catch (e) { re = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i'); }
      var gre = g ? globRe(/[*?]/.test(g) ? (g.indexOf('/') < 0 ? '**' + g : g) : U.normPath(g)) : null, out = [], total = 0;
      St().fileList().forEach(function (f) {
        if (gre && !gre.test(f)) return;
        files()[f].split('\n').forEach(function (l, i) { if (re.test(l)) { total++; if (out.length < 25) out.push(f + ':' + (i + 1) + ': ' + U.clip(l.trim(), 140, '…')); } });
      });
      return total ? total + ' match(es)' + (total > out.length ? ' (showing ' + out.length + ')' : '') + ':\n' + out.join('\n') : 'No matches for "' + q + '".';
    }
  });
  def({
    name: 'create_directory', perm: 'read', params: 'path',
    description: 'Not needed: write_file creates folders itself.',
    run: function (a) {
      var d = path(a.path, { dir: true });
      if (/\.[a-z0-9]{1,8}$/i.test(U.base(d))) throw fail('"' + d + '" looks like a file name, not a folder.');
      return 'OK - folder ' + d + '/ exists as soon as you write a file into it (write_file ' + d + '/index.html). Do not call create_directory again; write the files now.';
    }
  });
  def({
    name: 'scaffold', perm: 'write', params: 'name',
    description: 'Write a tested starter project: calculator, snake or todo.',
    run: function (a, ctx) {
      var n = String(a.name || a.template || '').toLowerCase().trim(), R = RC.recipes, rec = R && R.get(n);
      if (!rec) throw fail('Unknown template "' + n + '". Available: ' + (R ? R.names().join(', ') : 'none') + '.');
      var names = Object.keys(rec.files);
      return names.reduce(function (pr, f) { return pr.then(function () { return St().putFile(f, rec.files[f]); }).then(function () { ctx.touch(f); }); }, Promise.resolve())
        .then(function () { return 'Wrote the tested "' + rec.title + '" template: ' + names.join(', ') + '. It already works. Next: run_tests, then edit_file only what the user asked, then give the final answer.'; });
    }
  });
  function move(a, ctx, verb) {
    var from = must(a.from || a.path || a.src), to = a.to || a.dest || a.new_path || a.new_name;
    if (!to) throw fail('Missing destination.');
    var tp = String(to).trim();
    if (/\/$/.test(tp)) tp = tp + U.base(from);
    tp = path(tp);
    if (tp === from) throw fail('Source and destination are the same.');
    if (files()[tp] !== undefined) throw fail('Destination ' + tp + ' already exists. Delete it first or choose another name.');
    var c = files()[from];
    return St().putFile(tp, c).then(function () { return St().delFile(from); }).then(function () { ctx.touch(from); ctx.touch(tp); return verb + ' ' + from + ' -> ' + tp + '.'; });
  }
  def({ name: 'rename_file', perm: 'write', params: 'from, to', description: 'Rename a file (same folder or new name).', run: function (a, c) { return move(a, c, 'Renamed'); } });
  def({ name: 'move_file', perm: 'write', params: 'from, to', description: 'Move a file to another path or folder (to ending in / keeps the name).', run: function (a, c) { return move(a, c, 'Moved'); } });
  def({
    name: 'get_file_info', perm: 'read', params: 'path',
    description: 'Size, line count, type and a structure digest of a file.',
    run: function (a) {
      var p = must(a.path), c = files()[p];
      return p + '\ntype: ' + (U.ext(p) || 'none') + '\nsize: ' + U.bytes(c.length) + ' (' + c.length + ' chars, ~' + U.tok(c) + ' tokens)\nlines: ' + lineCount(c) +
        '\n' + RC.agents.digest(p, c) + (RC.run && RC.run.entry(files()) === p ? '\n(this is the entry page)' : '');
    }
  });
  def({
    name: 'check_syntax', perm: 'read', params: '[path]',
    description: 'Check syntax of one file (or all files): js, json, css, html, py.',
    run: function (a) {
      var names = a.path ? [must(a.path)] : St().fileList(), bad = [], ok = 0, skipped = 0;
      names.forEach(function (p) {
        var m = checkOne(p, files()[p]);
        if (m === null) skipped++; else if (m) bad.push(p + ': ' + m); else ok++;
      });
      if (!bad.length) return 'Syntax OK for ' + ok + ' file(s)' + (skipped ? ' (' + skipped + ' not checkable)' : '') + '.';
      return bad.length + ' syntax problem(s):\n' + bad.join('\n') + (ok ? '\n' + ok + ' other file(s) OK.' : '');
    }
  });
  def({
    name: 'run_command', perm: 'exec', params: 'command',
    description: 'Run a built-in command. ReCode has no shell. Supported: run (load the page in the sandbox and report errors), check, ls [folder], cat <file>, grep <text> [glob], wc <file>.',
    run: function (a, ctx) {
      var cmd = String(a.command || a.cmd || '').trim();
      if (!cmd) throw fail('Missing command.');
      var parts = cmd.match(/"[^"]*"|'[^']*'|\S+/g).map(function (x) { return x.replace(/^["']|["']$/g, ''); }), c = parts[0].toLowerCase(), rest = parts.slice(1);
      if (c === 'ls') return reg.list_files.run({ folder: rest[0] }, ctx);
      if (c === 'cat') return reg.read_file.run({ path: rest[0] }, ctx);
      if (c === 'grep') return reg.search_text.run({ pattern: rest[0], path: rest[1] }, ctx);
      if (c === 'wc') { var p = must(rest[0]); return lineCount(files()[p]) + ' lines ' + files()[p].length + ' chars ' + p; }
      if (c === 'check') return reg.run_tests.run({ only: 'page' }, ctx);
      if (c === 'run' || c === 'preview' || c === 'start') return reg.run_tests.run({ only: 'page' }, ctx);
      throw fail('Unknown command "' + c + '". ReCode has no shell. Supported: run, check, ls, cat, grep, wc.');
    }
  });
  def({
    name: 'run_tests', perm: 'exec', params: '[only]',
    description: 'Run project checks: file/reference lint, a real run of the page in the sandbox (runtime errors), and test files (test*.js, *.test.js using test(name, fn) and assert()).',
    run: async function (a) {
      if (!RC.run) throw fail('The runner is not available.');
      var lines = [], bad = 0;
      var r = await RC.run.check();
      r.fixes.forEach(function (m) { lines.push('auto-fix: ' + m); });
      r.issues.forEach(function (m) { bad++; lines.push('PROBLEM ' + m.file + ': ' + m.msg); });
      lines.push(r.ran ? (r.issues.length ? 'Page ran with problems.' : 'Page ran without errors.') : 'No page to run (static checks only).');
      var tf = a.only === 'page' ? [] : testFiles();
      if (tf.length) {
        var copy = Object.assign({}, files()), entry = RC.run.entry(copy);
        copy['__harness.js'] = HARNESS;
        var tags = ['__harness.js'].concat(tf).map(function (x) { return '<script src="' + x + '"></script>'; }).join('');
        var linked = function (h) { return tf.every(function (x) { return h.indexOf(x) >= 0; }); };
        if (entry) {
          var h = copy[entry];
          if (!linked(h)) copy[entry] = /<\/body>/i.test(h) ? h.replace(/<\/body>/i, tags + '</body>') : h + tags;
          else copy[entry] = h.replace(/<head(\s[^>]*)?>/i, function (x) { return x + '<script src="__harness.js"></script>'; });
        } else {
          copy['index.html'] = '<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>' + Object.keys(files()).filter(function (x) { return /\.m?js$/i.test(x) && tf.indexOf(x) < 0; }).map(function (x) { return '<script src="' + x + '"></script>'; }).join('').replace(/^/, '<script src="__harness.js"></script>') + tf.map(function (x) { return '<script src="' + x + '"></script>'; }).join('') + '</body></html>';
        }
        var pr = await RC.run.probe(copy, 1500), pass = 0, fl = 0;
        pr.logs.forEach(function (l) {
          var m = /T:(PASS|FAIL) (.*)/.exec(l);
          if (m) { if (m[1] === 'PASS') pass++; else { fl++; bad++; lines.push('TEST FAILED ' + m[2]); } }
        });
        pr.errors.forEach(function (e) { if (!/^console\.error: T:/.test(e.msg)) { bad++; lines.push('TEST ERROR ' + (e.file ? e.file + (e.line ? ':' + e.line : '') + ' ' : '') + e.msg); } });
        lines.push('Tests: ' + pass + ' passed, ' + fl + ' failed (' + tf.join(', ') + ').');
      } else if (a.only !== 'page') lines.push('No test files found (name them test*.js or *.test.js).');
      return (bad ? 'FAILED - ' + bad + ' problem(s)\n' : 'PASSED\n') + lines.join('\n');
    }
  });

  def({
    name: 'delegate', perm: 'read', params: 'agent, task',
    description: 'Hand a focused sub-task to a specialist agent (planner, explorer, frontend, backend, database, coder, debugger, fixer, tester, reviewer, security, optimizer, documentation, researcher, architect). It works on its own and returns a short report.',
    run: async function (a, ctx) {
      if (!RC.subagents) throw fail('Subagents are not available.');
      if ((ctx.depth || 0) >= 1) throw fail('Subagents cannot delegate further. Do the work yourself.');
      var name = String(a.agent || a.name || '').trim(), task = a.task || a.prompt || a.request;
      if (!name || !RC.subagents.get(name)) throw fail('No agent named "' + name + '". Available: ' + RC.subagents.names().join(', '));
      var r = await RC.subagents.run(name, task, { run: ctx.run, goal: ctx.goal, depth: ctx.depth || 0 });
      if (!r.ok) throw fail(r.text);
      return '[' + r.name + ' report]\n' + r.text;
    }
  });
  def({
    name: 'search_knowledge', perm: 'read', params: 'query',
    description: 'Search the knowledge base (your documents and project files) with BM25 and return the best passages.',
    run: function (a) {
      var q = String(a.query || a.pattern || '').trim();
      if (!q) throw fail('Missing query.');
      if (!RC.rag || !RC.rag.corpus().length) return 'The knowledge base is empty.';
      var hits = RC.rag.search(q, { k: 3 });
      return hits.length ? RC.rag.format(hits, 1800) : 'Nothing relevant found for "' + q + '".';
    }
  });
  def({
    name: 'web_search', perm: 'read', params: 'query',
    description: 'Search the web (needs internet and "Internet research" enabled). Returns titles, links and snippets.',
    run: async function (a) {
      var q = String(a.query || '').trim();
      if (!q) throw fail('Missing query.');
      if (RC.settings.autoResearch === false) throw fail('Web access is switched off in Settings (Internet research).');
      if (!RC.native.online()) throw fail('No internet connection. Work offline.');
      var h = await RC.native.search(q, 5);
      return h.length ? h.map(function (x, i) { return (i + 1) + '. ' + x.title + ' - ' + x.url + (x.snippet ? '\n   ' + U.clip(x.snippet, 160, '…') : ''); }).join('\n') : 'No results.';
    }
  });
  def({
    name: 'web_read', perm: 'read', params: 'url',
    description: 'Read a web page returned by web_search (text only).',
    run: async function (a) {
      var u = String(a.url || '').trim();
      if (!/^https?:\/\//i.test(u)) throw fail('Give a full http(s) URL.');
      if (RC.settings.autoResearch === false) throw fail('Web access is switched off in Settings (Internet research).');
      if (!RC.native.online()) throw fail('No internet connection. Work offline.');
      var d = await RC.native.read(u, 2500);
      return (d.title ? d.title + '\n' : '') + U.clip(d.text, 2500, '…');
    }
  });

  // ------------------------------------------------------------------ parser
  var NAMES_ALIAS = { ask_agent: 'delegate', subagent: 'delegate', agent: 'delegate', knowledge: 'search_knowledge', web: 'web_search', fetch: 'web_read', browse: 'web_read', read: 'read_file', write: 'write_file', edit: 'edit_file', delete: 'delete_file', remove: 'delete_file', ls: 'list_files', list: 'list_files', find: 'search_files', grep: 'search_text', search: 'search_text', mkdir: 'create_directory', rename: 'rename_file', mv: 'move_file', move: 'move_file', info: 'get_file_info', stat: 'get_file_info', run: 'run_command', exec: 'run_command', syntax: 'check_syntax', test: 'run_tests', tests: 'run_tests', create_file: 'write_file', create: 'write_file', cat: 'read_file', read_files: 'read_file', create_folder: 'create_directory', todos: 'todo', tasks: 'todo', task: 'todo', note: 'remember', notes: 'remember', memory: 'remember', memorize: 'remember', save_note: 'remember' };
  function canon(n) {
    n = String(n || '').trim().toLowerCase().replace(/[^a-z_]/g, '');
    return reg[n] ? n : (NAMES_ALIAS[n] && reg[NAMES_ALIAS[n]] ? NAMES_ALIAS[n] : '');
  }
  function paramNames(t) { return t.params.replace(/[\[\]]/g, '').split(',').map(function (x) { return x.trim(); }).filter(Boolean); }
  function fence(text, from) {
    // first fenced block that starts after `from`; returns {code, end} or null
    var re = /(^|\n)[ \t]*(`{3,}|~{3,})[^\n]*\n/g, m;
    re.lastIndex = from;
    m = re.exec(text);
    if (!m) return null;
    var open = m.index + m[0].length, tick = m[2], close = text.indexOf('\n' + tick, open);
    var code, end;
    if (close < 0) { code = text.slice(open); end = text.length; }
    else { code = text.slice(open, close); var nl = text.indexOf('\n', close + 1); end = nl < 0 ? text.length : nl; }
    return { code: code.replace(/\n$/, ''), end: end, start: m.index };
  }
  function parseEdit(body) {
    var m = /<{3,}\s*(?:SEARCH|OLD)[^\n]*\n([\s\S]*?)\n={3,}[^\n]*\n([\s\S]*?)\n?>{3,}\s*(?:REPLACE|NEW)?/i.exec(body);
    return m ? { old_text: m[1], new_text: m[2] } : null;
  }

  var T = RC.tools = {
    registry: reg,
    policy: policy,
    names: function () { return Object.keys(reg); },
    /** compact tool list for prompts: small models get short lines */
    prompt: function (names, compact) {
      return (names || T.names()).filter(function (n) { return reg[n]; }).map(function (n) { var t = reg[n]; return compact ? 'TOOL: ' + n + ' | ' + t.params.replace(/[\[\]]/g, '').split(',').join(' |').replace(/\s+\|/g, ' |') : '- ' + n + '(' + t.params + '): ' + t.description; }).join('\n');
    },
    /**
     * Parse model output into tool calls.
     * Supports: "TOOL: name | arg | arg" (+ following code block as content / edit block),
     * JSON {"tool":"x","args":{}} / {"name":"x","arguments":{}} / OpenAI tool_calls, <tool_call>{json}</tool_call>.
     * -> {calls:[{name,args,raw}], errors:[string], text:"model text without tool lines"}
     */
    parse: function (text) {
      text = String(text || '');
      var calls = [], errors = [], used = [];
      function addJson(obj, raw) {
        if (!obj || typeof obj !== 'object') return;
        if (Array.isArray(obj)) { obj.forEach(function (o) { addJson(o, raw); }); return; }
        if (obj.tool_calls) return addJson(obj.tool_calls, raw);
        var fn = obj.function || obj, n = fn.name || fn.tool || obj.tool || obj.name, args = fn.arguments || fn.args || fn.parameters || obj.args || obj.arguments || obj.input || obj.parameters;
        if (typeof args === 'string') { try { args = JSON.parse(args); } catch (e) { args = { path: args }; } }
        var c = canon(n);
        if (!c) { if (n) errors.push('Unknown tool "' + n + '". Available: ' + T.names().join(', ')); return; }
        calls.push({ name: c, args: args && typeof args === 'object' ? args : {}, raw: raw });
      }
      // 1. structured JSON (tags or fenced json, or a bare object that has a tool key)
      text.replace(/<tool_call>\s*([\s\S]*?)\s*<\/tool_call>/gi, function (all, j) {
        used.push(all); try { addJson(JSON.parse(j), j); } catch (e) { errors.push('Invalid JSON in <tool_call>.'); } return all;
      });
      text.replace(/(`{3,})json\s*\n([\s\S]*?)\n\1/gi, function (all, t, j) {
        if (!/"(tool|name|tool_calls|function)"\s*:/.test(j) || used.some(function (u) { return u.indexOf(j) >= 0; })) return all;
        try { addJson(JSON.parse(j), j); used.push(all); } catch (e) { /* normal json example, ignore */ }
        return all;
      });
      if (!calls.length && !used.length) {
        var t = text.trim();
        if (/^[\[{]/.test(t) && /"(tool|tool_calls|function)"\s*:/.test(t)) { try { addJson(JSON.parse(t), t); } catch (e) { errors.push('Invalid JSON tool call.'); } }
      }
      // 2. text protocol
      var re = /(^|\n)[ \t]*(?:[-*]\s*)?TOOL:[ \t]*([^\n]*)/gi, m, cursor = 0, lineHits = [];
      while ((m = re.exec(text))) lineHits.push({ idx: m.index + m[1].length, end: m.index + m[0].length, body: m[2] });
      for (var i = 0; i < lineHits.length; i++) {
        var h = lineHits[i];
        if (h.idx < cursor) continue;
        var segs = h.body.split(/\s+\|\s+|\s*\|\s*/).map(function (x) { return x.trim(); });
        var name = canon(segs[0].replace(/\(.*$/, ''));
        if (!name) { errors.push('Unknown tool "' + segs[0] + '". Available: ' + T.names().join(', ')); cursor = h.end; continue; }
        var t2 = reg[name], pn = paramNames(t2), args = {};
        var vals = segs.slice(1);
        var next = i + 1 < lineHits.length ? lineHits[i + 1].idx : text.length;
        var block = null, tail = text.slice(h.end, next);
        if (name === 'write_file' || name === 'edit_file') {
          var f = fence(text, h.end);
          if (f && f.start < next) { block = f; cursor = f.end; }
          else if (name === 'write_file' && vals.length > 1) { /* content inline after path */ }
          else if (tail.trim()) { block = { code: tail.replace(/^\n/, '').replace(/\s+$/, ''), end: next }; cursor = next; }
        } else cursor = h.end;
        if (name === 'write_file') {
          args.path = vals[0];
          if (block) args.content = block.code; else if (vals.length > 1) args.content = vals.slice(1).join(' | ');
        } else if (name === 'edit_file') {
          args.path = vals[0];
          var ed = block && parseEdit(block.code);
          if (!ed && block === null && /<{3,}\s*SEARCH/i.test(tail)) ed = parseEdit(tail);
          if (ed) { args.old_text = ed.old_text; args.new_text = ed.new_text; }
          else if (vals.length >= 3) { args.old_text = vals[1]; args.new_text = vals.slice(2).join(' | '); }
          else errors.push('edit_file needs a block:\n<<<<<<< SEARCH\nold text\n=======\nnew text\n>>>>>>> REPLACE');
        } else {
          pn.forEach(function (k, ix) { if (vals[ix] !== undefined && vals[ix] !== '') args[k] = vals[ix]; });
          if (name === 'search_text' && vals.length > 2) args.pattern = vals.slice(0, vals.length - 1).join(' | '), args.path = vals[vals.length - 1];
          if (name === 'run_command' && vals.length > 1) args.command = vals.join(' | ');
          if (name === 'delegate' && vals.length > 2) args.task = vals.slice(1).join(' | ');
          if (name === 'todo' && vals.length > 2) args.text = vals.slice(1).join(' | ');
          if (name === 'remember' && vals.length > 1) args.text = vals.join(' | ');
          if (name === 'delegate' && vals.length === 1 && /^@?[a-z-]+\s*:/i.test(vals[0])) { var dm = /^@?([a-z-]+)\s*:\s*([\s\S]*)$/i.exec(vals[0]); args.agent = dm[1]; args.task = dm[2]; }
        }
        calls.push({ name: name, args: args, raw: text.slice(h.idx, Math.min(next, h.end + 300)) });
      }
      var clean = text;
      used.forEach(function (u) { clean = clean.replace(u, ''); });
      clean = clean.replace(/(^|\n)[ \t]*(?:[-*]\s*)?TOOL:[^\n]*/gi, '$1').trim();
      return { calls: calls, errors: errors, text: clean };
    },
    /** decide allow|ask|deny for a call. Phase 2 replaces this with the permission manager. */
    gate: function (call, ctx) {
      var t = reg[call.name], lvl = policy[t.perm] || 'deny';
      if (ctx && ctx.mode === 'plan' && t.perm !== 'read') return { ok: false, why: 'Plan mode is read-only. Only reading tools can be used until the plan is approved.' };
      if (lvl === 'allow') return { ok: true };
      return { ok: false, why: t.perm === 'delete' ? 'Deleting files is not allowed by the current permissions.' : 'This action needs permission that is not granted.' };
    },
    /**
     * Execute one call. Never throws (except AbortError). -> {ok, out, blocked}
     */
    exec: async function (call, ctx) {
      ctx = ctx || {};
      var t = reg[call.name], HK = !ctx.skipHooks && RC.hooks, feedback = [];
      if (!t) return { ok: false, out: 'Unknown tool "' + call.name + '". Available: ' + T.names().join(', ') };
      if (!ctx.touch) ctx.touch = function () { };
      if (ctx.allowed && ctx.allowed.indexOf(call.name) < 0) return { ok: false, blocked: true, out: 'BLOCKED: tool "' + call.name + '" is not available to this agent. Available: ' + ctx.allowed.join(', ') };
      call = { name: call.name, args: Object.assign({}, call.args || {}), raw: call.raw };
      // 1. PreToolUse hooks may block or rewrite the arguments
      if (HK) {
        var pre = await HK.run('PreToolUse', { tool: call.name, args: call.args }, ctx);
        if (pre.blocked) return { ok: false, blocked: true, out: 'BLOCKED: ' + pre.reason };
        if (pre.input && pre.input.args) call.args = pre.input.args;
        feedback = feedback.concat(pre.feedback);
      }
      // 2. permission manager (DENY > ASK > ALLOW, plan/ask/auto mode)
      var g = (ctx.gate || T.gate)(call, ctx);
      if (g && typeof g.then === 'function') g = await g;
      if (!g || !g.ok) return { ok: false, blocked: true, out: 'BLOCKED: ' + ((g && g.why) || 'not permitted') };
      if (ctx.signal && ctx.signal.aborted) throw RC.llm.AbortErr();
      // 3. run
      var res;
      try {
        var out = await t.run(call.args || {}, ctx);
        res = { ok: true, out: String(out == null ? 'OK' : out) };
      } catch (e) {
        if (e && e.name === 'AbortError') throw e;
        res = { ok: false, out: 'ERROR: ' + (e && e.message || e) + (e && e.tool ? '' : ' (tool crashed)') };
      }
      // 4. PostToolUse hooks add feedback for the model
      if (HK) {
        try {
          var post = await HK.run('PostToolUse', { tool: call.name, args: call.args, result: res }, ctx);
          feedback = feedback.concat(post.feedback);
        } catch (e) { if (e && e.name === 'AbortError') throw e; }
        if (feedback.length) res.out += '\n' + feedback.join('\n');
      }
      return res;
    },
    // exposed for tests and later phases
    path: path, checkOne: checkOne
  };
})();
