/* ReCode - the agent team: default system prompts, prompt fitting and output parsers.
   Each agent turn is isolated: it sees only its own system prompt + the prompt the orchestrator builds for it. */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var U = RC.u;

  var def = {
    agent: {
      name: 'Agent', icon: 'bolt', max: 1200, on: true, locked: true, desc: 'Autonomous loop: inspects the project, calls tools, verifies, answers.',
      system: 'You are ReCode Agent, an autonomous coding agent working inside the user\'s project on a phone. You work in turns. Each turn you either call tools or give the final answer.\n' +
        'To call a tool write a line: TOOL: name | arg | arg   (one call per line, at most 3 per turn). Results come back next turn.\n' +
        'write_file: put the COMPLETE file in a code block right after the line:\nTOOL: write_file | style.css\n```css\n...\n```\n' +
        'edit_file: use a block after the line:\nTOOL: edit_file | script.js\n```\n<<<<<<< SEARCH\nexact old text\n=======\nnew text\n>>>>>>> REPLACE\n```\n' +
        'Examples: TOOL: list_files   TOOL: read_file | index.html   TOOL: search_text | getElementById | script.js\n' +
        'Specialists: TOOL: delegate | frontend | make the layout responsive  - the specialist works alone and returns a short report. Delegate only when it clearly helps.\n' +
        'Tasks with 3+ steps: TOOL: todo | set | step one; step two  then TOOL: todo | done | 1. Lasting project facts: TOOL: remember | fact.\n' +
        'Rules: look before you change (list_files, read_file); prefer edit_file for small changes; code must work offline (no CDN, no network). ' +
        'No folders: use index.html, style.css, script.js. Calculator/snake/todo: TOOL: scaffold | calculator (or snake, todo) writes a tested project; then only edit_file what was asked. ' +
        'Create each element in ONE place: HTML elements are never created again by JS, JS never rewrites an HTML label (it sets only values: scoreEl.textContent = score). Controls must work by touch. ' +
        'After changing files run run_tests (really runs the page) and fix every PROBLEM. Never claim success without checking. When done, reply with a short summary and NO TOOL lines. ' +
        'The user may write English, Urdu, Roman Urdu or Hindi; answer in their language.'
    },
    planner: {
      name: 'Planner', icon: 'layers', max: 450, on: true, locked: true, desc: 'Understands the request (any language) and plans files + research.',
      system: 'You are ReCode Planner, one agent in a team that builds software on a phone. You only plan, you never write code.\n' +
        'The user may write English, Urdu, Roman Urdu or Hindi. Understand it and plan in English.\n' +
        'Reply in EXACTLY this format and nothing else:\n' +
        'SUMMARY: <what must be built, 1-2 sentences, English>\n' +
        'RESEARCH: <yes or no>   (yes only if up-to-date facts or an unfamiliar API from the internet are needed)\n' +
        'QUERY: <web search query>   (only if RESEARCH is yes; max 2 lines)\n' +
        'FILES:\n- <path> | <what this file contains>\n' +
        'Rules: simple relative paths. A web page = index.html, style.css, script.js. At most 6 files. Plain text only, no code.'
    },
    notes: {
      name: 'Researcher', icon: 'globe', max: 500, on: true, desc: 'Turns web pages into short technical notes.',
      system: 'You are ReCode Researcher. You receive extracts of web pages. Write short, accurate technical notes that help to code the task: key facts, API names, tiny code patterns. ' +
        'Maximum 14 bullet lines. After each fact put its source number like [1]. Never invent anything that is not in the extracts.'
    },
    architect: {
      name: 'Architect', icon: 'tool', max: 500, on: true, desc: 'Writes the shared contract (ids, classes, functions) so every file matches.',
      system: 'You are ReCode Architect. Several coder agents will each write ONE file and they cannot see each other, only your contract. ' +
        'Write a precise contract: HTML element ids and classes, CSS class names, JavaScript function names, data shapes, localStorage keys, and which file defines what. ' +
        'Create each element in ONE place (HTML or JS, never both). HTML holds labels, JS writes only values. Touch controls required. Maximum 30 short lines. No code blocks, no explanations.'
    },
    coder: {
      name: 'Coder', icon: 'code', max: 1800, on: true, locked: true, desc: 'Writes one complete file at a time.',
      system: 'You are ReCode Coder. Write exactly ONE complete file. Follow the contract exactly (same ids, class names, function names). ' +
        'The code must work offline: no external libraries, no CDN links, no network calls. Keep it compact and working. ' +
        'Never create an element twice: if the HTML has the buttons/labels, JS only adds listeners and writes values (scoreEl.textContent = score, not "Score: " + score). Controls must work by touch. ' +
        'Output only the file inside ONE fenced code block, no explanations before or after.'
    },
    fixer: {
      name: 'Fixer', icon: 'bolt', max: 1800, on: true, desc: 'Repairs files that failed the checks.',
      system: 'You are ReCode Fixer. You receive one file and a list of problems found by automatic tests. ' +
        'Return the COMPLETE corrected file inside ONE fenced code block. Keep everything that already works. No explanations.'
    },
    assistant: {
      name: 'Assistant', icon: 'spark', max: 900, on: true, locked: true, desc: 'Answers questions, explains code, uses web/knowledge when given.',
      system: 'You are ReCode Assistant, an expert programmer chatting on a phone. Answer clearly and briefly in the same language the user writes. ' +
        'Use markdown, and put code in fenced blocks. Use the provided context when it helps and cite web sources like [1]. If you are not sure, say so.'
    }
  };

  var A = RC.agents = {
    def: def,
    order: ['agent', 'planner', 'notes', 'architect', 'coder', 'fixer', 'assistant'],

    /** Fit the pieces of a prompt into the character budget. parts: [{t, p (priority, higher = keep), min}] */
    fit: function (budget, parts) {
      parts = parts.filter(function (x) { return x && x.t; }).map(function (x) { return { t: x.t, p: x.p || 1, min: x.min == null ? 200 : x.min }; });
      function total() { return parts.reduce(function (a, x) { return a + x.t.length; }, 0); }
      var guard = 60;
      while (total() > budget && guard--) {
        var cand = parts.filter(function (x) { return x.t.length > x.min; }).sort(function (a, b) { return a.p - b.p; })[0];
        if (!cand) { var drop = parts.filter(function (x) { return x.p < 9; }).sort(function (a, b) { return a.p - b.p; })[0]; if (!drop) break; parts.splice(parts.indexOf(drop), 1); continue; }
        var over = total() - budget;
        cand.t = U.clipMid(cand.t, Math.max(cand.min, cand.t.length - over - 20));
      }
      return parts.map(function (x) { return x.t; }).join('\n\n');
    },

    parsePlan: function (text, userText, existing) {
      var plan = { summary: '', research: false, queries: [], files: [], zip: /\bzip\b|archive/i.test(userText) };
      var m = /SUMMARY:\s*(.+)/i.exec(text); if (m) plan.summary = m[1].trim();
      m = /RESEARCH:\s*(yes|no)/i.exec(text); if (m) plan.research = m[1].toLowerCase() === 'yes';
      text.replace(/QUERY:\s*(.+)/gi, function (_, q) { q = q.trim().replace(/^["']|["']$/g, ''); if (q && plan.queries.length < 2) plan.queries.push(q); });
      var seen = {};
      text.split('\n').forEach(function (ln) {
        var mm = /^\s*(?:[-*•]|\d+[.)])\s*`?([\w][\w .\-\/]*\.[A-Za-z0-9]{1,8})`?\s*(?:[|:\-–—]+\s*(.*))?$/.exec(ln);
        if (!mm) return;
        var p = U.normPath(mm[1].trim());
        if (!U.validPath(p) || seen[p] || plan.files.length >= 6) return;
        seen[p] = 1; plan.files.push({ path: p, purpose: (mm[2] || '').trim() || 'Part of the project' });
      });
      if (!plan.summary) plan.summary = U.clip(userText.replace(/\s+/g, ' '), 160, '');
      if (!plan.files.length) plan.files = A.fallbackFiles(userText, existing);
      if (plan.research && !plan.queries.length) plan.queries.push(U.clip(plan.summary, 90, ''));
      A.sortFiles(plan.files);
      return plan;
    },
    fallbackFiles: function (userText, existing) {
      var ex = existing || [];
      if (ex.length) {
        var named = ex.filter(function (p) { return userText.toLowerCase().indexOf(U.base(p).toLowerCase()) >= 0; });
        var pick = named.length ? named : ex.filter(function (p) { return /\.(html?|js|css)$/i.test(p); }).slice(0, 3);
        return pick.map(function (p) { return { path: p, purpose: 'Apply the requested change' }; });
      }
      if (/python|\.py\b/i.test(userText)) return [{ path: 'main.py', purpose: 'The program' }];
      return [{ path: 'index.html', purpose: 'Page structure and content' }, { path: 'style.css', purpose: 'All styling, responsive' }, { path: 'script.js', purpose: 'All behaviour' }];
    },
    sortFiles: function (files) {
      var rank = function (p) { var e = U.ext(p); return e === 'html' || e === 'htm' ? 0 : e === 'css' ? 1 : e === 'js' ? 2 : 3; };
      files.sort(function (a, b) { return rank(a.path) - rank(b.path); });
    },

    /** extract the code of an answer: longest fenced block (also when the closing fence is missing) */
    extractCode: function (text) {
      text = String(text || '');
      var parts = U.mdSplit(text).filter(function (x) { return x.type === 'code' && x.code.trim(); });
      if (parts.length) {
        parts.sort(function (a, b) { return b.code.length - a.code.length; });
        return { code: parts[0].code, open: parts[0].open, lang: parts[0].lang };
      }
      var t = text.trim();
      if (/^<!doctype|^<html|^[\w$.]+\s*[=(]|^(const|let|var|function|import|body|\*|:root|\.|#|@|def |class )/i.test(t)) return { code: t, open: false, lang: '' };
      var i = t.search(/<!doctype|<html/i);
      if (i > 0) return { code: t.slice(i), open: false, lang: 'html' };
      return { code: t, open: false, lang: '', weak: true };
    },
    /** cheap structural test: did the model stop in the middle of the file? */
    looksTruncated: function (path, code, open) {
      if (open) return true;
      var e = U.ext(path), c = code.trim();
      if (e === 'html' || e === 'htm') return /<html/i.test(c) && !/<\/html>\s*$/i.test(c);
      if (e === 'css' || e === 'js' || e === 'json' || e === 'mjs') {
        var o = (c.match(/\{/g) || []).length, cl = (c.match(/\}/g) || []).length;
        return o > cl;
      }
      return false;
    },
    /** short description of a file so other agents can match names without reading everything */
    digest: function (path, c) {
      var e = U.ext(path), out = [], seen = {};
      function add(x) { if (!seen[x] && out.length < 40) { seen[x] = 1; out.push(x); } }
      if (e === 'html' || e === 'htm') {
        c.replace(/\bid\s*=\s*["']([\w-]+)["']/g, function (_, i) { add('#' + i); });
        c.replace(/\bclass\s*=\s*["']([^"']+)["']/g, function (_, cl) { cl.split(/\s+/).forEach(function (k) { if (k) add('.' + k); }); });
        return 'ids/classes: ' + out.join(' ');
      }
      if (e === 'css') { c.replace(/([.#][\w-]+)\s*[{,:]/g, function (_, s) { add(s); }); return 'selectors: ' + out.join(' '); }
      if (e === 'js' || e === 'mjs') {
        c.replace(/\bfunction\s+([\w$]+)|\b(?:const|let|var)\s+([\w$]+)\s*=/g, function (_, a, b) { add(a || b); });
        return 'defines: ' + out.join(' ');
      }
      return U.clip(c.replace(/\s+/g, ' '), 160, '...');
    },
    stripThink: function (t) { return String(t || '').replace(/<think>[\s\S]*?(<\/think>|$)/gi, '').trim(); }
  };
})();
