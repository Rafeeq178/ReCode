/* ReCode - Phase 3: independent subagents. Each agent is a Markdown file with YAML frontmatter
   (.recode/agents/<name>.md): its own system prompt, tools, permission classes, turn limit, status and result.
   Agents run through the same agent loop but with their own isolated context and a restricted tool list.
   Stored in the app database (the project file system cannot hold dot-folders); export/import as .md files or ZIP. */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var U = RC.u;

  var REPORT = '\n\nWhen you are finished, reply in plain text (no TOOL lines) with a SHORT report, max 10 lines: what you found or did, files changed, open problems.';
  var READ = 'list_files, read_file, search_files, search_text, get_file_info, check_syntax';
  function md(name, desc, icon, triggers, tools, perms, turns, body) {
    return '---\nname: ' + name + '\ndescription: ' + desc + '\nicon: ' + icon + '\ntriggers: ' + triggers + '\ntools: ' + tools + '\npermissions: ' + perms + '\nmax_turns: ' + turns + '\nmax_tokens: 1200\n---\n' + body;
  }
  var DEFAULTS = {
    planner: md('planner', 'Breaks a large or complex request into ordered steps and names the files involved.', 'layers', 'plan, roadmap, steps, breakdown, large, complex, project, organize', READ, 'read', 5,
      'You are the Planner agent. You never change files. Inspect the project, then produce a numbered plan: each step names the file and what changes. Keep it under 12 steps. Mention risks and what to test.'),
    explorer: md('explorer', 'Reads and maps an existing project: structure, languages, entry points, related files.', 'search', 'understand, explore, structure, overview, where, find, locate, project, codebase, existing', READ, 'read', 6,
      'You are the Explorer agent. You never change files. Find out how the project is organised: entry page, scripts, styles, data, dependencies between files, naming conventions. Open only the files you need. Report facts with file names and line numbers.'),
    researcher: md('researcher', 'Looks up facts in the knowledge base and (when allowed) the web, then writes short sourced notes.', 'globe', 'research, latest, library, api, documentation, docs, how does, compare, version', READ + ', search_knowledge, web_search, web_read', 'read', 5,
      'You are the Researcher agent. You never change files. Use search_knowledge first, then web_search / web_read only if needed. Write at most 12 bullet notes, each with its source. Never invent facts; say when nothing was found.'),
    architect: md('architect', 'Designs the structure and the shared contract (ids, functions, data shapes) between files.', 'tool', 'architecture, architect, design, structure, contract, modules, layout, organize, schema', READ, 'read', 4,
      'You are the Architect agent. You never change files. Define the file layout and a precise contract: element ids, CSS classes, function names and signatures, data shapes, storage keys, which file owns what. Max 30 short lines, no code.'),
    frontend: md('frontend', 'Handles HTML, CSS, JavaScript and frontend development: pages, layout, responsive design, UI behaviour.', 'code', 'html, css, javascript, ui, layout, responsive, button, page, style, styling, design, dom, form, animation, mobile, screen', READ + ', write_file, edit_file, create_directory, run_tests', 'read, write, exec', 8,
      'You are a specialized frontend development agent. Follow project conventions. Inspect existing files before modifying them. Write clean, maintainable code that works offline (no CDN). Use edit_file for small changes. Verify your changes with check_syntax or run_tests.'),
    backend: md('backend', 'Handles server-side and application logic: APIs, data processing, business rules, scripts (Python, PHP, Node).', 'cpu', 'backend, server, api, endpoint, php, node, python, route, auth, login, logic, script, cli', READ + ', write_file, edit_file, create_directory, run_tests', 'read, write, exec', 8,
      'You are a backend development agent. Read the existing code first and keep its conventions. Validate inputs, handle errors, never hard-code secrets. Keep functions small. Verify with check_syntax or run_tests.'),
    database: md('database', 'Designs data models and storage: schemas, SQL, IndexedDB, localStorage, Firebase structures, migrations.', 'box', 'database, db, sql, schema, table, query, storage, indexeddb, firebase, data, model, migration, sqlite', READ + ', write_file, edit_file', 'read, write', 6,
      'You are a database agent. Inspect how data is stored now. Design the schema first (entities, keys, relations), then write the code or SQL. Keep it migration-safe: never drop existing data without saying so.'),
    coder: md('coder', 'General implementation: writes and edits code files for a clearly defined task.', 'code', 'write, implement, create, build, add, code, feature, function, class, make', READ + ', write_file, edit_file, create_directory, rename_file, move_file, run_tests', 'read, write, exec', 8,
      'You are the Coder agent. Implement exactly the task you are given. Read related files first, match their names and style, write complete working code, then verify with check_syntax or run_tests.'),
    debugger: md('debugger', 'Investigates bugs and failures: reproduces, finds the root cause, reports it. Does not change files.', 'bolt', 'bug, error, crash, broken, fails, failing, exception, not working, debug, wrong, undefined, stuck', READ + ', run_tests, run_command', 'read, exec', 6,
      'You are the Debugger agent. You never change files. Reproduce the problem with run_tests, read the failing code, and find the ROOT CAUSE. Report: symptom, cause, file and line, and the exact fix that should be made.'),
    fixer: md('fixer', 'Repairs known problems in code and re-tests, with minimal changes.', 'bolt', 'fix, repair, patch, resolve, correct, solve', READ + ', write_file, edit_file, run_tests', 'read, write, exec', 7,
      'You are the Fixer agent. You are given a problem. Make the smallest change that fixes it (edit_file preferred), keep everything that works, then run run_tests and confirm. Do not refactor unrelated code.'),
    tester: md('tester', 'Writes and runs tests, verifies behaviour, reports failures.', 'check', 'test, tests, testing, verify, coverage, assert, qa, regression', READ + ', write_file, run_tests', 'read, write, exec', 6,
      'You are the Tester agent. Write small test files named test*.js using test(name, fn) and assert(cond, msg), run run_tests, and report each failure with the likely cause. Never change the code under test.'),
    reviewer: md('reviewer', 'Reviews code quality, correctness and maintainability. Does not change files.', 'eye', 'review, quality, clean, refactor, readable, maintainable, best practice, smell, lint', READ, 'read', 5,
      'You are the Reviewer agent. You never change files. Read the code and list concrete problems by severity: bugs, risky logic, duplicated code, unclear names. Give file and line for each, and a one-line fix.'),
    security: md('security', 'Audits for security problems: XSS, injection, unsafe storage, secrets, unsafe permissions.', 'shield', 'security, vulnerability, xss, injection, password, secure, sanitize, secret, token, unsafe, csrf, auth', READ, 'read', 5,
      'You are the Security agent. You never change files. Search for innerHTML with user data, eval, unsanitised input, secrets in code, insecure storage, missing validation. Report each finding with file, line, impact and the fix.'),
    optimizer: md('optimizer', 'Improves speed, memory use and size without changing behaviour.', 'sliders', 'slow, performance, optimize, optimise, speed, faster, memory, lag, size, efficient', READ + ', write_file, edit_file, run_tests', 'read, write, exec', 7,
      'You are the Optimizer agent. Find the real bottleneck by reading the code (loops, DOM updates, repeated work), change only that, keep behaviour identical, and run run_tests afterwards. Say what you changed and why it is faster.'),
    documentation: md('documentation', 'Writes README files, code comments and usage docs.', 'book', 'docs, readme, document, documentation, comment, comments, explain, guide, usage, manual', READ + ', write_file, edit_file', 'read, write', 5,
      'You are the Documentation agent. Read the project, then write accurate docs: what it is, how to run it, file overview, important functions. Never document features that do not exist. Prefer README.md.')
  };
  var ORDER = ['planner', 'explorer', 'researcher', 'architect', 'frontend', 'backend', 'database', 'coder', 'debugger', 'fixer', 'tester', 'reviewer', 'security', 'optimizer', 'documentation'];
  var PERM_CLASSES = ['read', 'write', 'delete', 'exec'];

  // ------------------------------------------------------------------ markdown + YAML-lite
  function list(v) { return String(v || '').replace(/^\[|\]$/g, '').split(',').map(function (x) { return x.trim().replace(/^["']|["']$/g, ''); }).filter(Boolean); }
  function parse(text) {
    text = String(text || '').replace(/\r/g, '');
    var m = /^\s*---\n([\s\S]*?)\n---\s*\n?([\s\S]*)$/.exec(text);
    if (!m) return { meta: {}, body: text.trim(), error: 'Missing frontmatter. Start the file with --- and end it with --- before the instructions.' };
    var meta = {}, key = null;
    m[1].split('\n').forEach(function (ln) {
      var kv = /^([A-Za-z_][\w-]*)\s*:\s*(.*)$/.exec(ln), li = /^\s*-\s+(.*)$/.exec(ln);
      if (kv) { key = kv[1].toLowerCase().replace(/-/g, '_'); meta[key] = kv[2].trim(); }
      else if (li && key) meta[key] = (meta[key] ? meta[key] + ', ' : '') + li[1].trim();
    });
    return { meta: meta, body: m[2].trim() };
  }
  function serialize(a) {
    var l = ['---', 'name: ' + a.name, 'description: ' + a.description];
    if (a.icon) l.push('icon: ' + a.icon);
    if (a.triggers && a.triggers.length) l.push('triggers: ' + a.triggers.join(', '));
    l.push('tools: ' + a.tools.join(', '), 'permissions: ' + a.permissions.join(', '));
    if (a.max_turns) l.push('max_turns: ' + a.max_turns);
    if (a.max_tokens) l.push('max_tokens: ' + a.max_tokens);
    l.push('---', a.body);
    return l.join('\n');
  }
  /** -> {agent} or {error} */
  function build(text) {
    var p = parse(text);
    if (p.error) return { error: p.error };
    var m = p.meta, name = String(m.name || '').trim().toLowerCase();
    if (!/^[a-z][a-z0-9-]{1,30}$/.test(name)) return { error: 'name must be 2-31 chars: lowercase letters, digits and - (got "' + (m.name || '') + '")' };
    if (['agent', 'assistant', 'notes', 'main'].indexOf(name) >= 0) return { error: '"' + name + '" is reserved.' };
    if (!String(m.description || '').trim()) return { error: 'description is required (it is used to choose the agent).' };
    if (p.body.length < 20) return { error: 'The instructions below the frontmatter are too short.' };
    var tools = list(m.tools), perms = list(m.permissions || 'read').map(function (x) { return x.toLowerCase(); });
    var unknown = tools.filter(function (t) { return !RC.tools.registry[t]; });
    if (unknown.length) return { error: 'Unknown tool(s): ' + unknown.join(', ') + '. Available: ' + RC.tools.names().join(', ') };
    if (tools.indexOf('delegate') >= 0) return { error: 'Subagents cannot delegate to other agents.' };
    var badp = perms.filter(function (x) { return PERM_CLASSES.indexOf(x) < 0; });
    if (badp.length) return { error: 'Unknown permission(s): ' + badp.join(', ') + '. Use: ' + PERM_CLASSES.join(', ') };
    var turns = parseInt(m.max_turns, 10), tok = parseInt(m.max_tokens, 10);
    return { agent: {
      name: name, description: String(m.description).trim(), icon: m.icon || 'spark', triggers: list(m.triggers), tools: tools, permissions: perms,
      max_turns: Math.max(1, Math.min(20, isNaN(turns) ? 6 : turns)), max_tokens: Math.max(200, Math.min(4000, isNaN(tok) ? 1200 : tok)), body: p.body
    } };
  }

  // ------------------------------------------------------------------ registry
  var agents = {}, status = {}, builtinNames = ORDER.slice();
  function register(a, md, builtin, enabled) {
    a.md = md; a.builtin = builtin; a.enabled = enabled !== false;
    agents[a.name] = a;
    status[a.name] = status[a.name] || { state: 'idle', task: '', result: '', t0: 0, t1: 0, runs: 0 };
    RC.agents.def['sub:' + a.name] = { name: a.name.charAt(0).toUpperCase() + a.name.slice(1), icon: a.icon, max: a.max_tokens, on: a.enabled, desc: a.description, system: a.body, sub: true };
  }
  function loadDefaults() {
    ORDER.forEach(function (n) { var b = build(DEFAULTS[n]); if (b.error) throw new Error('default agent ' + n + ': ' + b.error); register(b.agent, DEFAULTS[n], true, true); });
  }
  function dbPut(n, o) { try { return RC.db.put('meta', Object.assign({ id: 'agent:' + n }, o)); } catch (e) { return Promise.resolve(); } }
  function dbDel(n) { try { return RC.db.del('meta', 'agent:' + n); } catch (e) { return Promise.resolve(); } }
  function emit() { RC.bus && RC.bus.emit('agents'); }

  var S = RC.subagents = {
    DEFAULTS: DEFAULTS, ORDER: ORDER, status: status, parse: parse, serialize: serialize,
    /** load saved edits / custom agents / disabled flags from the database */
    init: function () {
      return RC.db.all('meta').then(function (rows) {
        (rows || []).forEach(function (r) {
          if (!r || String(r.id).indexOf('agent:') !== 0) return;
          var n = r.id.slice(6);
          if (r.md) { var b = build(r.md); if (!b.error && b.agent.name === n) register(b.agent, r.md, builtinNames.indexOf(n) >= 0, r.enabled); }
          else if (agents[n]) { agents[n].enabled = r.enabled !== false; RC.agents.def['sub:' + n].on = agents[n].enabled; }
        });
        emit();
      }).catch(function () { });
    },
    names: function (all) { return Object.keys(agents).filter(function (n) { return all || agents[n].enabled; }).sort(function (a, b) { var i = ORDER.indexOf(a), j = ORDER.indexOf(b); return (i < 0 ? 99 : i) - (j < 0 ? 99 : j) || a.localeCompare(b); }); },
    get: function (n) { return agents[String(n || '').toLowerCase().replace(/^@/, '').replace(/^sub:/, '')] || null; },
    /** save markdown (create or edit). -> {ok, agent} | {ok:false, error} */
    save: function (text) {
      var b = build(text);
      if (b.error) return { ok: false, error: b.error };
      var old = agents[b.agent.name], en = old ? old.enabled : true;
      register(b.agent, text, builtinNames.indexOf(b.agent.name) >= 0, en);
      dbPut(b.agent.name, { md: text, enabled: en });
      emit(); return { ok: true, agent: b.agent };
    },
    /** custom agents are deleted; built-in agents are reset to their default text */
    remove: function (n) {
      var a = S.get(n); if (!a) return false;
      dbDel(a.name);
      if (a.builtin) { var b = build(DEFAULTS[a.name]); register(b.agent, DEFAULTS[a.name], true, true); }
      else { delete agents[a.name]; delete RC.agents.def['sub:' + a.name]; delete status[a.name]; }
      emit(); return true;
    },
    setEnabled: function (n, on) {
      var a = S.get(n); if (!a) return false;
      a.enabled = !!on; RC.agents.def['sub:' + a.name].on = a.enabled;
      dbPut(a.name, { md: a.md, enabled: a.enabled }); emit(); return true;
    },
    /** tools an agent may really use: its list, limited to its permission classes, never delegate */
    effectiveTools: function (n) {
      var a = S.get(n); if (!a) return [];
      return a.tools.filter(function (t) { var d = RC.tools.registry[t]; return d && t !== 'delegate' && a.permissions.indexOf(d.perm) >= 0; });
    },
    parallelSafe: function (n) {
      var a = S.get(n); if (!a || !a.enabled) return false;
      var t = S.effectiveTools(n); return !!t.length && t.every(function (x) { return RC.tools.registry[x].perm === 'read'; });
    },
    /** import {name, text} files (.md) -> [{name, ok, error}] */
    importFiles: function (files) {
      return files.map(function (f) { var r = S.save(f.text); return { name: f.name, ok: r.ok, error: r.error }; });
    },
    exportOne: function (n) { var a = S.get(n); return a ? { name: '.recode/agents/' + a.name + '.md', text: a.md } : null; },
    /** ZIP bytes with every agent as .recode/agents/<name>.md */
    exportZip: function () { return U.zip(S.names(true).map(function (n) { var e = S.exportOne(n); return { name: e.name, data: e.text }; })); },

    // -------------------------------------------------------------- dynamic selection
    /** best matching enabled agents for a request. Returns [] when the task is simple enough for the main agent. */
    select: function (text, max) {
      var words = (String(text || '').toLowerCase().match(/[a-z0-9]+/g) || []);
      if (!words.length) return [];
      var set = {}; words.forEach(function (w) { if (w.length > 2) set[w] = 1; });
      var res = [];
      S.names().forEach(function (n) {
        var a = agents[n], sc = 0, seen = {};
        function hit(term, wgt) { term.split(/\s+/).forEach(function (t) { if (set[t] && !seen[t]) { seen[t] = 1; sc += wgt; } }); }
        hit(a.name, 3);
        a.triggers.forEach(function (t) { hit(t, 2); });
        (a.description.toLowerCase().match(/[a-z0-9]+/g) || []).forEach(function (t) { if (t.length > 3) hit(t, 0.5); });
        if (sc >= 2) res.push({ name: n, score: sc, description: a.description });
      });
      res.sort(function (x, y) { return y.score - x.score; });
      if (words.length <= 6 && (!res[0] || res[0].score < 3)) return [];
      return res.slice(0, max || 3);
    },
    /** "@frontend make the button blue" -> {name, task} | null */
    manual: function (text) {
      var m = /^\s*@([a-z][a-z0-9-]*)\s+([\s\S]+)$/i.exec(String(text || ''));
      if (!m) return null;
      var a = S.get(m[1]);
      return a && a.enabled ? { name: a.name, task: m[2].trim() } : null;
    },
    /** options for RC.agentLoop for this agent */
    loopOpts: function (n) {
      var a = S.get(n);
      return { agent: 'sub:' + a.name, system: a.body + REPORT, tools: S.effectiveTools(a.name), maxIter: a.max_turns, maxTokens: a.max_tokens, label: a.name };
    },
    roster: function (names, desc) { return names.map(function (n) { var a = agents[n]; return a ? a.name + ' - ' + U.clip(a.description, desc || 80, '…') : ''; }).filter(Boolean).join('\n'); },

    // -------------------------------------------------------------- execution
    /** run one subagent in its own isolated context. -> {ok, name, text, files, verified} (never throws except on cancel) */
    run: async function (name, task, o) {
      o = o || {};
      var a = S.get(name);
      if (!a) return { ok: false, name: name, text: 'No agent named "' + name + '". Available: ' + S.names().join(', ') };
      if (!a.enabled) return { ok: false, name: a.name, text: 'Agent "' + a.name + '" is disabled.' };
      if (!String(task || '').trim()) return { ok: false, name: a.name, text: 'No task given for agent "' + a.name + '".' };
      var st = status[a.name]; st.state = 'running'; st.task = U.clip(task, 120, '…'); st.t0 = Date.now(); st.t1 = 0; st.runs++; emit();
      var goal = o.goal ? 'Overall goal: ' + U.clip(o.goal, 300, '…') + '\n' : '';
      var bb = { text: goal + 'YOUR TASK: ' + task };
      try {
        var r = await RC.agentLoop(o.run, bb, RC.pipe.H, Object.assign(S.loopOpts(a.name), { sub: true, depth: (o.depth || 0) + 1 }));
        var files = (r.state && r.state.modified) || [];
        var text = U.clip(String(r.final || '').trim() || '(no report)', 900, '…') + (files.length ? '\nFiles changed: ' + files.join(', ') + (r.state.verified ? ' (verified)' : ' (NOT verified)') : '');
        st.state = r.error ? 'error' : 'done'; st.result = text; st.t1 = Date.now(); emit();
        return { ok: !r.error, name: a.name, text: text, files: files, verified: r.state ? r.state.verified : true };
      } catch (e) {
        st.state = e && e.name === 'AbortError' ? 'cancelled' : 'error'; st.t1 = Date.now(); st.result = e && e.message || ''; emit();
        if (e && e.name === 'AbortError') throw e;
        return { ok: false, name: a.name, text: 'Agent "' + a.name + '" failed: ' + (e && e.message || e) };
      }
    }
  };
  loadDefaults();
})();
