/* ReCode - Settings: everything is user controlled (appearance, generation, agents, preview, data, diagnostics). */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var U = RC.u, h = U.h, UI = RC.ui, St = RC.store, N = RC.native;
  var root = U.$('#v-set'), body = h('div.scroll'), page = null;
  root.appendChild(body);

  function agents() {
    var box = h('div');
    box.appendChild(h('div.t2', { style: { marginBottom: '8px' } }, 'Each agent runs as its own isolated step. Change its role text or answer length, or switch optional agents off.'));
    RC.agents.order.forEach(function (id) {
      var d = RC.agents.def[id], cfg = RC.settings.agents[id] = RC.settings.agents[id] || {}, cur = RC.agentCfg(id);
      var ta = h('textarea.in', { value: cur.prompt, style: { minHeight: '140px' }, onchange: function () { cfg.prompt = ta.value === d.system ? '' : ta.value; RC.saveSettings(); } });
      ta.value = cur.prompt;
      var b = h('b', String(cur.max));
      var rg = h('input', { type: 'range', min: 100, max: 3000, step: 50, value: cur.max, oninput: function () { b.textContent = rg.value; cfg.max = +rg.value; }, onchange: function () { RC.saveSettings(); } });
      var tog = h('div.tog' + (cur.on ? '.on' : ''));
      var det = h('details.d', { style: { background: 'var(--card)', border: '1px solid var(--line)' } },
        h('summary', h('span', { html: RC.i(d.icon, 16), style: { color: 'var(--brand)', marginRight: '8px', verticalAlign: 'middle' } }), d.name, h('span.t2', ' - ' + d.desc)),
        d.locked ? null : h('button.setrow', { style: { width: '100%', textAlign: 'left' }, onclick: function () { cfg.on = !RC.agentCfg(id).on; tog.classList.toggle('on', cfg.on); RC.saveSettings(); } }, h('div.grow', h('div.t1', 'Enabled')), tog),
        h('div.setrow', h('div.grow', h('div.t1', 'Max answer tokens')), h('div.slider', rg, b)),
        UI.field('Role (system prompt)', ta),
        UI.btn('Reset to default', 'refresh', 'sm ghost', function () { delete RC.settings.agents[id]; RC.saveSettings(); sub('agents'); }));
      box.appendChild(det);
    });
    // specialist subagents: Markdown files (.recode/agents/<name>.md)
    var SA = RC.subagents;
    if (SA) {
      box.appendChild(h('div.sec', 'Specialist agents'));
      box.appendChild(h('div.t2', { style: { marginBottom: '8px' } }, 'Each specialist is a Markdown file with its own instructions, tools and permissions. The main agent hands work to them with the delegate tool, or you can write @name at the start of a message.'));
      SA.names(true).forEach(function (n) {
        var a = SA.get(n), tg = h('div.tog' + (a.enabled ? '.on' : ''));
        box.appendChild(h('div.card', { style: { marginBottom: '8px' } },
          h('button.setrow', { style: { width: '100%', textAlign: 'left' }, onclick: function () { SA.setEnabled(n, !SA.get(n).enabled); tg.classList.toggle('on', SA.get(n).enabled); } },
            h('div.grow', h('div.t1', a.name + (a.builtin ? '' : ' (custom)')), h('div.t2', a.description + ' · tools: ' + SA.effectiveTools(n).length)), tg),
          h('div.row', { style: { gap: '8px', paddingTop: '6px' } },
            UI.btn('Edit .md', 'edit', 'sm', function () { editAgent(n); }),
            UI.btn(a.builtin ? 'Reset' : 'Delete', a.builtin ? 'refresh' : 'trash', 'sm ghost', function () { UI.confirm((a.builtin ? 'Reset ' : 'Delete ') + n + '?', a.builtin ? 'Reset' : 'Delete', true).then(function (y) { if (y) { SA.remove(n); sub('agents'); } }); }))));
      });
      box.appendChild(h('div.row', { style: { gap: '8px' } },
        UI.btn('New agent', 'plus', 'sm', function () { editAgent(null); }),
        UI.btn('Export all (ZIP)', 'download', 'sm ghost', function () { N.save('recode-agents.zip', SA.exportZip(), 'application/zip').then(function () { UI.toast('Saved'); }, function (e) { if (e.message !== 'cancelled') UI.toast(e.message); }); })));
    }
    return box;
  }
  function editAgent(n) {
    var SA = RC.subagents, tpl = n ? SA.get(n).md : '---\nname: my-agent\ndescription: What this agent is good at (used to choose it).\ntools: list_files, read_file, search_text\npermissions: read\nmax_turns: 5\n---\nYou are a specialized agent. Describe your role and rules here.';
    UI.prompt(n ? 'Edit ' + n + '.md' : 'New agent', tpl, '', true).then(function (v) {
      if (v == null) return;
      var r = SA.save(v);
      if (!r.ok) { UI.toast(r.error); return; }
      UI.toast('Saved ' + r.agent.name); sub('agents');
    });
  }
  function sub(name) {
    page = name;
    UI.sheetStack.length && UI.closeSheet(true);
    var titles = { agents: 'Agents' };
    UI.sheet({ title: titles[name], body: agents(), onClose: function () { page = null; } });
  }

  function diag() {
    var i = N.info() || {}, box = h('div');
    [['App', 'ReCode ' + (i.version || '')], ['Android', i.android], ['Device', i.device], ['CPU', i.abis], ['RAM', i.ramMB ? i.ramMB + ' MB' : ''], ['Free storage', i.freeMB ? i.freeMB + ' MB' : '']].forEach(function (r) {
      if (r[1]) box.appendChild(h('div.setrow', h('div.grow', h('div.t1', r[0])), h('div.t2', r[1])));
    });
    if (i.crash) {
      box.appendChild(h('div.sec', 'Last crash'));
      box.appendChild(h('pre.code', { style: { maxHeight: '240px', overflow: 'auto', whiteSpace: 'pre-wrap' } }, i.crash));
      box.appendChild(h('div.row', { style: { marginTop: '10px' } }, UI.btn('Copy', 'copy', 'sm', function () { N.copy(i.crash); UI.toast('Copied'); }), UI.btn('Clear', 'trash', 'sm danger', function () { N.call('clearCrash'); UI.closeSheet(true); paint(); })));
    } else box.appendChild(h('div.t2', { style: { marginTop: '10px' } }, 'No crash recorded.'));
    UI.sheet({ title: 'Diagnostics', body: box });
  }

  function paint() {
    var k = body.scrollTop, S = RC.settings; U.clear(body);
    body.appendChild(UI.card(h('div.row', h('div', { html: RC.logo(46) }), h('div.grow', h('div.t1', 'ReCode'), h('div.t2', 'Private multi-agent coder')), h('span.badge', N.has ? 'Offline ready' : 'Preview'))));
    body.appendChild(UI.sec('Appearance'));
    body.appendChild(UI.card(UI.seg([['light', 'Light'], ['dark', 'Dark'], ['system', 'System']], S.theme, function (v) { RC.set('theme', v); UI.applyTheme(); })));
    body.appendChild(UI.sec('Team'));
    body.appendChild(UI.card(
      UI.row({ icon: 'layers', title: 'Agents', sub: 'Roles, answer length, on/off', onclick: function () { sub('agents'); }, right: h('span', { html: RC.i('chevR', 16) }) }), h('div.hr'),
      UI.row({ icon: 'shield', title: 'Permissions and hooks', sub: 'Plan / Ask / Auto, tool rules, file rules, history', onclick: function () { UI.openPerms(); }, right: h('span', { html: RC.i('chevR', 16) }) })));
    body.appendChild(UI.card(
      UI.toggle('autoResearch', 'Internet research', 'Planner may search the web when it needs facts (needs internet)'),
      UI.toggle('architect', 'Architect step', 'Shared contract so all files match'),
      UI.toggle('review', 'Test and auto-fix', 'Runs the page, finds errors, asks the Fixer to repair'),
      UI.slider('fixLoops', 'Fix rounds', 0, 4, 1, function (v) { return String(v); }),
      UI.slider('maxIter', 'Agent turns', 3, 30, 1, function (v) { return String(v); }, 'Agent mode: maximum model turns per request'),
      UI.toggle('autoAgent', 'Auto uses the Agent', 'Build requests in Auto mode run the tool-calling agent instead of the classic pipeline'),
      UI.toggle('useTemplates', 'Tested templates', 'Calculator, snake game and todo app requests start from a project that was tested (the model then only adapts it)')));
    body.appendChild(UI.sec('Memory and context'));
    body.appendChild(UI.card(
      UI.toggle('useNotes', 'Project notes (RECODE.md)', 'Agents read this file first in every run. Add facts with the remember tool or edit it yourself'),
      UI.slider('notesChars', 'Notes in the prompt', 300, 2500, 100, function (v) { return v + ' chars'; }, 'How much of RECODE.md an agent sees'),
      UI.row({ icon: 'edit', title: 'Edit project notes', sub: 'Opens RECODE.md in the Files view (created if missing)', onclick: function () { RC.mem.notesFile.ensure().then(function (n) { UI.mods.files.open(n); }); }, right: h('span', { html: RC.i('chevR', 16) }) }), h('div.hr'),
      UI.toggle('autoCompact', 'Compact long runs', 'Old steps become a short summary instead of being forgotten (no extra model call)'),
      UI.slider('compactKeep', 'Steps kept word for word', 2, 12, 1, function (v) { return String(v); }, 'The newest transcript entries that are never compacted')));
    body.appendChild(UI.sec('Knowledge'));
    body.appendChild(UI.card(UI.toggle('useRag', 'Use knowledge (RAG)', 'Search your documents before planning and coding'),
      UI.toggle('ragFiles', 'Include project files', 'Let agents find passages in your own files'),
      UI.slider('ragK', 'Passages per search', 1, 6, 1, function (v) { return String(v); })));
    body.appendChild(UI.sec('Generation'));
    body.appendChild(UI.card(
      UI.slider('ctxChars', 'Context per agent', 3000, 14000, 500, function (v) { return Math.round(v / 100) / 10 + 'k'; }, 'Characters handed to one agent. Small models: keep ~7k'),
      UI.slider('maxFile', 'Code file length', 400, 3000, 100, function (v) { return v + ' tok'; }, 'Used when the Coder agent has no own limit'),
      UI.toggle('keepAwake', 'Keep screen on while working', 'Android may pause long jobs in the background')));
    body.appendChild(UI.sec('Preview'));
    body.appendChild(UI.card(UI.toggle('autoPreview', 'Refresh preview automatically', 'When files change'),
      UI.toggle('netPreview', 'Allow internet in preview', 'Off = the page is fully offline and cannot call servers')));
    body.appendChild(UI.sec('Data'));
    body.appendChild(UI.card(
      UI.row({ icon: 'download', title: 'Export project as ZIP', onclick: function () { UI.downloadZip(); } }), h('div.hr'),
      UI.row({ icon: 'trash', title: 'Clear this chat', sub: 'Files are kept', onclick: function () { UI.confirm('Clear the chat of this project?', 'Clear', true).then(function (y) { if (y) St.clearMsgs().then(function () { UI.toast('Cleared'); RC.bus.emit('project'); }); }); } }), h('div.hr'),
      UI.row({ icon: 'refresh', title: 'Reset all settings', onclick: function () { UI.confirm('Reset every setting to default? Models and projects stay.', 'Reset', true).then(function (y) { if (y) { RC.settings = JSON.parse(JSON.stringify(RC.defaults)); RC.saveSettings(); UI.applyTheme(); paint(); } }); } })));
    body.appendChild(UI.sec('About'));
    body.appendChild(UI.card(UI.row({ icon: 'info', title: 'Diagnostics', sub: 'Version, device, last crash', onclick: diag, right: h('span', { html: RC.i('chevR', 16) }) }),
      h('div.t2', { style: { marginTop: '10px' } }, 'ReCode has no server and no account. Models, projects and keys stay on this phone. The internet is used only for web research, downloads and the optional online API.')));
    body.scrollTop = k;
  }
  RC.bus.on('project', function () { if (root.classList.contains('on')) paint(); });
  UI.mods.set = { show: paint };
})();
