RECODE - private multi-agent coding app for Android (offline GGUF, llama.cpp)

BUILD (GitHub only)
  1. Put ReCode_v1.zip and .github/workflows/build.yml in a GitHub repo (main branch). Push.
  2. Actions -> "Build APK" -> download ReCode-debug.apk from the Release. Android 10+, arm64.
  3. Newer version = upload ReCode_v2.zip; the workflow builds the highest ReCode_v*.zip.
  debug.keystore inside the project keeps the signature fixed so updates install over each other.

HOW IT WORKS
  - UI + agents are HTML/CSS/JS in app/src/main/assets/www (shown in a WebView, works offline).
  - Kotlin is only the bridge (Bridge.kt): llama.cpp model, downloads, file picker, save, web search.
  - Every agent step RELOADS the model with that agent's own system prompt and gets only the hand-over text
    from the orchestrator (js/pipeline.js): Planner -> Researcher -> Architect -> Coder (file by file)
    -> checks -> Fixer -> optional ZIP. Activity (Summary) shows each step live and what each agent knew.
  - Runner: project files are bundled and run in a sandboxed iframe, no network unless enabled in Settings.
  - RAG: BM25 keyword search over your documents and project files (no neural embeddings: the llama.cpp
    Android library has no embedding API).
  - Online API (OpenAI compatible) is optional and needs internet; web research needs internet.

LIMITS
  - Temperature/sampler of the local model is fixed by the llama.cpp Android library.
  - Local context is small (~4k tokens): that is why work is split into small isolated steps.
  - Output files are text (html, css, js, json, md, py ... and ZIP). Not docx/pdf/images.
  - Not compiled here (no Android SDK in the build sandbox): the first CI run may show a Kotlin error
    in the build log - send it and it gets fixed. The web UI and agent pipeline were tested in a browser
    with a mock model; the real model behaviour depends on the GGUF you choose.

UPGRADE PHASE 1 (agent loop + tools) - ReCode_v2
  - New "Agent" chip in the chat. The model picks each next action: it calls tools, gets the results, repeats until
    it writes a final answer (js/loop.js). Max turns: Settings maxIter (default 12). Stop button cancels.
  - Tools (js/tools.js): read_file, write_file, edit_file, delete_file, list_files, search_files, search_text,
    create_directory, rename_file, move_file, get_file_info, run_command, check_syntax, run_tests.
    They only touch the open project (no disk access, paths like ../ or /abs are rejected).
  - Tool calls: text form "TOOL: read_file | index.html" (+ code block for write_file / edit_file) for small models;
    also accepts JSON / <tool_call> / OpenAI tool_calls shapes in the reply text.
  - Safety for now: delete_file is DENIED by default, run_command only has built-ins (run, check, ls, cat, grep, wc;
    there is no shell on the phone). Changed files must be verified (check_syntax / run_tests) before the final answer.
  - The classic Build / Chat / Research pipeline is unchanged. Settings autoAgent=true makes Auto use the agent loop.
  - Tests: node tests/phase1.test.js (67 checks, mock model). Not yet run on a real phone / real GGUF model.
  - (superseded by Phase 2 below: delete is still DENY by default, but now configurable)
  - NOT done yet (later phases): memory, compaction, skills, todo,
    checkpoints, MCP, workflows, settings screens for these. True structured API tool-calling needs a Kotlin
    Bridge change (apiRun is text-only today).

UPGRADE PHASE 2 (hooks, permissions, plan/ask/auto) - ReCode_v3
  - Permission manager (js/perms.js): levels ALLOW / ASK / DENY, strictest wins (DENY > ASK > ALLOW).
    Sources: tool rule (project override > global > default), file rules (glob + level), dangerous commands,
    delete confirmation, overwrite confirmation. Defaults: read tools ALLOW, write/edit/move/command ASK, delete DENY.
    Every tool call goes through it; DENY is never bypassed, in any mode. Permission history is kept (last 200).
  - Modes (chips appear under Agent): Plan = read-only, the agent returns a plan with Approve / Edit plan / Reject;
    Ask = approval dialog (Allow once / Always allow in this project / Deny); Auto-approve = ASK is approved
    automatically, but deletes still ask.
  - Hooks (js/hooks.js): SessionStart, SessionEnd, UserPromptSubmit, PreToolUse, PostToolUse, Stop, PreCompact.
    Built in: dangerous-command block, overwrite protection, project structure checks, backup before changes,
    auto-format, syntax check after writes, error hints, and a Stop check that sends the agent back if files
    still have syntax errors (optional full test run). A PreToolUse hook can block or rewrite a call.
    A hook that crashes never crashes a run; safety hooks fail closed. User hooks: settings.hooks.custom.
  - Settings > Permissions and hooks: mode, per-tool rules (all projects / this project), file rules, safety
    toggles, hook toggles, history. Settings > Agent turns / Auto uses the Agent.
  - Tests: node tests/phase1.test.js and node tests/phase2.test.js (mock model). The new dialogs and settings
    screens were not opened in a browser or on a phone yet.
  - PreCompact is defined but nothing triggers it until Phase 4 (context compaction).

UPGRADE PHASE 3 (subagents + dynamic selection) - ReCode_v4
  - 15 specialist agents as Markdown + YAML frontmatter (js/subagents.js): planner, explorer, researcher, architect,
    frontend, backend, database, coder, debugger, fixer, tester, reviewer, security, optimizer, documentation.
    Frontmatter: name, description, tools, permissions (read/write/exec/delete), triggers, max_turns, max_tokens.
    Each runs with its own system prompt, ONLY its own tools (further capped by its permission classes), a fresh
    isolated context, status and a short report back to the main agent. They never delegate further.
  - Stored in the app database as .recode/agents/<name>.md (the project file system cannot hold dot-folders).
    Settings > Agents > Specialist agents: enable/disable, Edit .md, New, Reset/Delete, Export ZIP.
    Import: RC.subagents.importFiles([{name,text}]) (no file-picker screen yet).
  - Selection: the main agent sees only the 1-3 best matching specialists for the request (small requests get none),
    and calls TOOL: delegate | agent | task. Manual: start a message with @frontend ... to talk to one directly.
    Several read-only specialists requested in one turn run side by side; note the model queue in llm.js still
    serialises model calls, so on-device this is scheduling, not a speed-up.
  - Subagents inherit the permission mode (Plan = read-only) and all hooks. Classic pipeline agents are untouched
    (subagent ids are "sub:<name>").
  - New tools: delegate, search_knowledge (BM25), web_search / web_read (ASK by default; only for agents that list them).
  - Tests: node tests/phase1|phase2|phase3.test.js (all pass, mock model). UI not opened on a phone yet.

UPGRADE PHASE 4 (memory, todo, context compaction) - ReCode_v6
  - New js/memory.js. Three things, all for the Agent (also used by specialists where noted):
  - RECODE.md (project notes): a normal project file. Every agent run reads it first and puts it at the top of the prompt
    (Settings > Memory and context: on/off, how many characters). The agent saves lasting facts with
    TOOL: remember | text  (appends "- text", no duplicates, 3000 character limit, blocked in Plan mode, permission default ALLOW).
    You can edit it yourself: Settings > Edit project notes (creates it if missing). Lower-case recode.md also works.
    It is a project file, so it is included in the ZIP export. Specialists see a shorter copy.
  - todo tool: TOOL: todo | set | step one; step two  /  add / start N / done N / remove N / list / clear. Max 12 items.
    The list is shown in every prompt of the main agent, is stored in the project, and before the final answer the agent is
    reminded once if items are still open. A new request starts with an empty list; saying "continue" keeps unfinished items.
    Works in Plan mode (it does not change files). Specialists cannot use it.
  - Compaction: when an agent run gets long (transcript beyond ~80% of its share of the prompt, or more than 20 entries)
    the oldest steps are folded into a short summary (changed files, checks, problems seen, specialist reports, files read,
    last words) and only the newest steps (Settings > Steps kept word for word, default 6) stay in full. It is deterministic,
    so it costs no extra model call. It shows as a "Compacting context" step in Activity. The PreCompact hook now fires:
    payload {entries, chars, reason, state, todos}; {block:true} skips it, {feedback} text is kept in the summary.
  - Tests: node tests/phase1|phase2|phase3|phase4.test.js (all pass, mock model). Not yet run on a phone / real GGUF model.
  - NOT done yet: model-written summaries, checkpoints/undo, skills, MCP, workflows, loading the model once for all steps,
    notes/todo for the classic Build pipeline.

