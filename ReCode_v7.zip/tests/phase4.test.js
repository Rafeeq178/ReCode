// Phase 4 tests: todo tool, RECODE.md notes, context compaction (mock model, in-memory store). Run: node tests/phase4.test.js
const fs = require('fs'), path = require('path'), vm = require('vm');
const WWW = path.join(__dirname, '../ReCode/app/src/main/assets/www/js/');
const win = { RC: {}, addEventListener() {}, matchMedia: null };
global.window = win; global.document = { createElement() { return { style: {}, setAttribute() {}, remove() {} }; }, createTextNode: t => t, body: {}, querySelector() {} };
global.navigator = { onLine: true }; global.localStorage = { getItem() { return null; }, setItem() {} };
global.AbortController = AbortController;
const RC = win.RC;
function load(f) { vm.runInThisContext(fs.readFileSync(WWW + f, 'utf8'), { filename: f }); }
load('util.js');
// in-memory store, same surface as RC.store
const files = {};
RC.store = { files, cur: { id: 'p', name: 't' }, fileList: () => Object.keys(files).sort(),
  putFile: async (p, c) => { files[p] = c; }, delFile: async p => { delete files[p]; }, touch() {} };
RC.bus = { emit() {}, on() {} };
RC.saveSettings = () => {}; RC.set = (k, v) => { RC.settings[k] = v; };
RC.native = { call() {}, online: () => true, keepAwake() {} };
RC.settings = { maxIter: 6, ctxChars: 4000, agents: {}, provider: 'local', keepAwake: false, permMode: 'auto', perms: { global: {}, files: [], confirmDelete: true, confirmOverwrite: true, dangerous: 'deny' }, hooks: { format: true, syntax: true, overwrite: true, backup: true, structure: true, errors: true, autoTest: false, maxFiles: 60, custom: [] } };
RC.agentCfg = id => ({ on: true, max: 800, prompt: RC.agents.def[id].system });
RC.run = { entry: f => f['index.html'] ? 'index.html' : null, check: async () => ({ issues: [], fixes: [], ran: true }), probe: async () => ({ errors: [], logs: [] }) };
let script = [], prompts = [];
RC.llm = { AbortErr() { const e = new Error('Stopped'); e.name = 'AbortError'; return e; },
  run: async o => { prompts.push(o); if (!script.length) throw new Error('script exhausted'); const r = script.shift(); return typeof r === 'function' ? r(o) : r; } };

load('agents.js'); load('tools.js'); load('memory.js'); load('hooks.js'); load('perms.js'); load('pipeline.js'); load('loop.js');
const T = RC.tools, M = RC.mem, P = RC.perms;
let pass = 0, fail = 0;
function ok(c, m) { if (c) pass++; else { fail++; console.log('FAIL', m); } }
const ex = (name, args, ctx) => T.exec({ name, args }, Object.assign({ touch() {} }, ctx || {}));
function reset() {
  for (const k of Object.keys(files)) delete files[k];
  RC.store.cur = { id: 'p', name: 't' };
  RC.settings.permMode = 'auto'; RC.settings.maxIter = 10; RC.settings.ctxChars = 7000;
  RC.settings.autoCompact = true; RC.settings.compactKeep = 6; RC.settings.useNotes = true; RC.settings.notesChars = 1000;
  RC.settings.hooks = { format: false, syntax: true, overwrite: true, backup: true, structure: true, errors: true, autoTest: false, maxFiles: 60, custom: [] };
  P.requester = null; script = []; prompts = [];
}
function run(text) { return RC.pipe.start(text, 'agent').done; }
(async () => {
  reset();
  // ---- registration, permissions, parser
  ok(T.registry.todo && T.registry.remember, 'tools registered');
  ok(T.registry.todo.perm === 'read' && T.registry.remember.perm === 'write', 'perm classes');
  ok(P.DEFAULTS.todo === 'allow' && P.DEFAULTS.remember === 'allow', 'default permissions');
  let pr = T.parse('TOOL: todo | set | write index.html; write style.css; check it');
  ok(pr.calls.length === 1 && pr.calls[0].name === 'todo' && pr.calls[0].args.action === 'set' && pr.calls[0].args.text === 'write index.html; write style.css; check it', 'parse todo set ' + JSON.stringify(pr));
  pr = T.parse('TOOL: todo | add | fix a | b');
  ok(pr.calls[0].args.text === 'fix a | b', 'parse todo text with pipe');
  pr = T.parse('TOOL: remember | uses tabs | no CDN');
  ok(pr.calls[0].name === 'remember' && pr.calls[0].args.text === 'uses tabs | no CDN', 'parse remember');
  pr = T.parse('TOOL: note | something');
  ok(pr.calls[0] && pr.calls[0].name === 'remember', 'alias note -> remember');
  pr = T.parse('{"tool":"todo","args":{"action":"done","text":"2"}}');
  ok(pr.calls[0].name === 'todo' && pr.calls[0].args.action === 'done', 'json todo call');
  pr = T.parse('TOOL: todo');
  ok(pr.calls.length === 1 && pr.errors.length === 0, 'bare todo is a list call');

  // ---- todo list
  let r = await ex('todo', { action: 'list' });
  ok(r.ok && /empty/.test(r.out), 'empty list');
  r = await ex('todo', { action: 'set', text: 'write index.html; write style.css; check it' });
  ok(r.ok && /1\. write index.html/.test(r.out) && /\[ \] 3\. check it/.test(r.out), 'set: ' + r.out);
  r = await ex('todo', { action: 'start', text: '1' });
  ok(/\[~\] 1\./.test(r.out), 'start');
  r = await ex('todo', { action: 'done', text: '1, 2' });
  ok(/\[x\] 1\./.test(r.out) && /\[x\] 2\./.test(r.out) && /\[ \] 3\./.test(r.out) && !/All items/.test(r.out), 'done 1,2');
  r = await ex('todo', { action: 'done', text: 'check' });
  ok(/All items are done/.test(r.out), 'done by text, all finished hint: ' + r.out);
  ok(M.todo.open().length === 0, 'no open items');
  r = await ex('todo', { action: 'add', text: 'ship it' });
  ok(r.ok && /4\. ship it/.test(r.out) && M.todo.open().length === 1, 'add');
  r = await ex('todo', { action: 'remove', text: '1' });
  ok(r.ok && !/write index/.test(r.out) && /1\. write style.css/.test(r.out), 'remove');
  r = await ex('todo', { action: 'done', text: '9' });
  ok(!r.ok && /No such item/.test(r.out), 'bad number');
  r = await ex('todo', { action: 'Write index.html' });
  ok(r.ok && /Write index.html/.test(r.out), 'unknown action is added as an item');
  r = await ex('todo', { action: 'done', text: 'all' });
  ok(r.ok && M.todo.open().length === 0, 'done all');
  r = await ex('todo', { action: 'clear' });
  ok(r.ok && M.todo.items().length === 0, 'clear');
  r = await ex('todo', { action: 'set', text: Array.from({ length: 13 }, (_, i) => 'item ' + i).join('; ') });
  ok(!r.ok && /12 items/.test(r.out), 'limit 12');
  r = await ex('todo', { action: 'add', text: '' });
  ok(!r.ok && /item text/.test(r.out), 'empty add');
  r = await ex('todo', { action: 'list' }, { depth: 1 });
  ok(!r.ok && /Specialists/.test(r.out), 'specialists cannot use todo');
  r = await ex('todo', { action: 'set', text: 'a; b' }, { mode: 'plan' });
  ok(r.ok, 'todo works in plan mode (read-only class)');
  // lifecycle across requests
  M.todo.startRun(false);
  ok(M.todo.items().length === 0, 'new request clears the list');
  await ex('todo', { action: 'set', text: 'a; b' }); await ex('todo', { action: 'done', text: '1' });
  M.todo.startRun(true);
  ok(M.todo.items().length === 2, 'continue keeps unfinished list');
  await ex('todo', { action: 'done', text: 'all' });
  M.todo.startRun(true);
  ok(M.todo.items().length === 0, 'finished list is dropped even on continue');

  // ---- RECODE.md notes
  reset();
  ok(!M.notesFile.exists() && M.notes(500) === '', 'no notes yet');
  r = await ex('remember', { text: 'uses tabs, no frameworks' });
  ok(r.ok && files['RECODE.md'] && /^# Project notes/.test(files['RECODE.md']) && /- uses tabs, no frameworks/.test(files['RECODE.md']), 'remember creates RECODE.md: ' + r.out);
  r = await ex('remember', { text: 'uses tabs, no frameworks' });
  ok(r.ok && /Already/.test(r.out) && files['RECODE.md'].split('uses tabs').length === 2, 'no duplicates');
  await ex('remember', { text: '- entry file is index.html' });
  ok(/\n- entry file is index.html\n/.test(files['RECODE.md']), 'bullet prefix not doubled');
  ok(M.notes(500) === '- uses tabs, no frameworks\n- entry file is index.html', 'notes text without heading/comment: ' + JSON.stringify(M.notes(500)));
  ok(/\[middle cut\]/.test(M.notes(30)) && M.notes(30).length < M.notes(500).length, 'notes are clipped');
  r = await ex('remember', { text: '   ' });
  ok(!r.ok && /Nothing to remember/.test(r.out), 'empty remember');
  r = await ex('remember', { text: 'x'.repeat(500) });
  ok(r.ok && files['RECODE.md'].indexOf('x'.repeat(250)) < 0, 'long fact is shortened');
  files['RECODE.md'] += '\n- ' + 'filler '.repeat(400) + '\n';
  r = await ex('remember', { text: 'one more' });
  ok(!r.ok && /is full/.test(r.out) && files['RECODE.md'].indexOf('one more') < 0, 'full file refused');
  delete files['RECODE.md']; files['recode.md'] = '# mine\n- keep lines short\n';
  r = await ex('remember', { text: 'second fact' });
  ok(r.ok && !files['RECODE.md'] && /second fact/.test(files['recode.md']), 'lower-case recode.md is used');
  ok(M.notes(500) === '- keep lines short\n- second fact', 'user-written notes read: ' + JSON.stringify(M.notes(500)));
  delete files['recode.md'];
  ok(await M.notesFile.ensure() === 'RECODE.md' && files['RECODE.md'] !== undefined && M.notes(500) === '', 'ensure creates an empty template that adds nothing to the prompt');
  ok(await M.notesFile.ensure() === 'RECODE.md', 'ensure is idempotent');
  files['recode.md'] = '# mine\n- keep lines short\n- second fact\n'; delete files['RECODE.md'];
  r = await ex('remember', { text: 'plan mode fact' }, { mode: 'plan' });
  ok(!r.ok && r.blocked, 'remember is blocked in plan mode');

  // ---- compaction state (unit)
  const cs = M.compact.fresh();
  M.compact.fold(cs, [
    { role: 'tool', label: 'read_file a.js', ok: true, out: '--- a.js ---' },
    { role: 'tool', label: 'read_file a.js', ok: true, out: '--- a.js ---' },
    { role: 'tool', label: 'edit_file b.js', ok: true, out: 'Edited b.js' },
    { role: 'tool', label: 'write_file c.css', ok: true, out: 'Created c.css' },
    { role: 'tool', label: 'run_tests', ok: true, out: 'FAILED - 1 problem(s)\nPROBLEM x' },
    { role: 'tool', label: 'read_file nope.js', ok: false, out: 'ERROR: No such file: nope.js' },
    { role: 'tool', label: 'delegate', ok: true, out: '[frontend report]\nMade the layout responsive.' },
    { role: 'model', text: 'I will fix the css next.\nmore' },
    { role: 'note', text: 'ignored' }
  ]);
  const txt = M.compact.render(cs, 900);
  ok(cs.n === 9 && cs.read.length === 1, 'fold counts, dedupes reads');
  ok(/Read: a\.js/.test(txt) && /Changed: edit b\.js, write c\.css/.test(txt), 'summary lists reads and changes: ' + txt);
  ok(/Checks: run_tests: FAILED - 1 problem/.test(txt) && /No such file: nope\.js/.test(txt), 'summary keeps checks and problems');
  ok(/Specialists: frontend: Made the layout responsive/.test(txt) && /You said: I will fix the css next\./.test(txt), 'summary keeps delegates and last words');
  ok(M.compact.render(cs, 120).length <= 121, 'summary is capped');
  ok(M.compact.render(M.compact.fresh(), 900) === '', 'nothing to say = empty');

  // ---- loop: notes and todo reach the prompt, open todo items are checked before the final answer
  reset();
  files['RECODE.md'] = '# Project notes\n- always use two-space indentation\n';
  files['index.html'] = '<h1>hi</h1>';
  script = ['All good.'];
  let rr = await run('explain this project');
  ok(rr.status === 'done' && /PROJECT NOTES \(RECODE\.md\):\n- always use two-space indentation/.test(prompts[0].prompt), 'notes are in the first prompt');
  ok(!/Project notes/.test(prompts[0].prompt.split('PROJECT NOTES')[1] || ''), 'heading is not repeated in the prompt');
  reset(); files['RECODE.md'] = '# Project notes\n- always use two-space indentation\n';
  RC.settings.useNotes = false; script = ['ok']; await run('explain this project');
  ok(!/PROJECT NOTES/.test(prompts[0].prompt), 'useNotes=false switches it off');
  reset();
  files['index.html'] = '<h1>hi</h1>';
  script = ['TOOL: todo | set | read index.html; reply', 'Finished.', 'TOOL: todo | done | all', 'Everything is done.'];
  rr = await run('review index.html and answer');
  ok(prompts.length === 4 && /TODO LIST/.test(prompts[1].prompt) && /\[ \] 1\. read index\.html/.test(prompts[1].prompt), 'todo list shown on the next turn');
  ok(/todo list still has open items/.test(prompts[2].prompt), 'open items checked before the final answer');
  ok(rr.final === 'Everything is done.' && rr.status === 'done', 'run finishes after the list is done: ' + rr.final);
  // the nudge happens only once
  reset(); script = ['TOOL: todo | set | a; b', 'Done.', 'Really done.'];
  rr = await run('say hi to me');
  ok(rr.final === 'Really done.' && prompts.length === 3, 'one reminder only');
  // a new request starts with a clean list; "continue" keeps it
  reset(); script = ['TOOL: todo | set | a; b', 'x', 'y']; await run('first job here');
  ok(M.todo.items().length === 2, 'list survives the run');
  script = ['fine']; prompts = []; await run('continue');
  ok(/TODO LIST/.test(prompts[0].prompt), 'continue keeps the list');
  script = ['fine']; prompts = []; await run('something different');
  ok(!/TODO LIST/.test(prompts[0].prompt) && M.todo.items().length === 0, 'new request clears it');

  // ---- loop: compaction
  reset();
  RC.settings.ctxChars = 3000; RC.settings.compactKeep = 3; RC.settings.maxIter = 12;
  const big = 'line of code here\n'.repeat(60);
  for (let i = 0; i < 8; i++) files['f' + i + '.js'] = '// file ' + i + '\n' + big;
  let hookSeen = null;
  const off = RC.hooks.register('PreCompact', p => { hookSeen = p; return { feedback: 'user wants small files' }; }, { name: 'test-keep' });
  script = []; for (let i = 0; i < 8; i++) script.push('TOOL: read_file | f' + i + '.js'); script.push('Read them all.');
  rr = await run('read all the js files please');
  ok(rr.status === 'done' && rr.final === 'Read them all.', 'long run completes: ' + rr.status + ' ' + rr.final);
  ok((rr.compactions || 0) >= 1, 'compaction happened: ' + rr.compactions);
  ok(rr.steps.some(s => /Compacting context/.test(s.title)), 'compaction step is visible');
  const withSummary = prompts.filter(x => /older step\(s\) compacted/.test(x.prompt));
  ok(withSummary.length >= 1, 'summary is in the later prompts');
  ok(withSummary.length && /Read: f0\.js/.test(withSummary[withSummary.length - 1].prompt), 'summary remembers early reads');
  ok(withSummary.length && /Kept by hooks: \[test-keep\] user wants small files/.test(withSummary[withSummary.length - 1].prompt), 'hook feedback is kept');
  ok(hookSeen && hookSeen.entries >= 1 && hookSeen.chars > 0 && hookSeen.reason, 'PreCompact payload: ' + JSON.stringify(hookSeen && { e: hookSeen.entries, c: hookSeen.chars, r: hookSeen.reason }));
  ok(prompts.every(x => (x.system + x.prompt).length <= 3000 + 1200), 'prompts stay near the budget: ' + prompts.map(x => (x.system + x.prompt).length));
  off();
  // a hook can block compaction
  reset(); RC.settings.ctxChars = 3000; RC.settings.compactKeep = 3; RC.settings.maxIter = 12;
  for (let i = 0; i < 8; i++) files['f' + i + '.js'] = '// file ' + i + '\n' + big;
  const off2 = RC.hooks.register('PreCompact', () => ({ block: true, reason: 'no' }), { name: 'blocker' });
  script = []; for (let i = 0; i < 8; i++) script.push('TOOL: read_file | f' + i + '.js'); script.push('ok');
  rr = await run('read all the js files please');
  ok(rr.status === 'done' && !rr.compactions, 'blocked by PreCompact hook');
  off2();
  // switched off
  reset(); RC.settings.ctxChars = 3000; RC.settings.autoCompact = false; RC.settings.maxIter = 12;
  for (let i = 0; i < 8; i++) files['f' + i + '.js'] = '// file ' + i + '\n' + big;
  script = []; for (let i = 0; i < 8; i++) script.push('TOOL: read_file | f' + i + '.js'); script.push('ok');
  rr = await run('read all the js files please');
  ok(rr.status === 'done' && !rr.compactions && !prompts.some(x => /compacted/.test(x.prompt)), 'autoCompact=false switches it off');
  // short runs never compact
  reset(); files['a.js'] = 'var a=1;'; script = ['TOOL: read_file | a.js', 'TOOL: check_syntax | a.js', 'fine'];
  rr = await run('look at a.js');
  ok(!rr.compactions, 'short run: no compaction');

  console.log(pass + ' passed, ' + fail + ' failed');
  process.exit(fail ? 1 : 0);
})().catch(e => { console.log('CRASH', e && e.stack || e); process.exit(1); });
