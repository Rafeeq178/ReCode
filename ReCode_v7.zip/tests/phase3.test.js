// Phase 1 tests: tool registry, parser, agent loop (mock model, in-memory store). Run: node tests/phase1.test.js
const fs = require('fs'), path = require('path'), vm = require('vm');
const WWW = path.join(__dirname, '../ReCode/app/src/main/assets/www/js/');
const win = { RC: {}, addEventListener() {}, matchMedia: null };
global.window = win; global.document = { createElement() { return { style: {}, setAttribute() {}, remove() {} }; }, createTextNode: t => t, body: {}, querySelector() {} };
global.navigator = { onLine: true }; global.localStorage = { getItem() { return null; }, setItem() {} };
global.AbortController = AbortController;
const RC = win.RC;
function load(f) { vm.runInThisContext(fs.readFileSync(WWW + f, 'utf8'), { filename: f }); }
load('util.js');
// in-memory store, same surface as RC.store
const files = {};
RC.store = { files, cur: { id: 'p', name: 't' }, fileList: () => Object.keys(files).sort(),
  putFile: async (p, c) => { files[p] = c; }, delFile: async p => { delete files[p]; }, touch() {} };
RC.bus = { emit() {}, on() {} };
RC.saveSettings = () => {}; RC.set = (k, v) => { RC.settings[k] = v; };
RC.native = { call() {}, online: () => true, keepAwake() {} };
RC.settings = { maxIter: 6, ctxChars: 4000, agents: {}, provider: 'local', keepAwake: false, permMode: 'auto', perms: { global: {}, files: [], confirmDelete: true, confirmOverwrite: true, dangerous: 'deny' }, hooks: { format: true, syntax: true, overwrite: true, backup: true, structure: true, errors: true, autoTest: false, maxFiles: 60, custom: [] } };
RC.agentCfg = id => ({ on: true, max: 800, prompt: RC.agents.def[id].system });
RC.run = { entry: f => f['index.html'] ? 'index.html' : null, check: async () => ({ issues: [], fixes: [], ran: true }), probe: async () => ({ errors: [], logs: [] }) };
let script = [], prompts = [];
RC.llm = { AbortErr() { const e = new Error('Stopped'); e.name = 'AbortError'; return e; },
  run: async o => { prompts.push(o); if (!script.length) throw new Error('script exhausted'); const r = script.shift(); return typeof r === 'function' ? r(o) : r; } };
load('agents.js'); load('tools.js'); load('hooks.js'); load('perms.js'); load('subagents.js'); load('pipeline.js'); load('loop.js');
const T = RC.tools;


let pass = 0, fail = 0;
function ok(c, m) { if (c) pass++; else { fail++; console.log('FAIL', m); } }
const S = RC.subagents, P = RC.perms;
const ex = (name, args, ctx) => T.exec({ name, args }, Object.assign({ touch() {} }, ctx || {}));
function reset() { for (const k of Object.keys(files)) delete files[k]; RC.settings.permMode = 'auto'; RC.store.cur = { id: 'p', name: 't' }; P.requester = null; RC.settings.maxIter = 8; RC.settings.ctxChars = 5000; }
const calls = []; // [agent id, system start]
RC.llm.run = async o => { prompts.push(o); if (!script.length) throw new Error('script exhausted'); const r = script.shift(); return typeof r === 'function' ? r(o) : r; };
(async () => {
  // ---- 15 default agents, parsed from markdown
  const want = ['planner','explorer','researcher','architect','frontend','backend','database','coder','debugger','fixer','tester','reviewer','security','optimizer','documentation'];
  ok(want.every(n => S.get(n) && S.get(n).enabled && S.get(n).body.length > 40 && S.get(n).description), '15 agents exist');
  ok(S.names().length === 15, 'names ' + S.names().length);
  ok(RC.agents.def.planner.name === 'Planner' && RC.agents.def['sub:planner'].sub, 'classic agents untouched, sub ids separate');
  // frontmatter parsing
  const pm = S.parse('---\nname: x-y\ndescription: Does things.\ntools: read_file, write_file\n---\nBody here for the agent that is long enough.');
  ok(pm.meta.name === 'x-y' && pm.meta.tools === 'read_file, write_file' && /^Body/.test(pm.body), 'parse frontmatter');
  const listMd = S.parse('---\nname: lst\ndescription: d\ntools:\n  - read_file\n  - list_files\n---\nBody body body body body body body.');
  ok(listMd.meta.tools === 'read_file, list_files', 'yaml list form');
  ok(S.save('no frontmatter at all').ok === false, 'missing frontmatter rejected');
  ok(/Unknown tool/.test(S.save('---\nname: bad1\ndescription: d\ntools: hack_it\n---\nBody body body body body body body.').error), 'unknown tool rejected');
  ok(/reserved/.test(S.save('---\nname: agent\ndescription: d\ntools: read_file\n---\nBody body body body body body body.').error), 'reserved name');
  ok(/delegate/.test(S.save('---\nname: rec\ndescription: d\ntools: delegate\n---\nBody body body body body body body.').error), 'no delegate in subagent');
  // tool access + permission classes
  ok(S.effectiveTools('explorer').every(t => T.registry[t].perm === 'read'), 'explorer read-only tools');
  ok(!S.effectiveTools('debugger').includes('write_file') && S.effectiveTools('debugger').includes('run_tests'), 'debugger: exec but no write');
  ok(S.effectiveTools('frontend').includes('edit_file') && !S.effectiveTools('frontend').includes('delete_file'), 'frontend can edit, not delete');
  // a tool listed but outside the permission classes is dropped
  S.save('---\nname: sneaky\ndescription: tries more than allowed\ntools: read_file, write_file, delete_file\npermissions: read\n---\nBody body body body body body body body.');
  ok(JSON.stringify(S.effectiveTools('sneaky')) === '["read_file"]', 'permissions cap tools: ' + S.effectiveTools('sneaky'));
  // edit + persist roundtrip + reset
  const orig = S.get('frontend').md;
  const edited = orig.replace('Follow project conventions.', 'Follow project conventions. ALWAYS USE TABS.');
  ok(S.save(edited).ok && /ALWAYS USE TABS/.test(S.get('frontend').body), 'edit agent');
  S.remove('frontend'); ok(S.get('frontend').md === S.DEFAULTS.frontend && S.get('frontend').builtin, 'reset built-in to default');
  ok(S.remove('sneaky') && !S.get('sneaky') && !RC.agents.def['sub:sneaky'], 'delete custom');
  S.setEnabled('security', false); ok(!S.names().includes('security') && S.names(true).includes('security'), 'disable');
  ok(S.manual('@security check it') === null, 'disabled agent not manually selectable'); S.setEnabled('security', true);
  // import/export
  const ex1 = S.exportOne('tester'); ok(ex1.name === '.recode/agents/tester.md' && /^---\nname: tester/.test(ex1.text), 'export one');
  const zipBytes = S.exportZip(); ok(zipBytes.length > 2000, 'export zip');
  const imp = S.importFiles([{ name: 'a.md', text: '---\nname: imported\ndescription: custom helper for css\ntools: read_file, edit_file\npermissions: read, write\n---\nYou are a custom helper agent. Do things.' }, { name: 'b.md', text: 'garbage' }]);
  ok(imp[0].ok && !imp[1].ok && S.get('imported'), 'import'); S.remove('imported');

  // ---- dynamic selection
  ok(S.select('make the button responsive and fix the css layout').map(x => x.name).includes('frontend'), 'select frontend');
  ok(S.select('there is a bug and an error crash on load').map(x => x.name)[0] === 'debugger', 'select debugger');
  ok(S.select('review security xss in login form').map(x => x.name).includes('security'), 'select security');
  ok(S.select('hi').length === 0 && S.select('add a title').length === 0, 'simple requests select nothing');
  ok(S.select('improve performance, the page is slow and laggy').map(x => x.name).includes('optimizer'), 'select optimizer');
  ok(S.select('write readme documentation for the project').map(x => x.name).includes('documentation'), 'select docs');
  ok(S.select('build a database schema with sql tables and a query layer').length <= 3, 'at most 3');
  ok(S.manual('@frontend make it blue').name === 'frontend' && S.manual('hello @frontend') === null && S.manual('@nobody x') === null, 'manual parse');
  ok(RC.pipe.detectMode('@tester run all tests', 'auto') === 'agent', 'manual -> agent mode');

  // ---- parser for delegate
  let p = T.parse('TOOL: delegate | frontend | make the page | responsive');
  ok(p.calls[0].name === 'delegate' && p.calls[0].args.agent === 'frontend' && p.calls[0].args.task === 'make the page | responsive', 'delegate parse');
  p = T.parse('TOOL: delegate | tester: run everything'); ok(p.calls[0].args.agent === 'tester' && p.calls[0].args.task === 'run everything', 'delegate colon form');

  // ---- running a subagent: isolated context, restricted tools, concise result
  reset(); files['index.html'] = '<!DOCTYPE html><html><body><h1>Hi</h1></body></html>\n';
  script = ['TOOL: read_file | index.html', 'TOOL: write_file | x.js\n```js\nvar x=1;\n```', 'Mapped: index.html has a heading only.'];
  prompts = [];
  let run = await (async () => { const r = RC.pipe.start('@explorer what is in the project', 'agent'); return r.done; })();
  ok(run.manualAgent === 'explorer' && /Mapped/.test(run.final), 'manual agent ran as main: ' + run.final);
  ok(!files['x.js'], 'explorer cannot write (tool not available)');
  ok(prompts[0].system.indexOf('Explorer agent') >= 0 && prompts[0].system.indexOf('write_file') < 0, 'own system prompt, only own tools listed');
  ok(prompts.some(x => /not available to this agent/.test(x.prompt)), 'blocked tool reported to agent');
  ok(run.steps.every(s => !s.agent || s.agent === 'sub:explorer'), 'steps tagged with the agent');

  // main agent delegates; sub context does NOT contain main conversation
  reset(); files['index.html'] = '<html><body></body></html>\n';
  script = [
    'TOOL: delegate | frontend | add a heading to index.html',                 // main turn 1
    'TOOL: write_file | index.html\n```html\n<html><body><h1>Title</h1></body></html>\n```', // frontend turn 1
    'TOOL: check_syntax',                                                       // frontend turn 2
    'Added an h1 heading.',                                                     // frontend report
    'The frontend agent added the heading.'                                     // main final
  ];
  prompts = [];
  run = await RC.pipe.start('build me a page with a big title and responsive layout css', 'agent').done;
  ok(/frontend agent added/.test(run.final) && /<h1>Title/.test(files['index.html']), 'delegation end to end: ' + run.final);
  ok(prompts[0].prompt.indexOf('Specialists you may delegate to') >= 0 && /frontend/.test(prompts[0].prompt), 'roster in main prompt');
  ok(prompts[1].system.indexOf('frontend development agent') >= 0 && prompts[1].prompt.indexOf('Turn 1/') >= 0 && !/Specialists you may/.test(prompts[1].prompt) && !/delegate/.test(prompts[1].system), 'sub has own prompt, no delegate tool, fresh context');
  ok(/frontend report/.test(prompts[4].prompt) && /Files changed: index.html/.test(prompts[4].prompt), 'concise report + files returned to main');
  ok(run.steps.some(s => s.agent === 'sub:frontend') && run.steps.some(s => s.agent === 'agent'), 'both agents in activity');
  ok(S.status.frontend.state === 'done' && S.status.frontend.runs >= 1 && /h1 heading/.test(S.status.frontend.result), 'execution status + result');
  ok(run.files.includes('index.html'), 'run.files includes sub changes');
  // subagents cannot delegate
  let r = await ex('delegate', { agent: 'coder', task: 'x' }, { depth: 1 }); ok(!r.ok && /cannot delegate/.test(r.out), 'depth limit');
  r = await ex('delegate', { agent: 'nobody', task: 'x' }, {}); ok(!r.ok && /No agent named/.test(r.out), 'unknown agent');
  // plan mode: sub inherits read-only
  reset(); RC.settings.permMode = 'plan'; files['a.js'] = 'var a=1;\n';
  script = ['TOOL: delegate | coder | write b.js', 'TOOL: write_file | b.js\n```js\nvar b=1;\n```', 'Could not write in plan mode.', '1. Create b.js.'];
  run = await RC.pipe.start('implement and create b.js with a function to add code', 'agent').done;
  ok(!files['b.js'] && run.plan, 'plan mode applies to subagents');
  // parallel read-only specialists
  reset(); files['a.js'] = 'var a=1;\n'; files['index.html'] = '<html></html>\n';
  const order = [];
  script = [
    'TOOL: delegate | explorer | map the project\nTOOL: delegate | reviewer | review a.js',
    o => { order.push('x1'); return 'Explorer report.'; }, o => { order.push('x2'); return 'Reviewer report.'; },
    'Both reports received.'
  ];
  prompts = []; run = await RC.pipe.start('review the code quality and understand the project structure', 'agent').done;
  ok(S.parallelSafe('explorer') && S.parallelSafe('reviewer') && !S.parallelSafe('coder'), 'parallelSafe');
  ok(/Both reports/.test(run.final) && order.length === 2 && /Explorer report/.test(prompts[3].prompt) && /Reviewer report/.test(prompts[3].prompt), 'parallel read-only delegates: ' + run.final);
  // sub agent failure is reported, main continues
  reset(); script = ['TOOL: delegate | tester | test it', 'TOOL: bogus | x', 'TOOL: bogus | y', 'TOOL: bogus | z', 'The tester failed; I will stop here.'];
  run = await RC.pipe.start('write tests and verify everything works', 'agent').done;
  ok(run.status === 'done' && /tester failed/.test(run.final), 'sub failure does not kill main: ' + run.status + run.final);
  ok(!run.error, 'sub error not copied to the main run');
  // web tools off by default for main agent prompt
  reset(); prompts = []; script = ['Hello.']; await RC.pipe.start('say hello please now', 'agent').done;
  ok(prompts[0].system.indexOf('web_search') < 0 && prompts[0].system.indexOf('delegate') >= 0, 'main prompt: delegate yes, web tools no');
  // classic pipeline modes unaffected
  ok(RC.pipe.detectMode('hi there', 'auto') === 'chat', 'chat mode unchanged');
  console.log(pass + ' passed, ' + fail + ' failed'); process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
