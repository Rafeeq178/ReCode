package com.aicompany.app.ui.theme

import com.aicompany.app.data.AppSettings
import kotlinx.serialization.json.Json
import org.junit.Assert.*
import org.junit.Test

class ReCodeGlassModeTest {
    @Test fun olderDevicesAndDisabledExperimentsNeverSelectUnsupportedEffects() {
        for (sdk in listOf(26, 30, 31, 32, 33, 36)) {
            assertEquals(ReCodeGlassMode.OFF, ReCodeGlassMode.resolve(false, true, sdk))
        }
        assertEquals(ReCodeGlassMode.OFF, ReCodeGlassMode.resolve(true, true, 30))
        assertEquals(ReCodeGlassMode.FROSTED, ReCodeGlassMode.resolve(true, true, 31))
        assertEquals(ReCodeGlassMode.FROSTED, ReCodeGlassMode.resolve(true, true, 32))
        assertEquals(ReCodeGlassMode.FROSTED, ReCodeGlassMode.resolve(true, false, 33))
        assertEquals(ReCodeGlassMode.LIQUID, ReCodeGlassMode.resolve(true, true, 33))
    }

    @Test fun oldSettingsStayOffAndPortableSettingsRetainBothSwitches() {
        val old = Json.decodeFromString<AppSettings>("{}")
        assertFalse(old.recodeGlassEnabled)
        assertFalse(old.recodeLiquidGlass)
        assertEquals(.5f, old.recodeGlassTransparency)
        for (liquid in listOf(false, true)) {
            val saved = old.copy(recodeGlassEnabled = true, recodeLiquidGlass = liquid, recodeGlassTransparency = .8f)
            val restored = Json.decodeFromString<AppSettings>(Json.encodeToString(saved))
            assertEquals(saved, restored)
        }
    }

    @Test fun transparencyPreservesTheDefaultAndNeverChangesForegroundOpacity() {
        assertEquals(1f, liquidGlassOpacity(.3f, 0f), .001f)
        assertEquals(.3f, liquidGlassOpacity(.3f, .5f), .001f)
        assertEquals(0f, liquidGlassOpacity(.3f, 1f), .001f)
        assertEquals(.3f, liquidGlassOpacity(.3f, Float.NaN), .001f)
        assertEquals(1f, liquidGlassOpacity(.3f, -1f), .001f)
        assertEquals(0f, liquidGlassOpacity(.3f, 2f), .001f)
    }
}
