package com.aicompany.app.corp.tools

import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.JsonPrimitive
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.assertThrows
import org.junit.Test

class CorpToolsTest {
    @Test fun calculatorHandlesPrecedenceAndPower() {
        assertEquals(20.0, Calc.evaluate("(2+3)*4"), 0.0)
        assertEquals(1024.0, Calc.evaluate("2^10"), 0.0)
    }

    @Test fun calculatorRejectsNonFiniteAndEmptyInput() {
        assertThrows(IllegalArgumentException::class.java) { Calc.evaluate("1/0") }
        assertThrows(IllegalArgumentException::class.java) { Calc.evaluate("   ") }
    }

    @Test fun messagingTargetsAreValidated() {
        assertTrue(MessagingRules.CHAT.matches("@mychannel"))
        assertTrue(MessagingRules.CHAT.matches("-1001234567890"))
        assertFalse(MessagingRules.CHAT.matches("bad chat id"))
        assertTrue(MessagingRules.PHONE.matches("923001234567"))
        assertFalse(MessagingRules.PHONE.matches("+92 300"))
    }

    @Test fun customHttpToolMustUseHttps() {
        val params = buildJsonObject {
            put("type", "object")
            put("properties", buildJsonObject { put("q", buildJsonObject { put("type", "string") }) })
        }
        val ok = CustomToolDef("lookup", "Looks something up", "HTTP", params, "AUTO", 30,
            method = "GET", url = "https://example.com/search?q={q}")
        assertTrue(CustomToolValidator.validate(ok, emptySet()).isEmpty())
        val insecure = ok.copy(url = "http://example.com/search?q={q}")
        assertTrue(CustomToolValidator.validate(insecure, emptySet()).isNotEmpty())
        val unknownParam = ok.copy(url = "https://example.com/{missing}")
        assertTrue(CustomToolValidator.validate(unknownParam, emptySet()).isNotEmpty())
    }

    @Test fun secretsAreRefusedInShellCommands() {
        val params = buildJsonObject {
            put("type", "object")
            put("properties", buildJsonObject { })
        }
        val def = CustomToolDef("deploy", "Deploys", "SHELL", params, "ASK", 30,
            command = "curl -H 'X: {{secret:API_KEY}}' https://example.com")
        assertTrue(CustomToolValidator.validate(def, emptySet()).any { it.contains("Secrets") })
    }
}
