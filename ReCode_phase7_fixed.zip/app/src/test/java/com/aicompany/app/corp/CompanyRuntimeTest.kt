package com.aicompany.app.corp

import com.aicompany.app.corp.agents.RiskPolicy
import com.aicompany.app.corp.agents.ToolAliases
import com.aicompany.app.corp.approvals.ApprovalDecision
import com.aicompany.app.corp.approvals.ApprovalOutcome
import com.aicompany.app.corp.approvals.CorpApprovals
import com.aicompany.app.corp.scheduler.Router
import com.aicompany.app.llm.ProviderConfig
import com.aicompany.app.llm.ProviderType
import com.aicompany.app.tools.Schema
import com.aicompany.app.tools.Tool
import com.aicompany.app.tools.ToolContext
import com.aicompany.app.tools.ToolResult
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.JsonObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CompanyRuntimeTest {
    private fun tool(toolName: String, readOnly: Boolean) = object : Tool {
        override val name = toolName
        override val description = "test"
        override val parametersSchema = Schema.obj(emptyMap())
        override val isReadOnly = readOnly
        override suspend fun execute(args: JsonObject, ctx: ToolContext) = ToolResult(true, "")
    }

    private fun provider(id: String) = ProviderConfig(id, id, ProviderType.OPENAI_COMPAT, "https://example.com/v1", "m")

    @Test fun oldToolNamesMapToReCodeTools() {
        assertEquals("shell", ToolAliases.resolve("run_command"))
        assertEquals("shell", ToolAliases.resolve("run_python"))
        assertEquals("grep", ToolAliases.resolve("search_code"))
        assertEquals("read_file", ToolAliases.resolve("read_file"))
        assertNull(ToolAliases.resolve("drive_search"))
        assertEquals(setOf("shell", "read_file"), ToolAliases.resolveAll(setOf("run_command", "run_node", "read_file", "drive_read")))
    }

    @Test fun terminalPermissionDecidesWhatNeedsApproval() {
        val read = tool("read_file", true)
        val write = tool("write_file", false)
        val shell = tool("shell", false)
        assertFalse(RiskPolicy.needsApproval(read, "ASK"))
        assertTrue(RiskPolicy.needsApproval(write, "ASK"))
        assertFalse(RiskPolicy.needsApproval(write, "AUTO_SAFE"))
        assertTrue(RiskPolicy.needsApproval(shell, "AUTO_SAFE"))
        assertFalse(RiskPolicy.needsApproval(shell, "FULL_AUTO"))
    }

    @Test fun approvalWaitsForTheOwnerAndOneHourGrantSkipsTheQueue() = runBlocking {
        val approvals = CorpApprovals()
        val owner = launch {
            while (approvals.pending.value.isEmpty()) delay(10)
            approvals.resolve(approvals.pending.value.first().id, ApprovalDecision.ALLOW_ONE_HOUR)
        }
        val first = approvals.authorize("w1", "Worker", "shell", "shell ls")
        owner.join()
        assertTrue(first is ApprovalOutcome.Allowed)
        // Granted for an hour: no second prompt, and nothing is pending.
        val second = approvals.authorize("w1", "Worker", "shell", "shell pwd")
        assertTrue(second is ApprovalOutcome.Allowed)
        assertTrue(approvals.pending.value.isEmpty())
    }

    @Test fun rejectedActionIsDenied() = runBlocking {
        val approvals = CorpApprovals()
        val owner = launch {
            while (approvals.pending.value.isEmpty()) delay(10)
            approvals.resolve(approvals.pending.value.first().id, ApprovalDecision.REJECTED)
        }
        val outcome = approvals.authorize("w2", "Worker", "shell", "shell rm x")
        owner.join()
        assertTrue(outcome is ApprovalOutcome.Denied)
    }

    @Test fun lightWorkPrefersLocalAndHeavyWorkPrefersApi() {
        val chain = listOf(provider("api"), provider("local-qwen"))
        val isLocal = { p: ProviderConfig -> p.id.startsWith("local") }
        assertEquals("local-qwen", Router.prioritize(Router.Kind.LIGHT, chain, isLocal).first().id)
        assertEquals("api", Router.prioritize(Router.Kind.HEAVY, chain, isLocal).first().id)
        assertEquals(Router.Kind.HEAVY, Router.classify("please debug the login code"))
        assertEquals(Router.Kind.LIGHT, Router.classify("what is the latest planet news"))
    }
}
