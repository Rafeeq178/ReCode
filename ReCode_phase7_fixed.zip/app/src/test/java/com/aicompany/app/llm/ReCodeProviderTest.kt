package com.aicompany.app.llm

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.junit.Assert.*
import org.junit.Test
import org.junit.After

class ReCodeProviderTest {
    @After fun resetCatalog() { ReCodeProvider.restoreModels(ReCodeProvider.fallbackModels) }
    @Test fun stalePicksResetToDefault() {
        assertEquals(ReCodeProvider.DEFAULT_MODEL, ReCodeProvider.sanitize("ling-3.0-flash-fin-free"))
        assertEquals(ReCodeProvider.DEFAULT_MODEL, ReCodeProvider.sanitize("big-pickle"))
        assertEquals(ReCodeProvider.DEFAULT_MODEL, ReCodeProvider.sanitize("made-up-model"))
        assertEquals(ReCodeProvider.DEFAULT_MODEL, ReCodeProvider.sanitize(null))
    }

    @Test fun pooledPickSurvives() {
        assertEquals("kilo-auto/free", ReCodeProvider.sanitize("kilo-auto/free"))
        assertEquals("openai-fast", ReCodeProvider.sanitize("openai-fast"))
    }

    @Test fun customModelsSurviveSanitize() {
        assertEquals("my-custom-model", ReCodeProvider.sanitize("my-custom-model", setOf("my-custom-model")))
        assertEquals(ReCodeProvider.DEFAULT_MODEL, ReCodeProvider.sanitize("my-custom-model", setOf("other")))
    }

    @Test fun pooledModelsAreAcceptedAndLabeled() {
        ReCodeProvider.restoreModels(ReCodeProvider.models(listOf(ModelEntry("inclusionai/ling-3.1-flash"))))
        assertTrue(ReCodeProvider.isPooled("inclusionai/ling-3.1-flash"))
        assertFalse(ReCodeProvider.isPooled("z-ai/glm-5.2:free"))
        assertFalse(ReCodeProvider.isPooled("deepseek/deepseek-v4-flash-0731:free"))
        assertTrue(ReCodeProvider.isPooled("openai-fast"))
        assertFalse(ReCodeProvider.isPooled("ling-3.0-flash-fin-free"))
        assertFalse(ReCodeProvider.isPooled("Qwen3.5-397B-A17B"))

        assertEquals("inclusionai/ling-3.1-flash", ReCodeProvider.sanitize("inclusionai/ling-3.1-flash"))

        val models = ReCodeProvider.models(emptyList())
        val openaiFast = models.first { it.id == "openai-fast" }
        assertTrue(openaiFast.note.orEmpty().contains("Pollinations"))
        assertTrue(models.none { it.id == "nvidia/nemotron-3.5-content-safety:free" })
    }

    @Test fun wirePinMapping() {
        ReCodeProvider.pins = mapOf(
            "a" to ProviderType.ANTHROPIC.name,
            "b" to ProviderType.OPENAI_RESPONSES.name,
        )
        assertEquals(ProviderType.ANTHROPIC, ReCodeProvider.wire("a"))
        assertEquals(ProviderType.OPENAI_RESPONSES, ReCodeProvider.wire("b"))
        assertEquals(ProviderType.OPENAI_COMPAT, ReCodeProvider.wire("c"))
        ReCodeProvider.pins = emptyMap()
    }

    @Test fun refreshReplacesRetiredModelsAndKeepsMetadata() {
        ReCodeProvider.restoreModels(ReCodeProvider.models(listOf(ModelEntry("retired:free"))))
        val fresh = ModelEntry("new-free", reasoning = true, contextTokens = 128000)
        ReCodeProvider.restoreModels(ReCodeProvider.models(listOf(fresh)))
        assertFalse(ReCodeProvider.isPooled("retired:free"))
        assertEquals("new-free", ReCodeProvider.sanitize("retired:free"))
        assertEquals(fresh.copy(note = ReCodeProvider.KILO_NOTE), ReCodeProvider.pooledModels.first())
        assertEquals(ReCodeProvider.KILO_BASE_URL, ReCodeProvider.pool["new-free"]?.baseUrl)
    }

    @Test fun removesCredentialsWithoutImpersonatingAnotherClient() {
        val request = ReCodeProvider.anonymous(Request.Builder().url(ReCodeProvider.BASE_URL)
            .header("Authorization", "Bearer secret").header("x-api-key", "secret").build())
        assertNull(request.header("Authorization"))
        assertNull(request.header("x-api-key"))
        assertEquals("ReCode", request.header("User-Agent"))
        assertFalse(request.header(ReCodeProvider.SESSION_HEADER).isNullOrBlank())
    }

    @Test fun preservesStableOpenCodeSession() {
        val request = ReCodeProvider.anonymous(Request.Builder().url(ReCodeProvider.BASE_URL)
            .header(ReCodeProvider.SESSION_HEADER, "conversation-123").build())
        assertEquals("conversation-123", request.header(ReCodeProvider.SESSION_HEADER))
    }

    @Test fun isOpenCodeMatchesEndpointsAndNames() {
        assertTrue(ReCodeProvider.isOpenCode(ProviderConfig("custom-1", "Custom", ProviderType.OPENAI_COMPAT, "https://opencode.ai/zen/v1", "model")))
        assertTrue(ReCodeProvider.isOpenCode(ProviderConfig("custom-2", "Custom", ProviderType.OPENAI_COMPAT, "https://opencode.ai/v1", "model")))
        assertTrue(ReCodeProvider.isOpenCode(ProviderConfig("custom-3", "OpenCode Go", ProviderType.OPENAI_COMPAT, "https://proxy.example.com/v1", "model")))
        assertTrue(ReCodeProvider.isOpenCode(ReCodeProvider.config))

        assertFalse(ReCodeProvider.isOpenCode(ProviderConfig("p1", "OpenAI", ProviderType.OPENAI_COMPAT, "https://api.openai.com/v1", "gpt-4o")))
        assertFalse(ReCodeProvider.isOpenCode(ProviderConfig("p2", "Anthropic", ProviderType.ANTHROPIC, "https://api.anthropic.com", "claude-3-5-sonnet")))
        assertFalse(ReCodeProvider.isOpenCode(ProviderConfig("p3", "OpenRouter", ProviderType.OPENAI_COMPAT, "https://openrouter.ai/api/v1", "auto")))
    }

    @Test fun withSessionInjectsHeaderAndUserAgent() {
        val builder = Request.Builder().url("https://opencode.ai/zen/v1/chat/completions")
        val req = ReCodeProvider.withSession(builder, "sess-xyz").build()
        assertEquals("sess-xyz", req.header(ReCodeProvider.SESSION_HEADER))
        assertEquals("ReCode", req.header("User-Agent"))

        val fallbackBuilder = Request.Builder().url("https://opencode.ai/zen/v1/chat/completions")
        val fallbackReq = ReCodeProvider.withSession(fallbackBuilder, null).build()
        assertFalse(fallbackReq.header(ReCodeProvider.SESSION_HEADER).isNullOrBlank())
        assertEquals("ReCode", fallbackReq.header("User-Agent"))
    }

    @Test fun withSessionSendsFullIdentityHeaderSet() {
        val req = ReCodeProvider.withSession(
            Request.Builder().url("https://opencode.ai/zen/v1/chat/completions"), "sess-1",
        ).build()
        assertFalse(req.header("x-opencode-request").isNullOrBlank())
        assertEquals("recode", req.header("x-opencode-client"))
        assertFalse(req.header("x-opencode-project").isNullOrBlank())
    }

    @Test fun customOpenCodeGoProviderInjectsHeadersWithoutStrippingAuth() {
        val customConfig = ProviderConfig("custom-uuid", "OpenCode Go", ProviderType.OPENAI_COMPAT, "https://opencode.ai/zen/v1", "model")
        val dummyBody = "{}".toRequestBody("application/json".toMediaType())
        val req = OpenAiCompatProvider(okhttp3.OkHttpClient(), ProviderFactory.json).buildRequest(
            customConfig,
            "secret-token",
            dummyBody,
            RequestOptions(cacheKey = "my-chat-session"),
        )
        assertEquals("Bearer secret-token", req.header("Authorization"))
        assertEquals("my-chat-session", req.header(ReCodeProvider.SESSION_HEADER))
        assertEquals("ReCode", req.header("User-Agent"))
    }

    @Test fun modelCatalogInjectsOpenCodeHeadersWhileKeepingAuth() {
        val customConfig = ProviderConfig("custom-uuid", "OpenCode Go", ProviderType.OPENAI_COMPAT, "https://opencode.ai/zen/v1", "model")
        val req = ModelCatalog.buildRequest(customConfig, "secret-token")
        assertEquals("Bearer secret-token", req.header("Authorization"))
        assertFalse(req.header(ReCodeProvider.SESSION_HEADER).isNullOrBlank())
        assertEquals("ReCode", req.header("User-Agent"))

        val recodeReq = ModelCatalog.buildRequest(ReCodeProvider.config, "ignored")
        assertNull(recodeReq.header("Authorization"))
        assertEquals(ReCodeProvider.KILO_BASE_URL + "/models", recodeReq.url.toString())
        assertNull(recodeReq.header(ReCodeProvider.SESSION_HEADER))
        assertEquals("ReCode", recodeReq.header("User-Agent"))
    }
}
