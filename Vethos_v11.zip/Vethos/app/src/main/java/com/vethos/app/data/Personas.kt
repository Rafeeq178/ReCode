package com.vethos.app.data

import android.graphics.Color
import com.vethos.app.R
import com.vethos.app.tools.Tools
import org.json.JSONArray
import org.json.JSONObject

/**
 * temp = creativity in tenths (0..10); tone / lang = "" means automatic;
 * tools = "" none, "*" all, or comma separated tool ids.
 */
data class Persona(
    val id: String, var name: String, var desc: String, var prompt: String, var ico: Int,
    var temp: Int = 5, var tone: String = "", var lang: String = "", var tools: String = "",
) {
    /** Tool ids this personality may use right now (also switched on in the Phone tools screen). */
    fun allowedTools(): Set<String> {
        val ids = if (tools == "*") Tools.all.map { it.id } else tools.split(',').map { it.trim() }.filter { it.isNotEmpty() }
        val base = ids.filter { Tools.get(it) != null && Tools.enabled(it) }.toSet()
        // every personality can load skills as soon as one skill is switched on
        return if (Tools.enabled("read_skill") && Skills.hasEnabled()) base + "read_skill" else base
    }
}

class PIcon(val res: Int, val tint: Int)

object Personas {
    val icons = listOf(
        PIcon(R.drawable.ic_chat, Color.parseColor("#0E9AA7")),
        PIcon(R.drawable.ic_code, Color.parseColor("#7C5CFA")),
        PIcon(R.drawable.ic_heart, Color.parseColor("#16A34A")),
        PIcon(R.drawable.ic_book, Color.parseColor("#C9623F")),
        PIcon(R.drawable.ic_hash, Color.parseColor("#C9623F")),
        PIcon(R.drawable.ic_dollar, Color.parseColor("#C9623F")),
        PIcon(R.drawable.ic_flask, Color.parseColor("#C9623F")),
        PIcon(R.drawable.ic_edit, Color.parseColor("#C9623F")),
    )

    private val prefs get() = Store.app.getSharedPreferences("vethos", 0)
    private var cache: MutableList<Persona>? = null

    private fun defaults() = mutableListOf(
        Persona("general", "General Assistant", "Everyday questions, ideas and tools",
            "You are Vethos, a helpful, concise assistant running offline on the user's phone. Answer clearly. Use a tool or a skill only when it really helps.", 0, 5, "", "", "*"),
        planner(),
        coder(),
    )

    private fun planner() = Persona("planner", "Planner", "Breaks a goal into clear steps",
        "You are a planner. Turn the user's goal into a short numbered plan (3-7 steps). For each step say which skill or tool could help, if any. Do not write code. Ask at most one question, and only if the plan is impossible without the answer.", 6, 4)

    private fun coder() = Persona("coder", "Coder", "Writes and fixes code",
        "You are an expert software engineer. Follow the given plan if there is one. Write clean, working code in code blocks, keep explanations short, and say which file each block belongs to. When you find a bug, name the cause first, then show the fix.", 1, 3, "", "", "write_file,read_file,calc")

    fun all(): MutableList<Persona> {
        cache?.let { return it }
        val out = mutableListOf<Persona>()
        try {
            val raw = prefs.getString("personas", null)
            if (raw != null) {
                val a = JSONArray(raw)
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    out.add(fromJson(o, o.getString("id")))
                }
            }
        } catch (_: Exception) { out.clear() }
        if (out.isEmpty()) out.addAll(defaults())
        cache = out
        seed(out)
        return out
    }

    /** One-time upgrade for v11: add the Planner and Coder personalities, drop the old Translator. */
    private fun seed(list: MutableList<Persona>) {
        if (prefs.getBoolean("seed_v11", false)) return
        list.removeAll { it.id == "translator" }
        if (list.none { it.id == "planner" }) list.add(1.coerceAtMost(list.size), planner())
        if (list.none { it.id == "coder" }) list.add(coder())
        list.firstOrNull { it.id == "general" }?.let { if (it.tools.isEmpty()) it.tools = "*" }
        prefs.edit().putBoolean("seed_v11", true).apply()
        save()
    }

    private fun fromJson(o: JSONObject, id: String) = Persona(
        id, o.optString("name", "Personality"), o.optString("desc"), o.optString("prompt"),
        o.optInt("ico", 0), o.optInt("temp", 5).coerceIn(0, 10),
        o.optString("tone"), o.optString("lang"), o.optString("tools"),
    )

    private fun toJson(p: Persona, withId: Boolean) = JSONObject().apply {
        if (withId) put("id", p.id)
        put("name", p.name); put("desc", p.desc); put("prompt", p.prompt); put("ico", p.ico)
        put("temp", p.temp); put("tone", p.tone); put("lang", p.lang); put("tools", p.tools)
    }

    fun get(id: String?): Persona? = if (id.isNullOrEmpty()) null else all().firstOrNull { it.id == id }

    var selectedId: String
        get() = prefs.getString("persona", "general")!!
        set(v) = prefs.edit().putString("persona", v).apply()

    fun current(): Persona = get(selectedId) ?: all().first()

    fun save() {
        val a = JSONArray()
        all().forEach { a.put(toJson(it, true)) }
        prefs.edit().putString("personas", a.toString()).apply()
    }

    private var counter = 0
    private fun newId() = "p" + System.currentTimeMillis() + "_" + (counter++)

    fun duplicate(p: Persona): Persona {
        val c = p.copy(id = newId(), name = p.name + " copy")
        val i = all().indexOfFirst { it.id == p.id }
        all().add(if (i >= 0) i + 1 else all().size, c)
        save()
        return c
    }

    // ---- JSON export / import ----
    fun exportJson(list: List<Persona>): String {
        val a = JSONArray()
        list.forEach { a.put(toJson(it, false)) }
        return JSONObject().put("vethos", "personalities").put("version", 1).put("items", a).toString(2)
    }

    /** Adds personalities from exported JSON (also accepts a bare array or a single object). Returns how many were new. */
    fun importJson(text: String): Int {
        val t = text.trim()
        val items = mutableListOf<JSONObject>()
        if (t.startsWith("[")) {
            val a = JSONArray(t)
            for (i in 0 until a.length()) items.add(a.getJSONObject(i))
        } else {
            val o = JSONObject(t)
            val a = o.optJSONArray("items")
            if (a != null) for (i in 0 until a.length()) items.add(a.getJSONObject(i)) else items.add(o)
        }
        var added = 0
        items.forEach { o ->
            if (o.optString("name").isBlank() || o.optString("prompt").isBlank()) return@forEach
            val p = fromJson(o, newId())
            if (all().any { it.name == p.name && it.prompt == p.prompt }) return@forEach
            all().add(p); added++
        }
        if (added > 0) save()
        return added
    }

    fun add(name: String, desc: String, prompt: String, temp: Int = 5, tone: String = "", lang: String = "", tools: String = ""): Persona {
        val p = Persona(newId(), name, desc, prompt, all().size % icons.size, temp, tone, lang, tools)
        all().add(p); save()
        return p
    }

    fun delete(id: String) {
        if (all().size <= 1) return
        all().removeAll { it.id == id }
        if (selectedId == id) selectedId = all().first().id
        save()
    }
}
