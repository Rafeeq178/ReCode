package com.vethos.app.tools

import com.vethos.app.R
import com.vethos.app.data.Skills

/** The "read_skill" tool: the model asks for a skill by name and gets its full instructions back. */
object SkillTools {
    fun build(): List<ToolDef> = listOf(
        ToolDef(
            id = "read_skill", title = "Read skill", icon = R.drawable.ic_book, sensitive = false,
            desc = "Loads the instructions of a saved skill so the assistant can follow them",
            params = listOf(ToolParam("name", "Skill name")),
            usage = "{\"name\":\"skill name\"} loads the full instructions of a skill",
            run = { _, a, done ->
                val q = a.optString("name")
                val s = Skills.find(q)
                if (s == null) {
                    val names = Skills.all().filter { it.enabled }.joinToString(", ") { it.name }
                    done(ToolResult(false, "No skill called \"" + q + "\". Available: " + names))
                } else {
                    done(ToolResult(true, "Skill: " + s.name, "Follow these instructions (skill \"" + s.name + "\"):\n" + s.body.take(3000)))
                }
            },
            headless = true,
        )
    )
}
