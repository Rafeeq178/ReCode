package com.vethos.app.ui

import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.vethos.app.R
import com.vethos.app.data.Skill
import com.vethos.app.data.Skills
import com.vethos.app.databinding.ActivitySkillsBinding
import com.vethos.app.databinding.ItemToolBinding
import com.vethos.app.tools.Launchers

/** Add / edit / delete / import / export skills (folders with a SKILL.md). */
class SkillsActivity : AppCompatActivity() {
    private lateinit var b: ActivitySkillsBinding
    private val launchers = Launchers(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySkillsBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnBack.setOnClickListener { finish() }
        b.btnAdd.setOnClickListener { edit(null) }
        b.btnImport.setOnClickListener { importFile() }
        refresh()
    }

    private fun refresh() {
        b.list.removeAllViews()
        val all = Skills.all()
        if (all.isEmpty()) {
            b.list.addView(android.widget.TextView(this).apply {
                text = "No skills yet. Tap + to add one."
                setTextColor(getColor(R.color.v_muted))
                gravity = Gravity.CENTER
                setPadding(0, dp(40), 0, 0)
            })
        }
        all.forEach { s ->
            val r = ItemToolBinding.inflate(layoutInflater, b.list, false)
            r.icon.setImageResource(R.drawable.ic_book)
            r.title.text = s.name
            r.sub.text = s.desc.ifBlank { "(no description)" }
            r.sw.isChecked = s.enabled
            r.sw.setOnCheckedChangeListener { _, on -> Skills.setEnabled(s.id, on) }
            r.root.setOnClickListener { edit(s) }
            r.root.setOnLongClickListener { more(s); true }
            b.list.addView(r.root)
        }
    }

    private fun more(s: Skill) {
        showSheet(s.name, listOf(
            SheetRow(R.drawable.ic_edit, "Edit") { edit(s) },
            SheetRow(R.drawable.ic_copy, "Duplicate") { Skills.duplicate(s.id); refresh() },
            SheetRow(R.drawable.ic_share, "Export SKILL.md") {
                launchers.saveText(s.id + "-SKILL.md", Skills.render(s.name, s.desc, s.body)) { ok, msg ->
                    toast(if (ok) "Saved $msg" else msg)
                }
            },
            SheetRow(R.drawable.ic_trash, "Delete") {
                confirm("Delete skill?", "“" + s.name + "” will be removed.", "Delete") { Skills.delete(s.id); refresh() }
            },
        ))
    }

    private fun edit(s: Skill?) {
        fun field(hint: String, text: String, lines: Int) = EditText(this).apply {
            setHint(hint); setText(text)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            if (lines > 1) { minLines = lines; maxLines = lines + 6; gravity = Gravity.TOP }
        }
        val name = field("Name (e.g. Email writer)", s?.name ?: "", 1)
        val desc = field("When to use it (one line)", s?.desc ?: "", 1)
        val body = field("Instructions", s?.body ?: "", 8)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), 0)
            addView(name); addView(desc); addView(body)
        }
        val scroll = ScrollView(this).apply { addView(box) }
        MaterialAlertDialogBuilder(this)
            .setTitle(if (s == null) "New skill" else "Edit skill")
            .setView(scroll)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val n = name.text.toString().trim()
                if (n.isEmpty()) { toast("Name is needed"); return@setPositiveButton }
                Skills.save(s?.id, n, desc.text.toString(), body.text.toString())
                refresh()
            }
            .show()
    }

    private fun importFile() {
        launchers.pickFile { uri ->
            if (uri == null) return@pickFile
            try {
                val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                if (text.isBlank()) { toast("File is empty"); return@pickFile }
                val p = Skills.parse(text, "Imported skill")
                Skills.save(null, p.first, p.second, p.third)
                toast("Imported “" + p.first + "”")
                refresh()
            } catch (e: Exception) {
                toast("Could not read the file")
            }
        }
    }
}
