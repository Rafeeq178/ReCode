package com.vethos.app.ui

import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.vethos.app.databinding.ActivityToolsBinding
import com.vethos.app.databinding.ItemToolBinding
import com.vethos.app.tools.Launchers
import com.vethos.app.tools.PermHelper
import com.vethos.app.tools.ToolCtx
import com.vethos.app.tools.ToolDef
import com.vethos.app.tools.ToolRunner
import com.vethos.app.tools.Tools
import org.json.JSONObject

/** Lists every phone tool. Tap one to try it by hand; the switch turns it off for all personalities. */
class ToolsActivity : AppCompatActivity() {
    private lateinit var b: ActivityToolsBinding
    private val perms = PermHelper(this)
    private val launchers = Launchers(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityToolsBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnBack.setOnClickListener { finish() }
        Tools.all.forEach { d ->
            val r = ItemToolBinding.inflate(layoutInflater, b.list, false)
            r.icon.setImageResource(d.icon)
            r.title.text = d.title + if (d.sensitive) "  (asks first)" else ""
            r.sub.text = d.desc
            r.sw.isChecked = Tools.enabled(d.id)
            r.sw.setOnCheckedChangeListener { _, on -> Tools.setEnabled(d.id, on) }
            r.root.setOnClickListener { tryTool(d) }
            b.list.addView(r.root)
        }
    }

    private fun tryTool(d: ToolDef) {
        val ctx = ToolCtx(this, perms, launchers)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), 0)
        }
        val fields = d.params.map { p ->
            EditText(this).apply {
                hint = p.label + if (p.optional) " (optional)" else ""
                if (p.hint.isNotEmpty()) hint = hint.toString() + " – " + p.hint
                inputType = InputType.TYPE_CLASS_TEXT
            }.also { box.addView(it, LinearLayout.LayoutParams(-1, -2)) }
        }
        fun go() {
            val args = JSONObject()
            d.params.forEachIndexed { i, p ->
                val v = fields[i].text.toString().trim()
                if (v.isNotEmpty()) args.put(p.key, v)
            }
            ToolRunner.run(ctx, d, args, true) { r ->
                if (r.text.length > 70 || r.text.contains('\n'))
                    MaterialAlertDialogBuilder(this).setTitle(d.title).setMessage(r.text).setPositiveButton("OK", null).show()
                else toast(r.text)
            }
        }
        if (d.params.isEmpty()) { go(); return }
        MaterialAlertDialogBuilder(this).setTitle(d.title).setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Run") { _, _ -> go() }
            .show()
    }
}
