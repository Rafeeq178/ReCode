package com.vethos.app.data

import java.io.File

/** One skill = a folder skills/<id>/SKILL.md (same layout as Claude's skills). */
class Skill(val id: String, val name: String, val desc: String, val body: String, val enabled: Boolean)

object Skills {
    private val root: File get() = File(Store.app.filesDir, "skills").apply { mkdirs() }
    private val prefs get() = Store.app.getSharedPreferences("vethos", 0)

    fun slug(s: String): String {
        val t = s.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-')
        return t.take(40).ifEmpty { "skill" }
    }

    fun enabled(id: String): Boolean = !prefs.getBoolean("skill_off_" + id, false)
    fun setEnabled(id: String, on: Boolean) = prefs.edit().putBoolean("skill_off_" + id, !on).apply()

    fun all(): List<Skill> {
        seed()
        val dirs = root.listFiles { f -> f.isDirectory } ?: return emptyList()
        return dirs.sortedBy { it.name }.mapNotNull { d ->
            val f = File(d, "SKILL.md")
            if (!f.isFile) null
            else {
                val p = parse(f.readText(), d.name)
                Skill(d.name, p.first, p.second, p.third, enabled(d.name))
            }
        }
    }

    fun hasEnabled(): Boolean = all().any { it.enabled }

    fun find(q: String): Skill? {
        val k = q.trim().lowercase()
        if (k.isEmpty()) return null
        val list = all().filter { it.enabled }
        return list.firstOrNull { it.id == k || it.name.lowercase() == k || it.id == slug(q) }
            ?: list.firstOrNull { it.name.lowercase().contains(k) || k.contains(it.name.lowercase()) }
    }

    /** name, description, body. Reads the "---" header (name: / description:) if there is one. */
    fun parse(text: String, fallback: String): Triple<String, String, String> {
        val t = text.replace("\r\n", "\n").trim()
        var name = fallback
        var desc = ""
        var body = t
        if (t.startsWith("---")) {
            val end = t.indexOf("\n---", 3)
            if (end > 0) {
                val head = t.substring(3, end)
                body = t.substring(end + 4).trim()
                var key = ""
                val kv = Regex("^([A-Za-z_-]+):\\s*(.*)$")
                for (ln in head.lines()) {
                    val m = kv.find(ln)
                    if (m != null) {
                        key = m.groupValues[1].lowercase()
                        val v = unq(m.groupValues[2])
                        if (key == "name" && v.isNotBlank()) name = v
                        if (key == "description") desc = if (v in listOf(">", "|", ">-", "|-")) "" else v
                    } else if (key == "description" && ln.isNotBlank()) {
                        desc = (desc + " " + ln.trim()).trim()
                    }
                }
            }
        }
        return Triple(name, desc, body)
    }

    private fun unq(s: String): String {
        val t = s.trim()
        return if (t.length >= 2 && (t.startsWith("\"") && t.endsWith("\"") || t.startsWith("'") && t.endsWith("'")))
            t.substring(1, t.length - 1) else t
    }

    fun render(name: String, desc: String, body: String): String =
        "---\nname: " + name.replace('\n', ' ') + "\ndescription: " + desc.replace('\n', ' ') + "\n---\n\n" + body.trim() + "\n"

    private fun uniqueId(base: String, keep: String?): String {
        var c = base
        var i = 1
        while (File(root, c).exists() && c != keep) { i++; c = base + "-" + i }
        return c
    }

    /** Creates a skill (oldId == null) or edits/renames one. Returns the skill id. */
    fun save(oldId: String?, name: String, desc: String, body: String): String {
        val base = slug(name)
        val id = if (oldId != null && (oldId == base || oldId.startsWith(base + "-"))) oldId else uniqueId(base, oldId)
        val dir = File(root, id).apply { mkdirs() }
        File(dir, "SKILL.md").writeText(render(name.trim(), desc.trim(), body))
        if (oldId != null && oldId != id) {
            val was = enabled(oldId)
            File(root, oldId).deleteRecursively()
            prefs.edit().remove("skill_off_" + oldId).apply()
            setEnabled(id, was)
        }
        return id
    }

    fun delete(id: String) {
        File(root, id).deleteRecursively()
        prefs.edit().remove("skill_off_" + id).apply()
    }

    fun duplicate(id: String) {
        val s = all().firstOrNull { it.id == id } ?: return
        save(null, s.name + " copy", s.desc, s.body)
    }

    /** Short block for the system prompt: only names + descriptions, the full text is loaded on demand. */
    fun prompt(): String {
        val list = all().filter { it.enabled }.take(12)
        if (list.isEmpty()) return ""
        val sb = StringBuilder()
        sb.append("You have skills: saved instructions for special tasks. When the user's request matches a skill, FIRST reply with ONLY ")
        sb.append("<tool>{\"name\":\"read_skill\",\"args\":{\"name\":\"SKILL NAME\"}}</tool> and then follow the instructions you get back.\nSkills:\n")
        list.forEach { sb.append("- ").append(it.name).append(": ").append(it.desc.take(120)).append('\n') }
        return sb.toString().trimEnd()
    }

    private fun seed() {
        if (prefs.getBoolean("skills_seeded", false)) return
        prefs.edit().putBoolean("skills_seeded", true).apply()
        save(null, "Email writer", "Use when the user wants an email or formal message written.",
            "1. Ask for nothing extra; use what the user gave.\n2. Write a subject line, a greeting, a short body (3-5 sentences) and a polite closing.\n3. Keep the tone the user asked for (formal by default).\n4. Output only the email.")
        save(null, "Explain simply", "Use when the user says explain, samjhao, or asks how something works.",
            "1. Start with a one-sentence answer.\n2. Then explain in 3-5 short steps with a simple everyday example.\n3. Avoid jargon; if you must use a term, define it in a few words.")
    }
}
