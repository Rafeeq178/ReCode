package com.vethos.app.tools

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ResolveInfo
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.provider.Settings
import com.vethos.app.R
import org.json.JSONObject

/** Batch 1 tools: flashlight, volume, Wi-Fi, battery, open app, call, SMS, WhatsApp draft. */
object PhoneTools {
    private var torchOn = false

    fun build(): List<ToolDef> = listOf(
        ToolDef(
            id = "flashlight", title = "Flashlight", icon = R.drawable.ic_flask, sensitive = false,
            desc = "Turn the torch on or off",
            params = listOf(ToolParam("on", "on or off", "leave empty to toggle", optional = true)),
            usage = """{"on":true|false}""",
            run = { c, a, d -> flashlight(c, a, d) },
            headless = true,
        ),
        ToolDef(
            id = "volume", title = "Volume", icon = R.drawable.ic_play, sensitive = false,
            desc = "Raise, lower, mute or set the media volume",
            params = listOf(
                ToolParam("action", "up / down / mute / unmute / set", "", optional = true),
                ToolParam("level", "level 0-100", "only for set", optional = true),
            ),
            usage = """{"action":"up|down|mute|unmute|set","level":0-100}""",
            run = { c, a, d -> volume(c, a, d) },
            headless = true,
        ),
        ToolDef(
            id = "wifi", title = "Wi-Fi", icon = R.drawable.ic_wifioff, sensitive = false,
            desc = "Show Wi-Fi state and open the Wi-Fi panel",
            params = emptyList(),
            usage = "{}",
            run = { c, a, d -> wifi(c, a, d) },
        ),
        ToolDef(
            id = "battery", title = "Battery", icon = R.drawable.ic_chip, sensitive = false,
            desc = "Battery level, charging state, temperature",
            params = emptyList(),
            usage = "{}",
            run = { c, a, d -> battery(c, a, d) },
            headless = true,
        ),
        ToolDef(
            id = "open_app", title = "Open app", icon = R.drawable.ic_expand, sensitive = false,
            desc = "Open an installed app by its name",
            params = listOf(ToolParam("name", "App name", "e.g. Camera")),
            usage = """{"name":"app name"}""",
            run = { c, a, d -> openApp(c, a, d) },
        ),
        ToolDef(
            id = "call", title = "Call", icon = R.drawable.ic_phone, sensitive = false,
            desc = "Open the dialer with a number (you press call)",
            params = listOf(ToolParam("number", "Phone number", "+92300…")),
            usage = """{"number":"phone number"}""",
            run = { c, a, d -> call(c, a, d) },
        ),
        ToolDef(
            id = "sms", title = "SMS draft", icon = R.drawable.ic_chat, sensitive = false,
            desc = "Open the messages app with the text ready (you press send)",
            params = listOf(ToolParam("number", "Phone number", "+92300…"), ToolParam("text", "Message")),
            usage = """{"number":"phone number","text":"message"}""",
            run = { c, a, d -> sms(c, a, d) },
        ),
        ToolDef(
            id = "whatsapp", title = "WhatsApp draft", icon = R.drawable.ic_share, sensitive = false,
            desc = "Open WhatsApp with the message ready (you press send)",
            params = listOf(
                ToolParam("number", "Phone number", "with country code, optional", optional = true),
                ToolParam("text", "Message"),
            ),
            usage = """{"number":"optional number","text":"message"}""",
            run = { c, a, d -> whatsapp(c, a, d) },
        ),
    )

    // ---------- helpers ----------
    internal fun ok(t: String) = ToolResult(true, t)
    internal fun bad(t: String) = ToolResult(false, t)

    internal fun argBool(a: JSONObject, key: String): Boolean? {
        if (!a.has(key) || a.isNull(key)) return null
        val v = a.opt(key)
        if (v is Boolean) return v
        return when (v.toString().trim().lowercase()) {
            "true", "on", "1", "yes", "haan", "ha", "chalu", "start" -> true
            "false", "off", "0", "no", "nahi", "band", "stop" -> false
            else -> null
        }
    }

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    // ---------- 6. flashlight ----------
    private fun flashlight(c: ToolCtx, a: JSONObject, done: (ToolResult) -> Unit) {
        val cm = c.ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        var id: String? = null
        for (cid in cm.cameraIdList) {
            val ch = cm.getCameraCharacteristics(cid)
            if (ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true) {
                if (id == null || ch.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK) id = cid
            }
        }
        if (id == null) { done(bad("This phone has no flashlight")); return }
        val on = argBool(a, "on") ?: !torchOn
        cm.setTorchMode(id, on)
        torchOn = on
        done(ok(if (on) "Flashlight is ON" else "Flashlight is OFF"))
    }

    // ---------- 7. volume ----------
    private fun volume(c: ToolCtx, a: JSONObject, done: (ToolResult) -> Unit) {
        val am = c.ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val st = AudioManager.STREAM_MUSIC
        val max = am.getStreamMaxVolume(st).coerceAtLeast(1)
        val level = a.optInt("level", -1)
        var action = a.optString("action").trim().lowercase()
        if (action.isEmpty() && level >= 0) action = "set"
        when (action) {
            "up", "raise", "increase" -> am.adjustStreamVolume(st, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            "down", "lower", "decrease" -> am.adjustStreamVolume(st, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            "mute" -> am.adjustStreamVolume(st, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            "unmute" -> am.adjustStreamVolume(st, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
            "set" -> {
                if (level < 0) { done(bad("Give a level from 0 to 100")); return }
                val v = Math.round(level.coerceIn(0, 100) * max / 100f)
                am.setStreamVolume(st, v, AudioManager.FLAG_SHOW_UI)
            }
            else -> Unit
        }
        val now = Math.round(am.getStreamVolume(st) * 100f / max)
        done(ok("Media volume: $now%"))
    }

    // ---------- 9. wifi ----------
    private fun wifi(c: ToolCtx, a: JSONObject, done: (ToolResult) -> Unit) {
        val wm = c.act.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val state = try { if (wm.isWifiEnabled) "ON" else "OFF" } catch (_: Throwable) { "unknown" }
        try {
            c.act.startActivity(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
        } catch (_: Throwable) {
            c.act.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
        }
        done(ok("Wi-Fi is $state. Opened the Wi-Fi panel. Android does not let apps switch it directly, so tap the switch there."))
    }

    // ---------- 13. battery ----------
    private fun battery(c: ToolCtx, a: JSONObject, done: (ToolResult) -> Unit) {
        val bm = c.ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val i = c.ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val plug = when (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) {
            BatteryManager.BATTERY_PLUGGED_AC -> "AC"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "wireless"
            else -> ""
        }
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val sb = StringBuilder("Battery $pct%")
        sb.append(if (charging) " · charging" + (if (plug.isNotEmpty()) " ($plug)" else "") else " · not charging")
        if (temp > 0f) sb.append(" · ").append("%.1f".format(temp)).append("°C")
        done(ok(sb.toString()))
    }

    // ---------- 16. open app ----------
    /** Best matching launcher app for a name (null if none). Also used by the smart router. */
    fun findApp(ctx: Context, q: String): ResolveInfo? {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val apps: List<ResolveInfo> = pm.queryIntentActivities(main, 0)
        val key = norm(q)
        if (key.isEmpty()) return null
        var best: ResolveInfo? = null
        var bestScore = 0
        for (r in apps) {
            val label = norm(r.loadLabel(pm).toString())
            val pkg = r.activityInfo.packageName.lowercase()
            val s = when {
                label == key -> 5
                label.startsWith(key) -> 4
                label.contains(key) -> 3
                label.length >= 3 && key.contains(label) -> 2
                key.length >= 4 && pkg.contains(key) -> 1
                else -> 0
            }
            if (s > bestScore) { best = r; bestScore = s }
        }
        return best
    }

    private fun openApp(c: ToolCtx, a: JSONObject, done: (ToolResult) -> Unit) {
        val q = a.optString("name").trim()
        if (q.isEmpty()) { done(bad("Which app should I open?")); return }
        val hit = findApp(c.act, q)
        if (hit == null) { done(bad("No app found named “$q”")); return }
        val pm = c.act.packageManager
        val launch = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
        if (launch == null) { done(bad("Could not open that app")); return }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.act.startActivity(launch)
        done(ok("Opened " + hit.loadLabel(pm)))
    }

    // ---------- 17. call (opens the dialer; no CALL_PHONE permission needed) ----------
    private fun call(c: ToolCtx, a: JSONObject, done: (ToolResult) -> Unit) {
        val num = a.optString("number").filter { it.isDigit() || it in "+*#" }
        if (num.length < 3) { done(bad("I need a valid phone number")); return }
        try {
            c.act.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num))))
            done(ok("Dialer opened with $num. Press call."))
        } catch (e: Throwable) {
            done(bad(e.message ?: "Could not open the dialer"))
        }
    }

    // ---------- 18. sms (opens the messages app; no SEND_SMS permission needed) ----------
    private fun sms(c: ToolCtx, a: JSONObject, done: (ToolResult) -> Unit) {
        val num = a.optString("number").filter { it.isDigit() || it == '+' }
        val text = a.optString("text").trim()
        if (num.length < 3) { done(bad("I need a valid phone number")); return }
        if (text.isEmpty()) { done(bad("The message is empty")); return }
        try {
            c.act.startActivity(
                Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(num))).putExtra("sms_body", text)
            )
            done(ok("Messages app opened with your text for $num. Press send."))
        } catch (e: Throwable) {
            done(bad(e.message ?: "Could not open the messages app"))
        }
    }

    // ---------- 19. whatsapp draft ----------
    private fun whatsapp(c: ToolCtx, a: JSONObject, done: (ToolResult) -> Unit) {
        val num = a.optString("number").filter { it.isDigit() }
        val text = a.optString("text").trim()
        if (text.isEmpty()) { done(bad("The message is empty")); return }
        val url = "https://wa.me/" + num + "?text=" + Uri.encode(text)
        try {
            try {
                c.act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.whatsapp"))
            } catch (_: ActivityNotFoundException) {
                c.act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            }
            done(ok("WhatsApp opened with your message. Press send."))
        } catch (e: Throwable) {
            done(bad(e.message ?: "Could not open WhatsApp"))
        }
    }
}
