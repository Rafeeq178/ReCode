VETHOS v11 - minimal offline assistant (Kotlin, llama.cpp, no WebView)

Build: put Vethos_v11.zip in the GitHub repo (the workflow builds the highest Vethos_vN.zip). Android 10+, arm64.

What is inside
  - Chat with a local GGUF model (Library: download / pick a model). Code blocks with Copy / Save.
  - Personalities (drawer -> My Offline Chatbots): General Assistant, Planner, Coder. New / edit / duplicate / delete,
    import / export. Each has its own prompt, tone, creativity and list of allowed tools.
    Idea: ask the Planner for a plan, then switch to the Coder and paste the plan.
  - Tools (drawer -> Phone tools): torch, volume, wifi, battery, open app, call, SMS, WhatsApp, navigate, camera,
    notification, calculator, random/password, hash/base64, clipboard, QR maker/scanner, read file, write file, read aloud.
    The model asks with <tool>{"name":"...","args":{...}}</tool>. Call and SMS ask "Allow?" first.
  - Skills (drawer -> Skills): folders skills/<name>/SKILL.md (header: name, description; then instructions).
    Add / edit / duplicate / export / import / delete / switch on-off. The model sees only name + description and loads
    the full text with the tool read_skill. New or edited skills apply to new chats.
  - Agent loop: tool results that carry data are handed back to the model up to 3 times in a row.
  - Look: flat warm background, serif answers without a bubble, soft user bubble, rounded composer.

Removed in v11 (still in Vethos_v9.zip / Vethos_v10.zip): Automations, Mini apps and the HTML runner, Translator and
English mode, smart commands, web / news / weather / email tools, Insights, language packs.
Dropped libraries: ML Kit translate / language-id, jsoup.
