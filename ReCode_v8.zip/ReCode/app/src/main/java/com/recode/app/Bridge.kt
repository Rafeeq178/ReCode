package com.recode.app

import android.app.ActivityManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.StatFs
import android.os.SystemClock
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast
import com.recode.app.ai.ApiClient
import com.recode.app.ai.Engine
import com.recode.app.data.Dl
import com.recode.app.data.Docs
import com.recode.app.data.Downloads
import com.recode.app.net.Web
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Everything the HTML/JS user interface (assets/www) can ask the phone to do.
 * Calls arrive on a WebView background thread; answers go back through RC.native.emit(json).
 *   llm events : {t:"llm", id, k:"loading|loaded|tok|done|stopped|err", v}
 *   results    : {t:"res", id, ok, d}
 *   downloads  : {t:"dl", list:[{name, done, total, state, err}]}
 */
class Bridge(private val act: MainActivity, private val web: WebView) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val appCtx: Context = act.applicationContext
    private var job: Job? = null

    private var pendingPick: String? = null
    private class PendingSave(val id: String, val bytes: ByteArray)
    private var pendingSave: PendingSave? = null

    fun destroy() {
        job?.cancel()
        ApiClient.abort()
        scope.cancel()
    }

    // ------------------------------------------------------------------ events to JS
    private fun emit(o: JSONObject) {
        val js = "window.RC&&RC.native&&RC.native.emit(" + o.toString() + ")"
        web.post { web.evaluateJavascript(js, null) }
    }

    private fun llm(id: String, k: String, v: String = "") {
        emit(JSONObject().put("t", "llm").put("id", id).put("k", k).put("v", v))
    }

    private fun res(id: String, ok: Boolean, d: Any) {
        emit(JSONObject().put("t", "res").put("id", id).put("ok", ok).put("d", d))
    }

    fun emitDownloads(m: Map<String, Dl>) {
        val arr = JSONArray()
        for (d in m.values) {
            arr.put(
                JSONObject().put("name", d.name).put("done", d.done).put("total", d.total)
                    .put("state", d.state).put("err", d.err)
            )
        }
        emit(JSONObject().put("t", "dl").put("list", arr))
    }

    // ------------------------------------------------------------------ device
    @JavascriptInterface
    fun info(): String {
        val o = JSONObject()
        try {
            val am = appCtx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            val st = StatFs(Store.modelsDir.path)
            val ver = try { appCtx.packageManager.getPackageInfo(appCtx.packageName, 0).versionName } catch (_: Throwable) { "1.0" }
            o.put("version", ver ?: "1.0")
            o.put("android", android.os.Build.VERSION.RELEASE + " (API " + android.os.Build.VERSION.SDK_INT + ")")
            o.put("device", android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL)
            o.put("abis", android.os.Build.SUPPORTED_ABIS.joinToString())
            o.put("ramMB", mi.totalMem / (1024 * 1024))
            o.put("availRamMB", mi.availMem / (1024 * 1024))
            o.put("freeMB", st.availableBytes / (1024 * 1024))
            o.put("cores", Runtime.getRuntime().availableProcessors())
            o.put("online", online())
            val f = File(appCtx.filesDir, "crash.txt")
            o.put("crash", if (f.isFile) f.readText().take(6000) else "")
        } catch (e: Throwable) {
            o.put("error", e.message ?: "info failed")
        }
        return o.toString()
    }

    @JavascriptInterface
    fun online(): Boolean {
        return try {
            val cm = appCtx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (_: Throwable) {
            false
        }
    }

    @JavascriptInterface
    fun clearCrash() {
        try { File(appCtx.filesDir, "crash.txt").delete() } catch (_: Throwable) { }
    }

    @JavascriptInterface
    fun ready() {
        act.uiReady = true
    }

    @JavascriptInterface
    fun setBars(dark: Boolean, bg: String) {
        act.runOnUiThread { act.applyBars(dark, bg) }
    }

    @JavascriptInterface
    fun keepAwake(on: Boolean) {
        act.runOnUiThread { act.keepAwake(on) }
    }

    /** true = hide status + navigation bars (preview fullscreen), false = show them again */
    @JavascriptInterface
    fun immersive(on: Boolean) {
        act.runOnUiThread { act.applyImmersive(on) }
    }

    @JavascriptInterface
    fun toast(msg: String) {
        act.runOnUiThread { Toast.makeText(act, msg, Toast.LENGTH_SHORT).show() }
    }

    @JavascriptInterface
    fun copy(text: String) {
        act.runOnUiThread {
            val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("ReCode", text))
        }
    }

    @JavascriptInterface
    fun openExternal(url: String) {
        if (!url.startsWith("http://") && !url.startsWith("https://")) return
        act.runOnUiThread {
            try {
                act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            } catch (_: Throwable) {
                Toast.makeText(act, "No app can open this link", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ------------------------------------------------------------------ models
    @JavascriptInterface
    fun models(): String {
        val arr = JSONArray()
        val files = Store.modelsDir.listFiles { f -> f.isFile && f.name.endsWith(".gguf") }
        files?.sortedBy { it.name }?.forEach {
            arr.put(JSONObject().put("name", it.name).put("size", it.length()))
        }
        return arr.toString()
    }

    @JavascriptInterface
    fun pickModel() {
        act.runOnUiThread { act.pickModel.launch(false) }
    }

    @JavascriptInterface
    fun downloadModel(url: String, name: String, token: String) {
        Store.hfToken = token
        val n = if (name.isBlank()) (Downloads.fileNameFor(url) ?: "") else name
        if (n.isBlank() || !n.endsWith(".gguf", true) || n != File(n).name) {
            toast("The link must point to a .gguf file")
            return
        }
        act.runOnUiThread { act.askNotifPermission() }
        Downloads.start(url, n)
    }

    @JavascriptInterface
    fun resumeDownload(name: String, token: String) {
        Store.hfToken = token
        val u = Downloads.urls[name] ?: return
        Downloads.start(u, name)
    }

    @JavascriptInterface
    fun pauseDownload(name: String) {
        Downloads.pause(name)
    }

    @JavascriptInterface
    fun cancelDownload(name: String) {
        Downloads.cancel(name, true)
    }

    @JavascriptInterface
    fun clearDownload(name: String) {
        Downloads.clearFinished(name)
    }

    @JavascriptInterface
    fun deleteModel(name: String): Boolean {
        if (name != File(name).name) return false
        Engine.unload()
        return File(Store.modelsDir, name).delete()
    }

    // ------------------------------------------------------------------ local / online model
    /** Runs one agent step: loads the model fresh with this agent's system prompt, then streams the answer. */
    @JavascriptInterface
    fun llmRun(id: String, model: String, system: String, prompt: String, maxTokens: Int) {
        startRun(id) {
            val f = File(Store.modelsDir, model)
            if (model != f.name || !f.isFile) throw IllegalStateException("Model file not found: $model")
            llm(id, "loading")
            Engine.load(appCtx, f.absolutePath, system)
            llm(id, "loaded")
            val buf = StringBuilder()
            var last = 0L
            Engine.send(appCtx, prompt, maxTokens.coerceIn(16, 4096)).collect { tok ->
                buf.append(tok)
                val now = SystemClock.uptimeMillis()
                if (now - last > 40) {
                    llm(id, "tok", buf.toString())
                    buf.setLength(0)
                    last = now
                }
            }
            if (buf.isNotEmpty()) llm(id, "tok", buf.toString())
        }
    }

    @JavascriptInterface
    fun apiRun(id: String, base: String, key: String, model: String, system: String, prompt: String, maxTokens: Int, temp: Double) {
        startRun(id) {
            llm(id, "loaded")
            val buf = StringBuilder()
            var last = 0L
            withContext(Dispatchers.IO) {
                ApiClient.stream(base, key, model, system, prompt, maxTokens.coerceIn(16, 8192), temp) { tok ->
                    ensureActive()
                    buf.append(tok)
                    val now = SystemClock.uptimeMillis()
                    if (now - last > 40) {
                        llm(id, "tok", buf.toString())
                        buf.setLength(0)
                        last = now
                    }
                }
            }
            if (buf.isNotEmpty()) llm(id, "tok", buf.toString())
        }
    }

    @JavascriptInterface
    fun llmStop() {
        job?.cancel()
        ApiClient.abort()
    }

    private fun startRun(id: String, body: suspend CoroutineScope.() -> Unit) {
        val prev = job
        job = scope.launch {
            try {
                prev?.cancelAndJoin()
                body()
                llm(id, "done")
            } catch (e: CancellationException) {
                llm(id, "stopped")
                throw e
            } catch (e: Throwable) {
                if (!isActive) llm(id, "stopped") else llm(id, "err", e.message ?: e.javaClass.simpleName)
            }
        }
    }

    // ------------------------------------------------------------------ web
    @JavascriptInterface
    fun webSearch(id: String, query: String, count: Int) {
        scope.launch(Dispatchers.IO) {
            try {
                val arr = JSONArray()
                for (h in Web.search(query, count.coerceIn(1, 8))) {
                    arr.put(JSONObject().put("title", h.title).put("url", h.url).put("snippet", h.snippet))
                }
                res(id, true, arr)
            } catch (e: Throwable) {
                res(id, false, e.message ?: "Search failed")
            }
        }
    }

    @JavascriptInterface
    fun webRead(id: String, url: String, maxChars: Int) {
        scope.launch(Dispatchers.IO) {
            try {
                val (title, text) = Web.readable(url, maxChars.coerceIn(500, 12000))
                res(id, true, JSONObject().put("title", title).put("text", text).put("url", url))
            } catch (e: Throwable) {
                res(id, false, e.message ?: "Could not read the page")
            }
        }
    }

    // ------------------------------------------------------------------ files
    /** Opens the system file picker (several files). Answer: [{name, text} | {name, error}]. */
    @JavascriptInterface
    fun pickDocs(id: String) {
        pendingPick = id
        act.runOnUiThread { act.pickDocs.launch(true) }
    }

    fun onDocsPicked(uris: List<Uri>) {
        val id = pendingPick ?: return
        pendingPick = null
        scope.launch(Dispatchers.IO) {
            try {
                res(id, true, Docs.readAll(appCtx, uris))
            } catch (e: Throwable) {
                res(id, false, e.message ?: "Could not read the files")
            }
        }
    }

    /** Lets the user choose where to save a file (system "Save as" screen). [b64] is the file content. */
    @JavascriptInterface
    fun saveFile(id: String, name: String, mime: String, b64: String) {
        val bytes = try {
            Base64.decode(b64, Base64.DEFAULT)
        } catch (_: Throwable) {
            res(id, false, "Bad file data")
            return
        }
        pendingSave = PendingSave(id, bytes)
        act.runOnUiThread { act.createDoc.launch(arrayOf(name, if (mime.isBlank()) "application/octet-stream" else mime)) }
    }

    fun onSaveTarget(uri: Uri?) {
        val p = pendingSave ?: return
        pendingSave = null
        if (uri == null) {
            res(p.id, false, "cancelled")
            return
        }
        scope.launch(Dispatchers.IO) {
            try {
                val out = appCtx.contentResolver.openOutputStream(uri, "w") ?: throw IllegalStateException("Cannot write there")
                out.use { it.write(p.bytes) }
                res(p.id, true, "saved")
            } catch (e: Throwable) {
                res(p.id, false, e.message ?: "Save failed")
            }
        }
    }
}
