/* ReCode - Phase 1: the agentic loop.
   The model decides the next action each turn: call tools or give the final answer. ReCode executes the tools,
   feeds the results back and repeats until a final answer, the iteration limit, an error limit or a cancel.
   Every turn is still an isolated model call (the local model has a ~4k context), so the loop rebuilds a compact
   prompt each turn from the task, the task state and a trimmed transcript.
   Phase 4 (js/memory.js): RECODE.md project notes and the todo list are put into every prompt, and when the transcript
   gets long the oldest steps are folded into a short summary instead of being dropped. */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var U = RC.u, St = RC.store;

  var MAX_CALLS_PER_TURN = 3;
  var WRITE_TOOLS = { write_file: 1, edit_file: 1, delete_file: 1, rename_file: 1, move_file: 1, create_directory: 1 };
  var VERIFY_TOOLS = { check_syntax: 1, run_tests: 1, run_command: 1 };
  var CONTINUE_RE = /^\s*(continue|go on|keep going|resume|carry on|next|jari|aage|agay|dobara|phir se)\b/i;

  function oneLine(call) {
    var a = call.args || {}, k = a.path || a.from || a.pattern || a.command || a.folder || '';
    return call.name + (k ? ' ' + U.clip(String(k), 50, '…') : '');
  }
  function argsText(call) { return oneLine(call); }

  /** the transcript as prompt text: old results shrink to one line, the newest stay readable */
  function history(tr, budget) {
    var out = [], used = 0, keepFull = 2, n = tr.length;
    for (var i = n - 1; i >= 0; i--) {
      var e = tr[i], age = n - 1 - i, txt;
      if (e.role === 'tool') {
        var full = age < keepFull * 2;
        txt = '[' + e.label + '] ' + (e.ok ? '' : 'FAILED: ') + (full ? U.clip(e.out, Math.min(1400, Math.max(300, Math.floor(budget / 3))), '\n…[cut]') : U.clip(e.out.split('\n')[0], 110, '…'));
      } else if (e.role === 'note') txt = 'NOTE: ' + e.text;
      else txt = 'You said: ' + U.clip(e.text, age < 2 ? 500 : 120, '…');
      if (used + txt.length > budget && out.length) { out.unshift('…(' + (i + 1) + ' earlier step(s) omitted)'); break; }
      used += txt.length; out.unshift(txt);
    }
    return out.join('\n');
  }

  RC.agentLoop = async function (run, bb, H, opts) {
    opts = opts || {};
    var S = RC.settings, A = RC.agents, T = RC.tools, agentId = opts.agent || 'agent', isSub = !!opts.sub, err = '';
    var cfg = opts.system ? { prompt: opts.system } : RC.agentCfg('agent'), B = H.budget();
    var maxIter = opts.maxIter ? Math.max(1, Math.min(20, opts.maxIter)) : Math.max(2, Math.min(40, +S.maxIter || 12));
    var names = (opts.tools || T.names().filter(function (n) { return !/^web_/.test(n); })).filter(function (n) { return T.registry[n]; });
    if (!names.length) names = ['list_files', 'read_file'];
    var sys = cfg.prompt + '\n\nTools (name | params - what it does):\n' + names.map(function (n) { var t = T.registry[n]; return n + ' | ' + t.params + ' - ' + U.clip(t.description, 90, ''); }).join('\n');
    var planMode = RC.perms && RC.perms.mode() === 'plan';
    if (planMode && !isSub) sys += '\n\nPLAN MODE (read-only): you can only use reading tools. Explore the project, then reply with the final answer as a PLAN: a numbered list of concrete steps naming the files to create or change. Do not write code in the plan.';
    if (planMode && isSub) sys += '\n\nPLAN MODE: files cannot be changed now. Investigate and report what you would change.';
    if (!isSub) run.permMode = planMode ? 'plan' : RC.perms ? RC.perms.mode() : 'ask';
    var roster = '';
    if (!isSub && RC.subagents && names.indexOf('delegate') >= 0) {
      var sel = RC.subagents.select(bb.text, 3);
      if (sel.length) roster = 'Specialists you may delegate to with TOOL: delegate | agent | task (only if it clearly helps; otherwise work alone):\n' + RC.subagents.roster(sel.map(function (x) { return x.name; }), 70);
      bb.suggested = sel.map(function (x) { return x.name; });
    }
    var state = bb.state = { task: bb.text, modified: [], verified: true, calls: 0 };
    var stopBlocks = 0, tr = [], invalid = 0, fails = 0, nudged = false, lastSig = '', repeat = 0, final = '', ctxTouch = {};
    var M = RC.mem, cs = M ? M.compact.fresh() : null, todoNudged = false, compactSkip = 0;
    if (M && !isSub) M.todo.startRun(CONTINUE_RE.test(bb.text));
    var ctx = {
      mode: RC.perms ? RC.perms.mode() : 'ask', signal: run.ctl.signal, ts: null, allowed: names, depth: opts.depth || 0, agent: agentId, goal: bb.goal || '',
      touch: function (p) { ctxTouch[p] = 1; if (run.files.indexOf(p) < 0) run.files.push(p); if (state.modified.indexOf(p) < 0) state.modified.push(p); }
    };
    if (RC.hooks && RC.hooks.attach) RC.hooks.attach(ctx, run);

    /** fold the oldest transcript entries into the summary when the transcript no longer fits (Phase 4) */
    async function maybeCompact(histBudget) {
      var keep = Math.max(2, Math.min(12, +S.compactKeep || 6));
      if (tr.length <= keep + 2) return;
      var raw = history(tr, 1e9).length;
      if (tr.length <= 20 && raw <= histBudget * 0.8) return;
      var old = tr.slice(0, tr.length - keep), why = tr.length > 20 ? 'many steps' : 'transcript too long';
      if (RC.hooks) {
        var pc = await RC.hooks.run('PreCompact', { entries: old.length, chars: raw, reason: why, state: state, todos: M.todo.items().slice() }, ctx);
        if (pc.blocked) { compactSkip = iter + 3; return; }
        pc.feedback.forEach(function (f) { M.compact.keep(cs, f); });
      }
      M.compact.fold(cs, old);
      tr = tr.slice(tr.length - keep);
      cs.runs++; run.compactions = (run.compactions || 0) + 1;
      await H.toolStep(run, agentId, 'Compacting context (' + old.length + ' steps)', async function (ts) {
        ts.log.push(why + ': ' + raw + ' chars of transcript, ' + old.length + ' older step(s) folded into a summary.');
        ts.log.push(M.compact.render(cs, 900));
        ts.note = old.length + ' steps -> summary';
        return 1;
      });
    }

    for (var iter = 1; iter <= maxIter; iter++) {
      H.check(run);
      run.agentIter = iter;
      var files = St.fileList();
      var rest = B - sys.length - 220;
      if (cs && S.autoCompact !== false && iter >= compactSkip) await maybeCompact(Math.floor(rest * 0.55));
      var stateTxt = 'Project files (' + files.length + '): ' + (files.length ? U.clip(files.join(', '), 500, '…') : 'none yet') +
        (state.modified.length ? '\nChanged by you so far: ' + state.modified.join(', ') + (state.verified ? ' (verified)' : ' (NOT yet verified)') : '');
      var hist = history(tr, Math.floor(rest * 0.55));
      var notes = M && S.useNotes !== false ? M.notes(isSub ? 500 : (+S.notesChars || 1000)) : '';
      var todoTxt = M && !isSub ? M.todo.text() : '';
      var prompt = A.fit(B - sys.length, [
        { t: notes && 'PROJECT NOTES (RECODE.md):\n' + notes, p: 6, min: 120 },
        { t: 'TASK: ' + U.clip(bb.text, 1500), p: 10, min: 300 },
        { t: todoTxt && 'TODO LIST (keep it up to date with TOOL: todo):\n' + todoTxt, p: 9, min: 100 },
        { t: stateTxt, p: 7, min: 120 },
        { t: cs && M.compact.render(cs, Math.max(300, Math.min(900, Math.floor(B * 0.15)))), p: 9, min: 150 },
        { t: roster, p: 4, min: 80 },
        { t: !isSub && bb.skills, p: 3, min: 120 },
        { t: hist && 'Progress so far (tool results):\n' + hist, p: 8, min: 300 },
        { t: 'Turn ' + iter + '/' + maxIter + '. ' + (tr.length ? 'Decide the next step: call tools, or if the task is complete give the final answer in plain text (no TOOL lines).' : 'Start by inspecting what you need (list_files / read_file), or act directly if the task is simple.'), p: 10, min: 60 }
      ]);
      var s = H.step(run, agentId, 'Turn ' + iter + ' · deciding');
      var out;
      try { out = await H.llmStep(run, s, sys, prompt, opts.maxTokens || H.maxOf(agentId, 1200)); }
      catch (e) { if (e.name === 'AbortError') throw e; if (iter === 1) throw e; fails++; tr.push({ role: 'note', text: 'The model call failed (' + e.message + '). Try again.' }); if (fails >= 3) { final = 'The model kept failing: ' + e.message; break; } continue; }

      var parsed = T.parse(out);
      s.title = 'Turn ' + iter + (parsed.calls.length ? ' · ' + parsed.calls.map(function (c) { return c.name; }).join(', ') : ' · answer');
      if (parsed.calls.length) s.note = parsed.calls.length + ' tool call(s)';
      if (parsed.text) tr.push({ role: 'model', text: parsed.text });

      // ---- no valid call: either the final answer or a malformed call
      if (!parsed.calls.length) {
        if (parsed.errors.length) {
          invalid++;
          s.note = 'invalid tool call';
          tr.push({ role: 'note', text: 'Your tool call was invalid: ' + parsed.errors[0] + ' Use exactly: TOOL: name | arg | arg' });
          if (invalid >= 3) { final = 'Stopped: the model could not produce a valid tool call after 3 tries. ' + parsed.errors[0] + (parsed.text ? '\n\n' + parsed.text : ''); err = 'invalid tool calls'; break; }
          continue;
        }
        var ans = parsed.text.replace(/^\s*FINAL(?: ANSWER)?:\s*/i, '').trim();
        if (!ans && tr.length) { // empty answer: ask once more, then fall back to what was done
          invalid++;
          if (invalid >= 3) { final = H.summary(run, state, 'The model returned no answer.'); break; }
          tr.push({ role: 'note', text: 'Your reply was empty. Call a tool or give the final answer.' });
          continue;
        }
        // Stop hooks (syntax verification, optional tests) can send the agent back to work
        if (RC.hooks && !planMode && stopBlocks < 2) {
          var sh = await RC.hooks.run('Stop', { state: state, text: ans }, ctx);
          if (sh.blocked) { stopBlocks++; tr.push({ role: 'note', text: sh.reason }); s.note = 'stop blocked by hook'; continue; }
        }
        // an unfinished todo list: ask once to finish or tidy it before the final answer
        if (M && !isSub && !planMode && !todoNudged && M.todo.open().length) {
          todoNudged = true;
          tr.push({ role: 'note', text: 'Your todo list still has open items:\n' + M.todo.text() + '\nFinish them, or mark them (TOOL: todo | done | N, or remove), then give the final answer.' });
          s.note = 'open todo items';
          continue;
        }
        // do not accept "done" for changed code that was never checked: ask once to verify
        if (state.modified.length && !state.verified && !nudged) {
          nudged = true;
          tr.push({ role: 'note', text: 'You changed files but did not verify them. Run check_syntax or run_tests now, then give the final answer.' });
          continue;
        }
        final = ans || H.summary(run, state, '');
        break;
      }

      // ---- execute the requested tools
      invalid = 0;
      var calls = parsed.calls.slice(0, MAX_CALLS_PER_TURN);
      if (parsed.calls.length > calls.length) tr.push({ role: 'note', text: 'Only ' + MAX_CALLS_PER_TURN + ' tool calls run per turn; ' + (parsed.calls.length - calls.length) + ' skipped - request them again next turn.' });
      var turnFail = 0;
      async function execCall(call) {
        var cctx = Object.assign({}, ctx);
        var res = await H.toolStep(run, agentId, argsText(call), async function (ts) {
          cctx.ts = ts;
          ts.log.push('TOOL ' + call.name + ' ' + U.clip(JSON.stringify(call.args), 400, '…'));
          var r = await T.exec(call, cctx);
          ts.log.push(U.clip(r.out, 1500, '…'));
          if (r.ok) ts.note = 'ok'; else H.finish(run, ts, 'error', r.blocked ? 'blocked' : 'failed');
          return r;
        });
        state.calls++;
        return res;
      }
      function record(call, res) {
        if (res.ok) {
          if (WRITE_TOOLS[call.name]) state.verified = false;
          if (VERIFY_TOOLS[call.name] && !/^(FAILED|ERROR)/.test(res.out)) state.verified = true;
          if (call.name === 'run_tests' && /^FAILED/.test(res.out)) state.verified = false;
          if (call.name === 'delegate' && /NOT verified/.test(res.out)) state.verified = false;
          if (call.name === 'delegate') { var fm = /Files changed: ([^\n(]+)/.exec(res.out); if (fm) fm[1].split(',').forEach(function (x) { x = x.trim(); if (x && state.modified.indexOf(x) < 0) state.modified.push(x); }); }
        } else turnFail++;
        tr.push({ role: 'tool', label: oneLine(call), ok: res.ok, out: res.out });
        H.emit(run, true);
      }
      // several read-only specialists in one turn run side by side
      var par = calls.length > 1 && RC.subagents && calls.every(function (c) { return c.name === 'delegate' && RC.subagents.parallelSafe(c.args && c.args.agent); });
      if (par) {
        H.check(run);
        var results = await Promise.all(calls.map(execCall));
        calls.forEach(function (c, i) { record(c, results[i]); });
      } else for (var c = 0; c < calls.length; c++) {
        var call = calls[c];
        H.check(run);
        var sig = call.name + JSON.stringify(call.args);
        if (sig === lastSig) repeat++; else { repeat = 0; lastSig = sig; }
        if (repeat >= 2) {
          tr.push({ role: 'tool', label: oneLine(call), ok: false, out: 'You already ran this exact call ' + (repeat + 1) + ' times with the same result. Do something different or give the final answer.' });
          turnFail++; continue;
        }
        record(call, await execCall(call));
      }
      fails = turnFail === calls.length ? fails + 1 : 0;
      if (fails >= 4) { final = H.summary(run, state, 'Stopped: four turns in a row had only failing tool calls.'); err = 'tool failures'; break; }
    }
    if (!final) final = H.summary(run, state, 'Stopped after ' + maxIter + ' turns (iteration limit). Say "continue" to go on.');
    if (!isSub) { run.final = final; if (err) run.error = err; if (planMode && !err) run.plan = final; }
    return { final: final, state: state, error: err };
  };
})();
