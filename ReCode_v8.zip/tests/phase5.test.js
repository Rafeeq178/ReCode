// Phase 5 (v8) tests: assets/binary guard, loop detector, skills, site kit, pipeline site flow, research filter. Run: node tests/phase5.test.js
const fs = require('fs'), path = require('path'), vm = require('vm');
const WWW = path.join(__dirname, '../ReCode/app/src/main/assets/www/js/');
const win = { RC: {}, addEventListener() {}, matchMedia: null };
global.window = win; global.document = { createElement() { return { style: {}, setAttribute() {}, remove() {} }; }, createTextNode: t => t, body: {}, querySelector() {} };
global.navigator = { onLine: true }; global.localStorage = { getItem() { return null; }, setItem() {} }; global.AbortController = AbortController;
const RC = win.RC;
function load(f) { vm.runInThisContext(fs.readFileSync(WWW + f, 'utf8'), { filename: f }); }
load('util.js');
const files = {};
RC.store = { files, cur: { id: 'p', name: 'My first project' }, fileList: () => Object.keys(files).sort(), putFile: async (p, c) => { files[p] = c; }, delFile: async p => { delete files[p]; }, touch() {}, msgs: [] };
RC.bus = { emit() {}, on() {} }; RC.saveSettings = () => {}; RC.set = (k, v) => { RC.settings[k] = v; };
let searched = [];
RC.native = { call() {}, online: () => true, keepAwake() {}, search: async q => { searched.push(q); return [
  { title: 'Behance', url: 'https://www.behance.net/x', snippet: 'a' }, { title: 'MDN', url: 'https://developer.mozilla.org/en-US/docs/Web/CSS/grid', snippet: 'grid' }]; },
  read: async u => ({ title: 'MDN grid', text: 'CSS grid layout is a two-dimensional system. '.repeat(10) }) };
RC.settings = { maxIter: 6, ctxChars: 7000, agents: {}, provider: 'local', keepAwake: false, permMode: 'auto', perms: { global: {}, files: [], confirmDelete: true, confirmOverwrite: true }, useSkills: true, useSiteKit: true, siteCopy: true, autoResearch: true, review: true, fixLoops: 1, architect: true, skills: [], skillsOff: [], hooks: { custom: [] } };
RC.agentCfg = id => ({ on: true, max: 800, prompt: RC.agents.def[id].system });
let script = [], prompts = [];
RC.run = { entry: f => f['index.html'] ? 'index.html' : null, check: async () => ({ issues: [], fixes: [], ran: true }), probe: async () => ({ errors: [], logs: [] }) };
RC.llm = { AbortErr() { const e = new Error('Stopped'); e.name = 'AbortError'; return e; }, ready: () => ({ ok: true }),
  run: async o => { prompts.push(o); if (!script.length) throw new Error('script exhausted'); const r = script.shift(); return typeof r === 'function' ? r(o) : r; } };
['assets.js', 'skills.js', 'sitekit.js', 'agents.js', 'tools.js', 'memory.js', 'hooks.js', 'perms.js', 'pipeline.js', 'loop.js'].forEach(load);
const A = RC.assets, K = RC.sitekit, S = RC.skills;
let pass = 0, fail = 0;
function ok(c, m) { if (c) pass++; else { fail++; console.log('FAIL', m); } }
function reset() { for (const k of Object.keys(files)) delete files[k]; script = []; prompts = []; searched = []; RC.settings.useSiteKit = true; RC.settings.siteCopy = true; }

(async () => {
  // ---- binary guard
  ok(A.fixPath('assets/logo.png') === 'assets/logo.svg' && A.fixPath('a/b.JPG') === 'a/b.svg', 'png/jpg -> svg');
  ok(A.fixPath('x.mp3') === '' && A.fixPath('style.css') === 'style.css', 'audio dropped, css kept');
  const plan = RC.agents.parsePlan('SUMMARY: coffee\nRESEARCH: no\nFILES:\n- index.html | page\n- assets/logo.png | the logo\n- song.mp3 | music\n- style.css | css', 'coffee site', []);
  ok(plan.files.map(f => f.path).join() === 'index.html,style.css,assets/logo.svg' || plan.files.some(f => f.path === 'assets/logo.svg'), 'planner turns logo.png into logo.svg');
  ok(!plan.files.some(f => /mp3|png/.test(f.path)), 'planner drops binary files');

  // ---- loop detector (the screenshot: Xu9995777333...)
  ok(A.degenerate('const a = 1;\n' + 'Xu9995777333'.repeat(40)), 'detects the Xu999 loop');
  ok(!A.degenerate('<li>One</li>\n<li>Two</li>\n<li>Three</li>\n'.repeat(3)), 'normal repeated html is not a loop');
  ok(!A.degenerate('-'.repeat(300)) && !A.degenerate('function a(){return 1}\n'.repeat(2)), 'dash line is not a loop');
  ok(A.trimLoop('good start ' + 'Xu9995777333'.repeat(40)).length < 60, 'trimLoop keeps the good start only');

  // ---- llm.js loop guard stops the model
  delete RC.llm; let stopped = 0, handler = null;
  RC.native = Object.assign(RC.native, { has: true, call(m) { if (m === 'llmStop') { stopped++; setTimeout(() => handler({ k: 'stopped' }), 5); } }, onLlm(id, fn) { handler = fn; return () => { }; }, models: () => [{ name: 'm.gguf' }] });
  RC.settings.model = 'm.gguf';
  win.Android = {}; load('llm.js'); 
  const p = RC.llm.run({ system: 's', prompt: 'p', maxTokens: 500 });
  setTimeout(() => { handler({ k: 'loaded' }); handler({ k: 'tok', v: 'body{color:red}\n' }); for (let i = 0; i < 40; i++) handler({ k: 'tok', v: 'Xu9995777333' }); }, 5);
  const out = await p;
  ok(stopped >= 1 && out.length < 200 && out.indexOf('body{color:red}') === 0, 'llm.js stopped the loop and kept the good part: ' + out.length);
  RC.llm = { AbortErr() { const e = new Error('Stopped'); e.name = 'AbortError'; return e; }, ready: () => ({ ok: true }), run: async o => { prompts.push(o); if (!script.length) throw new Error('script exhausted'); const r = script.shift(); return typeof r === 'function' ? r(o) : r; } };

  // ---- repair + empty sections
  const rp = A.repair({ 'index.html': '<link rel="icon" href="favicon.ico"><img src="assets/logo.png" alt="x"><div style="background:url(img/bg.jpg)"></div>' }, { name: 'Brew', type: 'coffee' });
  ok(rp.files['assets/logo.svg'] && rp.files['index.html'].indexOf('assets/logo.svg') > 0 && rp.files['favicon.svg'], 'missing images get SVG files and the HTML is rewritten');
  ok(A.emptySections('index.html', '<section id="menu"><h2>Menu</h2></section>').length === 1, 'empty menu section found');
  ok(A.emptySections('index.html', '<section><h2>Menu</h2><div class="cards"><ul><li>a</li></ul></div></section>').length === 0, 'filled section not flagged');

  // ---- skills
  ok(S.pick('build a coffee shop website with a logo', 'coder').some(k => k.name === 'web-design'), 'web-design skill picked');
  ok(S.pick('make a logo png', 'coder').some(k => k.name === 'images-and-logos'), 'images skill picked for logo');
  ok(/Skills/.test(S.prompt('contact form validation', 'coder', 600)) && S.prompt('contact form validation', 'coder', 300).length <= 400, 'skill prompt is short');
  RC.settings.useSkills = false; ok(S.prompt('website', 'coder', 600) === '', 'skills can be switched off'); RC.settings.useSkills = true;
  const nm = S.importText('---\nname: My Rules\ntriggers: invoice,billing\n---\nAlways show totals with two decimals and the currency code.');
  ok(nm === 'my-rules' && S.pick('make an invoice page', 'coder').some(k => k.name === 'my-rules'), 'custom skill import + pick');
  S.toggle('my-rules', false); ok(!S.pick('make an invoice page', 'coder').some(k => k.name === 'my-rules'), 'skill toggle off'); S.remove('my-rules');

  // ---- site kit
  const req = 'Build a modern landing page for a coffee shop with a menu and contact form';
  ok(K.isSite(req) && K.detectType(req) === 'coffee', 'detects a coffee website');
  ok(!K.isSite('make a snake game') && !K.isSite('python script to scrape a page'), 'games/python are not sites');
  const f = K.files(K.spec(req));
  ok(['index.html', 'style.css', 'script.js', 'assets/logo.svg', 'assets/hero.svg', 'assets/favicon.svg'].every(n => f[n] && f[n].length > 200), 'site has 6 real files');
  ok(A.emptySections('index.html', f['index.html']).length === 0, 'no empty sections in the site');
  ok(!/\.(png|jpe?g)/i.test(f['index.html'] + f['style.css']), 'site uses no binary images');
  const rf = A.repair(f, { name: 'x' }); ok(Object.keys(rf.files).length === 0, 'site has no broken references');
  ok((f['index.html'].match(/<article class="card/g) || []).length === 6, 'menu has 6 items');
  ok(!/opacity:0/.test(f['style.css'].replace(/\.js \.reveal\.pre\{opacity:0/, '')), 'content is visible without JS (opacity:0 only behind .js)');
  let syn = true; try { new Function(f['script.js']); } catch (e) { syn = false; } ok(syn, 'site script.js parses');
  const sp = K.spec('landing page for a pizza restaurant called "Luigi\'s Oven"', { tagline: 'Wood-fired pizza', items: [{ name: 'Margherita', desc: 'Basil', price: '$9' }, { name: 'Pepperoni', desc: 'Spicy', price: '$10' }, { name: 'Veggie', desc: 'Fresh', price: '$9' }] });
  ok(sp.type === 'restaurant' && /Luigi/.test(sp.name) && sp.tag === 'Wood-fired pizza' && sp.items.length === 3, 'spec: name from request, copy merged');
  ok(K.parseCopy('Sure! ```json\n{"name":"A","items":[]}\n```') && K.parseCopy('no json') === null, 'copy json parsed tolerant');
  ok(K.files(K.spec('portfolio website for me'))['index.html'].indexOf('id="work"') > 0, 'portfolio has Work section');

  // ---- pipeline: build mode uses the site kit (model writes only the text)
  reset();
  script = ['{"name":"Brew & Bean","tagline":"Coffee roasted fresh","about":"We roast coffee in small batches.","features":[{"title":"A","text":"a"},{"title":"B","text":"b"},{"title":"C","text":"c"}],"items":[{"name":"Mocha","desc":"x","price":"$4"},{"name":"Latte","desc":"y","price":"$4"},{"name":"Flat White","desc":"z","price":"$4"}]}'];
  let run = await RC.pipe.start(req, 'build').done;
  ok(run.status === 'done' && files['index.html'] && files['assets/logo.svg'] && /Mocha/.test(files['index.html']), 'build mode: site written with model copy; status=' + run.status + ' ' + (run.error || ''));
  ok(prompts.length === 1, 'only ONE model call for a website (was 14 steps): ' + prompts.length);
  ok(/Done/.test(run.final) && /SVG/.test(run.final), 'final message mentions SVG');
  // model failure -> default text, still a full site
  reset(); script = ['I cannot do this'];
  run = await RC.pipe.start(req, 'build').done; ok(run.status === 'done' && /Espresso/.test(files['index.html']), 'bad copy -> tested default text');
  reset(); RC.settings.siteCopy = false; run = await RC.pipe.start(req, 'build').done; ok(run.status === 'done' && prompts.length === 0, 'siteCopy off -> zero model calls');
  // existing project -> not replaced by the site kit
  reset(); files['index.html'] = '<html><body><h1>mine</h1></body></html>'; files['style.css'] = 'body{}';
  script = ['SUMMARY: change the page\nRESEARCH: no\nFILES:\n- index.html | edit', '```html\n<html><body><h1>changed landing page</h1></body></html>\n```'];
  run = await RC.pipe.start('change the landing page for the coffee shop title', 'build').done; ok(/changed/.test(files['index.html']) && !files['assets/logo.svg'], 'existing project is edited, not replaced');

  // ---- build mode: a planned logo.png is generated as SVG with no model call
  reset(); RC.settings.useSiteKit = false;
  script = ['SUMMARY: a page\nRESEARCH: no\nFILES:\n- index.html | page\n- assets/logo.png | logo', 'ARCH', '```html\n<!DOCTYPE html><html><body><h1>Hi</h1><img src="assets/logo.svg" alt="logo"><p>some body text that is long enough</p></body></html>\n```'];
  run = await RC.pipe.start('Build a page with a logo', 'build').done;
  ok(files['assets/logo.svg'] && /<svg/.test(files['assets/logo.svg']) && !files['assets/logo.png'], 'logo became a generated SVG: ' + Object.keys(files).join());
  ok(prompts.every(x => !/logo\.png/.test(x.prompt.split('FILE TO WRITE')[1] || '')), 'model never asked to write logo.png');
  RC.settings.useSiteKit = true;

  // ---- write_file tool guard
  reset();
  let r = await RC.tools.exec({ name: 'write_file', args: { path: 'assets/logo.png', content: 'Xu999' } }, { touch() {} });
  ok(r.ok && files['assets/logo.svg'] && !files['assets/logo.png'], 'write_file logo.png -> SVG created: ' + JSON.stringify(r).slice(0, 120));
  r = await RC.tools.exec({ name: 'write_file', args: { path: 'a.js', content: 'x=1;\n' + 'Xu9995777333'.repeat(40) } }, { touch() {} });
  ok(!r.ok && !files['a.js'], 'write_file refuses looping content');
  r = await RC.tools.exec({ name: 'write_file', args: { path: 'song.mp3', content: 'abc' } }, { touch() {} });
  ok(!r.ok, 'write_file refuses mp3');

  // ---- research: blocked sites are never read, queries exclude them
  reset(); script = ['SUMMARY: page\nRESEARCH: yes\nQUERY: modern coffee shop landing page design inspiration\nFILES:\n- index.html | page', 'notes [1]', 'ARCH', '```html\n<!DOCTYPE html><html><body><h1>x</h1><p>a long enough paragraph of body text here</p></body></html>\n```'];
  RC.settings.useSiteKit = false;
  run = await RC.pipe.start('Build a page about coffee', 'build').done;
  ok(searched.length === 2 && searched.every(q => /-site:behance\.net/.test(q)), 'two research queries, both exclude Behance/Dribbble: ' + searched.length);
  ok(!run.sources.some(s => /behance/.test(s.url)) && run.sources.some(s => /mozilla/.test(s.url)), 'research used MDN, not Behance');
  console.log(pass + ' passed, ' + fail + ' failed');
  process.exit(fail ? 1 : 0);
})().catch(e => { console.log('CRASH', e); process.exit(1); });
