package com.androidharness.app.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/**
 * Google-blue–seeded Material 3 palettes.
 *
 * These are the fallback schemes used when wallpaper dynamic color is unavailable or
 * disabled (pre-Android 12 devices, or dynamicColor off). The seed is the Google Blue
 * (#0B57D0) used across Google's Material 3 apps.
 *
 * The tertiary ramp is deliberately a neutral slate instead of the default purple,
 * the UI does not use tertiary for branding, and a purple accent leaking through
 * chips/badges is exactly what made the old design feel noisy.
 */

internal val LightColors = lightColorScheme(
    primary = Color(0xFF1F1E1D),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFF0DDD3),
    onPrimaryContainer = Color(0xFF3A1F12),
    secondary = Color(0xFFC6613F),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFF0EEE6),
    onSecondaryContainer = Color(0xFF2B2A28),
    tertiary = Color(0xFFD97757),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFF6E3DA),
    onTertiaryContainer = Color(0xFF3A1F12),
    error = Color(0xFFBA1A1A),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
    background = Color(0xFFFAF9F5),
    onBackground = Color(0xFF1F1E1D),
    surface = Color(0xFFFAF9F5),
    onSurface = Color(0xFF1F1E1D),
    surfaceVariant = Color(0xFFEDEBE3),
    onSurfaceVariant = Color(0xFF5F5D58),
    outline = Color(0xFF8C8A84),
    outlineVariant = Color(0xFFE3E0D6),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF5F3EC),
    surfaceContainer = Color(0xFFF0EEE6),
    surfaceContainerHigh = Color(0xFFEBE8DF),
    surfaceContainerHighest = Color(0xFFE5E2D8),
    inverseSurface = Color(0xFF2B2A28),
    inverseOnSurface = Color(0xFFF5F3EC),
    inversePrimary = Color(0xFFE8E6DF),
    scrim = Color(0xFF000000),
)

internal val DarkColors = darkColorScheme(
    primary = Color(0xFFF5F3EC),
    onPrimary = Color(0xFF1F1E1D),
    primaryContainer = Color(0xFF5A3322),
    onPrimaryContainer = Color(0xFFF6E3DA),
    secondary = Color(0xFFE08A6A),
    onSecondary = Color(0xFF3A1F12),
    secondaryContainer = Color(0xFF3A3835),
    onSecondaryContainer = Color(0xFFEDEBE3),
    tertiary = Color(0xFFE08A6A),
    onTertiary = Color(0xFF232B33),
    tertiaryContainer = Color(0xFF4A3329),
    onTertiaryContainer = Color(0xFFF6E3DA),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
    background = Color(0xFF262624),
    onBackground = Color(0xFFEDEBE3),
    surface = Color(0xFF262624),
    onSurface = Color(0xFFEDEBE3),
    surfaceVariant = Color(0xFF3A3835),
    onSurfaceVariant = Color(0xFFBDBAB2),
    outline = Color(0xFF8C8A84),
    outlineVariant = Color(0xFF45433F),
    surfaceContainerLowest = Color(0xFF1F1E1D),
    surfaceContainerLow = Color(0xFF2B2A28),
    surfaceContainer = Color(0xFF302F2C),
    surfaceContainerHigh = Color(0xFF3A3835),
    surfaceContainerHighest = Color(0xFF45433F),
    inverseSurface = Color(0xFFEDEBE3),
    inverseOnSurface = Color(0xFF2B2A28),
    inversePrimary = Color(0xFF1F1E1D),
    scrim = Color(0xFF000000),
)

/**
 * AMOLED surfaces: the dark scheme with every background role at (or near)
 * true black, where OLED pixels are fully off. Accent and content roles come
 * from the base scheme untouched, so this works over both the static palette
 * and a wallpaper-derived dynamic one.
 */
internal fun ColorScheme.amoledSurfaces(): ColorScheme = copy(
    background = Color.Black,
    surface = Color.Black,
    surfaceVariant = Color(0xFF1B1B1F),
    surfaceContainerLowest = Color.Black,
    surfaceContainerLow = Color(0xFF0A0A0C),
    surfaceContainer = Color(0xFF101014),
    surfaceContainerHigh = Color(0xFF16161A),
    surfaceContainerHighest = Color(0xFF1D1D22),
    outlineVariant = Color(0xFF2C2C31),
)

/**
 * The only hardcoded hues in the app: status colors.
 *
 * M3 has no success/warning roles, and status must read the same regardless of the
 * (dynamic, wallpaper-derived) accent, a green "done" and a red "failed" are
 * universal. Everything else in the UI uses theme roles only.
 */
class StatusColors(val success: Color, val warning: Color)

internal val StatusLight = StatusColors(
    success = Color(0xFF157A3E),
    warning = Color(0xFF9A6A00),
)

internal val StatusDark = StatusColors(
    success = Color(0xFF83D69F),
    warning = Color(0xFFF0C97A),
)

val LocalStatusColors = staticCompositionLocalOf { StatusLight }
