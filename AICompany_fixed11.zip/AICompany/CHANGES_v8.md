# ReCode v8 (from fixed9)

## Root cause: tools never worked
- `ApprovalQueue` was never shown to the owner, so every ASK tool (run_command, run_python, run_node,
  install_package, hire_worker, edit_worker, messaging) waited 5 minutes and then failed with "Approval timed out".
  New global permission popup (`ApprovalHost`): Allow once / Allow 1 hour / Reject.
- The Chat screen was a plain model chat and never called a tool. Chat now runs the tool-using agent
  (button with the wrench icon next to the model chip switches Tools ON/OFF).
- Assistant tools now include run_command, run_python, run_node, install_package; run limit 15 min, 12 steps.
- Alpine minirootfs has no /etc/resolv.conf (apk/pip could not resolve names): written before each shell start.
- run_python / run_node install python3 / nodejs with apk on first use when missing.

## Terminal
- It was running (prompt `localhost:/workspace#` visible) but white text was drawn on the cream app surface. The view now
  has a dark background. Tap opens the keyboard (was an empty handler). Extra key row: Esc Tab ^C ^D arrows - / | ~.

## Local models
- LFM3 needs llama.cpp b11960+ (pinned b8683 does not know the architecture, so loading returned 0).
  `LLAMA_REF` is now b12088 in `.github/workflows/build.yml`. If the build fails on a llama.cpp API change, set it back to
  b8683 and send the CI log.
- llama.cpp error text is captured (`nativeLastError`) and shown in the load error instead of "could not be loaded".
- A big model that fails to create its context is retried with 3072 / 2048 / 1536 / 1024 / 512 tokens of context.
- Threads: only the fast CPU cores (was fixed 4).

## Company screen
- One card per worker: avatar, name, role, status chip (WORKING / IDLE / PAUSED / FIRED), current task, last result,
  tool count, done count, version. Summary line on top.

Not compiled here: build through CI and check the log.
