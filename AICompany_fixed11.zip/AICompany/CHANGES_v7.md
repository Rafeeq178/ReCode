# AICompany v7 -> ReCode (from fixed8)

## Providers: only paste an API key
- Models screen has a "Cloud model (free API)" card: Groq, OpenRouter, Gemini, Cerebras, NVIDIA NIM, Mistral, DeepSeek, OpenAI, Claude.
  Tap one -> name, base URL and a default model are filled in; paste the key, Save.
- "Load models" in the editor asks the service for the live model list (free `:free` models first), so no model name has to be typed.

## Local model
- RamGuard: models are memory-mapped, so free RAM under-reported what fits (a 1 GB model was refused on a 4 GB phone).
  Budget is now max(free RAM, 55% of total RAM). Clear message when a model is really too big.

## Terminal "Shell exited with code -9"
- `PROOT_NO_SECCOMP=1` is always set (Android's seccomp filter kills proot's accelerated mode on several phones).
- If the shell is still killed with -9, it restarts once automatically in a minimal "safe mode" (no fake root, no /sys bind).

## Agent
- Small models sent `final_report` with empty arguments until LOOP_DETECTED. Invalid-argument errors now include the exact
  correct JSON shape, and the CEO prompt shows a final_report example.

## Skills & Tools (new drawer entry)
- Add / edit / delete skills, import .md/.txt skills. Deleting a skill also removes it from every worker.
- Add custom tools (Web API, terminal command, prompt) without code, import tools from an MCP server, delete custom tools.
  Built-in tools are listed (read-only); per-worker on/off stays in Company > worker.

## Branding
- New ReCode logo (tower + red/blue orbit) as adaptive icon, themed (monochrome) icon, splash screen (Android 12+ and older,
  light and dark) and in the drawer / home screen. App name is now ReCode.
