cmake_minimum_required(VERSION 3.22.1)
project(aicompany_llm LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# The CI builds assembleDebug, and AGP passes -DCMAKE_BUILD_TYPE=Debug, which compiles llama.cpp
# and ggml with -O0 (a 10-50x slowdown: tokens/sec collapse and requests hit the timeout).
# Force optimisation for the Debug flags. Release/RelWithDebInfo keep their own optimised flags.
# Both the cache entries and the plain variables are set because the NDK toolchain file seeds the
# cache, while subprojects read the variable.
set(CMAKE_C_FLAGS_DEBUG "-O3 -DNDEBUG" CACHE STRING "Debug C flags (optimised on purpose)" FORCE)
set(CMAKE_CXX_FLAGS_DEBUG "-O3 -DNDEBUG" CACHE STRING "Debug C++ flags (optimised on purpose)" FORCE)
set(CMAKE_C_FLAGS_DEBUG "-O3 -DNDEBUG")
set(CMAKE_CXX_FLAGS_DEBUG "-O3 -DNDEBUG")
message(STATUS "aicompany_llm: build type=${CMAKE_BUILD_TYPE}, C flags (debug)=${CMAKE_C_FLAGS_DEBUG}")

# llama.cpp is cloned by CI (see .github/workflows/build.yml). It lands at the
# project root (AICompany/llama.cpp); also accept src/main/cpp/llama.cpp.
set(LLAMA_DIR "${CMAKE_CURRENT_SOURCE_DIR}/../../../../llama.cpp")
if(NOT EXISTS "${LLAMA_DIR}/CMakeLists.txt")
    set(LLAMA_DIR "${CMAKE_CURRENT_SOURCE_DIR}/llama.cpp")
endif()
if(NOT EXISTS "${LLAMA_DIR}/CMakeLists.txt")
    message(FATAL_ERROR "llama.cpp is missing. CI clones it at LLAMA_REF into the project root (llama.cpp/).")
endif()

set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
set(LLAMA_CURL OFF CACHE BOOL "" FORCE)
set(LLAMA_OPENSSL OFF CACHE BOOL "" FORCE)      # newer llama.cpp uses OpenSSL for model downloads; Android has none
set(LLAMA_BUILD_COMMON OFF CACHE BOOL "" FORCE)  # only libllama is needed
set(GGML_LLAMAFILE OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_SERVER OFF CACHE BOOL "" FORCE)
set(GGML_OPENMP OFF CACHE BOOL "" FORCE)

add_subdirectory(${LLAMA_DIR} ${CMAKE_CURRENT_BINARY_DIR}/llama)

add_library(aicompany_llm SHARED aicompany_llm.cpp)
target_include_directories(aicompany_llm PRIVATE
    ${LLAMA_DIR}/include
    ${LLAMA_DIR}/ggml/include)
target_link_libraries(aicompany_llm PRIVATE llama log)
