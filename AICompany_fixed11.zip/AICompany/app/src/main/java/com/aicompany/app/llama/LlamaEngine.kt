package com.aicompany.app.llama

import android.content.Context
import com.aicompany.app.local.CpuInfo
import com.aicompany.app.local.MemoryMonitor
import com.aicompany.app.local.RamGuard
import com.aicompany.app.provider.ChatMessage
import com.aicompany.app.util.Logger
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Owns the single loaded local model. Only one model is ever loaded.
 *
 * Thread safety: load/unload are serialised by [stateLock]. Generation is serialised by
 * LocalScheduler and, as a second safety net, by a mutex inside the native engine. Unloading
 * while a generation runs cancels it first and the native free waits for it to leave, so the
 * native memory is never released under a running call. Memory-pressure unloads are deferred
 * until the running request finishes.
 */
@Singleton
class LlamaEngine @Inject constructor(
    @ApplicationContext private val context: Context,
    private val memory: MemoryMonitor,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val stateLock = Any()

    @Volatile private var handle: Long = 0L
    @Volatile private var loadedName: String? = null
    @Volatile private var loadedCtx: Int = 0
    @Volatile private var generating = false
    @Volatile private var unloadRequested = false
    @Volatile private var cancelRequested = false

    init {
        scope.launch {
            memory.trimLevel.collect { level ->
                if (MemoryMonitor.shouldUnload(level)) requestUnload()
            }
        }
    }

    val isLoaded: Boolean get() = handle != 0L

    /** File name of the loaded model, or null. */
    val loadedModelName: String? get() = loadedName

    /** Context window of the loaded model, or 0 when nothing is loaded. */
    val contextSize: Int get() = if (handle != 0L) loadedCtx else 0

    /** Loads a GGUF file unless the same one is already loaded. Checks RAM before loading. */
    fun ensureLoaded(file: File, nCtx: Int = DEFAULT_CTX, threads: Int = CpuInfo.performanceThreads()): Result<Unit> = runCatching {
        synchronized(stateLock) {
            check(LlamaNative.available) { "Local engine is not included in this build" }
            require(file.isFile) { "Model file is missing" }
            unloadRequested = false
            // loadedCtx can be smaller than nCtx after a low-memory retry, so only the file name decides.
            if (handle != 0L && loadedName == file.name) return@runCatching
            val verdict = RamGuard.assess(file.length(), memory.availableBytes(), memory.totalBytes())
            check(verdict != RamGuard.Verdict.TOO_LARGE) {
                "Ye model is phone ki RAM ke liye bahut bada hai. Chhota model (Q4, 1 GB se kam) ya cloud provider (Groq/OpenRouter) use karein."
            }
            if (verdict == RamGuard.Verdict.TIGHT) Logger.w("Llama", "Model is close to the memory limit")
            unloadLocked()
            val path = file.absolutePath.toByteArray(Charsets.UTF_8)
            var h = 0L
            var usedCtx = nCtx
            // A big model may fit with a smaller context window (the KV cache shrinks), so step down before giving up.
            for (ctx in contextLadder(nCtx)) {
                h = LlamaNative.nativeLoad(path, ctx, threads, true)
                if (h != 0L) {
                    usedCtx = ctx
                    break
                }
                if (isHopeless(LlamaNative.lastError())) break
            }
            check(h != 0L) { loadFailureMessage() }
            if (usedCtx < nCtx) Logger.w("Llama", "Loaded with a reduced context window: $usedCtx")
            handle = h
            loadedName = file.name
            loadedCtx = usedCtx
        }
    }

    /**
     * Formats [messages] with the model's own chat template. Roles must be system, user or assistant.
     * Returns the prompt as UTF-8 bytes.
     */
    fun buildPrompt(messages: List<ChatMessage>): ByteArray {
        val h = handle
        check(h != 0L) { "No model is loaded" }
        val roles = Array(messages.size) { messages[it].role.toByteArray(Charsets.UTF_8) }
        val contents = Array(messages.size) { messages[it].content.toByteArray(Charsets.UTF_8) }
        return LlamaNative.nativeApplyTemplate(h, roles, contents)
            ?: error("The model's chat template could not be applied")
    }

    /** Token count of an already formatted prompt. */
    fun countTokens(prompt: ByteArray): Int {
        val h = handle
        check(h != 0L) { "No model is loaded" }
        val n = LlamaNative.nativeCountTokens(h, prompt)
        check(n >= 0) { "Could not count tokens (code $n)" }
        return n
    }

    /**
     * Generates text from a formatted prompt. Tokens are delivered to [onToken] as they are produced.
     * Returns the native status code, see [LlamaStatus]; negative values are errors.
     */
    fun generate(
        prompt: ByteArray,
        maxTokens: Int,
        temperature: Double,
        seed: Long,
        grammar: String?,
        grammarRoot: String,
        onToken: (String) -> Boolean,
    ): Int {
        val h = handle
        check(h != 0L) { "No model is loaded" }
        cancelRequested = false
        generating = true
        try {
            return LlamaNative.nativeGenerate(
                h, prompt, maxTokens, temperature.toFloat(), seed,
                grammar?.toByteArray(Charsets.UTF_8), grammarRoot.toByteArray(Charsets.UTF_8),
                TokenSink { text -> !cancelRequested && onToken(text) },
            )
        } finally {
            generating = false
            if (unloadRequested) unload()
        }
    }

    /** Stops the running generation as soon as possible. Safe to call from any thread. */
    fun cancel() {
        cancelRequested = true
        val h = handle
        if (h != 0L) LlamaNative.nativeCancel(h)
    }

    /** Unloads now, or right after the running request when one is in progress. */
    fun requestUnload() {
        if (generating) {
            unloadRequested = true
        } else {
            unload()
        }
    }

    fun unload() {
        synchronized(stateLock) { unloadLocked() }
    }

    private fun unloadLocked() {
        val h = handle
        if (h != 0L) {
            // Native free cancels a running generation and waits for it to leave before releasing memory.
            handle = 0L
            loadedName = null
            loadedCtx = 0
            LlamaNative.nativeFree(h)
        }
        unloadRequested = false
    }

    private fun contextLadder(start: Int): List<Int> =
        (listOf(start, 3072, 2048, 1536, 1024, 512)).filter { it <= start }.distinct()

    /** Errors where a smaller context cannot help. */
    private fun isHopeless(error: String?): Boolean {
        val e = error?.lowercase().orEmpty()
        return e.contains("unknown model architecture") || e.contains("invalid magic") ||
            e.contains("failed to open") || e.contains("not a gguf")
    }

    private fun loadFailureMessage(): String {
        val detail = LlamaNative.lastError()?.trim().orEmpty()
        val low = detail.lowercase()
        val hint = when {
            low.contains("unknown model architecture") ->
                "Is model ka architecture app ke llama.cpp engine mein nahi hai (engine purana hai). " +
                    "App ko naye llama.cpp (build.yml mein LLAMA_REF) ke saath dobara build karein, ya koi purana model use karein."
            low.contains("alloc") || low.contains("out of memory") || low.contains("mmap") ->
                "Phone ki RAM kam padi. Baaki apps band karein ya chhota model / chhota quant (Q4_K_M, Q4_0) lein."
            else -> "Model load nahi ho saka."
        }
        return if (detail.isEmpty()) hint else "$hint\n[engine: ${detail.take(260)}]"
    }

    companion object {
        const val DEFAULT_CTX = 4096
    }
}
