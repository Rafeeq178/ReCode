package com.aicompany.app.agents

import com.aicompany.app.provider.ChatMessage

/**
 * Keeps the model-facing history small without throwing information away blindly (idea from AndroidHarness):
 * old tool outputs are cut to head + tail, the newest few stay complete so the model can still act on them.
 */
object ContextHygiene {
    const val RECENT_FULL_TOOLS = 3
    const val STALE_TOOL_CHARS = 1_200
    private const val TOOL_PREFIX = "TOOL_RESULT "

    fun shrinkStaleToolResults(
        history: MutableList<ChatMessage>,
        recentFull: Int = RECENT_FULL_TOOLS,
        maxChars: Int = STALE_TOOL_CHARS,
    ) {
        val toolIndices = history.indices.filter { history[it].role == "user" && history[it].content.startsWith(TOOL_PREFIX) }
        val protectedIndices = toolIndices.takeLast(recentFull).toSet()
        for (i in toolIndices) {
            if (i in protectedIndices) continue
            val m = history[i]
            if (m.content.length > maxChars) history[i] = ChatMessage(m.role, truncate(m.content, maxChars))
        }
    }

    fun truncate(text: String, maxChars: Int): String {
        if (text.length <= maxChars) return text
        val marker = "\n[truncated ${text.length - maxChars} chars of old tool output]\n"
        val keep = ((maxChars - marker.length) / 2).coerceAtLeast(64)
        return text.take(keep) + marker + text.takeLast(keep)
    }
}
