package com.aicompany.app.tools.builtin

/**
 * Whitespace-tolerant string replacement for the edit tool (ported from the AndroidHarness project).
 *
 * Models often reproduce code with drifted whitespace: trailing spaces dropped, indentation off by a level, CRLF read
 * as LF. An exact match then fails and the whole turn is wasted. This matcher retries at increasingly tolerant levels,
 * accepts a level only when the match is unambiguous, and replaces using the ORIGINAL text span so the surrounding
 * formatting is never rewritten. It is whitespace-only on purpose: similar-but-wrong code must fail, not corrupt a file.
 */
object FuzzyEdit {

    enum class Level { EXACT, LINE_ENDINGS, INDENTATION }

    sealed interface Result {
        data class Ok(val newText: String, val count: Int, val level: Level) : Result
        data class NotFound(val detail: String) : Result
        data class Ambiguous(val count: Int) : Result
    }

    /** One occurrence in the text: [start] inclusive, [end] exclusive. */
    data class Match(val start: Int, val end: Int)

    fun replace(text: String, old: String, new: String, replaceAll: Boolean): Result {
        if (old.isEmpty()) return Result.NotFound("old_string is empty")

        val exact = findAllExact(text, old)
        if (exact.isNotEmpty()) return finish(text, exact, old, new, replaceAll, Level.EXACT)

        val l1 = findNormalized(text, old, Level.LINE_ENDINGS)
        if (l1.isNotEmpty()) return finish(text, l1, old, new, replaceAll, Level.LINE_ENDINGS)

        val l2 = findNormalized(text, old, Level.INDENTATION)
        if (l2.isNotEmpty()) return finish(text, l2, old, new, replaceAll, Level.INDENTATION)

        return Result.NotFound(
            "old_string not found (exact or whitespace-tolerant). Re-read the file and retry with the current contents."
        )
    }

    private fun finish(
        text: String,
        matches: List<Match>,
        old: String,
        new: String,
        replaceAll: Boolean,
        level: Level,
    ): Result {
        if (matches.size > 1 && !replaceAll) return Result.Ambiguous(matches.size)
        val out = StringBuilder(text.length)
        var cursor = 0
        val use = if (replaceAll) matches else matches.take(1)
        for (m in use) {
            out.append(text, cursor, m.start)
            val separator = lineEnding(text, m.start, m.end) ?: lineEnding(text, 0, text.length)
            // A normalized match swallows the whole first line, so keep the file's own indentation.
            val oldIndent = old.takeWhile { it == ' ' || it == '\t' }
            val replacement = if (level != Level.EXACT && new.isNotEmpty() && new.startsWith(oldIndent)) {
                text.substring(m.start, m.end).takeWhile { it == ' ' || it == '\t' } + new.removePrefix(oldIndent)
            } else {
                new
            }
            out.append(
                if (separator == null) replacement
                else replacement.replace("\r\n", "\n").replace('\r', '\n').replace("\n", separator)
            )
            cursor = m.end
        }
        out.append(text, cursor, text.length)
        return Result.Ok(out.toString(), use.size, level)
    }

    private fun findAllExact(text: String, old: String): List<Match> {
        val out = ArrayList<Match>()
        var i = text.indexOf(old)
        while (i >= 0) {
            out += Match(i, i + old.length)
            i = text.indexOf(old, i + old.length.coerceAtLeast(1))
        }
        return out
    }

    private fun findNormalized(text: String, old: String, level: Level): List<Match> {
        val textLines = splitLines(text)
        val oldLines = splitLines(old)
        if (oldLines.isEmpty() || oldLines.size > textLines.size) return emptyList()

        val starts = lineStarts(text)
        val norm: (String) -> String = when (level) {
            Level.LINE_ENDINGS -> { s -> s.trimEnd() }
            Level.INDENTATION -> { s -> s.trim() }
            Level.EXACT -> { s -> s }
        }
        val normOld = oldLines.map(norm)

        val out = ArrayList<Match>()
        var i = 0
        outer@ while (i + oldLines.size <= textLines.size) {
            for (j in oldLines.indices) {
                if (norm(textLines[i + j]) != normOld[j]) {
                    i++
                    continue@outer
                }
            }
            val startIdx = starts[i]
            var endIdx = starts[i + oldLines.size - 1] + textLines[i + oldLines.size - 1].length
            if (old.endsWith('\n') || old.endsWith('\r')) {
                if (endIdx < text.length && text[endIdx] == '\r') endIdx++
                if (endIdx < text.length && text[endIdx] == '\n') endIdx++
            }
            out += Match(startIdx, endIdx)
            i += oldLines.size
        }
        return out
    }

    /** Lines without terminators; a single trailing line break does not create an extra empty line. */
    internal fun splitLines(text: String): List<String> {
        if (text.isEmpty()) return emptyList()
        var s = text
        if (s.endsWith("\r\n")) s = s.substring(0, s.length - 2)
        else if (s.endsWith("\n") || s.endsWith("\r")) s = s.substring(0, s.length - 1)
        if (s.isEmpty()) return listOf("")
        return s.split("\r\n", "\n", "\r")
    }

    private fun lineStarts(text: String): IntArray {
        val starts = IntArray(text.length + 1)
        var count = 0
        starts[count++] = 0
        var i = 0
        while (i < text.length) {
            val c = text[i]
            if (c == '\r' || c == '\n') {
                i += if (c == '\r' && i + 1 < text.length && text[i + 1] == '\n') 2 else 1
                starts[count++] = i
            } else {
                i++
            }
        }
        return starts.copyOf(count)
    }

    private fun lineEnding(text: String, start: Int, end: Int): String? {
        for (i in start until end) {
            when (text[i]) {
                '\r' -> return if (i + 1 < text.length && text[i + 1] == '\n') "\r\n" else "\r"
                '\n' -> return "\n"
            }
        }
        return null
    }
}
