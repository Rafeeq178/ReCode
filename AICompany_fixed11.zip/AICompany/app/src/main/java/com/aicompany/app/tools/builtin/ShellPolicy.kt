package com.aicompany.app.tools.builtin

/**
 * Commands that are refused even after the owner pressed Allow (ported from AndroidHarness).
 * The shell runs inside proot with the workspace and /dev bound in, so "rm -rf /" would reach real files.
 */
object ShellPolicy {

    fun denyReason(command: String): String? {
        val cmd = command.trim()
        if (cmd.isEmpty()) return null
        if (isRmRoot(cmd)) return "Blocked: recursive delete of the filesystem root is never allowed."
        if (PIPE_TO_SHELL.containsMatchIn(cmd)) return "Blocked: piping a download straight into a shell is never allowed. Download the file, read it, then run it."
        if (MKFS.containsMatchIn(cmd)) return "Blocked: formatting a block device is never allowed."
        if (DD_DEV.containsMatchIn(cmd)) return "Blocked: writing directly to a block device is never allowed."
        if (FORK_BOMB.containsMatchIn(cmd)) return "Blocked: fork bomb is never allowed."
        if (CHMOD_ROOT.containsMatchIn(cmd)) return "Blocked: chmod 777 on the filesystem root is never allowed."
        return null
    }

    private fun isRmRoot(cmd: String): Boolean {
        if (!RM.containsMatchIn(cmd)) return false
        val recursive = RECURSIVE.containsMatchIn(cmd)
        val force = FORCE.containsMatchIn(cmd)
        val noPreserve = cmd.contains("--no-preserve-root")
        val rootTarget = ROOT_PATH.containsMatchIn(cmd)
        return ((recursive && force) || noPreserve) && (rootTarget || noPreserve)
    }

    private val RM = Regex("""(^|[\s;&|])rm\b""")
    private val RECURSIVE = Regex("""(^|[\s])(-[a-zA-Z]*r[a-zA-Z]*|--recursive)\b""")
    private val FORCE = Regex("""(^|[\s])(-[a-zA-Z]*f[a-zA-Z]*|--force)\b""")
    private val ROOT_PATH = Regex("""(^|[\s])/(?:\*+)?(\s|$)""")
    private val PIPE_TO_SHELL = Regex("""\b(curl|wget)\b[\s\S]*\|\s*(ba)?sh\b""")
    private val MKFS = Regex("""(^|[\s;&|])mkfs(\.\w+)?\b""")
    private val DD_DEV = Regex("""(^|[\s;&|])dd\b[\s\S]*\bof=/dev/""")
    private val FORK_BOMB = Regex(""":\s*\(\s*\)\s*\{\s*:\s*\|\s*:\s*&\s*\}\s*;\s*:""")
    private val CHMOD_ROOT = Regex("""(^|[\s;&|])chmod\b[\s\S]*\b777\b[\s\S]*(^|[\s])/(\s|$)""")
}
