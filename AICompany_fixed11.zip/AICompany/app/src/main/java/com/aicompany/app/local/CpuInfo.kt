package com.aicompany.app.local

import java.io.File

/** Picks a thread count for llama.cpp: the fast cores only. Slow cores drag every token down to their speed. */
object CpuInfo {
    fun performanceThreads(): Int {
        val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
        val freqs = (0 until cores).mapNotNull { i ->
            runCatching {
                File("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq").readText().trim().toLong()
            }.getOrNull()
        }
        if (freqs.size == cores) {
            val max = freqs.maxOrNull() ?: 0L
            val fast = freqs.count { it >= max * 0.8 }
            if (fast >= 2) return fast.coerceIn(2, 6)
        }
        return (cores / 2).coerceIn(2, 6)
    }
}
