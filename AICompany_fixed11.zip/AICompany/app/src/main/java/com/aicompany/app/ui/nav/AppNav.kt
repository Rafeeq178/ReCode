package com.aicompany.app.ui.nav

import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.aicompany.app.terminal.TerminalScreen
import com.aicompany.app.ui.chat.ChatScreen
import com.aicompany.app.ui.company.CompanyScreen
import com.aicompany.app.ui.company.EmployeeEditorScreen
import com.aicompany.app.ui.company.NEW_EMPLOYEE_ID
import com.aicompany.app.ui.drive.DriveConnectScreen
import com.aicompany.app.ui.logs.LogsScreen
import com.aicompany.app.ui.providers.ProvidersScreen
import com.aicompany.app.ui.skills.SkillsToolsScreen
import com.aicompany.app.ui.settings.SettingsScreen
import kotlinx.coroutines.launch

object Routes {
    const val CHAT = "chat"
    const val PROVIDERS = "providers"
    const val LOGS = "logs"
    const val TERMINAL = "terminal"
    const val COMPANY = "company"
    const val EMPLOYEE = "employee/{employeeId}"
    const val DRIVE = "drive"
    const val SETTINGS = "settings"
    const val SKILLS = "skills"
}

private val TOP_LEVEL = setOf(
    Routes.CHAT, Routes.COMPANY, Routes.LOGS, Routes.TERMINAL, Routes.PROVIDERS, Routes.SETTINGS, Routes.SKILLS,
)

@Composable
fun AppNav(appViewModel: AppViewModel = hiltViewModel()) {
    val nav = rememberNavController()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route

    val recents by appViewModel.recents.collectAsState()
    val currentChatId by appViewModel.currentId.collectAsState()
    val userName by appViewModel.userName.collectAsState()

    val openDrawer: () -> Unit = { scope.launch { drawerState.open() } }

    fun go(target: String) {
        scope.launch { drawerState.close() }
        if (target == Routes.CHAT) {
            nav.popBackStack(Routes.CHAT, inclusive = false)
        } else {
            nav.navigate(target) {
                popUpTo(Routes.CHAT) { inclusive = false }
                launchSingleTop = true
            }
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        // The terminal needs edge swipes for itself; the drawer still opens with the menu button.
        gesturesEnabled = route in TOP_LEVEL && route != Routes.TERMINAL,
        drawerContent = {
            AppDrawerContent(
                currentRoute = route,
                recents = recents,
                currentChatId = currentChatId,
                userName = userName,
                onNavigate = { go(it) },
                onOpenChat = { id ->
                    appViewModel.open(id)
                    go(Routes.CHAT)
                },
                onNewChat = {
                    appViewModel.newChat()
                    go(Routes.CHAT)
                },
            )
        },
    ) {
        NavHost(navController = nav, startDestination = Routes.CHAT) {
            composable(Routes.CHAT) {
                ChatScreen(
                    onMenu = openDrawer,
                    onOpenProviders = { nav.navigate(Routes.PROVIDERS) { launchSingleTop = true } },
                    onOpenLogs = { nav.navigate(Routes.LOGS) { launchSingleTop = true } },
                    onOpenTerminal = { nav.navigate(Routes.TERMINAL) { launchSingleTop = true } },
                    onOpenCompany = { nav.navigate(Routes.COMPANY) { launchSingleTop = true } },
                    onOpenDrive = { nav.navigate(Routes.DRIVE) { launchSingleTop = true } },
                )
            }
            composable(Routes.PROVIDERS) { ProvidersScreen(onMenu = openDrawer) }
            composable(Routes.SKILLS) { SkillsToolsScreen(onMenu = openDrawer) }
            composable(Routes.LOGS) { LogsScreen(onMenu = openDrawer) }
            composable(Routes.TERMINAL) { TerminalScreen(onMenu = openDrawer) }
            composable(Routes.COMPANY) {
                CompanyScreen(
                    onMenu = openDrawer,
                    onOpenEmployee = { id -> nav.navigate("employee/$id") },
                    onNewEmployee = { nav.navigate("employee/$NEW_EMPLOYEE_ID") },
                )
            }
            composable(Routes.SETTINGS) {
                SettingsScreen(
                    onMenu = openDrawer,
                    onOpenProviders = { nav.navigate(Routes.PROVIDERS) { launchSingleTop = true } },
                    onOpenCompany = { nav.navigate(Routes.COMPANY) { launchSingleTop = true } },
                    onOpenLogs = { nav.navigate(Routes.LOGS) { launchSingleTop = true } },
                    onOpenTerminal = { nav.navigate(Routes.TERMINAL) { launchSingleTop = true } },
                    onOpenDrive = { nav.navigate(Routes.DRIVE) { launchSingleTop = true } },
                )
            }
            composable(Routes.DRIVE) { DriveConnectScreen(onBack = { nav.popBackStack() }) }
            composable(Routes.EMPLOYEE) { EmployeeEditorScreen(onBack = { nav.popBackStack() }) }
        }
    }
}
