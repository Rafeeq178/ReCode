package com.aicompany.app.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aicompany.app.doctor.DoctorService
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DoctorViewModel @Inject constructor(
    private val doctor: DoctorService,
) : ViewModel() {
    private val _report = MutableStateFlow<String?>(null)
    val report: StateFlow<String?> = _report.asStateFlow()

    fun runCheck() {
        _report.value = "Check ho raha hai..."
        viewModelScope.launch {
            _report.value = runCatching { doctor.report() }.getOrElse { "Doctor failed: ${it.message}" }
        }
    }

    fun clear() {
        _report.value = null
    }
}
