package com.aicompany.app.ui.providers

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aicompany.app.data.ProviderDraft
import com.aicompany.app.data.ProviderRepository
import com.aicompany.app.local.LocalModelService
import com.aicompany.app.local.ModelStore
import com.aicompany.app.provider.ChatGateway
import com.aicompany.app.provider.ChatMessage
import com.aicompany.app.provider.ApiFormat
import com.aicompany.app.provider.ChatParams
import com.aicompany.app.provider.ModelLister
import com.aicompany.app.provider.ProviderConfig
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ProvidersViewModel @Inject constructor(
    private val repo: ProviderRepository,
    private val gateway: ChatGateway,
    private val modelStore: ModelStore,
    private val modelService: LocalModelService,
    private val modelLister: ModelLister,
) : ViewModel() {

    val providers: StateFlow<List<ProviderConfig>> = repo.observe()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _status = MutableStateFlow<String?>(null)
    val status: StateFlow<String?> = _status.asStateFlow()

    private val _localModels = MutableStateFlow(modelStore.list())
    val localModels: StateFlow<List<ModelStore.LocalModelFile>> = _localModels.asStateFlow()

    private val _importing = MutableStateFlow(false)
    val importing: StateFlow<Boolean> = _importing.asStateFlow()

    private val _importMessage = MutableStateFlow<String?>(null)
    val importMessage: StateFlow<String?> = _importMessage.asStateFlow()

    /** File name of the model that was just imported; the editor dialog consumes it. */
    private val _pickedModel = MutableStateFlow<String?>(null)
    val pickedModel: StateFlow<String?> = _pickedModel.asStateFlow()

    /**
     * Copies a picked .gguf into the app. With [register] a LOCAL provider is created for it
     * too (one-tap add); without it the editor dialog picks the file up and fills its form.
     */
    fun importModel(uri: Uri, displayName: String?, register: Boolean) {
        if (_importing.value) return
        viewModelScope.launch {
            _importing.value = true
            _importMessage.value = "Model copy ho raha hai... (bade model mein kuch minute lag sakte hain)"
            val result = if (register) {
                modelService.importAndRegister(uri, displayName)
            } else {
                modelStore.importFile(uri, displayName).map { it.name }
            }
            _importing.value = false
            result.fold(
                onSuccess = { name ->
                    _localModels.value = modelStore.list()
                    if (!register) _pickedModel.value = name
                    _importMessage.value = "Model add ho gaya: $name"
                },
                onFailure = { _importMessage.value = it.message ?: "Model import fail ho gaya" },
            )
        }
    }

    fun deleteModel(name: String) {
        runCatching { modelStore.delete(name) }
        _localModels.value = modelStore.list()
    }

    fun consumePickedModel() { _pickedModel.value = null }
    fun clearImportMessage() { _importMessage.value = null }

    fun save(draft: ProviderDraft, onSaved: () -> Unit) {
        viewModelScope.launch {
            runCatching { repo.save(draft) }
                .onSuccess {
                    _status.value = "Saved. Connection test ke liye 'Test' dabayein."
                    onSaved()
                }
                .onFailure { _status.value = it.message ?: "Save failed" }
        }
    }

    fun delete(id: String) {
        viewModelScope.launch { repo.delete(id) }
    }

    fun test(id: String) {
        viewModelScope.launch {
            _status.value = "Testing..."
            val config = repo.get(id)
            if (config == null) {
                _status.value = "Provider nahi mila"
                return@launch
            }
            val result = runCatching {
                gateway.stream(
                    chain = listOf(config),
                    messages = listOf(ChatMessage("user", "Reply with the single word OK.")),
                    params = ChatParams(maxTokens = 16, temperature = 0.0),
                ).toList()
            }
            _status.value = result.fold(
                onSuccess = { tokens -> if (tokens.isEmpty()) "Provider ne koi jawab nahi diya" else "Connection OK: ${config.name}" },
                onFailure = { it.message ?: "Test failed" },
            )
        }
    }

    private val _fetchedModels = MutableStateFlow<List<String>>(emptyList())
    val fetchedModels: StateFlow<List<String>> = _fetchedModels.asStateFlow()

    private val _fetching = MutableStateFlow(false)
    val fetching: StateFlow<Boolean> = _fetching.asStateFlow()

    /** Asks the service which models this key can use (dialog "Load models" button). */
    fun loadModels(format: ApiFormat, baseUrl: String, firstKeyLine: String) {
        if (_fetching.value) return
        viewModelScope.launch {
            _fetching.value = true
            val key = firstKeyLine.lines().map { it.trim() }.firstOrNull { it.isNotEmpty() }.orEmpty()
            modelLister.list(format, baseUrl.trim(), key).fold(
                onSuccess = {
                    _fetchedModels.value = it
                    _status.value = if (it.isEmpty()) "Is key par koi model nahi mila" else "${it.size} models mil gaye, neeche se chunein"
                },
                onFailure = { _status.value = it.message ?: "Model list nahi mili" },
            )
            _fetching.value = false
        }
    }

    fun clearFetchedModels() { _fetchedModels.value = emptyList() }

    fun clearStatus() {
        _status.value = null
    }
}
