package com.aicompany.app.llama

/**
 * JNI entry points. The C++ side lives in app/src/main/cpp/aicompany_llm.cpp.
 * If the native library is missing (for example a build without llama.cpp),
 * [available] is false and the local provider reports a clear error instead of crashing.
 *
 * All text crosses JNI as UTF-8 byte arrays. JNI's own string functions use "modified UTF-8",
 * which mangles emoji (4-byte characters) and can abort the VM under CheckJNI in debug builds.
 */
object LlamaNative {
    val available: Boolean = try {
        System.loadLibrary("aicompany_llm")
        true
    } catch (e: UnsatisfiedLinkError) {
        false
    }

    external fun nativeLoad(path: ByteArray, nCtx: Int, nThreads: Int, useMmap: Boolean): Long
    external fun nativeFree(handle: Long)

    /** Last error text printed by llama.cpp while loading (for example "unknown model architecture"). */
    external fun nativeLastError(): ByteArray?

    fun lastError(): String? = if (available) nativeLastError()?.toString(Charsets.UTF_8) else null
    external fun nativeCancel(handle: Long)

    /** Formats chat messages with the template stored in the model file. Null when formatting failed. */
    external fun nativeApplyTemplate(handle: Long, roles: Array<ByteArray>, contents: Array<ByteArray>): ByteArray?

    /** Number of tokens the text would use, or a negative error code. */
    external fun nativeCountTokens(handle: Long, text: ByteArray): Int

    external fun nativeGenerate(
        handle: Long,
        prompt: ByteArray,
        maxTokens: Int,
        temperature: Float,
        seed: Long,
        grammar: ByteArray?,
        grammarRoot: ByteArray?,
        sink: TokenSink,
    ): Int
}

/** Result codes returned by nativeGenerate. */
object LlamaStatus {
    const val OK = 0
    const val CANCELLED = 1
    const val CONTEXT_FULL = 2
    const val LENGTH = 3
}

/**
 * Receives tokens from native code as UTF-8 bytes. Native code only passes complete characters,
 * so every chunk decodes cleanly. Return false to stop generation.
 */
class TokenSink(private val consumer: (String) -> Boolean) {
    fun onToken(bytes: ByteArray): Boolean = consumer(String(bytes, Charsets.UTF_8))
}
