package com.aicompany.app.ui.approvals

import androidx.lifecycle.ViewModel
import com.aicompany.app.approvals.ApprovalDecision
import com.aicompany.app.approvals.ApprovalQueue
import com.aicompany.app.approvals.ApprovalRequest
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject

@HiltViewModel
class ApprovalViewModel @Inject constructor(
    private val queue: ApprovalQueue,
) : ViewModel() {
    val pending: StateFlow<List<ApprovalRequest>> = queue.pending

    fun decide(id: String, decision: ApprovalDecision) {
        queue.resolve(id, decision)
    }
}
