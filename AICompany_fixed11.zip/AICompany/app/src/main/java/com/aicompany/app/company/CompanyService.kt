package com.aicompany.app.company

import com.aicompany.app.agents.AgentConfig
import com.aicompany.app.agents.AgentLoop
import com.aicompany.app.agents.RunOutcome
import com.aicompany.app.agents.RunStatus
import com.aicompany.app.data.AgentRunRepository
import com.aicompany.app.data.CompanyRepository
import com.aicompany.app.data.ProviderRepository
import com.aicompany.app.data.SkillEntity
import com.aicompany.app.data.TaskEntity
import com.aicompany.app.provider.ProviderConfig
import com.aicompany.app.scheduler.ApiScheduler
import com.aicompany.app.scheduler.Router
import com.aicompany.app.service.WorkTracker
import com.aicompany.app.tools.ToolRegistry
import com.aicompany.app.util.Logger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.json.Json
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The company: CEO agent, workers, task board, employee editor, version history, templates and skills.
 * Edits never affect a task that already started: a worker reads its employee once, at assign time.
 */
@Singleton
class CompanyService @Inject constructor(
    private val repo: CompanyRepository,
    private val runs: AgentRunRepository,
    private val loop: AgentLoop,
    private val scheduler: ApiScheduler,
    private val providers: ProviderRepository,
    private val registry: ToolRegistry,
    private val json: Json,
    private val tracker: WorkTracker,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val jobs = ConcurrentHashMap<String, Job>()
    private val _activeCount = MutableStateFlow(0)
    val activeCount: StateFlow<Int> = _activeCount.asStateFlow()

    // ---------- Employees: create, edit, versions, templates ----------

    suspend fun createEmployee(snapshot: EmployeeSnapshot): String {
        validate(snapshot)
        require(repo.activeEmployeeCount() < CompanyRules.MAX_WORKERS) { "Worker limit reached" }
        val id = UUID.randomUUID().toString()
        val entity = snapshot.toEntity(id, System.currentTimeMillis(), 1, EmployeeStatus.IDLE.name)
        repo.saveEmployee(entity)
        repo.saveVersion(id, 1, encode(entity.toSnapshot()))
        return id
    }

    /** Quick hire used by the Company screen. */
    suspend fun hire(name: String, role: String, tools: Set<String>): String =
        createEmployee(EmployeeSnapshot(name = name.trim(), role = role.trim(), tools = tools.sorted()))

    /** Saves edits as a new version. Running tasks keep the settings they started with. */
    suspend fun updateEmployee(employeeId: String, snapshot: EmployeeSnapshot): Int {
        val current = repo.getEmployee(employeeId) ?: throw IllegalArgumentException("Employee not found")
        require(current.status != EmployeeStatus.FIRED.name) { "This employee was fired" }
        validate(snapshot)
        val nextVersion = current.version + 1
        val status = if (current.status == EmployeeStatus.WORKING.name) EmployeeStatus.WORKING.name else snapshot.status
        val entity = snapshot.toEntity(employeeId, current.createdAt, nextVersion, status)
        repo.saveEmployee(entity)
        repo.saveVersion(employeeId, nextVersion, encode(entity.toSnapshot()))
        return nextVersion
    }

    /** Restores an older version. This is saved as a new version, so the history keeps growing. */
    suspend fun rollback(employeeId: String, version: Int): Int {
        val row = repo.getVersion(employeeId, version) ?: throw IllegalArgumentException("Version not found")
        return updateEmployee(employeeId, decode(row.snapshot))
    }

    suspend fun saveTemplate(employeeId: String, templateName: String): Long {
        val clean = templateName.trim()
        require(clean.length in 1..60) { "Template name must be 1-60 characters" }
        val employee = repo.getEmployee(employeeId) ?: throw IllegalArgumentException("Employee not found")
        return repo.saveTemplate(clean, encode(employee.toSnapshot()))
    }

    suspend fun hireFromTemplate(templateId: Long, name: String): String {
        val template = repo.getTemplate(templateId) ?: throw IllegalArgumentException("Template not found")
        val copy = decode(template.snapshot).copy(name = name.trim(), status = EmployeeStatus.IDLE.name)
        return createEmployee(copy)
    }

    suspend fun fire(employeeId: String) {
        val employee = repo.getEmployee(employeeId) ?: throw IllegalArgumentException("Employee not found")
        jobs["worker:$employeeId"]?.cancel()
        repo.saveEmployee(employee.copy(status = EmployeeStatus.FIRED.name))
    }

    // ---------- Skills library ----------

    suspend fun saveSkill(name: String, description: String, instructions: String, existingId: String? = null): String {
        val cleanName = name.trim()
        val cleanInstructions = instructions.trim()
        require(cleanName.length in 1..60) { "Skill name must be 1-60 characters" }
        require(description.length <= 200) { "Description is too long (max 200)" }
        require(cleanInstructions.length in 1..EmployeeRules.MAX_INSTRUCTIONS) { "Instructions must be 1-20000 characters" }
        val id = existingId ?: UUID.randomUUID().toString()
        repo.saveSkill(
            SkillEntity(
                id = id,
                name = cleanName,
                description = description.trim(),
                instructions = cleanInstructions,
                createdAt = System.currentTimeMillis(),
            )
        )
        return id
    }

    suspend fun deleteSkill(id: String) = repo.deleteSkill(id)

    /** Imports a .md or .txt file. The first non-empty line becomes the description. */
    suspend fun importSkill(fileName: String, text: String): String {
        val lower = fileName.lowercase()
        require(lower.endsWith(".md") || lower.endsWith(".txt")) { "Only .md and .txt files can be imported" }
        require(text.length <= EmployeeRules.MAX_INSTRUCTIONS) { "File is too large" }
        val name = fileName.substringBeforeLast('.').take(60).ifBlank { "Imported skill" }
        val description = text.lineSequence().map { it.trim().trimStart('#', ' ') }.firstOrNull { it.isNotEmpty() }
            ?.take(200).orEmpty()
        return saveSkill(name, description, text)
    }

    // ---------- Company work ----------

    /** Creates a task and starts the worker in the background. Returns the task id at once. */
    suspend fun assign(employeeId: String, title: String, description: String): Long {
        val cleanTitle = title.trim()
        val cleanDescription = description.trim()
        require(cleanTitle.length in 1..CompanyRules.MAX_TITLE) { "Title must be 1-${CompanyRules.MAX_TITLE} characters" }
        require(cleanDescription.length in 1..CompanyRules.MAX_DESCRIPTION) { "Description is empty or too long" }

        val employee = repo.getEmployee(employeeId) ?: throw IllegalArgumentException("Employee not found")
        require(employee.status != EmployeeStatus.FIRED.name) { "This employee was fired" }
        require(employee.status != EmployeeStatus.PAUSED.name) { "This employee is paused" }
        val key = "worker:$employeeId"
        require(!jobs.containsKey(key)) { "Worker is busy with another task" }

        val baseChain = workerChain(employee.providerList(), employee.model)
        // The owner's explicit provider order for this employee is respected. Only when none is set does the
        // router decide: light work prefers the local model, heavy work prefers the API models.
        val chain = if (employee.providerList().isEmpty()) {
            Router.prioritize(Router.classify("$cleanTitle $cleanDescription"), baseChain)
        } else {
            baseChain
        }

        val now = System.currentTimeMillis()
        val runId = runs.createRun(employee.name, cleanTitle)
        val taskId = repo.insertTask(
            TaskEntity(
                title = cleanTitle,
                description = cleanDescription,
                assigneeId = employeeId,
                status = TaskStatus.IN_PROGRESS.name,
                result = "",
                runId = runId,
                createdAt = now,
                updatedAt = now,
            )
        )
        repo.saveEmployee(employee.copy(status = EmployeeStatus.WORKING.name))

        val config = AgentConfig(
            id = employee.id,
            name = employee.name,
            role = employee.role,
            allowedTools = employee.toolSet(),
            maxSteps = employee.maxSteps,
            timeoutMs = employee.timeoutSeconds * 1_000L,
            maxTokens = employee.maxTokens,
            temperature = employee.temperature,
            extraInstructions = employee.systemPrompt,
            skillIds = employee.skillSet(),
        )
        val job = scope.launch {
            tracker.track { runWorker(employeeId, taskId, runId, config, cleanDescription, chain) }
        }
        jobs[key] = job
        if (job.isCompleted) jobs.remove(key)
        updateActive()
        return taskId
    }

    /** Waits for a task to finish, up to [waitMs]. Returns the latest task row. */
    suspend fun await(taskId: Long, waitMs: Long): TaskEntity? {
        require(waitMs in 0..CompanyRules.MAX_WAIT_SECONDS * 1000) { "Wait out of range" }
        val finished = withTimeoutOrNull(waitMs) {
            repo.observeTask(taskId).first { t ->
                t != null && (t.status == TaskStatus.DONE.name || t.status == TaskStatus.FAILED.name)
            }
        }
        return finished ?: repo.observeTask(taskId).first()
    }

    /** Starts the CEO on a goal. Returns the CEO run id. */
    suspend fun startCeo(goal: String): Long {
        val clean = goal.trim()
        require(clean.isNotEmpty()) { "Goal is empty" }
        require(clean.length <= AgentRunRepository.MAX_GOAL_CHARS) { "Goal is too long" }
        require(!jobs.containsKey(CompanyRules.CEO_ID)) { "The CEO is already working. Stop it first." }
        val chain = providers.observe().first()
        require(chain.isNotEmpty()) { "Add a provider first" }

        val runId = runs.createRun("CEO", clean)
        val config = AgentConfig(
            id = CompanyRules.CEO_ID,
            name = "CEO",
            role = "chief executive officer",
            allowedTools = CompanyRules.CEO_ONLY_TOOLS,
            maxSteps = 40,
            timeoutMs = 3_600_000,
            isCeo = true,
        )
        val job = scope.launch {
            tracker.track {
                var outcome = RunOutcome(RunStatus.STOPPED, "Stopped by owner", 0)
                try {
                    outcome = withTimeoutOrNull(config.timeoutMs) {
                        loop.run(runId, config, clean, chain) { }
                    } ?: RunOutcome(RunStatus.TIMED_OUT, "Time limit reached", 0)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    outcome = RunOutcome(RunStatus.FAILED, "Unexpected error: ${e.javaClass.simpleName}", outcome.steps)
                } finally {
                    withContext(NonCancellable) {
                        runs.finish(runId, outcome.status, outcome.reason, outcome.steps)
                        jobs.remove(CompanyRules.CEO_ID)
                        updateActive()
                    }
                }
            }
        }
        jobs[CompanyRules.CEO_ID] = job
        if (job.isCompleted) jobs.remove(CompanyRules.CEO_ID)
        updateActive()
        return runId
    }

    /** The CEO edits a worker only when the owner allowed it for that worker. */
    suspend fun ceoEditWorker(employeeId: String, role: String?, tools: Set<String>?, maxSteps: Int?): Int {
        val current = repo.getEmployee(employeeId) ?: throw IllegalArgumentException("Employee not found")
        require(current.ceoCanModify) { "The owner has not allowed the CEO to edit this worker" }
        require(role != null || tools != null || maxSteps != null) { "Nothing to change" }
        val base = current.toSnapshot()
        val updated = base.copy(
            role = role?.trim() ?: base.role,
            tools = tools?.sorted() ?: base.tools,
            maxSteps = maxSteps ?: base.maxSteps,
        )
        return updateEmployee(employeeId, updated)
    }

    fun stopAll() {
        jobs.values.toList().forEach { it.cancel() }
    }

    // ---------- Internals ----------

    private suspend fun validate(snapshot: EmployeeSnapshot) {
        val providerIds = providers.observe().first().map { it.id }.toSet()
        val errors = EmployeeRules.validate(
            snapshot,
            knownTools = registry.allNames(),
            knownSkills = repo.skillIds(),
            knownProviders = providerIds,
        )
        require(errors.isEmpty()) { errors.joinToString("; ") }
    }

    /** Employee's provider order (or all providers when none chosen). The primary may use the employee's model. */
    private suspend fun workerChain(providerIds: List<String>, model: String): List<ProviderConfig> {
        val all = providers.observe().first()
        val ordered = if (providerIds.isEmpty()) all else providerIds.mapNotNull { id -> all.find { it.id == id } }
        require(ordered.isNotEmpty()) { "None of this employee's providers exist. Edit the employee." }
        return ordered.mapIndexed { index, p ->
            if (index == 0 && model.isNotBlank()) p.copy(model = model) else p
        }
    }

    private suspend fun runWorker(
        employeeId: String,
        taskId: Long,
        runId: Long,
        config: AgentConfig,
        description: String,
        chain: List<ProviderConfig>,
    ) {
        var outcome = RunOutcome(RunStatus.STOPPED, "Stopped", 0)
        try {
            outcome = scheduler.run(chain.first().id) {
                withTimeoutOrNull(config.timeoutMs) {
                    loop.run(runId, config, description, chain) { }
                } ?: RunOutcome(RunStatus.TIMED_OUT, "Time limit reached", 0)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Logger.e("Company", "Worker failed: ${e.javaClass.simpleName}")
            outcome = RunOutcome(RunStatus.FAILED, "Unexpected error: ${e.javaClass.simpleName}", outcome.steps)
        } finally {
            withContext(NonCancellable) {
                val taskStatus = if (outcome.status == RunStatus.COMPLETED) TaskStatus.DONE else TaskStatus.FAILED
                repo.updateTask(taskId, taskStatus.name, outcome.reason, runId)
                runs.finish(runId, outcome.status, outcome.reason, outcome.steps)
                repo.getEmployee(employeeId)?.let { current ->
                    if (current.status == EmployeeStatus.WORKING.name) {
                        repo.saveEmployee(current.copy(status = EmployeeStatus.IDLE.name))
                    }
                }
                jobs.remove("worker:$employeeId")
                updateActive()
            }
        }
    }

    private fun encode(snapshot: EmployeeSnapshot): String =
        json.encodeToString(EmployeeSnapshot.serializer(), snapshot)

    private fun decode(text: String): EmployeeSnapshot =
        json.decodeFromString(EmployeeSnapshot.serializer(), text)

    private fun updateActive() {
        _activeCount.value = jobs.size
    }
}
