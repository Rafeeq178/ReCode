package com.aicompany.app.ui.skills

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aicompany.app.company.CompanyService
import com.aicompany.app.data.CompanyRepository
import com.aicompany.app.data.SkillEntity
import com.aicompany.app.tools.ToolRegistry
import com.aicompany.app.tools.custom.CustomToolCatalog
import com.aicompany.app.tools.custom.CustomToolDef
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import javax.inject.Inject

/** One line in the tools list. */
data class ToolRow(
    val name: String,
    val description: String,
    val kind: String,          // BUILT-IN, HTTP, SHELL, PROMPT, MCP, SCRIPT
    val approval: String,
    val deletable: Boolean,
)

/** Form values for a new custom tool. [params] is a comma separated list of argument names. */
data class NewToolForm(
    val name: String,
    val description: String,
    val type: String,          // HTTP | SHELL | PROMPT
    val params: String,
    val url: String,
    val method: String,
    val command: String,
    val prompt: String,
    val approval: String,      // ASK | AUTO
)

@HiltViewModel
class SkillsToolsViewModel @Inject constructor(
    private val repo: CompanyRepository,
    private val company: CompanyService,
    private val catalog: CustomToolCatalog,
    private val registry: ToolRegistry,
) : ViewModel() {

    val skills: StateFlow<List<SkillEntity>> = repo.observeSkills()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _tools = MutableStateFlow<List<ToolRow>>(emptyList())
    val tools: StateFlow<List<ToolRow>> = _tools.asStateFlow()

    private val _notice = MutableStateFlow<String?>(null)
    val notice: StateFlow<String?> = _notice.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    init { refreshTools(reload = true) }

    fun clearNotice() { _notice.value = null }

    private fun refreshTools(reload: Boolean = false) {
        viewModelScope.launch {
            if (reload) {
                val problems = runCatching { catalog.reload() }.getOrDefault(emptyList())
                if (problems.isNotEmpty()) _notice.value = "Kuch tools load nahi huay: ${problems.first()}"
            }
            val saved = runCatching { catalog.savedNames() }.getOrDefault(emptySet())
            val defs = catalog.definitions()
            val customNames = defs.map { it.name }.toSet()
            val builtin = registry.specsFor(registry.allNames())
                .filter { it.name !in customNames }
                .sortedBy { it.name }
                .map { ToolRow(it.name, it.description, "BUILT-IN", it.approval.name, deletable = false) }
            val custom = defs.map { ToolRow(it.name, it.description, it.type, it.approval, deletable = it.name in saved) }
            _tools.value = custom + builtin
        }
    }

    // ---------- Skills ----------

    fun saveSkill(id: String?, name: String, description: String, instructions: String) {
        viewModelScope.launch {
            runCatching { company.saveSkill(name, description, instructions, id) }
                .onSuccess { _notice.value = if (id == null) "Skill add ho gayi" else "Skill update ho gayi" }
                .onFailure { _notice.value = it.message ?: "Skill save nahi hui" }
        }
    }

    fun deleteSkill(id: String) {
        viewModelScope.launch {
            runCatching { company.deleteSkill(id) }
                .onSuccess { _notice.value = "Skill delete ho gayi (workers se bhi hata di)" }
                .onFailure { _notice.value = it.message ?: "Delete nahi hui" }
        }
    }

    fun importSkill(fileName: String, text: String) {
        viewModelScope.launch {
            runCatching { company.importSkill(fileName, text) }
                .onSuccess { _notice.value = "Skill import ho gayi" }
                .onFailure { _notice.value = it.message ?: "Import nahi hua" }
        }
    }

    fun reportError(message: String) { _notice.value = message }

    // ---------- Tools ----------

    fun addTool(form: NewToolForm) {
        viewModelScope.launch {
            val result = runCatching {
                val names = form.params.split(',').map { it.trim() }.filter { it.isNotEmpty() }.distinct()
                require(names.all { Regex("^[a-zA-Z_][a-zA-Z0-9_]{0,30}$").matches(it) }) {
                    "Arguments ke naam sirf letters, numbers aur _ se hon (comma se alag)"
                }
                val parameters: JsonObject = buildJsonObject {
                    put("type", "object")
                    put("properties", buildJsonObject {
                        names.forEach { n ->
                            put(n, buildJsonObject {
                                put("type", "string")
                                put("description", n)
                            })
                        }
                    })
                    put("required", buildJsonArray { names.forEach { add(JsonPrimitive(it)) } })
                }
                val def = CustomToolDef(
                    name = form.name.trim(),
                    description = form.description.trim(),
                    type = form.type,
                    parameters = parameters,
                    approval = form.approval,
                    command = if (form.type == "SHELL") form.command.trim() else null,
                    method = if (form.type == "HTTP") form.method else null,
                    url = if (form.type == "HTTP") form.url.trim() else null,
                    prompt = if (form.type == "PROMPT") form.prompt.trim() else null,
                )
                catalog.save(def)
            }
            result.onSuccess {
                _notice.value = "Tool add ho gaya. Company > worker edit mein ise assign karein."
                refreshTools()
            }.onFailure { _notice.value = it.message ?: "Tool save nahi hua" }
        }
    }

    fun deleteTool(name: String) {
        viewModelScope.launch {
            runCatching { catalog.delete(name) }
                .onSuccess { _notice.value = "Tool delete ho gaya" }
                .onFailure { _notice.value = it.message ?: "Delete nahi hua" }
            refreshTools()
        }
    }

    fun importMcp(url: String) {
        if (_busy.value) return
        viewModelScope.launch {
            _busy.value = true
            runCatching { catalog.importMcp(url.trim()) }
                .onSuccess { _notice.value = "$it MCP tools import ho gaye" }
                .onFailure { _notice.value = it.message ?: "MCP import fail ho gaya" }
            _busy.value = false
            refreshTools()
        }
    }
}
