package com.aicompany.app.agents

import com.aicompany.app.provider.ChatMessage

/**
 * Keeps memory bounded on a 4 GB phone. Index 0 (system prompt) and 1 (goal) are never removed.
 * The oldest middle messages are dropped and replaced by one marker line. The marker also lists which tools were
 * already used and which files were touched, so the model does not repeat finished work after a compaction.
 */
object HistoryCompressor {
    private const val KEEP_TAIL = 4
    private const val MAX_DIGEST = 400
    private val TOOL_NAME = Regex("\"tool\"\\s*:\\s*\"([a-z0-9_]+)\"")
    private val PATH_ARG = Regex("\"path\"\\s*:\\s*\"([^\"]{1,120})\"")
    private val OLD_MARKER = Regex("^\\[(\\d+) earlier messages were removed to save memory\\](.*)$", RegexOption.DOT_MATCHES_ALL)

    fun compact(history: MutableList<ChatMessage>, maxChars: Int) {
        require(maxChars >= 1_000) { "Context budget too small" }
        if (history.size < 2) return
        var total = history.sumOf { it.content.length }
        if (total <= maxChars) return

        var dropped = 0
        var carriedDigest = ""
        val removedTexts = ArrayList<String>()
        while (total > maxChars && history.size > 2 + KEEP_TAIL) {
            val removed = history.removeAt(2)
            total -= removed.content.length
            val previous = OLD_MARKER.find(removed.content)
            if (previous != null) {
                dropped += previous.groupValues[1].toIntOrNull() ?: 1
                carriedDigest = previous.groupValues[2].trim()
            } else {
                dropped++
                removedTexts += removed.content
            }
        }
        if (dropped > 0) {
            val digest = (carriedDigest + " " + digest(removedTexts)).trim().take(MAX_DIGEST)
            history.add(2, ChatMessage("user", "[$dropped earlier messages were removed to save memory]" + if (digest.isEmpty()) "" else " $digest"))
        }
    }

    private fun digest(removed: List<String>): String {
        val tools = removed.flatMap { m -> TOOL_NAME.findAll(m).map { it.groupValues[1] }.toList() }
        if (tools.isEmpty()) return ""
        val counts = tools.groupingBy { it }.eachCount().entries
            .sortedByDescending { it.value }
            .take(8)
            .joinToString(", ") { "${it.key} x${it.value}" }
        val paths = removed.flatMap { m -> PATH_ARG.findAll(m).map { it.groupValues[1] }.toList() }.distinct().take(8)
        return "Already done: $counts." + if (paths.isEmpty()) "" else " Files touched: ${paths.joinToString(", ")}."
    }
}
