package com.aicompany.app.tools.builtin

import com.aicompany.app.tools.ApprovalLevel
import com.aicompany.app.tools.Schema
import com.aicompany.app.tools.Tool
import com.aicompany.app.tools.ToolContext
import com.aicompany.app.tools.ToolResult
import com.aicompany.app.tools.ToolSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.io.File
import javax.inject.Inject

/** One plan per run, kept in .recode/todo/<run>.md so the owner can read it and a restart does not lose it. */
object TodoPlan {
    val STATUSES = listOf("pending", "in_progress", "completed")

    data class Item(val status: String, val text: String)

    fun parse(raw: List<String>): List<Item> = raw.mapNotNull { line ->
        val trimmed = line.trim()
        if (trimmed.isEmpty()) return@mapNotNull null
        val colon = trimmed.indexOf(':')
        val head = if (colon > 0) trimmed.substring(0, colon).trim().lowercase().replace(' ', '_').replace('-', '_') else ""
        if (head in STATUSES) Item(head, trimmed.substring(colon + 1).trim()) else Item("pending", trimmed)
    }.filter { it.text.isNotEmpty() }

    fun format(items: List<Item>): String =
        items.joinToString("\n") { "- [${it.status}] ${it.text}" }

    fun file(root: File, agentId: String): File {
        val safe = agentId.replace(Regex("[^A-Za-z0-9_-]"), "_").take(64).ifEmpty { "run" }
        return File(root, ".recode/todo/$safe.md")
    }
}

class TodoWriteTool @Inject constructor() : Tool {
    override val spec = ToolSpec(
        name = "todo_write",
        description = "Write or update your short task plan. Each item is 'status: task' where status is pending, " +
            "in_progress or completed. Send the whole list every time.",
        schema = Schema.obj(
            mapOf(
                "todos" to buildJsonObject {
                    put("type", "array")
                    put("description", "Whole plan, for example [\"completed: read the file\", \"in_progress: fix the bug\"]")
                    put("maxItems", 12)
                    put("items", buildJsonObject {
                        put("type", "string")
                        put("maxLength", 200)
                    })
                },
            ),
            listOf("todos"),
        ),
        approval = ApprovalLevel.AUTO,
    )

    override suspend fun execute(args: JsonObject, ctx: ToolContext): ToolResult = withContext(Dispatchers.IO) {
        val raw = (args["todos"] as? JsonArray)
            ?.mapNotNull { (it as? JsonPrimitive)?.takeIf { p -> p.isString }?.content }
            ?: return@withContext ToolResult.Error("invalid_args", "todos must be a list of strings")
        val items = TodoPlan.parse(raw)
        if (items.isEmpty()) return@withContext ToolResult.Error("invalid_args", "todos has no usable items")
        val text = TodoPlan.format(items)
        atomicWrite(TodoPlan.file(ctx.workspace.root, ctx.agentId), text + "\n")
        val open = items.count { it.status != "completed" }
        ToolResult.Ok(
            "Plan saved ($open open):\n$text\n" +
                "Mark an item completed only when a tool result proves it. Keep failed work open."
        )
    }
}
