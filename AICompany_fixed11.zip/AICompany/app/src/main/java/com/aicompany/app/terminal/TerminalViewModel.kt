package com.aicompany.app.terminal

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.termux.terminal.TerminalSession
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class TerminalViewModel @Inject constructor(
    val installer: RootfsInstaller,
    private val launcher: ShellLauncher,
) : ViewModel() {

    val installState: StateFlow<InstallState> = installer.state

    private val _session = MutableStateFlow<TerminalSession?>(null)
    val session: StateFlow<TerminalSession?> = _session.asStateFlow()

    private val _notice = MutableStateFlow<String?>(null)
    val notice: StateFlow<String?> = _notice.asStateFlow()

    fun install() {
        viewModelScope.launch { installer.install() }
    }

    private var autoRetried = false

    /** Creates the owner's interactive shell once. Re-entering the screen reuses it. */
    fun ensureSession() {
        if (_session.value != null) return
        val reason = launcher.notReadyReason()
        if (reason != null) {
            _notice.value = reason
            return
        }
        _session.value = TermuxBridge.createSession(
            argv = launcher.interactiveArgv(),
            environment = launcher.environment(),
            cwd = launcher.hostCwd(),
            onFinished = { code -> onShellFinished(code) },
        )
    }

    private fun onShellFinished(code: Int) {
        if (code == KILLED && !autoRetried) {
            // Signal 9 right at the start: retry once with the minimal proot options.
            autoRetried = true
            launcher.safeMode = true
            _notice.value = "Shell band ho gaya (code -9). Safe mode mein dobara chala raha hoon..."
            _session.value = null
            ensureSession()
            return
        }
        _notice.value = if (code == KILLED) {
            "Shell code -9 se band hua (phone ne process kill kiya). Settings mein battery optimisation band karein, " +
                "app ko recent apps mein lock karein, phir Restart (upar refresh icon) dabayein."
        } else {
            "Shell exited with code $code"
        }
    }

    fun restartSession() {
        _session.value?.finishIfRunning()
        _session.value = null
        _notice.value = null
        autoRetried = false
        ensureSession()
    }

    override fun onCleared() {
        _session.value?.finishIfRunning()
        super.onCleared()
    }

    private companion object {
        const val KILLED = -9
    }
}
