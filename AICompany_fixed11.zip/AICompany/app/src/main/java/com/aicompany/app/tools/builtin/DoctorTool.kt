package com.aicompany.app.tools.builtin

import com.aicompany.app.doctor.DoctorService
import com.aicompany.app.tools.ApprovalLevel
import com.aicompany.app.tools.Schema
import com.aicompany.app.tools.Tool
import com.aicompany.app.tools.ToolContext
import com.aicompany.app.tools.ToolResult
import com.aicompany.app.tools.ToolSpec
import kotlinx.serialization.json.JsonObject
import javax.inject.Inject

class SystemDoctorTool @Inject constructor(
    private val doctor: DoctorService,
) : Tool {
    override val spec = ToolSpec(
        name = "system_doctor",
        description = "Read-only check of this phone and app: RAM, CPU features, local models, terminal, internet.",
        schema = Schema.obj(emptyMap(), emptyList()),
        approval = ApprovalLevel.AUTO,
        timeoutMs = 25_000,
        maxOutputChars = 6_000,
    )

    override suspend fun execute(args: JsonObject, ctx: ToolContext): ToolResult = ToolResult.Ok(doctor.report())
}
