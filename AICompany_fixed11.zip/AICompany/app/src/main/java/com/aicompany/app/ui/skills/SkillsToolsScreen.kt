package com.aicompany.app.ui.skills

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import androidx.hilt.navigation.compose.hiltViewModel
import com.aicompany.app.data.SkillEntity
import com.aicompany.app.ui.components.AppTopBar
import com.aicompany.app.ui.components.ChipFlow
import com.aicompany.app.ui.components.PillButton
import com.aicompany.app.ui.components.PillOutlinedButton
import com.aicompany.app.ui.components.RowDivider
import com.aicompany.app.ui.components.SectionLabel
import com.aicompany.app.ui.components.SettingsGroup
import com.aicompany.app.ui.components.SettingsRow

/** Owner-controlled library: add, edit and delete skills and custom tools. */
@Composable
fun SkillsToolsScreen(
    onMenu: () -> Unit,
    viewModel: SkillsToolsViewModel = hiltViewModel(),
) {
    val skills by viewModel.skills.collectAsState()
    val tools by viewModel.tools.collectAsState()
    val notice by viewModel.notice.collectAsState()
    val busy by viewModel.busy.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    val context = LocalContext.current

    var skillDialog by remember { mutableStateOf(false) }
    var editingSkill by remember { mutableStateOf<SkillEntity?>(null) }
    var toolDialog by remember { mutableStateOf(false) }
    var mcpDialog by remember { mutableStateOf(false) }
    var confirmSkill by remember { mutableStateOf<SkillEntity?>(null) }
    var confirmTool by remember { mutableStateOf<ToolRow?>(null) }

    LaunchedEffect(notice) {
        notice?.let {
            snackbar.showSnackbar(it)
            viewModel.clearNotice()
        }
    }

    val skillFilePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val resolver = context.contentResolver
            val name = runCatching {
                resolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
            }.getOrNull() ?: "skill.md"
            val text = runCatching {
                resolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
            }.getOrNull()
            if (text == null) viewModel.reportError("File padhi nahi ja saki") else viewModel.importSkill(name, text)
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { AppTopBar("Skills & Tools", Icons.Default.Menu, "Menu", onMenu) },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item { SectionLabel("Skills (workers ke liye instructions)") }
            item {
                SettingsGroup {
                    if (skills.isEmpty()) {
                        Text(
                            "Abhi koi skill nahi. Neeche Add dabayein, ya .md / .txt file import karein.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(16.dp),
                        )
                    }
                    skills.forEachIndexed { i, s ->
                        if (i > 0) RowDivider()
                        SettingsRow(
                            title = s.name,
                            subtitle = s.description.ifBlank { s.instructions.take(80) },
                            trailing = {
                                IconButton(onClick = { editingSkill = s; skillDialog = true }) {
                                    Icon(Icons.Default.Edit, contentDescription = "Edit skill")
                                }
                                IconButton(onClick = { confirmSkill = s }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete skill")
                                }
                            },
                        )
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    PillButton(
                        text = "Add skill",
                        icon = Icons.Default.Add,
                        modifier = Modifier.weight(1f),
                        onClick = { editingSkill = null; skillDialog = true },
                    )
                    PillOutlinedButton(
                        text = "Import file",
                        icon = Icons.Outlined.FolderOpen,
                        modifier = Modifier.weight(1f),
                        onClick = { skillFilePicker.launch(arrayOf("*/*")) },
                    )
                }
            }

            item { SectionLabel("Tools") }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    PillButton(
                        text = "Add tool",
                        icon = Icons.Default.Add,
                        modifier = Modifier.weight(1f),
                        onClick = { toolDialog = true },
                    )
                    PillOutlinedButton(
                        text = if (busy) "Wait..." else "MCP server",
                        enabled = !busy,
                        modifier = Modifier.weight(1f),
                        onClick = { mcpDialog = true },
                    )
                }
            }
            item {
                SettingsGroup {
                    tools.forEachIndexed { i, t ->
                        if (i > 0) RowDivider()
                        SettingsRow(
                            title = t.name,
                            subtitle = "${t.kind} · ${t.approval}\n${t.description}",
                            trailing = {
                                if (t.deletable) {
                                    IconButton(onClick = { confirmTool = t }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete tool")
                                    }
                                }
                            },
                        )
                    }
                }
            }
            item {
                Text(
                    "Built-in tools hata nahi sakte, lekin Company > worker edit mein har worker ke liye on/off kar sakte hain. " +
                        "Naye tool ko wahin worker ko assign karein.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 4.dp),
                )
            }
        }
    }

    if (skillDialog) {
        SkillDialog(
            initial = editingSkill,
            onDismiss = { skillDialog = false },
            onSave = { name, desc, text ->
                viewModel.saveSkill(editingSkill?.id, name, desc, text)
                skillDialog = false
            },
        )
    }
    if (toolDialog) {
        ToolDialog(
            onDismiss = { toolDialog = false },
            onSave = { form ->
                viewModel.addTool(form)
                toolDialog = false
            },
        )
    }
    if (mcpDialog) {
        var url by remember { mutableStateOf("https://") }
        AlertDialog(
            onDismissRequest = { mcpDialog = false },
            title = { Text("MCP server se tools") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Server ka https URL daalein. Uske saare tools import ho jayenge (approval: ASK).", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(url, { url = it }, label = { Text("MCP URL") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                PillButton(text = "Import", onClick = { viewModel.importMcp(url); mcpDialog = false })
            },
            dismissButton = { TextButton(onClick = { mcpDialog = false }) { Text("Cancel") } },
        )
    }
    confirmSkill?.let { s ->
        AlertDialog(
            onDismissRequest = { confirmSkill = null },
            title = { Text("Skill delete karein?") },
            text = { Text("\"${s.name}\" sab workers se bhi hat jayegi.") },
            confirmButton = {
                PillButton(text = "Delete", onClick = { viewModel.deleteSkill(s.id); confirmSkill = null })
            },
            dismissButton = { TextButton(onClick = { confirmSkill = null }) { Text("Cancel") } },
        )
    }
    confirmTool?.let { t ->
        AlertDialog(
            onDismissRequest = { confirmTool = null },
            title = { Text("Tool delete karein?") },
            text = { Text("\"${t.name}\" hamesha ke liye hat jayega.") },
            confirmButton = {
                PillButton(text = "Delete", onClick = { viewModel.deleteTool(t.name); confirmTool = null })
            },
            dismissButton = { TextButton(onClick = { confirmTool = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun SkillDialog(
    initial: SkillEntity?,
    onDismiss: () -> Unit,
    onSave: (String, String, String) -> Unit,
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var desc by remember { mutableStateOf(initial?.description ?: "") }
    var text by remember { mutableStateOf(initial?.instructions ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth(0.94f),
        properties = DialogProperties(usePlatformDefaultWidth = false),
        title = { Text(if (initial == null) "New skill" else "Edit skill") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(desc, { desc = it }, label = { Text("Short description") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(text, { text = it }, label = { Text("Instructions") }, minLines = 6, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            PillButton(text = "Save", enabled = name.isNotBlank() && text.isNotBlank(), onClick = { onSave(name, desc, text) })
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun ToolDialog(
    onDismiss: () -> Unit,
    onSave: (NewToolForm) -> Unit,
) {
    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("HTTP") }
    var params by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("https://") }
    var method by remember { mutableStateOf("GET") }
    var command by remember { mutableStateOf("") }
    var prompt by remember { mutableStateOf("") }
    var approval by remember { mutableStateOf("ASK") }
    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth(0.94f),
        properties = DialogProperties(usePlatformDefaultWidth = false),
        title = { Text("New tool") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it.lowercase() }, label = { Text("Name (lowercase_with_underscores)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(desc, { desc = it }, label = { Text("Kya karta hai (model ko dikhega)") }, modifier = Modifier.fillMaxWidth())
                Text("Type", style = MaterialTheme.typography.labelLarge)
                ChipFlow {
                    listOf("HTTP" to "Web API", "SHELL" to "Terminal command", "PROMPT" to "Prompt").forEach { (t, label) ->
                        FilterChip(selected = type == t, onClick = { type = t }, label = { Text(label) })
                    }
                }
                OutlinedTextField(
                    params, { params = it },
                    label = { Text("Arguments (comma se, jaise: city, query)") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                when (type) {
                    "HTTP" -> {
                        OutlinedTextField(url, { url = it }, label = { Text("URL (https). {city} jaisa placeholder chalta hai") }, modifier = Modifier.fillMaxWidth())
                        ChipFlow {
                            listOf("GET", "POST").forEach { m ->
                                FilterChip(selected = method == m, onClick = { method = m }, label = { Text(m) })
                            }
                        }
                    }
                    "SHELL" -> OutlinedTextField(
                        command, { command = it },
                        label = { Text("Command. {arg} placeholder chalta hai") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    else -> OutlinedTextField(
                        prompt, { prompt = it },
                        label = { Text("Prompt text. {arg} placeholder chalta hai") },
                        minLines = 3, modifier = Modifier.fillMaxWidth(),
                    )
                }
                Text("Permission", style = MaterialTheme.typography.labelLarge)
                ChipFlow {
                    listOf("ASK" to "Har baar poochho", "AUTO" to "Khud chalao").forEach { (a, label) ->
                        FilterChip(selected = approval == a, onClick = { approval = a }, label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) })
                    }
                }
            }
        },
        confirmButton = {
            PillButton(
                text = "Save",
                enabled = name.isNotBlank() && desc.isNotBlank(),
                onClick = { onSave(NewToolForm(name, desc, type, params, url, method, command, prompt, approval)) },
            )
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
