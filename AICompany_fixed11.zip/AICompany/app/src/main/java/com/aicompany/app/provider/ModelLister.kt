package com.aicompany.app.provider

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

/** Asks a cloud service which models the key can use, so the owner can pick instead of typing a name. */
@Singleton
class ModelLister @Inject constructor(
    private val http: OkHttpClient,
    private val json: Json,
) {
    suspend fun list(format: ApiFormat, baseUrl: String, apiKey: String): Result<List<String>> =
        withContext(Dispatchers.IO) {
            runCatching {
                require(format != ApiFormat.LOCAL) { "Local models are chosen from the phone" }
                requireSafeBaseUrl(baseUrl)
                val key = apiKey.trim()
                require(key.isNotEmpty() || isLocalNetworkUrl(baseUrl)) { "Pehle API key daalein" }
                val builder = Request.Builder()
                when (format) {
                    ApiFormat.GEMINI -> builder
                        .url(joinUrl(baseUrl, "/v1beta/models?pageSize=200"))
                        .header("x-goog-api-key", key)
                    ApiFormat.ANTHROPIC -> builder
                        .url(joinUrl(baseUrl, "/v1/models?limit=100"))
                        .header("x-api-key", key)
                        .header("anthropic-version", "2023-06-01")
                    else -> builder
                        .url(joinUrl(baseUrl, "/models"))
                        .header("Authorization", "Bearer $key")
                }
                val client = http.newBuilder()
                    .connectTimeout(15, TimeUnit.SECONDS)
                    .readTimeout(20, TimeUnit.SECONDS)
                    .followSslRedirects(false)
                    .build()
                val body = try {
                    client.newCall(builder.build()).execute().use { resp ->
                        val text = resp.body?.string().orEmpty()
                        if (resp.code == 401 || resp.code == 403) error("API key galat hai ya is service ke liye allowed nahi (${resp.code})")
                        if (!resp.isSuccessful) error("Model list nahi mili (HTTP ${resp.code})")
                        text
                    }
                } catch (e: IOException) {
                    error("Internet / network error: ${e.javaClass.simpleName}")
                }
                parse(format, body)
            }
        }

    internal fun parse(format: ApiFormat, body: String): List<String> {
        val root = json.parseToJsonElement(body).jsonObject
        val names: List<String> = if (format == ApiFormat.GEMINI) {
            (root["models"] as? JsonArray).orEmpty().mapNotNull { m ->
                val obj = m.jsonObject
                val methods = (obj["supportedGenerationMethods"] as? JsonArray)
                    ?.mapNotNull { it.jsonPrimitive.contentOrNull }.orEmpty()
                val name = obj["name"]?.jsonPrimitive?.contentOrNull?.removePrefix("models/")
                if (name != null && (methods.isEmpty() || "generateContent" in methods)) name else null
            }
        } else {
            (root["data"] as? JsonArray).orEmpty().mapNotNull { m ->
                m.jsonObject["id"]?.jsonPrimitive?.contentOrNull
            }
        }
        // Free models first (OpenRouter marks them with ":free"), then alphabetical.
        return names.distinct()
            .filter { it.length <= 120 }
            .sortedWith(compareBy<String>({ !it.endsWith(":free") }, { it.lowercase() }))
            .take(300)
    }
}
