package com.aicompany.app.tools.builtin

import com.aicompany.app.tools.ApprovalLevel
import com.aicompany.app.tools.Schema
import com.aicompany.app.tools.Tool
import com.aicompany.app.tools.ToolContext
import com.aicompany.app.tools.ToolResult
import com.aicompany.app.tools.ToolSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import java.io.File
import javax.inject.Inject

private val SKIP_DIRS = setOf(".git", "node_modules", ".recode", ".tmp", "build", "dist", "__pycache__", ".gradle", ".venv")
private const val MAX_FILES_SCANNED = 4_000
private const val MAX_FILE_BYTES = 512 * 1024L

private fun str(args: JsonObject, key: String): String? =
    (args[key] as? JsonPrimitive)?.takeIf { it.isString }?.content

/** "*.kt" matches by file name, "src/**/*.js" matches the relative path. */
internal fun globToRegex(glob: String): Regex {
    val sb = StringBuilder("^")
    var i = 0
    while (i < glob.length) {
        val c = glob[i]
        when {
            c == '*' && i + 1 < glob.length && glob[i + 1] == '*' -> {
                sb.append(".*")
                i++
            }
            c == '*' -> sb.append("[^/]*")
            c == '?' -> sb.append("[^/]")
            else -> sb.append(Regex.escape(c.toString()))
        }
        i++
    }
    return Regex(sb.append('$').toString())
}

private fun walk(root: File, start: File): Sequence<File> =
    start.walkTopDown()
        .onEnter { dir -> dir == start || dir.name !in SKIP_DIRS }
        .filter { it.isFile }
        .take(MAX_FILES_SCANNED)

private fun matchesGlob(root: File, file: File, glob: Regex?, hasSlash: Boolean): Boolean {
    if (glob == null) return true
    val rel = file.relativeTo(root).path.replace(File.separatorChar, '/')
    return glob.matches(if (hasSlash) rel else file.name)
}

class SearchCodeTool @Inject constructor() : Tool {
    override val spec = ToolSpec(
        name = "search_code",
        description = "Search text inside workspace files (like grep). Returns file:line: text. Use it to find code before editing.",
        schema = Schema.obj(
            mapOf(
                "query" to Schema.str("Text to find (case-insensitive)", 200),
                "path" to Schema.str("Folder to search, '.' for the whole workspace", 512),
                "glob" to Schema.str("Optional file filter such as *.kt or src/**/*.js", 120),
            ),
            listOf("query"),
        ),
        approval = ApprovalLevel.AUTO,
        timeoutMs = 25_000,
        maxOutputChars = 8_000,
    )

    override suspend fun execute(args: JsonObject, ctx: ToolContext): ToolResult = withContext(Dispatchers.IO) {
        val query = str(args, "query")?.takeIf { it.isNotBlank() }
            ?: return@withContext ToolResult.Error("invalid_args", "query must be a non-empty string")
        val start = try {
            ctx.workspace.resolve(str(args, "path")?.takeIf { it.isNotBlank() } ?: ".")
        } catch (e: IllegalArgumentException) {
            return@withContext ToolResult.Error("invalid_path", e.message ?: "Invalid path")
        }
        if (!start.exists()) return@withContext ToolResult.Error("not_found", "Path does not exist")
        val globText = str(args, "glob")?.trim()?.takeIf { it.isNotEmpty() }
        val glob = globText?.let { runCatching { globToRegex(it) }.getOrNull() }
        val root = ctx.workspace.root
        val results = ArrayList<String>()

        for (file in walk(root, start)) {
            if (results.size >= MAX_RESULTS) break
            if (file.length() > MAX_FILE_BYTES || !matchesGlob(root, file, glob, globText?.contains('/') == true)) continue
            val lines = runCatching { file.readText(Charsets.UTF_8) }.getOrNull() ?: continue
            if (lines.take(1_024).contains('\u0000')) continue
            val rel = file.relativeTo(root).path
            lines.lineSequence().forEachIndexed { index, line ->
                if (results.size < MAX_RESULTS && line.contains(query, ignoreCase = true)) {
                    results += "$rel:${index + 1}: ${line.trim().take(200)}"
                }
            }
        }
        if (results.isEmpty()) ToolResult.Ok("No matches")
        else ToolResult.Ok(results.joinToString("\n") + if (results.size >= MAX_RESULTS) "\n[stopped at $MAX_RESULTS matches]" else "")
    }

    private companion object {
        const val MAX_RESULTS = 60
    }
}

class FindFilesTool @Inject constructor() : Tool {
    override val spec = ToolSpec(
        name = "find_files",
        description = "List workspace files whose name or path matches a pattern such as *.py or src/**/*.ts.",
        schema = Schema.obj(
            mapOf("pattern" to Schema.str("Glob pattern, * matches within a folder, ** across folders", 120)),
            listOf("pattern"),
        ),
        approval = ApprovalLevel.AUTO,
        timeoutMs = 25_000,
    )

    override suspend fun execute(args: JsonObject, ctx: ToolContext): ToolResult = withContext(Dispatchers.IO) {
        val pattern = str(args, "pattern")?.trim()?.takeIf { it.isNotEmpty() }
            ?: return@withContext ToolResult.Error("invalid_args", "pattern must be a non-empty string")
        val glob = runCatching { globToRegex(pattern) }.getOrNull()
            ?: return@withContext ToolResult.Error("invalid_args", "pattern is not valid")
        val root = ctx.workspace.root
        val found = walk(root, root)
            .filter { matchesGlob(root, it, glob, pattern.contains('/')) }
            .map { it.relativeTo(root).path }
            .sorted()
            .take(MAX_RESULTS)
            .toList()
        ToolResult.Ok(if (found.isEmpty()) "No files match" else found.joinToString("\n"))
    }

    private companion object {
        const val MAX_RESULTS = 100
    }
}
