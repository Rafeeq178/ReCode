package com.aicompany.app.local

import android.app.ActivityManager
import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/** Reports free RAM and the latest system trim level. The local engine unloads only when memory is really short. */
@Singleton
class MemoryMonitor @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val am = context.getSystemService(ActivityManager::class.java)

    private val _trimLevel = MutableStateFlow(0)
    val trimLevel: StateFlow<Int> = _trimLevel.asStateFlow()

    fun availableBytes(): Long {
        val info = ActivityManager.MemoryInfo()
        am?.getMemoryInfo(info)
        return info.availMem
    }

    fun totalBytes(): Long {
        val info = ActivityManager.MemoryInfo()
        am?.getMemoryInfo(info)
        return info.totalMem
    }

    fun isLowMemory(): Boolean {
        val info = ActivityManager.MemoryInfo()
        am?.getMemoryInfo(info)
        return info.lowMemory
    }

    /** Called from Application.onTrimMemory. */
    fun onTrim(level: Int) {
        _trimLevel.value = level
    }

    fun shouldUnloadModel(level: Int): Boolean = shouldUnload(level)

    companion object {
        /** TRIM_MEMORY_RUNNING_CRITICAL: the app is in the foreground and the device is nearly out of memory. */
        const val RUNNING_CRITICAL = 15

        /** TRIM_MEMORY_UI_HIDDEN (20) only means "the UI is not visible"; background work keeps running. */
        const val UI_HIDDEN = 20

        /** TRIM_MEMORY_MODERATE: the process sits in the middle of the system's kill list. */
        const val CACHED_MODERATE = 60

        /**
         * Unload on RUNNING_CRITICAL and on the cached-process levels that precede a kill (60 and 80).
         * UI_HIDDEN (20) and BACKGROUND (40) must NOT unload, otherwise the model vanishes under an agent
         * that is still working while the app is merely in the background. A running generation is
         * never interrupted: the engine defers the unload until the request ends.
         */
        fun shouldUnload(level: Int): Boolean = level == RUNNING_CRITICAL || level >= CACHED_MODERATE
    }
}
