package com.aicompany.app.ui.company

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.aicompany.app.company.TaskStatus
import com.aicompany.app.data.TaskEntity
import com.aicompany.app.ui.components.AppTopBar
import com.aicompany.app.ui.components.PillButton
import com.aicompany.app.ui.components.PillOutlinedButton
import com.aicompany.app.ui.components.RowDivider
import com.aicompany.app.ui.components.SectionLabel
import com.aicompany.app.ui.components.SettingsGroup
import com.aicompany.app.ui.components.SettingsRow
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import com.aicompany.app.data.EmployeeEntity

@Composable
fun CompanyScreen(
    onMenu: () -> Unit,
    onOpenEmployee: (String) -> Unit,
    onNewEmployee: () -> Unit,
    viewModel: CompanyViewModel = hiltViewModel(),
) {
    val employees by viewModel.employees.collectAsState()
    val tasks by viewModel.tasks.collectAsState()
    val active by viewModel.active.collectAsState()
    val notice by viewModel.notice.collectAsState()
    var goal by rememberSaveable { mutableStateOf("") }
    var hireName by rememberSaveable { mutableStateOf("") }
    var hireRole by rememberSaveable { mutableStateOf("") }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(notice) {
        notice?.let {
            snackbar.showSnackbar(it)
            viewModel.clearNotice()
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { AppTopBar("Company", Icons.Default.Menu, "Menu", onMenu) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onNewEmployee,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("New worker", fontWeight = FontWeight.Medium) },
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            SettingsGroup {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Goal for the CEO", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(
                        value = goal,
                        onValueChange = { if (it.length <= 4000) goal = it },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2,
                        maxLines = 5,
                        placeholder = { Text("Goal likhein, CEO plan banayega") },
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        PillButton(
                            text = "Send to CEO",
                            onClick = {
                                viewModel.runCeo(goal)
                                goal = ""
                            },
                            enabled = goal.isNotBlank(),
                        )
                        PillOutlinedButton(
                            text = "Stop all",
                            onClick = viewModel::stopAll,
                            icon = Icons.Default.Warning,
                            danger = true,
                        )
                    }
                    Text(
                        "Active runs: $active",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            val working = employees.count { it.status == "WORKING" }
            val done = tasks.count { it.status == TaskStatus.DONE.name }
            val failed = tasks.count { it.status == TaskStatus.FAILED.name }
            SectionLabel("Employees (${employees.size})")
            Text(
                "$working kaam kar rahe  \u00b7  $done task done  \u00b7  $failed fail",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 4.dp),
            )
            if (employees.isEmpty()) {
                Text(
                    "Abhi koi employee nahi. Neeche New worker ya Quick hire use karein.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 4.dp),
                )
            } else {
                employees.forEach { e ->
                    WorkerCard(
                        employee = e,
                        tasks = tasks.filter { it.assigneeId == e.id },
                        onOpen = { onOpenEmployee(e.id) },
                        onFire = { viewModel.fire(e.id) },
                    )
                }
            }

            SectionLabel("Quick hire")
            SettingsGroup {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(hireName, { hireName = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(hireRole, { hireRole = it }, label = { Text("Role") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    PillButton(
                        text = "Hire (default tools)",
                        onClick = {
                            viewModel.hire(hireName, hireRole)
                            hireName = ""
                            hireRole = ""
                        },
                        enabled = hireName.isNotBlank() && hireRole.isNotBlank(),
                    )
                }
            }

            SectionLabel("Task board")
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                TaskStatus.entries.forEach { status ->
                    BoardColumn(status, tasks.filter { it.status == status.name })
                }
            }
        }
    }
}

@Composable
private fun BoardColumn(status: TaskStatus, items: List<TaskEntity>) {
    Column(
        modifier = Modifier.width(220.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(
            "${status.name} (${items.size})",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        items.forEach { t ->
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(t.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                    if (t.result.isNotEmpty()) {
                        Text(
                            t.result.take(200),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 4,
                        )
                    }
                }
            }
        }
        if (items.isEmpty()) {
            Spacer(Modifier.height(4.dp))
        }
    }
}

private fun parseColor(hex: String, fallback: Color): Color =
    runCatching { Color(android.graphics.Color.parseColor(hex)) }.getOrDefault(fallback)

/** One card per worker: who they are, what they are doing right now, and what they last delivered. */
@Composable
private fun WorkerCard(
    employee: EmployeeEntity,
    tasks: List<TaskEntity>,
    onOpen: () -> Unit,
    onFire: () -> Unit,
) {
    val accent = parseColor(employee.color, MaterialTheme.colorScheme.primary)
    val fired = employee.status == "FIRED"
    val current = tasks.filter { it.status == TaskStatus.IN_PROGRESS.name }.maxByOrNull { it.updatedAt }
    val last = tasks.filter { it.status == TaskStatus.DONE.name || it.status == TaskStatus.FAILED.name }
        .maxByOrNull { it.updatedAt }
    val statusColor = when (employee.status) {
        "WORKING" -> Color(0xFF2E9E5B)
        "PAUSED" -> Color(0xFFE0A030)
        "FIRED" -> MaterialTheme.colorScheme.error
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, if (employee.status == "WORKING") statusColor else MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(40.dp).clip(CircleShape).background(accent),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        employee.name.take(1).uppercase(),
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.titleMedium,
                    )
                }
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(employee.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        employee.role,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(statusColor.copy(alpha = 0.14f))
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(statusColor))
                    Text(
                        "  " + employee.status,
                        style = MaterialTheme.typography.labelMedium,
                        color = statusColor,
                        fontWeight = FontWeight.Medium,
                    )
                }
            }
            when {
                current != null -> Text(
                    "Abhi: ${current.title}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                last != null -> Text(
                    (if (last.status == TaskStatus.DONE.name) "Last kaam: " else "Last kaam fail: ") +
                        last.title + (if (last.result.isNotBlank()) " \u2014 " + last.result.take(140) else ""),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                )
                else -> Text(
                    "Abhi koi task nahi mila.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${employee.toolSet().size} tools  \u00b7  ${tasks.count { it.status == TaskStatus.DONE.name }} done  \u00b7  v${employee.version}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f),
                )
                if (!fired) {
                    TextButton(onClick = onFire) { Text("Fire", color = MaterialTheme.colorScheme.error) }
                }
            }
        }
    }
}
