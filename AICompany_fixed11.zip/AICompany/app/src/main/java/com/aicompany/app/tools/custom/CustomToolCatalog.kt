package com.aicompany.app.tools.custom

import android.content.Context
import com.aicompany.app.data.CustomToolDao
import com.aicompany.app.data.CustomToolEntity
import com.aicompany.app.tools.Tool
import com.aicompany.app.tools.ToolSpec
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Holds every custom tool: those saved in Room and those dropped into filesDir/plugins as .json.
 * Built-in tools always win on a name clash. Bad plugin files are skipped and reported.
 */
@Singleton
class CustomToolCatalog @Inject constructor(
    @ApplicationContext context: Context,
    private val dao: CustomToolDao,
    private val runner: CustomToolRunner,
    private val mcp: McpClient,
    private val json: Json,
    builtins: Set<@JvmSuppressWildcards Tool>,
) {
    private val tools = ConcurrentHashMap<String, CustomTool>()
    private val builtinNames: Set<String> = builtins.map { it.spec.name }.toSet()
    private val pluginDir = File(context.filesDir, "plugins")
    private val lock = Mutex()

    fun get(name: String): Tool? = tools[name]
    fun names(): Set<String> = tools.keys.toSet()
    fun specs(): List<ToolSpec> = tools.values.map { it.spec }
    fun definitions(): List<CustomToolDef> = tools.values.map { it.def }.sortedBy { it.name }

    /** Names saved in the database (these can be deleted in the app; plugin files cannot). */
    suspend fun savedNames(): Set<String> = withContext(Dispatchers.IO) { dao.all().map { it.name }.toSet() }

    /** Reloads from the database and the plugin folder. Returns human-readable problems. */
    suspend fun reload(): List<String> = lock.withLock {
        withContext(Dispatchers.IO) {
            val problems = mutableListOf<String>()
            tools.clear()
            dao.all().forEach { row ->
                runCatching { json.decodeFromString(CustomToolDef.serializer(), row.definition) }
                    .onSuccess { def -> register(def)?.let { problems += it } }
                    .onFailure { problems += "Saved tool ${row.name} could not be read" }
            }
            pluginDir.listFiles { f -> f.isFile && f.name.endsWith(".json") }
                ?.sortedBy { it.name }
                ?.forEach { file ->
                    runCatching { parsePlugin(file.readText(Charsets.UTF_8).take(MAX_PLUGIN_CHARS)) }
                        .onSuccess { defs -> defs.forEach { def -> register(def)?.let { problems += "${file.name}: $it" } } }
                        .onFailure { problems += "${file.name} is not valid JSON" }
                }
            problems
        }
    }

    suspend fun save(def: CustomToolDef) = lock.withLock {
        withContext(Dispatchers.IO) {
            val errors = CustomToolValidator.validate(def, builtinNames)
            require(errors.isEmpty()) { errors.joinToString("; ") }
            dao.save(
                CustomToolEntity(
                    name = def.name,
                    definition = json.encodeToString(CustomToolDef.serializer(), def),
                    createdAt = System.currentTimeMillis(),
                )
            )
            tools[def.name] = CustomTool(def, runner)
        }
    }

    suspend fun delete(name: String) = lock.withLock {
        withContext(Dispatchers.IO) {
            dao.delete(name)
            tools.remove(name)
        }
    }

    /** Imports every tool an MCP server offers. Each becomes a saved custom tool with approval ASK. */
    suspend fun importMcp(serverUrl: String): Int {
        require(serverUrl.startsWith("https://") && serverUrl.length <= 300) { "MCP server URL must start with https://" }
        val listed = mcp.listTools(serverUrl)
        require(listed.isNotEmpty()) { "The MCP server offered no tools" }
        var saved = 0
        listed.forEach { info ->
            val safe = info.name.lowercase().replace(Regex("[^a-z0-9_]"), "_").take(36)
            val def = CustomToolDef(
                name = "mcp_$safe",
                description = info.description.ifBlank { "MCP tool ${info.name}" }.take(500),
                type = "MCP",
                parameters = info.inputSchema,
                approval = "ASK",
                timeoutSeconds = 60,
                serverUrl = serverUrl,
                remoteName = info.name,
            )
            runCatching { save(def) }.onSuccess { saved++ }
        }
        return saved
    }

    private fun register(def: CustomToolDef): String? {
        val errors = CustomToolValidator.validate(def, builtinNames)
        if (errors.isNotEmpty()) return "${def.name}: ${errors.first()}"
        tools[def.name] = CustomTool(def, runner)
        return null
    }

    private fun parsePlugin(text: String): List<CustomToolDef> {
        val trimmed = text.trimStart()
        return if (trimmed.startsWith("[")) {
            json.decodeFromString(ListSerializer(CustomToolDef.serializer()), trimmed)
        } else {
            listOf(json.decodeFromString(CustomToolDef.serializer(), trimmed))
        }
    }

    companion object {
        private const val MAX_PLUGIN_CHARS = 200_000
    }
}
