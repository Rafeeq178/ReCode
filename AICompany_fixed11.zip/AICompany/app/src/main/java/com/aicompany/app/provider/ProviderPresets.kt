package com.aicompany.app.provider

/**
 * Ready-made settings for the popular cloud services, so the owner only pastes an API key.
 * Free tiers change often: [model] is just a sensible starting point, and the editor's
 * "Load models" button asks the service for its live model list.
 */
data class ProviderPreset(
    val id: String,
    val label: String,
    val format: ApiFormat,
    val baseUrl: String,
    val model: String,
    val keyUrl: String,
    val note: String,
    val maxTokens: Int = 2048,
)

object ProviderPresets {
    val ALL: List<ProviderPreset> = listOf(
        ProviderPreset(
            id = "groq", label = "Groq", format = ApiFormat.OPENAI,
            baseUrl = "https://api.groq.com/openai/v1", model = "llama-3.3-70b-versatile",
            keyUrl = "console.groq.com/keys", note = "Free, very fast",
        ),
        ProviderPreset(
            id = "openrouter", label = "OpenRouter", format = ApiFormat.OPENAI,
            baseUrl = "https://openrouter.ai/api/v1", model = "meta-llama/llama-3.3-70b-instruct:free",
            keyUrl = "openrouter.ai/keys", note = "Many models ending in :free",
        ),
        ProviderPreset(
            id = "gemini", label = "Google Gemini", format = ApiFormat.GEMINI,
            baseUrl = "https://generativelanguage.googleapis.com", model = "gemini-2.5-flash",
            keyUrl = "aistudio.google.com/apikey", note = "Free tier",
        ),
        ProviderPreset(
            id = "cerebras", label = "Cerebras", format = ApiFormat.OPENAI,
            baseUrl = "https://api.cerebras.ai/v1", model = "llama-3.3-70b",
            keyUrl = "cloud.cerebras.ai", note = "Free, very fast",
        ),
        ProviderPreset(
            id = "nvidia", label = "NVIDIA NIM", format = ApiFormat.OPENAI,
            baseUrl = "https://integrate.api.nvidia.com/v1", model = "meta/llama-3.3-70b-instruct",
            keyUrl = "build.nvidia.com", note = "Free credits",
        ),
        ProviderPreset(
            id = "mistral", label = "Mistral", format = ApiFormat.OPENAI,
            baseUrl = "https://api.mistral.ai/v1", model = "mistral-small-latest",
            keyUrl = "console.mistral.ai", note = "Free tier",
        ),
        ProviderPreset(
            id = "deepseek", label = "DeepSeek", format = ApiFormat.OPENAI,
            baseUrl = "https://api.deepseek.com/v1", model = "deepseek-chat",
            keyUrl = "platform.deepseek.com", note = "Cheap",
        ),
        ProviderPreset(
            id = "openai", label = "OpenAI", format = ApiFormat.OPENAI,
            baseUrl = "https://api.openai.com/v1", model = "gpt-4o-mini",
            keyUrl = "platform.openai.com/api-keys", note = "Paid",
        ),
        ProviderPreset(
            id = "anthropic", label = "Claude", format = ApiFormat.ANTHROPIC,
            baseUrl = "https://api.anthropic.com", model = "claude-sonnet-4-5",
            keyUrl = "console.anthropic.com", note = "Paid",
        ),
    )

    /** The ones shown as one-tap chips on the Models screen. */
    val QUICK: List<ProviderPreset> = ALL.filter { it.id in setOf("groq", "openrouter", "gemini", "cerebras") }

    fun byId(id: String): ProviderPreset? = ALL.firstOrNull { it.id == id }
}
