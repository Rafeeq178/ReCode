package com.aicompany.app

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.aicompany.app.prefs.UiPrefs
import com.aicompany.app.ui.CrashReportScreen
import com.aicompany.app.ui.approvals.ApprovalHost
import com.aicompany.app.ui.nav.AppNav
import com.aicompany.app.ui.theme.AICompanyTheme
import com.aicompany.app.util.CrashReporter
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var uiPrefs: UiPrefs

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val lastCrash = CrashReporter.read(this)
        setContent {
            val mode by uiPrefs.themeMode.collectAsState()
            val systemDark = isSystemInDarkTheme()
            val dark = when (mode) {
                UiPrefs.THEME_DARK -> true
                UiPrefs.THEME_LIGHT -> false
                else -> systemDark
            }

            // Keep status/navigation bar icons readable for the chosen theme.
            DisposableEffect(dark) {
                val style = if (dark) {
                    SystemBarStyle.dark(AndroidColor.TRANSPARENT)
                } else {
                    SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT)
                }
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
                onDispose {}
            }

            AICompanyTheme(darkTheme = dark) {
                Surface(modifier = Modifier, color = MaterialTheme.colorScheme.background) {
                    var report by remember { mutableStateOf(lastCrash) }
                    val shown = report
                    if (shown != null) {
                        CrashReportScreen(shown) {
                            CrashReporter.clear(this@MainActivity)
                            report = null
                        }
                    } else {
                        AppNav()
                        ApprovalHost()
                    }
                }
            }
        }
    }
}
