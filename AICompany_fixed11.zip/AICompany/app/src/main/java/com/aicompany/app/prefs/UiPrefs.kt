package com.aicompany.app.prefs

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/** Small non-secret UI settings: display name for the greeting and light/dark choice. */
@Singleton
class UiPrefs @Inject constructor(
    @ApplicationContext context: Context,
) {
    private val sp = context.getSharedPreferences("ui_prefs", Context.MODE_PRIVATE)

    private val _userName = MutableStateFlow(sp.getString(KEY_NAME, DEFAULT_NAME) ?: DEFAULT_NAME)
    val userName: StateFlow<String> = _userName.asStateFlow()

    private val _themeMode = MutableStateFlow(sp.getString(KEY_THEME, THEME_SYSTEM) ?: THEME_SYSTEM)
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()

    private val _selectedProviderId = MutableStateFlow(sp.getString(KEY_PROVIDER, null))

    /** Provider the owner chose in the chat model switcher, or null for "first in the list". */
    val selectedProviderId: StateFlow<String?> = _selectedProviderId.asStateFlow()

    private val _agentMode = MutableStateFlow(sp.getBoolean(KEY_AGENT, true))

    /** True: chat messages run through the tool-using agent. False: plain chat with the model. */
    val agentMode: StateFlow<Boolean> = _agentMode.asStateFlow()

    fun setAgentMode(on: Boolean) {
        sp.edit().putBoolean(KEY_AGENT, on).apply()
        _agentMode.value = on
    }

    fun setSelectedProviderId(id: String?) {
        sp.edit().apply { if (id == null) remove(KEY_PROVIDER) else putString(KEY_PROVIDER, id) }.apply()
        _selectedProviderId.value = id
    }

    fun setUserName(value: String) {
        val v = value.trim().take(40)
        sp.edit().putString(KEY_NAME, v).apply()
        _userName.value = v
    }

    fun setThemeMode(mode: String) {
        val m = if (mode == THEME_LIGHT || mode == THEME_DARK) mode else THEME_SYSTEM
        sp.edit().putString(KEY_THEME, m).apply()
        _themeMode.value = m
    }

    companion object {
        const val THEME_SYSTEM = "system"
        const val THEME_LIGHT = "light"
        const val THEME_DARK = "dark"
        private const val KEY_NAME = "user_name"
        private const val KEY_THEME = "theme_mode"
        private const val KEY_PROVIDER = "selected_provider"
        private const val KEY_AGENT = "agent_mode"
        private const val DEFAULT_NAME = "Rafeeq"
    }
}
