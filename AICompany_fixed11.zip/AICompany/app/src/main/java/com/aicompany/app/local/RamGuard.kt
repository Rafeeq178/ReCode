package com.aicompany.app.local

/**
 * Decides whether a GGUF model should load on this phone.
 *
 * The weights are memory-mapped, so they live in the page cache, which Android can drop and reload at any
 * time. "Free" RAM (availMem) therefore under-reports what a model can really use: a 1 GB model was refused on
 * a 4 GB phone just because many apps were open. The budget is the larger of the free memory and a share of
 * the phone's total RAM; the hard limit is that the model must fit in that share.
 */
object RamGuard {
    /** Runtime overhead on top of the weights: KV cache, buffers, and the app itself. */
    const val OVERHEAD_BYTES = 350L * 1024 * 1024

    /** Share of total RAM a mapped model may use, since the system and other apps keep the rest. */
    const val TOTAL_SHARE = 0.55

    enum class Verdict { OK, TIGHT, TOO_LARGE }

    fun assess(modelBytes: Long, availableBytes: Long, totalBytes: Long = 0L): Verdict {
        require(modelBytes >= 0) { "Model size is negative" }
        require(availableBytes >= 0) { "Available memory is negative" }
        require(totalBytes >= 0) { "Total memory is negative" }
        val need = modelBytes + OVERHEAD_BYTES
        val budget = maxOf(availableBytes, (totalBytes * TOTAL_SHARE).toLong())
        return when {
            need > budget -> Verdict.TOO_LARGE
            need > (budget * 0.8).toLong() -> Verdict.TIGHT
            else -> Verdict.OK
        }
    }
}
