package com.aicompany.app.tools

import com.aicompany.app.tools.company.AskOwnerTool
import com.aicompany.app.tools.company.EditWorkerTool
import com.aicompany.app.tools.company.LoadSkillTool
import com.aicompany.app.tools.company.AssignTaskTool
import com.aicompany.app.tools.company.CheckTaskTool
import com.aicompany.app.tools.company.FinalReportTool
import com.aicompany.app.tools.company.FireWorkerTool
import com.aicompany.app.tools.company.HireWorkerTool
import com.aicompany.app.tools.social.TelegramSendTool
import com.aicompany.app.tools.drive.DriveReadTool
import com.aicompany.app.tools.drive.DriveSearchTool
import com.aicompany.app.tools.social.WhatsAppSendTool
import com.aicompany.app.tools.builtin.CalculatorTool
import com.aicompany.app.tools.builtin.EditFileTool
import com.aicompany.app.tools.builtin.FindFilesTool
import com.aicompany.app.tools.builtin.MemoryReadTool
import com.aicompany.app.tools.builtin.MemorySearchTool
import com.aicompany.app.tools.builtin.MemoryWriteTool
import com.aicompany.app.tools.builtin.SearchCodeTool
import com.aicompany.app.tools.builtin.SystemDoctorTool
import com.aicompany.app.tools.builtin.TodoWriteTool
import com.aicompany.app.tools.builtin.UndoEditTool
import com.aicompany.app.tools.builtin.WebSearchTool
import com.aicompany.app.tools.builtin.GetTimeTool
import com.aicompany.app.tools.builtin.InstallPackageTool
import com.aicompany.app.tools.builtin.ListDirTool
import com.aicompany.app.tools.builtin.ReadFileTool
import com.aicompany.app.tools.builtin.RunCommandTool
import com.aicompany.app.tools.builtin.RunNodeTool
import com.aicompany.app.tools.builtin.RunPythonTool
import com.aicompany.app.tools.builtin.WebFetchTool
import com.aicompany.app.tools.builtin.WriteFileTool
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import dagger.multibindings.IntoSet

@Module
@InstallIn(SingletonComponent::class)
abstract class ToolsModule {
    @Binds @IntoSet abstract fun readFile(t: ReadFileTool): Tool
    @Binds @IntoSet abstract fun writeFile(t: WriteFileTool): Tool
    @Binds @IntoSet abstract fun listDir(t: ListDirTool): Tool
    @Binds @IntoSet abstract fun getTime(t: GetTimeTool): Tool
    @Binds @IntoSet abstract fun calculator(t: CalculatorTool): Tool
    @Binds @IntoSet abstract fun webFetch(t: WebFetchTool): Tool
    @Binds @IntoSet abstract fun runCommand(t: RunCommandTool): Tool
    @Binds @IntoSet abstract fun runPython(t: RunPythonTool): Tool
    @Binds @IntoSet abstract fun runNode(t: RunNodeTool): Tool
    @Binds @IntoSet abstract fun installPackage(t: InstallPackageTool): Tool
    @Binds @IntoSet abstract fun hireWorker(t: HireWorkerTool): Tool
    @Binds @IntoSet abstract fun fireWorker(t: FireWorkerTool): Tool
    @Binds @IntoSet abstract fun assignTask(t: AssignTaskTool): Tool
    @Binds @IntoSet abstract fun checkTask(t: CheckTaskTool): Tool
    @Binds @IntoSet abstract fun askOwner(t: AskOwnerTool): Tool
    @Binds @IntoSet abstract fun finalReport(t: FinalReportTool): Tool
    @Binds @IntoSet abstract fun loadSkill(t: LoadSkillTool): Tool
    @Binds @IntoSet abstract fun editWorker(t: EditWorkerTool): Tool
    @Binds @IntoSet abstract fun telegramSend(t: TelegramSendTool): Tool
    @Binds @IntoSet abstract fun whatsappSend(t: WhatsAppSendTool): Tool
    @Binds @IntoSet abstract fun driveSearch(t: DriveSearchTool): Tool
    @Binds @IntoSet abstract fun driveRead(t: DriveReadTool): Tool
    @Binds @IntoSet abstract fun editFile(t: EditFileTool): Tool
    @Binds @IntoSet abstract fun undoEdit(t: UndoEditTool): Tool
    @Binds @IntoSet abstract fun searchCode(t: SearchCodeTool): Tool
    @Binds @IntoSet abstract fun findFiles(t: FindFilesTool): Tool
    @Binds @IntoSet abstract fun memoryRead(t: MemoryReadTool): Tool
    @Binds @IntoSet abstract fun memoryWrite(t: MemoryWriteTool): Tool
    @Binds @IntoSet abstract fun memorySearch(t: MemorySearchTool): Tool
    @Binds @IntoSet abstract fun todoWrite(t: TodoWriteTool): Tool
    @Binds @IntoSet abstract fun webSearch(t: WebSearchTool): Tool
    @Binds @IntoSet abstract fun systemDoctor(t: SystemDoctorTool): Tool
}
