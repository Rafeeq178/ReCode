package com.aicompany.app.doctor

import android.content.Context
import android.os.Build
import com.aicompany.app.BuildConfig
import com.aicompany.app.data.ProviderRepository
import com.aicompany.app.llama.LlamaEngine
import com.aicompany.app.llama.LlamaNative
import com.aicompany.app.local.CpuInfo
import com.aicompany.app.local.MemoryMonitor
import com.aicompany.app.local.ModelStore
import com.aicompany.app.local.RamGuard
import com.aicompany.app.terminal.RootfsInstaller
import com.aicompany.app.terminal.ShellLauncher
import com.aicompany.app.tools.WorkspaceProvider
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.File
import java.net.InetAddress
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Self-check: what this phone can do and what is missing. Used by Settings > System doctor and by the system_doctor tool.
 * The CPU feature line decides how fast local models can run (dotprod / i8mm kernels), so it is always shown.
 */
@Singleton
class DoctorService @Inject constructor(
    @ApplicationContext private val context: Context,
    private val memory: MemoryMonitor,
    private val models: ModelStore,
    private val engine: LlamaEngine,
    private val shell: ShellLauncher,
    private val installer: RootfsInstaller,
    private val providers: ProviderRepository,
    private val workspace: WorkspaceProvider,
) {
    suspend fun report(): String = withContext(Dispatchers.IO) {
        val mb = 1024L * 1024
        val total = memory.totalBytes()
        val avail = memory.availableBytes()
        val features = cpuFeatures()
        val flags = features.split(' ').filter { it.isNotEmpty() }.toSet()
        val dotprod = "asimddp" in flags
        val i8mm = "i8mm" in flags
        val network = runCatching { InetAddress.getByName("dl-cdn.alpinelinux.org"); true }.getOrDefault(false)
        val providerCount = runCatching { providers.observe().first().size }.getOrDefault(0)
        val resolv = File(installer.rootfsDir, "etc/resolv.conf").let { it.isFile && it.length() > 0 }

        buildString {
            appendLine("ReCode ${BuildConfig.VERSION_NAME}  |  Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL}  |  ABI: ${Build.SUPPORTED_ABIS.firstOrNull().orEmpty()}")
            appendLine()
            appendLine("RAM: ${total / mb} MB total, ${avail / mb} MB free" + if (memory.isLowMemory()) "  (LOW MEMORY now)" else "")
            appendLine("Storage free: ${context.filesDir.usableSpace / mb} MB")
            appendLine()
            appendLine("CPU cores: ${Runtime.getRuntime().availableProcessors()}  |  threads used for models: ${CpuInfo.performanceThreads()}")
            appendLine("dotprod: ${if (dotprod) "yes" else "no"}  |  i8mm: ${if (i8mm) "yes" else "no"}  |  fp16: ${if ("asimdhp" in flags || "fphp" in flags) "yes" else "no"}")
            appendLine("Features: ${features.ifEmpty { "(not readable)" }}")
            appendLine(
                when {
                    dotprod && i8mm -> "Tip: build with GGML_ARM_ARCH=armv8.2-a+dotprod+i8mm for much faster local models."
                    dotprod -> "Tip: build with GGML_ARM_ARCH=armv8.2-a+dotprod for much faster local models."
                    features.isEmpty() -> "Tip: could not read CPU features."
                    else -> "No dotprod: keep the default build. Prefer small models (1B or less, Q4_0)."
                }
            )
            appendLine()
            appendLine("Local engine: " + if (LlamaNative.available) "included" else "NOT included in this build")
            appendLine("Loaded model: ${engine.loadedModelName ?: "none"}" + if (engine.isLoaded) " (context ${engine.contextSize})" else "")
            val files = models.list()
            if (files.isEmpty()) {
                appendLine("Models on this phone: none")
            } else {
                appendLine("Models on this phone:")
                files.forEach { f ->
                    val verdict = RamGuard.assess(f.sizeBytes, avail, total)
                    appendLine("  - ${f.name}  ${f.sizeBytes / mb} MB  -> $verdict")
                }
            }
            appendLine()
            appendLine("Terminal: ${shell.notReadyReason() ?: "ready"}")
            appendLine("DNS file in Alpine: ${if (resolv) "ok" else "missing (created on next shell start)"}")
            appendLine("Internet (DNS lookup): ${if (network) "ok" else "FAILED"}")
            appendLine("Providers configured: $providerCount")
            appendLine("Workspace: ${workspace.sandbox.root.absolutePath}")
        }.trimEnd()
    }

    private fun cpuFeatures(): String = runCatching {
        File("/proc/cpuinfo").useLines { lines ->
            lines.firstOrNull { it.startsWith("Features") }?.substringAfter(':')?.trim().orEmpty()
        }
    }.getOrDefault("")
}
