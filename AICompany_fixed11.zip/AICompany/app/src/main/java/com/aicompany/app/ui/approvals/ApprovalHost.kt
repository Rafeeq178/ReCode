package com.aicompany.app.ui.approvals

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.aicompany.app.approvals.ApprovalDecision

/**
 * Global permission popup. Tools marked ASK (terminal, install, hire, messaging) wait here for the owner.
 * Without this host nobody answers the queue and every such tool times out after 5 minutes.
 */
@Composable
fun ApprovalHost(viewModel: ApprovalViewModel = hiltViewModel()) {
    val pending by viewModel.pending.collectAsState()
    val request = pending.firstOrNull() ?: return

    AlertDialog(
        onDismissRequest = { },
        title = { Text("Permission chahiye") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Agent ye tool chalana chahta hai: ${request.toolName}")
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = MaterialTheme.shapes.medium,
                ) {
                    Text(
                        request.summary,
                        modifier = Modifier.padding(12.dp),
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        maxLines = 10,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                if (pending.size > 1) {
                    Text(
                        "Line mein ${pending.size - 1} aur request hain.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        },
        confirmButton = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Button(
                    onClick = { viewModel.decide(request.id, ApprovalDecision.APPROVED) },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Allow (sirf ek baar)") }
                OutlinedButton(
                    onClick = { viewModel.decide(request.id, ApprovalDecision.ALLOW_ONE_HOUR) },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Allow 1 ghanta") }
                TextButton(
                    onClick = { viewModel.decide(request.id, ApprovalDecision.REJECTED) },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Reject", color = MaterialTheme.colorScheme.error) }
            }
        },
    )
}
