package com.aicompany.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Keeps agent and chat work alive while the app is in the background. Shows how much work is running.
 * [WorkTracker] starts it when work begins; it stops itself after a short grace period once nothing runs.
 */
@AndroidEntryPoint
class AgentForegroundService : Service() {

    @Inject lateinit var tracker: WorkTracker

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var watcher: Job? = null

    @Volatile private var latestStartId = 0

    override fun onCreate() {
        super.onCreate()
        ensureChannel()
        startForeground(NOTIFICATION_ID, buildNotification(0))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        latestStartId = startId
        // Every startForegroundService() call must be answered with startForeground(), including a
        // restart that reaches an instance that had already left the foreground state.
        startForeground(NOTIFICATION_ID, buildNotification(tracker.active.value))
        // One watcher only, however many times the service is started.
        if (watcher?.isActive != true) {
            watcher = scope.launch {
                tracker.active.collectLatest { count ->
                    getSystemService(NotificationManager::class.java)
                        ?.notify(NOTIFICATION_ID, buildNotification(count))
                    if (count == 0) {
                        delay(IDLE_GRACE_MS)   // cancelled by collectLatest when new work arrives
                        stopForeground(STOP_FOREGROUND_REMOVE)
                        // Only stops if no newer start request arrived in the meantime.
                        stopSelf(latestStartId)
                    }
                }
            }
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(CHANNEL_ID) == null) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Agent activity", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun buildNotification(running: Int): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_popup_sync)
            .setContentTitle("ReCode")
            .setContentText(if (running == 0) "No agents running" else "$running agent(s) working")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()

    companion object {
        private const val CHANNEL_ID = "agents"
        private const val NOTIFICATION_ID = 4101
        private const val IDLE_GRACE_MS = 5_000L

        fun start(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, AgentForegroundService::class.java))
        }
    }
}
