package com.aicompany.app.tools.builtin

import com.aicompany.app.tools.ApprovalLevel
import com.aicompany.app.tools.Schema
import com.aicompany.app.tools.Tool
import com.aicompany.app.tools.ToolContext
import com.aicompany.app.tools.ToolResult
import com.aicompany.app.tools.ToolSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.io.File
import javax.inject.Inject

private const val MAX_EDIT_CHARS = 20_000
private const val MAX_EDIT_FILE_BYTES = 512 * 1024L

private fun optString(args: JsonObject, key: String): String? =
    (args[key] as? JsonPrimitive)?.takeIf { it.isString }?.content

/** Temp file first, then rename, so a crash never leaves a half-written file. */
internal fun atomicWrite(target: File, content: String): Boolean {
    target.parentFile?.mkdirs()
    val tmp = File(target.parentFile, target.name + ".tmp")
    tmp.writeText(content, Charsets.UTF_8)
    if (tmp.renameTo(target)) return true
    target.delete()
    if (tmp.renameTo(target)) return true
    tmp.delete()
    return false
}

/**
 * Keeps the last few versions of every file an agent changes, inside the workspace (.recode/undo), so a bad edit
 * can be rolled back with undo_edit.
 */
object FileBackups {
    private const val DIR = ".recode/undo"
    private const val KEEP_PER_FILE = 10
    private const val MAX_BYTES = 2L * 1024 * 1024

    private fun prefix(root: File, target: File): String =
        target.relativeTo(root).path.replace(Regex("[^A-Za-z0-9._-]"), "_").take(120)

    private fun backups(root: File, target: File): List<File> {
        val pattern = Regex("^" + Regex.escape(prefix(root, target)) + "\\.\\d+\\.bak$")
        return File(root, DIR).listFiles { f -> f.isFile && pattern.matches(f.name) }
            .orEmpty()
            .sortedBy { it.name }
    }

    fun snapshot(root: File, target: File) {
        runCatching {
            if (!target.isFile || target.length() > MAX_BYTES) return
            val dir = File(root, DIR).apply { mkdirs() }
            target.copyTo(File(dir, "${prefix(root, target)}.${System.currentTimeMillis()}.bak"), overwrite = true)
            backups(root, target).dropLast(KEEP_PER_FILE).forEach { it.delete() }
        }
    }

    /** Puts the newest backup back and removes it, so calling it again goes one version further back. */
    fun restoreLatest(root: File, target: File): Boolean {
        val latest = backups(root, target).lastOrNull() ?: return false
        return runCatching {
            latest.copyTo(target, overwrite = true)
            latest.delete()
        }.isSuccess
    }

    fun count(root: File, target: File): Int = backups(root, target).size
}

class EditFileTool @Inject constructor() : Tool {
    override val spec = ToolSpec(
        name = "edit_file",
        description = "Replace text inside an existing workspace file. old_string must be copied exactly from the file " +
            "(a short unique snippet). Prefer this over rewriting the whole file.",
        schema = Schema.obj(
            mapOf(
                "path" to Schema.str("Relative file path", 512),
                "old_string" to Schema.str("Exact text to replace (short, unique)", MAX_EDIT_CHARS),
                "new_string" to Schema.str("Replacement text (empty string deletes old_string)", MAX_EDIT_CHARS),
                "replace_all" to buildJsonObject {
                    put("type", "boolean")
                    put("description", "true to replace every match")
                },
            ),
            listOf("path", "old_string", "new_string"),
        ),
        approval = ApprovalLevel.AUTO,
    )

    override suspend fun execute(args: JsonObject, ctx: ToolContext): ToolResult = withContext(Dispatchers.IO) {
        val path = optString(args, "path")
            ?: return@withContext ToolResult.Error("invalid_args", "path must be a string")
        val old = optString(args, "old_string")
            ?: return@withContext ToolResult.Error("invalid_args", "old_string must be a string")
        val new = optString(args, "new_string")
            ?: return@withContext ToolResult.Error("invalid_args", "new_string must be a string")
        val replaceAll = (args["replace_all"] as? JsonPrimitive)?.booleanOrNull ?: false
        if (old == new) return@withContext ToolResult.Error("no_change", "old_string and new_string are identical")

        val target = try {
            ctx.workspace.resolve(path)
        } catch (e: IllegalArgumentException) {
            return@withContext ToolResult.Error("invalid_path", e.message ?: "Invalid path")
        }
        if (!target.isFile) {
            return@withContext ToolResult.Error("not_found", "File does not exist. Use write_file to create it.")
        }
        if (target.length() > MAX_EDIT_FILE_BYTES) return@withContext ToolResult.Error("too_large", "File is larger than 512 KB")

        val text = target.readText(Charsets.UTF_8)
        when (val r = FuzzyEdit.replace(text, old, new, replaceAll)) {
            is FuzzyEdit.Result.Ok -> {
                FileBackups.snapshot(ctx.workspace.root, target)
                if (!atomicWrite(target, r.newText)) {
                    ToolResult.Error("write_failed", "Could not save the file")
                } else {
                    val note = if (r.level == FuzzyEdit.Level.EXACT) "" else " (whitespace-tolerant match)"
                    ToolResult.Ok("Edited ${target.relativeTo(ctx.workspace.root).path}: ${r.count} replacement(s)$note")
                }
            }
            is FuzzyEdit.Result.NotFound -> ToolResult.Error("no_match", r.detail)
            is FuzzyEdit.Result.Ambiguous -> ToolResult.Error(
                "ambiguous",
                "old_string matches ${r.count} places. Add more surrounding lines to make it unique, or set replace_all to true.",
            )
        }
    }
}

class UndoEditTool @Inject constructor() : Tool {
    override val spec = ToolSpec(
        name = "undo_edit",
        description = "Restore the previous version of a workspace file changed by edit_file or write_file.",
        schema = Schema.obj(mapOf("path" to Schema.str("Relative file path", 512)), listOf("path")),
        approval = ApprovalLevel.AUTO,
    )

    override suspend fun execute(args: JsonObject, ctx: ToolContext): ToolResult = withContext(Dispatchers.IO) {
        val path = optString(args, "path")
            ?: return@withContext ToolResult.Error("invalid_args", "path must be a string")
        val target = try {
            ctx.workspace.resolve(path)
        } catch (e: IllegalArgumentException) {
            return@withContext ToolResult.Error("invalid_path", e.message ?: "Invalid path")
        }
        if (FileBackups.restoreLatest(ctx.workspace.root, target)) {
            val left = FileBackups.count(ctx.workspace.root, target)
            ToolResult.Ok("Restored the previous version of ${target.relativeTo(ctx.workspace.root).path} ($left older version(s) left)")
        } else {
            ToolResult.Error("no_backup", "No earlier version of this file is stored")
        }
    }
}
