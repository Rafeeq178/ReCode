package com.aicompany.app.terminal

import android.content.Context
import com.aicompany.app.tools.WorkspaceProvider
import com.aicompany.app.tools.builtin.ShellPolicy
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Builds proot command lines that run inside the Alpine rootfs.
 * proot and its loader ship as native libs (jniLibs), so they can execute on Android 10+
 * with targetSdk 28 and useLegacyPackaging enabled.
 */
@Singleton
class ShellLauncher @Inject constructor(
    @ApplicationContext context: Context,
    private val installer: RootfsInstaller,
    private val workspace: WorkspaceProvider,
) {
    private val nativeDir = File(context.applicationInfo.nativeLibraryDir)
    private val prootBin = File(nativeDir, "libproot.so")
    private val loaderBin = File(nativeDir, "libproot-loader.so")
    private val prootTmp = File(context.filesDir, "proot-tmp").apply { mkdirs() }

    /** Null when the terminal can run, otherwise the reason it cannot. */
    fun notReadyReason(): String? = when {
        !prootBin.canExecute() -> "proot binary is missing from this APK"
        !loaderBin.canExecute() -> "proot loader is missing from this APK"
        !installer.isInstalled() -> "Alpine rootfs is not installed yet"
        else -> null
    }

    /**
     * Minimal proot options. Used after a normal start was killed with signal 9 (some phones kill
     * proot when it fakes root or touches /sys). Set automatically by the terminal screen.
     */
    @Volatile var safeMode: Boolean = false

    /**
     * Alpine's minirootfs ships without /etc/resolv.conf, so apk, pip and curl cannot resolve any name and
     * every install tool fails. Written before each shell start (only when missing).
     */
    fun prepareRootfs() {
        runCatching {
            val etc = File(installer.rootfsDir, "etc")
            val resolv = File(etc, "resolv.conf")
            if (!resolv.exists() || resolv.length() == 0L) {
                etc.mkdirs()
                resolv.writeText("nameserver 8.8.8.8\nnameserver 1.1.1.1\n")
            }
            File(installer.rootfsDir, "tmp").mkdirs()
        }
    }

    fun argv(shellArgs: List<String>): List<String> {
        prepareRootfs()
        val ws = workspace.sandbox.root.absolutePath
        return buildList {
            add(prootBin.absolutePath)
            add("--link2symlink")
            if (!safeMode) add("-0")
            add("-r"); add(installer.rootfsDir.absolutePath)
            add("-b"); add("/dev")
            add("-b"); add("/proc")
            if (!safeMode) { add("-b"); add("/sys") }
            add("-b"); add("$ws:/workspace")
            add("-w"); add("/workspace")
            addAll(shellArgs)
        }
    }

    /** Interactive login shell for the embedded terminal. */
    fun interactiveArgv(): List<String> = argv(listOf("/bin/sh", "-l"))

    /** Non-interactive shell for tools. The command runs inside the Alpine rootfs only. */
    fun commandArgv(command: String): List<String> {
        require(command.isNotBlank()) { "Command is empty" }
        require(command.length <= MAX_COMMAND_CHARS) { "Command is too long" }
        require(!command.contains('\u0000')) { "Invalid command" }
        ShellPolicy.denyReason(command)?.let { throw IllegalArgumentException(it) }
        return argv(listOf("/bin/sh", "-c", command))
    }

    /** Host folder used as the process working directory (must exist on the host). */
    fun hostCwd(): String = workspace.sandbox.root.absolutePath

    fun environment(): Map<String, String> = mapOf(
        "PROOT_TMP_DIR" to prootTmp.absolutePath,
        "PROOT_LOADER" to loaderBin.absolutePath,
        // Android's own seccomp filter makes proot's seccomp acceleration crash/kill the shell (exit -9)
        // on several phones. Plain ptrace mode is slightly slower but starts reliably.
        "PROOT_NO_SECCOMP" to "1",
        "HOME" to "/root",
        "PATH" to "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
        "TERM" to "xterm-256color",
        "LANG" to "C.UTF-8",
    )

    companion object {
        const val MAX_COMMAND_CHARS = 4000
    }
}
