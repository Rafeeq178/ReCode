package com.aicompany.app.tools.builtin

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FuzzyEditTest {

    @Test fun exactMatchReplacesOnce() {
        val r = FuzzyEdit.replace("a\nb\nc\n", "b", "X", false) as FuzzyEdit.Result.Ok
        assertEquals("a\nX\nc\n", r.newText)
        assertEquals(1, r.count)
        assertEquals(FuzzyEdit.Level.EXACT, r.level)
    }

    @Test fun indentationDriftIsTolerated() {
        val text = "fun a() {\n    val x = 1\n    val y = 2\n}\n"
        val r = FuzzyEdit.replace(text, "  val x = 1\n  val y = 2", "  val z = 3", false) as FuzzyEdit.Result.Ok
        assertEquals("fun a() {\n    val z = 3\n}\n", r.newText)
        assertEquals(FuzzyEdit.Level.INDENTATION, r.level)
    }

    @Test fun crlfFileKeepsItsLineEndings() {
        val r = FuzzyEdit.replace("a\r\nb\r\nc\r\n", "b\nc", "B\nC", false) as FuzzyEdit.Result.Ok
        assertEquals("a\r\nB\r\nC\r\n", r.newText)
        assertEquals(FuzzyEdit.Level.LINE_ENDINGS, r.level)
    }

    @Test fun ambiguousMatchIsRefusedUnlessReplaceAll() {
        val ambiguous = FuzzyEdit.replace("x\nx\n", "x", "y", false)
        assertTrue(ambiguous is FuzzyEdit.Result.Ambiguous)
        assertEquals(2, (ambiguous as FuzzyEdit.Result.Ambiguous).count)

        val all = FuzzyEdit.replace("x\nx\n", "x", "y", true) as FuzzyEdit.Result.Ok
        assertEquals("y\ny\n", all.newText)
        assertEquals(2, all.count)
    }

    @Test fun missingTextIsNotFound() {
        assertTrue(FuzzyEdit.replace("abc", "zzz", "q", false) is FuzzyEdit.Result.NotFound)
        assertTrue(FuzzyEdit.replace("abc", "", "q", false) is FuzzyEdit.Result.NotFound)
    }
}
