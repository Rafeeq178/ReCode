package com.aicompany.app.agents

import com.aicompany.app.provider.ChatMessage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ContextHygieneTest {

    @Test fun oldToolResultsAreCutButRecentOnesStayFull() {
        val h = mutableListOf(ChatMessage("system", "SYS"), ChatMessage("user", "GOAL"))
        repeat(6) {
            h += ChatMessage("assistant", "{\"tool\": \"read_file\"}")
            h += ChatMessage("user", "TOOL_RESULT read_file: " + "y".repeat(5_000))
        }
        val lastTool = h.last().content
        ContextHygiene.shrinkStaleToolResults(h)
        assertTrue(h[3].content.length < 2_000)
        assertTrue(h[3].content.contains("truncated"))
        assertEquals(lastTool, h.last().content)
        assertEquals("GOAL", h[1].content)
    }

    @Test fun shortToolResultsAreNeverTouched() {
        val h = mutableListOf(ChatMessage("system", "S"), ChatMessage("user", "G"))
        repeat(6) { h += ChatMessage("user", "TOOL_RESULT x: ok") }
        val before = h.toList()
        ContextHygiene.shrinkStaleToolResults(h)
        assertEquals(before, h)
    }
}
