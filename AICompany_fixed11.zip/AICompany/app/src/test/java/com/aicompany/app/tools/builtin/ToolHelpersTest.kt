package com.aicompany.app.tools.builtin

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ToolHelpersTest {

    @Test fun globMatchesNamesAndPaths() {
        val kt = globToRegex("*.kt")
        assertTrue(kt.matches("A.kt"))
        assertFalse(kt.matches("dir/A.kt"))
        val deep = globToRegex("src/**/*.js")
        assertTrue(deep.matches("src/a/b/c.js"))
        assertFalse(deep.matches("src/a/b/c.kt"))
    }

    @Test fun todoLinesAreParsed() {
        val items = TodoPlan.parse(listOf("completed: read the file", "in progress: fix the bug", "do more", "  "))
        assertEquals(3, items.size)
        assertEquals("completed", items[0].status)
        assertEquals("read the file", items[0].text)
        assertEquals("in_progress", items[1].status)
        assertEquals("pending", items[2].status)
        assertEquals("do more", items[2].text)
        assertEquals("- [completed] read the file\n- [in_progress] fix the bug\n- [pending] do more", TodoPlan.format(items))
    }

    @Test fun duckDuckGoResultsAreParsed() {
        val html = """
            <a rel="nofollow" class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.com%2Fpage&amp;rut=abc">Example <b>Title</b></a>
            <a class="result__snippet" href="x">A &amp; B snippet</a>
        """.trimIndent()
        val hits = DuckDuckGoParser.parse(html)
        assertEquals(1, hits.size)
        assertEquals("https://example.com/page", hits[0].url)
        assertEquals("Example Title", hits[0].title)
        assertEquals("A & B snippet", hits[0].snippet)
    }
}
