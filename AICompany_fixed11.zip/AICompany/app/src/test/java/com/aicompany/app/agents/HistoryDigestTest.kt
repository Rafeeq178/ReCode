package com.aicompany.app.agents

import com.aicompany.app.provider.ChatMessage
import org.junit.Assert.assertTrue
import org.junit.Test

class HistoryDigestTest {

    private fun toolCall(i: Int) =
        "{\"tool\": \"read_file\", \"arguments\": {\"path\": \"f$i.txt\"}}".padEnd(1_000, ' ')

    @Test fun markerListsToolsAndFilesThatWereDropped() {
        val h = mutableListOf(ChatMessage("system", "SYS"), ChatMessage("user", "GOAL"))
        repeat(20) { i -> h += ChatMessage("assistant", toolCall(i)) }
        HistoryCompressor.compact(h, 5_000)
        val marker = h[2].content
        assertTrue(marker.contains("removed to save memory"))
        assertTrue(marker.contains("read_file"))
        assertTrue(marker.contains("Files touched"))
    }

    @Test fun digestSurvivesASecondCompaction() {
        val h = mutableListOf(ChatMessage("system", "SYS"), ChatMessage("user", "GOAL"))
        repeat(20) { i -> h += ChatMessage("assistant", toolCall(i)) }
        HistoryCompressor.compact(h, 5_000)
        repeat(20) { i -> h += ChatMessage("assistant", toolCall(100 + i)) }
        HistoryCompressor.compact(h, 5_000)
        val marker = h[2].content
        assertTrue(marker.contains("removed to save memory"))
        assertTrue(marker.contains("read_file"))
    }
}
