package com.aicompany.app.tools.builtin

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MemoryNotesTest {

    @Test fun blankMemoryLoadsAsNull() {
        assertNull(MemoryNotes.load(null))
        assertNull(MemoryNotes.load("   \n"))
    }

    @Test fun longMemoryIsTruncatedInTheMiddle() {
        val loaded = MemoryNotes.load("a".repeat(10_000))!!
        assertTrue(loaded.length <= MemoryNotes.MAX_CHARS)
        assertTrue(loaded.contains("truncated"))
    }

    @Test fun appendAndReplace() {
        assertEquals("hello\n", MemoryNotes.write("", "hello", "append"))
        assertEquals("a\n\nb\n", MemoryNotes.write("a", "b", "append"))
        assertEquals("new\n", MemoryNotes.write("old stuff", "new", "replace"))
    }

    @Test fun overflowKeepsTheNewestTail() {
        val out = MemoryNotes.write("x".repeat(9_000), "y", "append")
        assertEquals(MemoryNotes.MAX_CHARS, out.length)
        assertTrue(out.endsWith("y\n"))
    }

    @Test fun topicNamesAreSanitizedAndWritesAreStrict() {
        assertEquals("my-topic", MemoryTopics.sanitize("My Topic!"))
        assertNull(MemoryTopics.sanitize("!!!"))
        assertNull(MemoryTopics.strictTopicPath("My Topic!"))
        assertNull(MemoryTopics.strictTopicPath("../../etc"))
        assertEquals(".recode/memory/my-topic.md", MemoryTopics.strictTopicPath("my-topic"))
    }
}
