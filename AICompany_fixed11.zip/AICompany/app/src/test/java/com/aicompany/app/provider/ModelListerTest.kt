package com.aicompany.app.provider

import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import org.junit.Assert.assertEquals
import org.junit.Test

class ModelListerTest {
    private val lister = ModelLister(OkHttpClient(), Json { ignoreUnknownKeys = true })

    @Test fun openAiListPutsFreeModelsFirst() {
        val body = """{"data":[{"id":"b-model"},{"id":"a:free"},{"id":"c"}]}"""
        assertEquals(listOf("a:free", "b-model", "c"), lister.parse(ApiFormat.OPENAI, body))
    }

    @Test fun geminiListKeepsOnlyChatModelsAndStripsPrefix() {
        val body = """{"models":[
            {"name":"models/gemini-x","supportedGenerationMethods":["generateContent"]},
            {"name":"models/embed","supportedGenerationMethods":["embedContent"]}]}"""
        assertEquals(listOf("gemini-x"), lister.parse(ApiFormat.GEMINI, body))
    }
}
