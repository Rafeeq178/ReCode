# ReCode v9 (from fixed10) - ideas ported from AndroidHarness + research

## New agent tools (all AUTO, workspace-sandboxed)
- `edit_file`: replace a short exact snippet instead of rewriting a file. Whitespace/indent/CRLF drift is tolerated
  (FuzzyEdit, ported from AndroidHarness), ambiguous matches are refused, writes are atomic.
- `undo_edit` + automatic backups: `edit_file` and `write_file` keep the last 10 versions per file in `.recode/undo`.
- `search_code` (grep-like) and `find_files` (glob) so agents locate code before changing it.
- `todo_write`: a short per-run plan saved in `.recode/todo/` (agents track progress, owner can read it).
- `memory_read` / `memory_write` / `memory_search`: long-term notes in `.recode/memory.md` (8 KB core, loaded into every
  run's prompt) and `.recode/memory/<topic>.md` (40 KB each, listed by name only). Secrets are redacted before saving.
- `web_search`: keyless DuckDuckGo search (title, url, snippet), then `web_fetch` for the page. Results marked untrusted.
- `system_doctor`: RAM, CPU features (dotprod/i8mm), local models vs RAM, terminal, DNS, internet.

## Safety
- `ShellPolicy`: even after Allow, `rm -rf /`, `curl | sh`, `mkfs`, `dd of=/dev/..`, fork bombs and `chmod 777 /` are refused.

## Context
- Old tool outputs are cut to head+tail (last 3 stay complete). The "messages removed" marker now lists tools already
  used and files touched, and keeps that digest across repeated compactions.
- Prompt habits (only for tools the agent really has): search before edit, edit_file not rewrite, plan with todo_write,
  check memory, web_search then web_fetch, run the code after changing it.

## UI
- Settings > System doctor shows the report (CPU features decide how fast local models can be).

## Build
- CMake: LLAMA_OPENSSL / LLAMA_BUILD_COMMON / GGML_LLAMAFILE off (needed by newer llama.cpp on Android).
- Optional CPU target: set `GGML_ARM_ARCH` in `.github/workflows/build.yml` (for example `armv8.2-a+dotprod`).
  Empty (default) keeps the portable build. A pinned arch makes prompt processing several times faster, but phones
  without dotprod (Cortex-A53/A73-only chips) would crash, so check System doctor first.

## Defaults
- New workers get: read/write/edit file, list_dir, search_code, find_files, calculator, get_time, web_search, web_fetch,
  todo_write, memory_read, memory_write. The chat assistant gets the same plus the terminal tools.

Not compiled here: build through CI (unit tests run there) and send the log if anything fails.
