package com.recode.app.ai

import android.content.Context
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import kotlinx.coroutines.flow.Flow

/**
 * Thin wrapper over llama.cpp's Android AI-chat library (com.arm.aichat).
 * If the upstream API changes, this is the only file that needs editing.
 *
 * ReCode always loads the model FRESH for every agent step: each agent gets its own system prompt and an
 * empty context, so it only knows what the orchestrator hands over (this is the isolation the app is built on).
 */
object Engine {
    private var engine: InferenceEngine? = null
    private var loaded = false

    private fun get(ctx: Context): InferenceEngine =
        engine ?: AiChat.getInferenceEngine(ctx.applicationContext).also { engine = it }

    /** Unloads whatever is loaded, loads [path] again and sets the agent's system prompt. */
    suspend fun load(ctx: Context, path: String, system: String) {
        val e = get(ctx)
        if (loaded) {
            try { e.cleanUp() } catch (_: Throwable) { }
            loaded = false
        }
        e.loadModel(path)
        e.setSystemPrompt(system)
        loaded = true
    }

    fun send(ctx: Context, prompt: String, maxTokens: Int): Flow<String> =
        get(ctx).sendUserPrompt(prompt, maxTokens)

    /** Forget the loaded model (e.g. the user deleted it). */
    fun unload() {
        try { engine?.cleanUp() } catch (_: Throwable) { }
        loaded = false
    }
}
