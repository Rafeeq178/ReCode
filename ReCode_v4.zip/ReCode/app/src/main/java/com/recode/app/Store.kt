package com.recode.app

import android.content.Context
import java.io.File

/** Tiny holder for the application context and the folder that keeps the GGUF models. */
object Store {
    lateinit var app: Context
        private set

    @Volatile
    var hfToken: String = ""

    fun init(c: Context) {
        app = c.applicationContext
    }

    val modelsDir: File
        get() = File(app.filesDir, "models").apply { mkdirs() }
}
