package com.recode.app

import android.app.Application
import java.io.File

class ReCodeApp : Application() {
    override fun onCreate() {
        // Save any crash to files/crash.txt; Settings -> Diagnostics shows it on the next launch.
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                File(filesDir, "crash.txt").writeText(
                    "Android ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT})\n" +
                        "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}\n" +
                        "abis=${android.os.Build.SUPPORTED_ABIS.joinToString()}\n" +
                        "thread=${t.name}\n\n" + android.util.Log.getStackTraceString(e)
                )
            } catch (_: Throwable) {
            }
            old?.uncaughtException(t, e)
        }
        super.onCreate()
        Store.init(this)
    }
}
