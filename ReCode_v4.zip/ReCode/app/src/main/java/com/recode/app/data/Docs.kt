package com.recode.app.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.zip.ZipInputStream

/** Reads files the user picked (text, code, .docx, PDF) so their text can go into a project or the knowledge base. */
object Docs {
    private const val MAX_BYTES = 3_000_000
    private const val MAX_CHARS = 400_000

    private val unsupported = setOf(
        "png", "jpg", "jpeg", "gif", "webp", "bmp", "heic", "mp3", "wav", "m4a", "mp4", "mkv", "avi",
        "zip", "rar", "7z", "apk", "gguf", "exe", "bin", "doc", "xls", "xlsx", "ppt", "pptx"
    )

    /** One entry per picked file: {name, text} or {name, error}. Call from a background thread. */
    fun readAll(ctx: Context, uris: List<Uri>): JSONArray {
        val out = JSONArray()
        for (u in uris) {
            val o = JSONObject()
            val name = displayName(ctx, u)
            o.put("name", name)
            try {
                o.put("text", read(ctx, u, name))
            } catch (e: Throwable) {
                o.put("error", e.message ?: "Could not read this file")
            }
            out.put(o)
        }
        return out
    }

    private fun displayName(ctx: Context, uri: Uri): String {
        var name = "file"
        try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) c.getString(i)?.let { name = it }
                }
            }
        } catch (_: Throwable) { }
        return name
    }

    private fun read(ctx: Context, uri: Uri, name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext in unsupported) {
            throw IllegalArgumentException(".$ext files cannot be read. Use text, code, .docx or PDF files.")
        }
        val ins = ctx.contentResolver.openInputStream(uri) ?: throw IllegalArgumentException("Could not open this file")
        val full: String = ins.use {
            when (ext) {
                "docx" -> readDocx(it)
                "pdf" -> PdfText.extract(ctx, it, 60)
                else -> {
                    val bytes = readCapped(it, MAX_BYTES)
                    val head = minOf(bytes.size, 4096)
                    for (k in 0 until head) {
                        if (bytes[k].toInt() == 0) throw IllegalArgumentException("This looks like a binary file, not text")
                    }
                    String(bytes, Charsets.UTF_8)
                }
            }
        }
        val text = full.trim()
        if (text.isEmpty()) throw IllegalArgumentException("This file is empty")
        return if (text.length > MAX_CHARS) text.substring(0, MAX_CHARS) else text
    }

    private fun readCapped(ins: InputStream, cap: Int): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(16 * 1024)
        var total = 0
        while (total < cap) {
            val n = ins.read(buf, 0, minOf(buf.size, cap - total))
            if (n < 0) break
            out.write(buf, 0, n)
            total += n
        }
        return out.toByteArray()
    }

    private fun readDocx(ins: InputStream): String {
        ZipInputStream(ins).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (e.name == "word/document.xml") {
                    val xml = String(readCapped(z, 8_000_000), Charsets.UTF_8)
                    return xml.replace("</w:p>", "\n").replace("<w:tab/>", "\t").replace("<w:br/>", "\n")
                        .replace(Regex("<[^>]+>"), "")
                        .replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
                        .replace("&apos;", "'").replace("&amp;", "&")
                }
                e = z.nextEntry
            }
        }
        throw IllegalArgumentException("Could not read this .docx file")
    }
}
