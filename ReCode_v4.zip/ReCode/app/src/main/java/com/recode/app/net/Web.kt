package com.recode.app.net

import org.json.JSONObject
import org.jsoup.Jsoup
import org.jsoup.parser.Parser
import java.io.IOException
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.Calendar
import java.util.TimeZone

/** Web search and page reading. All blocking: call from a background thread. */
object Web {
    class Hit(val title: String, val url: String, val snippet: String)
    
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    // ---------- reading a page ----------
    /** Title and the readable text of a page (menus, ads, scripts removed). */
    fun readable(url: String, maxChars: Int = 4000): Pair<String, String> {
        val r = Net.request("GET", url, mapOf("Accept" to "text/html,application/xhtml+xml,text/plain;q=0.8"))
        if (r.code >= 400) throw IOException("The site answered HTTP " + r.code)
        val doc = Jsoup.parse(r.body, r.url)
        doc.select("script,style,noscript,nav,footer,header,aside,form,iframe,svg,button,figure").remove()
        val root = doc.selectFirst("article") ?: doc.selectFirst("main") ?: doc.body()
        val sb = StringBuilder()
        if (root != null) {
            for (el in root.select("h1,h2,h3,p,li,pre,blockquote")) {
                val t = el.text().trim()
                if (t.length >= 30 || el.tagName().startsWith("h")) sb.append(t).append('\n')
                if (sb.length > maxChars * 2) break
            }
        }
        var text = sb.toString().trim()
        if (text.length < 200) text = (root?.text() ?: doc.text()).trim()
        if (text.isEmpty()) throw IOException("No readable text on this page")
        return doc.title().trim() to text.take(maxChars)
    }

    // ---------- web search ----------
    private fun unwrap(href: String): String {
        val h = if (href.startsWith("//")) "https:$href" else href
        val m = Regex("[?&]uddg=([^&]+)").find(h)
        return if (m != null) URLDecoder.decode(m.groupValues[1], "UTF-8") else h
    }

    fun search(query: String, count: Int = 5): List<Hit> {
        val hits = ArrayList<Hit>()
        try {
            val r = Net.request(
                "POST", "https://html.duckduckgo.com/html/",
                mapOf("Content-Type" to "application/x-www-form-urlencoded", "Referer" to "https://html.duckduckgo.com/"),
                "q=" + enc(query)
            )
            val doc = Jsoup.parse(r.body)
            for (res in doc.select("div.result")) {
                if (res.hasClass("result--ad")) continue
                val a = res.selectFirst("a.result__a") ?: continue
                val url = unwrap(a.attr("href"))
                if (!url.startsWith("http")) continue
                hits.add(Hit(a.text().trim(), url, res.selectFirst(".result__snippet")?.text()?.trim() ?: ""))
                if (hits.size >= count) break
            }
        } catch (e: Net.OfflineException) {
            throw e
        } catch (_: Exception) { }
        if (hits.isEmpty()) {
            try {
                val r = Net.request("GET", "https://lite.duckduckgo.com/lite/?q=" + enc(query))
                val doc = Jsoup.parse(r.body)
                val links = doc.select("a.result-link")
                val snips = doc.select("td.result-snippet")
                for ((i, a) in links.withIndex()) {
                    val url = unwrap(a.attr("href"))
                    if (!url.startsWith("http")) continue
                    hits.add(Hit(a.text().trim(), url, snips.getOrNull(i)?.text()?.trim() ?: ""))
                    if (hits.size >= count) break
                }
            } catch (e: Net.OfflineException) {
                throw e
            } catch (_: Exception) { }
        }
        if (hits.isEmpty()) {
            // last resort: Wikipedia search, so there is always something
            try {
                val r = Net.request("GET", "https://en.wikipedia.org/w/api.php?action=query&list=search&format=json&utf8=1&srlimit=$count&srsearch=" + enc(query))
                val arr = JSONObject(r.body).optJSONObject("query")?.optJSONArray("search")
                if (arr != null) for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val title = o.optString("title")
                    hits.add(Hit(title + " (Wikipedia)", "https://en.wikipedia.org/wiki/" + enc(title.replace(' ', '_')).replace("+", "%20"),
                        Jsoup.parse(o.optString("snippet")).text()))
                }
            } catch (e: Net.OfflineException) {
                throw e
            } catch (_: Exception) { }
        }
        if (hits.isEmpty()) throw IOException("The search engines did not answer. Try again in a moment.")
        return hits
    }

    fun format(hits: List<Hit>): String {
        val sb = StringBuilder()
        hits.forEachIndexed { i, h ->
            sb.append(i + 1).append(". ").append(h.title).append('\n').append("   ").append(h.url).append('\n')
            if (h.snippet.isNotBlank()) sb.append("   ").append(h.snippet).append('\n')
        }
        return sb.toString().trim()
    }
}
