/* ReCode - Files tab: project files, viewer/editor, import, download, ZIP. */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var U = RC.u, h = U.h, UI = RC.ui, St = RC.store, N = RC.native;
  var root = U.$('#v-files'), open = null, editing = false;
  var body = h('div.scroll');
  root.appendChild(body);

  function icon(p) { var e = U.ext(p); return e === 'html' ? 'globe' : e === 'css' ? 'eye' : e === 'js' ? 'bolt' : e === 'json' ? 'box' : 'file'; }
  function bar() {
    return h('div.toolbar', { style: { padding: '0 0 10px' } },
      UI.btn('New file', 'plus', 'sm soft', newFile),
      UI.btn('Import', 'upload', 'sm ghost', importFiles),
      UI.btn('ZIP', 'download', 'sm ghost', function () { UI.downloadZip(); }));
  }
  function newFile() {
    UI.prompt('New file name', '', 'e.g. about.html').then(function (n) {
      if (!n) return; n = U.normPath(n);
      if (!U.validPath(n)) return UI.toast('Use a valid name like app.js');
      if (St.files[n] !== undefined) return UI.toast('That file already exists');
      St.putFile(n, '').then(function () { show(n); editing = true; paint(); });
    });
  }
  function importFiles() {
    N.pickDocs().then(function (docs) {
      var ok = docs.filter(function (d) { return d.text; }), bad = docs.filter(function (d) { return d.error; });
      bad.forEach(function (d) { UI.toast(d.name + ': ' + d.error); });
      return Promise.all(ok.map(function (d) { var p = U.normPath(d.name); return U.validPath(p) ? St.putFile(p, d.text) : null; })).then(function () { if (ok.length) UI.toast(ok.length + ' file(s) imported'); });
    }, function (e) { UI.toast(e.message); });
  }
  function show(p) { open = p; editing = false; paint(); }

  function list() {
    var files = St.fileList();
    body.appendChild(bar());
    if (!files.length) { body.appendChild(h('div.empty', 'No files yet. Ask ReCode to build something, or tap New file / Import.')); return; }
    files.forEach(function (p) {
      body.appendChild(h('button.frow', { onclick: function () { show(p); } }, h('div.ico', { html: RC.i(icon(p), 19) }),
        h('div.grow', h('div.t1.ell', p), h('div.t2', U.bytes(St.files[p].length) + ' · ' + St.files[p].split('\n').length + ' lines')),
        h('span', { html: RC.i('chevR', 16), style: { color: 'var(--muted2)' } })));
    });
  }
  function viewer() {
    var p = open, c = St.files[p];
    if (c === undefined) { open = null; return list(); }
    body.appendChild(h('div.row', { style: { marginBottom: '10px' } }, UI.rbtn('chevL', function () { open = null; editing = false; paint(); }, 'Back', 'sm'),
      h('div.grow', h('div.t1.ell', p), h('div.t2', U.bytes(c.length)))));
    var acts = h('div.toolbar', { style: { padding: '0 0 10px' } });
    if (editing) {
      var ed = h('textarea.editor', { spellcheck: false, value: c, style: { minHeight: '55vh' } });
      acts.appendChild(UI.btn('Save', 'check', 'sm', function () { St.putFile(p, ed.value).then(function () { editing = false; UI.toast('Saved'); paint(); }); }));
      acts.appendChild(UI.btn('Cancel', null, 'sm ghost', function () { editing = false; paint(); }));
      body.appendChild(acts); body.appendChild(ed);
      ed.addEventListener('keydown', function (e) { if (e.key === 'Tab') { e.preventDefault(); var s = ed.selectionStart; ed.value = ed.value.slice(0, s) + '  ' + ed.value.slice(ed.selectionEnd); ed.selectionStart = ed.selectionEnd = s + 2; } });
      return;
    }
    acts.appendChild(UI.btn('Edit', 'edit', 'sm soft', function () { editing = true; paint(); }));
    if (/\.(html?|js|css|svg)$/i.test(p)) acts.appendChild(UI.btn('Run', 'play', 'sm', function () { UI.go('run'); }));
    acts.appendChild(UI.btn('Copy', 'copy', 'sm ghost', function () { N.copy(c).then(function () { UI.toast('Copied'); }, function () { }); }));
    acts.appendChild(UI.btn('Download', 'download', 'sm ghost', function () { N.save(U.base(p), c).then(function () { UI.toast('Saved'); }, function (e) { if (e.message !== 'cancelled') UI.toast(e.message); }); }));
    acts.appendChild(UI.btn('Rename', 'edit', 'sm ghost', function () {
      UI.prompt('Rename file', p).then(function (n) { if (n && n !== p) St.renameFile(p, n).then(function () { open = U.normPath(n); paint(); }, function (e) { UI.toast(e.message); }); });
    }));
    acts.appendChild(UI.btn('Delete', 'trash', 'sm danger', function () {
      UI.confirm('Delete ' + p + '?', 'Delete', true).then(function (y) { if (y) St.delFile(p).then(function () { open = null; paint(); }); });
    }));
    body.appendChild(acts);
    body.appendChild(h('pre.code', { html: U.hl(c, U.ext(p)) || '<span class="tk-c">(empty file)</span>' }));
  }
  function paint() {
    var keep = body.scrollTop;
    U.clear(body);
    if (open) viewer(); else list();
    body.scrollTop = keep;
  }
  RC.bus.on('files', function (p) { if (root.classList.contains('on') && !editing) paint(); });
  RC.bus.on('project', function () { open = null; editing = false; paint(); });
  UI.mods.files = {
    show: paint,
    open: function (p) { open = p; editing = false; if (UI.wide) { UI.wsTab = 'files'; UI.lastNav = 'files'; UI.paint(); } else UI.go('files'); paint(); },
    back: function () { if (open) { open = null; editing = false; paint(); return true; } return false; }
  };
})();
