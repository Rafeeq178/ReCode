/* ReCode - shared helpers: DOM, formatting, markdown, syntax colours, ZIP writer. No dependencies. */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var U = RC.u = {};

  U.$ = function (s, r) { return (r || document).querySelector(s); };
  U.$$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  /** h('div.card#id', {onclick: fn, style:{}}, child, 'text', [children]) */
  U.h = function (tag, attrs) {
    var m = /^([a-z0-9]+)?((?:[.#][\w-]+)*)$/i.exec(tag) || [];
    var el = document.createElement(m[1] || 'div');
    (m[2] || '').replace(/([.#])([\w-]+)/g, function (_, k, v) { if (k === '.') el.classList.add(v); else el.id = v; });
    var i = 2;
    if (attrs && (typeof attrs !== 'object' || attrs.nodeType || Array.isArray(attrs))) { i = 1; attrs = null; }
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        var v = attrs[k];
        if (v == null || v === false) return;
        if (k === 'class') el.className += (el.className ? ' ' : '') + v;
        else if (k === 'html') el.innerHTML = v;
        else if (k === 'text') el.textContent = v;
        else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
        else if (k.slice(0, 2) === 'on' && typeof v === 'function') el.addEventListener(k.slice(2), v);
        else if (k === 'value') el.value = v;
        else if (v === true) el.setAttribute(k, '');
        else el.setAttribute(k, v);
      });
    }
    for (; i < arguments.length; i++) U.add(el, arguments[i]);
    return el;
  };
  U.add = function (el, c) {
    if (c == null || c === false) return el;
    if (Array.isArray(c)) { c.forEach(function (x) { U.add(el, x); }); return el; }
    el.appendChild(c.nodeType ? c : document.createTextNode(String(c)));
    return el;
  };
  U.clear = function (el) { while (el.firstChild) el.removeChild(el.firstChild); return el; };
  U.esc = function (s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  };
  U.uid = function (p) { return (p || 'id') + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7); };
  U.sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
  U.debounce = function (fn, ms) {
    var t; return function () { var a = arguments, s = this; clearTimeout(t); t = setTimeout(function () { fn.apply(s, a); }, ms); };
  };
  U.raf = function (fn) {
    var q = false;
    return function () { if (q) return; q = true; requestAnimationFrame(function () { q = false; fn(); }); };
  };
  U.bytes = function (n) {
    if (n == null || isNaN(n)) return '';
    if (n < 1024) return n + ' B';
    if (n < 1048576) return (n / 1024).toFixed(n < 10240 ? 1 : 0) + ' KB';
    if (n < 1073741824) return (n / 1048576).toFixed(n < 104857600 ? 1 : 0) + ' MB';
    return (n / 1073741824).toFixed(2) + ' GB';
  };
  U.dur = function (ms) {
    var s = Math.max(0, Math.round(ms / 1000));
    if (s < 60) return s + 's';
    var m = Math.floor(s / 60); s = s % 60;
    if (m < 60) return m + 'm ' + (s < 10 ? '0' : '') + s + 's';
    return Math.floor(m / 60) + 'h ' + (m % 60) + 'm';
  };
  U.ago = function (t) {
    var d = Date.now() - t;
    if (d < 60000) return 'just now';
    if (d < 3600000) return Math.floor(d / 60000) + ' min ago';
    if (d < 86400000) return Math.floor(d / 3600000) + ' h ago';
    return new Date(t).toLocaleDateString();
  };
  /** rough token estimate: code and mixed text are about 3.3 characters per token */
  U.tok = function (s) { return Math.ceil(String(s || '').length / 3.3); };
  U.clip = function (s, n, tail) {
    s = String(s == null ? '' : s);
    if (s.length <= n) return s;
    return s.slice(0, Math.max(0, n)) + (tail === undefined ? '\n...[cut]' : tail);
  };
  U.clipMid = function (s, n) {
    s = String(s || '');
    if (s.length <= n) return s;
    var a = Math.floor(n * 0.6), b = n - a;
    return s.slice(0, a) + '\n...[middle cut]...\n' + s.slice(s.length - b);
  };
  U.ext = function (p) { var m = /\.([a-z0-9]+)$/i.exec(p || ''); return m ? m[1].toLowerCase() : ''; };
  U.base = function (p) { return String(p || '').split('/').pop(); };
  U.slug = function (s) {
    return String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40) || 'project';
  };
  U.normPath = function (p) {
    p = String(p || '').trim().replace(/\\/g, '/').replace(/^\.?\/+/, '').replace(/\/{2,}/g, '/');
    var parts = [];
    p.split('/').forEach(function (x) { if (x === '..') parts.pop(); else if (x && x !== '.') parts.push(x); });
    return parts.join('/');
  };
  U.validPath = function (p) { return /^[\w][\w .\-\/]{0,80}\.[A-Za-z0-9]{1,8}$/.test(p) && p.indexOf('..') < 0; };
  U.mime = function (p) {
    return ({
      html: 'text/html', htm: 'text/html', css: 'text/css', js: 'text/javascript', json: 'application/json',
      svg: 'image/svg+xml', txt: 'text/plain', md: 'text/markdown', csv: 'text/csv', xml: 'application/xml',
      zip: 'application/zip', py: 'text/x-python'
    })[U.ext(p)] || 'text/plain';
  };

  // ------------------------------------------------------------------ base64 / bytes
  U.toB64 = function (u8) {
    var s = '', CH = 0x8000;
    for (var i = 0; i < u8.length; i += CH) s += String.fromCharCode.apply(null, u8.subarray(i, i + CH));
    return btoa(s);
  };
  U.utf8 = function (s) { return new TextEncoder().encode(s); };

  // ------------------------------------------------------------------ ZIP (stored, UTF-8 names)
  var crcT = null;
  function crc32(u8) {
    if (!crcT) {
      crcT = new Uint32Array(256);
      for (var n = 0; n < 256; n++) { var c = n; for (var k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1); crcT[n] = c >>> 0; }
    }
    var crc = 0xFFFFFFFF;
    for (var i = 0; i < u8.length; i++) crc = crcT[(crc ^ u8[i]) & 0xFF] ^ (crc >>> 8);
    return (crc ^ 0xFFFFFFFF) >>> 0;
  }
  U.crc32 = crc32;
  /** files: [{name, data: string | Uint8Array}] -> Uint8Array of a valid .zip */
  U.zip = function (files) {
    var now = new Date();
    var dt = ((now.getHours() << 11) | (now.getMinutes() << 5) | (now.getSeconds() >> 1)) & 0xFFFF;
    var dd = (((now.getFullYear() - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate()) & 0xFFFF;
    var parts = [], central = [], offset = 0;
    function u16(v) { return [v & 255, (v >> 8) & 255]; }
    function u32(v) { return [v & 255, (v >>> 8) & 255, (v >>> 16) & 255, (v >>> 24) & 255]; }
    files.forEach(function (f) {
      var name = U.utf8(f.name), data = typeof f.data === 'string' ? U.utf8(f.data) : f.data;
      var crc = crc32(data);
      var lh = [].concat(u32(0x04034b50), u16(20), u16(0x0800), u16(0), u16(dt), u16(dd), u32(crc), u32(data.length), u32(data.length), u16(name.length), u16(0));
      parts.push(new Uint8Array(lh), name, data);
      var ch = [].concat(u32(0x02014b50), u16(20), u16(20), u16(0x0800), u16(0), u16(dt), u16(dd), u32(crc), u32(data.length), u32(data.length),
        u16(name.length), u16(0), u16(0), u16(0), u16(0), u32(0), u32(offset));
      central.push(new Uint8Array(ch), name);
      offset += lh.length + name.length + data.length;
    });
    var cdSize = 0; central.forEach(function (c) { cdSize += c.length; });
    var end = new Uint8Array([].concat(u32(0x06054b50), u16(0), u16(0), u16(files.length), u16(files.length), u32(cdSize), u32(offset), u16(0)));
    var all = parts.concat(central, [end]), total = 0;
    all.forEach(function (p) { total += p.length; });
    var out = new Uint8Array(total), pos = 0;
    all.forEach(function (p) { out.set(p, pos); pos += p.length; });
    return out;
  };

  // ------------------------------------------------------------------ syntax colours (for code views)
  var KW_JS = 'async|await|break|case|catch|class|const|continue|default|delete|do|else|export|extends|finally|for|from|function|if|import|in|instanceof|let|new|of|return|static|super|switch|this|throw|try|typeof|var|void|while|yield';
  var KW_GEN = KW_JS + '|def|elif|lambda|pass|with|as|is|not|and|or|None|True|False|print|fun|val|object|when|package|public|private|protected|interface|enum|struct|impl|fn|mut|use|mod|int|float|double|char|string|bool|boolean|void|String|Int|Boolean|echo|foreach';
  var STR = '"(?:\\\\.|[^"\\\\\\n])*"|\'(?:\\\\.|[^\'\\\\\\n])*\'|`(?:\\\\.|[^`\\\\])*`';
  var LANGS = {
    js: [['c', '\\/\\/[^\\n]*|\\/\\*[\\s\\S]*?\\*\\/'], ['s', STR], ['n', '\\b\\d+(?:\\.\\d+)?\\b'], ['l', '\\b(?:true|false|null|undefined|NaN)\\b'], ['k', '\\b(?:' + KW_JS + ')\\b']],
    gen: [['c', '\\/\\/[^\\n]*|#[^\\n]*|\\/\\*[\\s\\S]*?\\*\\/'], ['s', STR], ['n', '\\b\\d+(?:\\.\\d+)?\\b'], ['l', '\\b(?:true|false|null|nil)\\b'], ['k', '\\b(?:' + KW_GEN + ')\\b']],
    css: [['c', '\\/\\*[\\s\\S]*?\\*\\/'], ['s', STR], ['k', '@[\\w-]+'], ['a', '[\\w-]+(?=\\s*:(?!:))'], ['n', '#[0-9a-fA-F]{3,8}\\b|-?\\b\\d+(?:\\.\\d+)?(?:px|em|rem|%|vh|vw|s|ms|deg|fr)?\\b']],
    html: [['c', '<!--[\\s\\S]*?-->'], ['t', '<\\/?[a-zA-Z][\\w-]*|\\/?>|<!DOCTYPE[^>]*>'], ['a', '[\\w:-]+(?==)'], ['s', STR]],
    json: [['a', '"(?:\\\\.|[^"\\\\\\n])*"(?=\\s*:)'], ['s', '"(?:\\\\.|[^"\\\\\\n])*"'], ['n', '-?\\b\\d+(?:\\.\\d+)?(?:[eE][+-]?\\d+)?\\b'], ['l', '\\b(?:true|false|null)\\b']],
    md: [['k', '^#{1,6} [^\\n]*'], ['s', '`[^`\\n]+`'], ['l', '\\*\\*[^*\\n]+\\*\\*']]
  };
  var cache = {};
  function langKey(lang) {
    lang = String(lang || '').toLowerCase();
    if (/^(js|javascript|mjs|ts|typescript|jsx|tsx)$/.test(lang)) return 'js';
    if (lang === 'css' || lang === 'scss') return 'css';
    if (/^(html|htm|xml|svg|xhtml)$/.test(lang)) return 'html';
    if (lang === 'json') return 'json';
    if (/^(md|markdown)$/.test(lang)) return 'md';
    if (/^(txt|text|csv|)$/.test(lang)) return 'none';
    return 'gen';
  }
  /** Returns safe HTML with <span class="tk-x"> colour spans. */
  U.hl = function (code, lang) {
    var key = langKey(lang);
    code = String(code == null ? '' : code);
    if (key === 'none' || code.length > 60000) return U.esc(code);
    var c = cache[key];
    if (!c) {
      var defs = LANGS[key];
      c = cache[key] = { cls: defs.map(function (d) { return d[0]; }), re: defs.map(function (d) { return '(' + d[1] + ')'; }).join('|') };
    }
    var re = new RegExp(c.re, 'gm'), out = '', last = 0, m;
    while ((m = re.exec(code))) {
      if (m[0] === '') { re.lastIndex++; continue; }
      var gi = 1; while (gi < m.length && m[gi] === undefined) gi++;
      out += U.esc(code.slice(last, m.index)) + '<span class="tk-' + c.cls[gi - 1] + '">' + U.esc(m[0]) + '</span>';
      last = m.index + m[0].length;
    }
    return out + U.esc(code.slice(last));
  };

  // ------------------------------------------------------------------ markdown (small, safe, streaming friendly)
  function inline(s) {
    s = U.esc(s);
    s = s.replace(/`([^`\n]+)`/g, '<code>$1</code>');
    s = s.replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>');
    s = s.replace(/(^|[^*\w])\*([^*\n]+)\*(?!\w)/g, '$1<em>$2</em>');
    s = s.replace(/\[([^\]\n]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="#" data-href="$2">$1</a>');
    s = s.replace(/(^|[\s(])(https?:\/\/[^\s<)]+)/g, '$1<a href="#" data-href="$2">$2</a>');
    return s;
  }
  /** Splits markdown into [{type:'text', text}, {type:'code', lang, code, open}] so code blocks can become widgets. */
  U.mdSplit = function (src) {
    var out = [], re = /```([\w+#.-]*)[^\n]*\n([\s\S]*?)(```|$)/g, last = 0, m;
    src = String(src || '');
    while ((m = re.exec(src))) {
      if (m.index > last) out.push({ type: 'text', text: src.slice(last, m.index) });
      out.push({ type: 'code', lang: m[1] || '', code: m[2].replace(/\n$/, ''), open: m[3] !== '```' });
      last = m.index + m[0].length;
      if (m[3] !== '```') break;
    }
    if (last < src.length) out.push({ type: 'text', text: src.slice(last) });
    return out;
  };
  U.md = function (src) {
    var lines = String(src || '').replace(/\r/g, '').split('\n'), html = '', i = 0, para = [];
    function flush() { if (para.length) { html += '<p>' + inline(para.join(' ')) + '</p>'; para = []; } }
    while (i < lines.length) {
      var ln = lines[i], m;
      if (!ln.trim()) { flush(); i++; continue; }
      if ((m = /^(#{1,4})\s+(.*)$/.exec(ln))) { flush(); html += '<h' + (m[1].length + 1) + '>' + inline(m[2]) + '</h' + (m[1].length + 1) + '>'; i++; continue; }
      if (/^\s*([-*_])\1{2,}\s*$/.test(ln)) { flush(); html += '<hr>'; i++; continue; }
      if (/^\s*[-*+]\s+/.test(ln)) {
        flush(); html += '<ul>';
        while (i < lines.length && (m = /^\s*[-*+]\s+(.*)$/.exec(lines[i]))) { html += '<li>' + inline(m[1]) + '</li>'; i++; }
        html += '</ul>'; continue;
      }
      if (/^\s*\d+[.)]\s+/.test(ln)) {
        flush(); html += '<ol>';
        while (i < lines.length && (m = /^\s*\d+[.)]\s+(.*)$/.exec(lines[i]))) { html += '<li>' + inline(m[1]) + '</li>'; i++; }
        html += '</ol>'; continue;
      }
      if (/^>\s?/.test(ln)) {
        flush(); var q = [];
        while (i < lines.length && /^>\s?/.test(lines[i])) { q.push(lines[i].replace(/^>\s?/, '')); i++; }
        html += '<blockquote>' + inline(q.join(' ')) + '</blockquote>'; continue;
      }
      if (/^\|.*\|\s*$/.test(ln) && i + 1 < lines.length && /^\|?\s*:?-{2,}/.test(lines[i + 1])) {
        flush();
        var head = ln.replace(/^\||\|\s*$/g, '').split('|'); i += 2;
        html += '<div class="tbl"><table><thead><tr>' + head.map(function (c) { return '<th>' + inline(c.trim()) + '</th>'; }).join('') + '</tr></thead><tbody>';
        while (i < lines.length && /^\|.*\|\s*$/.test(lines[i])) {
          html += '<tr>' + lines[i].replace(/^\||\|\s*$/g, '').split('|').map(function (c) { return '<td>' + inline(c.trim()) + '</td>'; }).join('') + '</tr>'; i++;
        }
        html += '</tbody></table></div>'; continue;
      }
      para.push(ln.trim()); i++;
    }
    flush();
    return html;
  };
})();
