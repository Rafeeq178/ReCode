/* ReCode - Settings: everything is user controlled (appearance, generation, agents, preview, data, diagnostics). */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var U = RC.u, h = U.h, UI = RC.ui, St = RC.store, N = RC.native;
  var root = U.$('#v-set'), body = h('div.scroll'), page = null;
  root.appendChild(body);

  function agents() {
    if(RC.agentRuntime)RC.agentRuntime.agents.list();
    var box = h('div');
    box.appendChild(h('div.t2', { style: { marginBottom: '8px' } }, 'Configure independent specialist instructions and enable or disable agents used by the autonomous runtime.'));
    var newId=h('input.in',{placeholder:'custom-agent-id'}),newMarkdown=h('textarea.in',{placeholder:'---\nname: Custom Agent\ndescription: Specialist role\ntools: read_file, search_text\n---\n\nInstructions...',style:{minHeight:'120px'}});
    box.appendChild(h('div.t1','Create custom agent'));box.appendChild(newId);box.appendChild(newMarkdown);box.appendChild(UI.btn('Add agent','plus','sm',function(){var md=newMarkdown.value;if(!/^---/.test(md))md='---\nname: '+newId.value+'\ndescription: Custom specialist\ntools: read_file, search_text\n---\n\n'+md;RC.agentRuntime.agents.add(newId.value,md).then(function(){UI.toast('Agent added');sub('agents');}).catch(function(e){UI.toast(e.message);});}));
    box.appendChild(h('div.row',UI.btn('Export agents','download','sm ghost',function(){var all={};RC.agentRuntime.agents.list().forEach(function(a){all[a.id]=RC.agentRuntime.exportAgent(a.id)||('---\nname: '+a.name+'\ndescription: '+a.description+'\n---\n\n'+a.instructions);});N.save('recode-agents.json',JSON.stringify(all,null,2),'application/json');}),UI.btn('Import agents','upload','sm ghost',function(){N.pickDocs().then(function(ds){var f=ds.find(function(x){return x.text;});if(f)RC.agentRuntime.agents.import(f.text).then(function(){UI.toast('Agents imported');sub('agents');}).catch(function(e){UI.toast(e.message);});});})));
    RC.agents.order.forEach(function (id) {
      var d = RC.agents.def[id], cfg = RC.settings.agents[id] = RC.settings.agents[id] || {}, cur = RC.agentCfg(id);
      var ta = h('textarea.in', { value: cur.prompt, style: { minHeight: '140px' }, onchange: function () { cfg.prompt = ta.value === d.system ? '' : ta.value; RC.saveSettings(); } });
      ta.value = cur.prompt;
      var profile=RC.agentRuntime.agents.list().filter(function(x){return x.id===id;})[0],toolTA=h('input.in',{value:profile?profile.tools:'*',placeholder:'read_file, search_text'});
      var b = h('b', String(cur.max));
      var rg = h('input', { type: 'range', min: 100, max: 3000, step: 50, value: cur.max, oninput: function () { b.textContent = rg.value; cfg.max = +rg.value; }, onchange: function () { RC.saveSettings(); } });
      var tog = h('div.tog' + (cur.on ? '.on' : ''));
      var det = h('details.d', { style: { background: 'var(--card)', border: '1px solid var(--line)' } },
        h('summary', h('span', { html: RC.i(d.icon, 16), style: { color: 'var(--brand)', marginRight: '8px', verticalAlign: 'middle' } }), d.name, h('span.t2', ' - ' + d.desc)),
        d.locked ? null : h('button.setrow', { style: { width: '100%', textAlign: 'left' }, onclick: function () { cfg.on = !RC.agentCfg(id).on; RC.agentRuntime.agents.enable(id,cfg.on); tog.classList.toggle('on', cfg.on); RC.saveSettings(); } }, h('div.grow', h('div.t1', 'Enabled')), tog),
        h('div.setrow', h('div.grow', h('div.t1', 'Max answer tokens')), h('div.slider', rg, b)),
        UI.field('Role (system prompt)', ta),
        UI.field('Allowed tools (comma-separated or *)',toolTA),
        UI.btn('Save agent tool access','shield','sm',function(){var md='---\nname: '+d.name+'\ndescription: '+d.desc+'\ntools: '+toolTA.value+'\n---\n\n'+ta.value;RC.agentRuntime.agents.edit(id,md).then(function(){UI.toast('Agent tools saved');}).catch(function(e){UI.toast(e.message);});}),
        UI.btn('Reset to default', 'refresh', 'sm ghost', function () { delete RC.settings.agents[id]; RC.saveSettings(); sub('agents'); }),
        d.custom ? UI.btn('Delete custom agent','trash','sm danger',function(){try{RC.agentRuntime.agents.remove(id);sub('agents');}catch(e){UI.toast(e.message);}}) : null);
      box.appendChild(det);
    });
    return box;
  }
  function sub(name) {
    page = name;
    UI.sheetStack.length && UI.closeSheet(true);
    var titles = { agents: 'Agents' };
    UI.sheet({ title: titles[name], body: agents(), onClose: function () { page = null; } });
  }

  function permissionSettings(){
    var box=h('div'),rt=RC.agentRuntime,tools=Object.keys(rt.registry),pid=St.cur&&St.cur.id;
    box.appendChild(h('div.t2','DENY always takes priority over ASK and ALLOW. Terminal commands remain disabled in this Android build. Global and active-project rules are evaluated together.'));
    var prefix=h('input.in',{placeholder:'Optional file/folder prefix, e.g. src/'});box.appendChild(h('div.sec','File-specific rule'));box.appendChild(prefix);
    tools.forEach(function(name){var current=rt.permissions.global[name]||'ASK',project=(pid&&rt.permissions.projects[pid]&&rt.permissions.projects[pid][name])||'INHERIT';var globalSel=h('select.in',{style:{width:'100%',marginTop:'6px'},onchange:function(){rt.setPermission(name,globalSel.value);}});['ALLOW','ASK','DENY'].forEach(function(v){globalSel.appendChild(h('option',{value:v,selected:v===current},v));});var projectSel=h('select.in',{style:{width:'100%',marginTop:'6px'},onchange:function(){if(pid){if(projectSel.value==='INHERIT')rt.clearProjectPermission(name,pid);else rt.setPermission(name,projectSel.value,pid);}}});['INHERIT','ALLOW','ASK','DENY'].forEach(function(v){projectSel.appendChild(h('option',{value:v,selected:v===project},v));});var row=h('div.setrow',h('div.grow',h('div.t1',name),h('div.t2',rt.registry[name].description)),h('div',h('div.t2','Global'),globalSel),pid?h('div',h('div.t2','This project'),projectSel):null);row.appendChild(UI.btn('Apply file rule','shield','sm ghost',function(){if(!prefix.value.trim())return UI.toast('Enter a file/folder prefix');rt.setPermission(name,globalSel.value,pid,prefix.value.trim());UI.toast('File rule saved');}));box.appendChild(row);});
    box.appendChild(h('div.sec','Recent permission history'));rt.permissionHistory().slice(-20).reverse().forEach(function(x){box.appendChild(h('div.t2',new Date(x.t).toLocaleString()+' · '+x.tool+' · '+x.decision+' · '+x.target));});
    UI.sheet({title:'Tool permissions',body:box});
  }
  function monitor(){var rt=RC.agentRuntime,box=h('div'),tasks=rt.tasks.get(),cps=rt.checkpoints.list();
    box.appendChild(h('div.setrow',h('div.grow',h('div.t1','Execution mode'),h('div.t2',rt.mode()))));
    var active=RC.pipe&&RC.pipe.current;if(active){var last=active.steps[active.steps.length-1];box.appendChild(h('div.setrow',h('div.grow',h('div.t1','Active run'),h('div.t2',(last&&last.title||'Starting')+' · '+(last&&last.agent||'main')+' · '+(last&&last.phase||active.status))),UI.btn('Cancel','stop','sm danger',function(){RC.pipe.stop();})));}
    box.appendChild(h('div.setrow',h('div.grow',h('div.t1','Context budget'),h('div.t2',rt.context.budget()+' characters (approximate; tokenizer unavailable)'))));
    box.appendChild(h('div.setrow',h('div.grow',h('div.t1','Project files'),h('div.t2',String(St.fileList().length)))));
    box.appendChild(h('div.setrow',h('div.grow',h('div.t1','Tasks'),h('div.t2',tasks.filter(function(x){return x.status==='COMPLETED';}).length+' / '+tasks.length+' completed'))));
    box.appendChild(h('div.setrow',h('div.grow',h('div.t1','Checkpoints'),h('div.t2',String(cps.length)))));
    var taskInput=h('input.in',{placeholder:'Add project task'});box.appendChild(taskInput);box.appendChild(UI.btn('Add task','plus','sm',function(){if(taskInput.value.trim()){rt.tasks.add(taskInput.value.trim());UI.toast('Task added');UI.closeSheet(true);monitor();}}));
    tasks.forEach(function(t){var sel=h('select.in',{style:{width:'130px'},onchange:function(){rt.tasks.update(t.id,sel.value);UI.toast('Task updated');}});['PENDING','IN_PROGRESS','COMPLETED','BLOCKED','FAILED'].forEach(function(v){sel.appendChild(h('option',{value:v,selected:v===t.status},v.replace('_',' ')));});box.appendChild(h('div.setrow',h('div.grow',h('div.t1',t.title),h('div.t2',t.parent?'Subtask':'Project task')),sel));});
    cps.slice().reverse().slice(0,8).forEach(function(cp){box.appendChild(h('div.setrow',h('div.grow',h('div.t1',cp.label),h('div.t2',new Date(cp.time).toLocaleString())),UI.btn('Restore','refresh','sm ghost',function(){rt.checkpoints.restore(cp.id).then(function(){UI.toast('Checkpoint restored');UI.closeSheet(true);}).catch(function(e){UI.toast(e.message);});})))});
    UI.sheet({title:'Execution monitor',body:box});
  }
  function skillSettings(){var rt=RC.agentRuntime,box=h('div'),list=h('div');
    function refresh(){U.clear(list);rt.skills.list().forEach(function(sk){var raw=rt.exportSkill(sk.name)||('# '+sk.name+'\n\n'+sk.description),ta=h('textarea.in',{style:{minHeight:'90px'},value:raw});ta.value=raw;list.appendChild(h('details.d',h('summary',sk.name+' · '+(sk.enabled?'Enabled':'Disabled')),ta,h('div.row',UI.btn('Save','check','sm',function(){rt.skills.import(sk.name,ta.value).then(function(){UI.toast('Skill saved');refresh();});}),UI.btn(sk.enabled?'Disable':'Enable','toggle','sm ghost',function(){rt.skills.enable(sk.name,!sk.enabled);refresh();}),UI.btn('Export','copy','sm ghost',function(){N.copy(raw);UI.toast('SKILL.md copied');}),UI.btn('Delete','trash','sm danger',function(){UI.confirm('Delete skill '+sk.name+'?','Delete',true).then(function(y){if(y)rt.skills.remove(sk.name).then(refresh);});}))));});}
    var name=h('input.in',{placeholder:'new-skill-name'}),content=h('textarea.in',{placeholder:'Write complete SKILL.md instructions',style:{minHeight:'120px'}});
    box.appendChild(h('div.t1','Add a custom skill'));box.appendChild(name);box.appendChild(content);box.appendChild(UI.btn('Add skill','plus','sm',function(){if(!name.value.trim()||!content.value.trim())return UI.toast('Enter a name and instructions');rt.skills.add(name.value.trim(),content.value).then(function(){name.value='';content.value='';refresh();UI.toast('Skill added');});}));
    box.appendChild(h('div.row',UI.btn('Export skills','download','sm ghost',function(){N.save('recode-skills.json',JSON.stringify(rt.skills.list().reduce(function(o,x){o[x.name]=rt.exportSkill(x.name)||x.content;return o;},{}),null,2),'application/json');}),UI.btn('Import skills','upload','sm ghost',function(){N.pickDocs().then(function(ds){var f=ds.find(function(x){return x.text;});if(f){try{var data=JSON.parse(f.text);Promise.all(Object.keys(data).map(function(k){return rt.skills.import(k,data[k]);})).then(function(){refresh();UI.toast('Skills imported');});}catch(e){UI.toast('Invalid skills JSON: '+e.message);}}});})));
    box.appendChild(list);refresh();UI.sheet({title:'Skills manager',body:box});
  }
  function diag() {
    var i = N.info() || {}, box = h('div');
    [['App', 'ReCode ' + (i.version || '')], ['Android', i.android], ['Device', i.device], ['CPU', i.abis], ['RAM', i.ramMB ? i.ramMB + ' MB' : ''], ['Free storage', i.freeMB ? i.freeMB + ' MB' : '']].forEach(function (r) {
      if (r[1]) box.appendChild(h('div.setrow', h('div.grow', h('div.t1', r[0])), h('div.t2', r[1])));
    });
    if (i.crash) {
      box.appendChild(h('div.sec', 'Last crash'));
      box.appendChild(h('pre.code', { style: { maxHeight: '240px', overflow: 'auto', whiteSpace: 'pre-wrap' } }, i.crash));
      box.appendChild(h('div.row', { style: { marginTop: '10px' } }, UI.btn('Copy', 'copy', 'sm', function () { N.copy(i.crash); UI.toast('Copied'); }), UI.btn('Clear', 'trash', 'sm danger', function () { N.call('clearCrash'); UI.closeSheet(true); paint(); })));
    } else box.appendChild(h('div.t2', { style: { marginTop: '10px' } }, 'No crash recorded.'));
    UI.sheet({ title: 'Diagnostics', body: box });
  }

  function advancedTools() {
    var A = RC.advanced, box = h('div'), out = h('pre.code', { style: { whiteSpace: 'pre-wrap', maxHeight: '42vh', overflow: 'auto' } }, 'Choose an analysis tool.');
    function show(title, value) { out.textContent = title + "\n\n" + JSON.stringify(value, null, 2); }
    box.appendChild(h('div.t2', 'Run local, read-only project analysis. These checks are heuristic and do not replace real builds or security testing.'));
    box.appendChild(h('div.row', UI.btn('Dependencies', 'git', 'sm', function () { show('Dependency graph', A.graph()); }), UI.btn('Security audit', 'shield', 'sm', function () { show('Security audit', A.securityAudit()); }), UI.btn('Code quality', 'check', 'sm', function () { show('Quality audit', A.qualityAudit()); }), UI.btn('Responsive audit', 'smartphone', 'sm', function () { out.textContent='Running isolated viewport probes…'; A.responsiveCheck().then(function(r){show('Responsive audit',r);}).catch(function(e){show('Responsive audit error',e.message);}); })));
    box.appendChild(out); UI.sheet({ title: 'Project intelligence', body: box });
  }
  function mcpSettings() {
    var A = RC.advanced.mcp, box = h('div'), name = h('input.in', { placeholder: 'Server name' }), url = h('input.in', { placeholder: 'https://server.example/mcp' }), headers = h('textarea.in', { placeholder: '{"Authorization":"Bearer ..."}', style: { minHeight: '76px' } }), list = h('div');
    function refresh() { U.clear(list); A.list().forEach(function (s) { list.appendChild(h('div.setrow', h('div.grow', h('div.t1', s.name), h('div.t2', s.url + (s.connected ? ' · Connected' : ''))), UI.btn('Connect', 'plug', 'sm', function () { A.connect(s.id).then(function (r) { UI.toast('Connected · ' + r.tools + ' tools'); refresh(); }).catch(function (e) { UI.toast(e.message); }); }), UI.btn('Remove', 'trash', 'sm danger', function () { A.remove(s.id); refresh(); }))); }); }
    box.appendChild(h('div.t2', 'MCP uses user-configured HTTPS Streamable HTTP endpoints. STDIO servers, OAuth flows and SSE-only transports are not supported in this Android build. Only connect to servers you trust. Header credentials are stored in local app settings and are not encrypted by ReCode.'));
    box.appendChild(name); box.appendChild(url); box.appendChild(headers);
    box.appendChild(UI.btn('Save server', 'plus', 'sm', function () { try { var parsed = headers.value.trim() ? JSON.parse(headers.value) : {}; A.save({ name: name.value.trim(), url: url.value.trim(), headers: parsed }); name.value = ''; url.value = ''; headers.value = ''; refresh(); UI.toast('MCP server saved'); } catch (e) { UI.toast(e.message); } }));
    box.appendChild(h('div.sec', 'Configured servers')); box.appendChild(list); refresh(); UI.sheet({ title: 'MCP integrations', body: box });
  }
  function modelCompare() {
    var box = h('div'), prompt = h('textarea.in', { style: { minHeight: '100px' }, placeholder: 'Enter one coding question to compare available models.' }), result = h('pre.code', { style: { whiteSpace: 'pre-wrap', maxHeight: '45vh', overflow: 'auto' } }, 'Comparison results will appear here.');
    box.appendChild(prompt); box.appendChild(UI.btn('Compare available models', 'spark', 'sm', function () { if (!prompt.value.trim()) return UI.toast('Enter a prompt'); result.textContent = 'Running model comparison…'; RC.advanced.compareModels(prompt.value.trim()).then(function (r) { result.textContent = JSON.stringify(r, null, 2); }).catch(function (e) { result.textContent = e.message; }); })); box.appendChild(result); UI.sheet({ title: 'Model comparison', body: box });
  }
  function datasetSettings() {
    var A=RC.advanced, box=h('div'), files=St.fileList().filter(function(p){return /\.jsonl$/i.test(p);}), choice=h('select.in'), report=h('pre.code',{style:{whiteSpace:'pre-wrap',maxHeight:'45vh',overflow:'auto'}});
    files.forEach(function(p){choice.appendChild(h('option',{value:p},p));});
    if(!files.length)box.appendChild(h('div.t2','No .jsonl dataset file exists in the current project. Add a JSONL file first.'));
    else { box.appendChild(choice); box.appendChild(UI.btn('Validate dataset','check','sm',function(){report.textContent=JSON.stringify(A.datasetAudit(choice.value),null,2);})); box.appendChild(report); }
    box.appendChild(h('div.t2','This validates dataset structure only. Model-weight training/fine-tuning is not available in this Android app build.'));
    UI.sheet({title:'Fine-tuning dataset',body:box});
  }
  function advancedPanel() {
    var A = RC.advanced, box = h('div'), branch = h('input.in', { placeholder: 'Branch name (e.g. feature/login)', value: 'main' }), label = h('input.in', { placeholder: 'Snapshot label' }), history = h('div');
    box.appendChild(h('div.t2', 'Automatic model routing chooses local or online per task without changing your saved provider. Online requests may send prompt and project context to your configured API.'));
    box.appendChild(UI.toggle('autoModelRouting', 'Intelligent model routing', 'Use the online model for complex tasks when available'));
    box.appendChild(UI.slider('apiRouteThreshold', 'Online routing threshold', 3, 9, 1, function(v){return String(v);}, 'Lower = more tasks may use your configured online model.'));
    box.appendChild(UI.toggle('selfReview', 'Final-answer self review', 'One extra bounded model call checks claims and verification'));
    box.appendChild(UI.row({ icon: 'activity', title: 'Project intelligence', sub: 'Dependencies, security, quality and responsive audits', onclick: advancedTools }));
    box.appendChild(UI.row({ icon: 'plug', title: 'MCP integrations', sub: 'Configure optional HTTP tool servers', onclick: mcpSettings }));
    box.appendChild(UI.row({ icon: 'file-check', title: 'Fine-tuning dataset validator', sub: 'Validate JSONL examples; does not train weights', onclick: datasetSettings }));
    box.appendChild(UI.row({ icon: 'layers', title: 'Compare models', sub: 'Run the same prompt on available local and online models', onclick: modelCompare }));
    box.appendChild(h('div.sec', 'Local snapshot history (Git-like, not a Git repository)')); box.appendChild(branch); box.appendChild(label);
    box.appendChild(UI.btn('Create snapshot', 'history', 'sm', function () { A.history.save(label.value.trim() || 'Manual snapshot', branch.value.trim() || 'main').then(function () { UI.toast('Snapshot saved'); refreshHistory(); }); }));
    function refreshHistory() { U.clear(history); A.history.list().slice().reverse().slice(0, 15).forEach(function (cp) { history.appendChild(h('div.setrow', h('div.grow', h('div.t1', cp.label), h('div.t2', new Date(cp.time).toLocaleString() + ' · ' + Object.keys(cp.files || {}).length + ' files')), UI.btn('Restore', 'refresh', 'sm ghost', function () { A.history.restore(cp.id).then(function () { UI.toast('Snapshot restored'); refreshHistory(); }).catch(function (e) { UI.toast(e.message); }); }))); }); }
    box.appendChild(history); refreshHistory(); UI.sheet({ title: 'ReCode advanced systems', body: box });
  }

  function paint() {
    var k = body.scrollTop, S = RC.settings; U.clear(body);
    body.appendChild(UI.card(h('div.row', h('div', { html: RC.logo(46) }), h('div.grow', h('div.t1', 'ReCode'), h('div.t2', 'Private multi-agent coder')), h('span.badge', N.has ? 'Offline ready' : 'Preview'))));
    body.appendChild(UI.sec('Appearance'));
    body.appendChild(UI.card(UI.seg([['light', 'Light'], ['dark', 'Dark'], ['system', 'System']], S.theme, function (v) { RC.set('theme', v); UI.applyTheme(); })));
    body.appendChild(UI.sec('Autonomous Agent Runtime')); 
    if (RC.agentRuntime) {
      body.appendChild(UI.card(h('div.t2', 'Execution mode'), UI.seg([['PLAN','Plan'],['ASK','Ask'],['AUTO','Auto']], RC.agentRuntime.mode(), function(v){ RC.agentRuntime.mode(v); UI.toast(v + ' mode enabled'); })));
      body.appendChild(UI.card(UI.row({icon:'layers',title:'Available specialist agents',sub:'25 specialist role definitions',onclick:function(){ var a=RC.agentRuntime.agents.list(); UI.sheet({title:'Specialist agents',body:h('div',a.map(function(x){return h('div.setrow',h('div.grow',h('div.t1',x.name),h('div.t2',x.description)));}))}); }}), UI.row({icon:'book',title:'Skills library',sub:'Load skills on demand',onclick:skillSettings}), UI.row({icon:'history',title:'Create checkpoint',sub:'Snapshot current project files',onclick:function(){RC.agentRuntime.checkpoints.create('Manual checkpoint').then(function(cp){UI.toast('Checkpoint saved: '+cp.label);}).catch(function(e){UI.toast(e.message);});}})));
    }
    
    body.appendChild(UI.sec('Advanced Intelligence · V4'));
    body.appendChild(UI.card(UI.row({ icon: 'spark', title: 'Advanced systems', sub: 'Model router, self-review, local history and diagnostics', onclick: advancedPanel }), UI.row({ icon: 'plug', title: 'MCP servers', sub: 'Optional external tools over HTTP', onclick: mcpSettings })));
    body.appendChild(UI.sec('Specialists & Skills')); 
    body.appendChild(UI.card(
      UI.row({ icon: 'layers', title: 'Agents', sub: 'Roles, answer length, on/off', onclick: function () { sub('agents'); }, right: h('span', { html: RC.i('chevR', 16) }) })));
    body.appendChild(UI.card(
      UI.row({icon:'shield',title:'Tool permissions',sub:'ALLOW / ASK / DENY rules',onclick:function(){permissionSettings();}}),
      UI.row({icon:'activity',title:'Execution monitor',sub:'Current runtime, tasks and checkpoints',onclick:function(){monitor();}})));
    body.appendChild(UI.sec('Knowledge'));
    body.appendChild(UI.card(UI.toggle('useRag', 'Use knowledge (RAG)', 'Search your documents before planning and coding'),
      UI.toggle('ragFiles', 'Include project files', 'Let agents find passages in your own files'),
      UI.slider('ragK', 'Passages per search', 1, 6, 1, function (v) { return String(v); })));
    body.appendChild(UI.sec('Generation'));
    body.appendChild(UI.card(
      UI.slider('ctxChars', 'Context budget', 1800, 14000, 200, function (v) { return Math.round(v / 100) / 10 + 'k'; }, 'Automatic compaction preserves request, decisions and progress. Small models: 4–7k'),
      UI.slider('maxFile', 'Code file length', 400, 3000, 100, function (v) { return v + ' tok'; }, 'Used when the Coder agent has no own limit'),
      UI.toggle('keepAwake', 'Keep screen on while working', 'Android may pause long jobs in the background')));
    body.appendChild(UI.sec('Preview'));
    body.appendChild(UI.card(UI.toggle('autoPreview', 'Refresh preview automatically', 'When files change'),
      UI.toggle('netPreview', 'Allow internet in preview', 'Off = the page is fully offline and cannot call servers')));
    body.appendChild(UI.sec('Data'));
    body.appendChild(UI.card(
      UI.row({ icon: 'download', title: 'Export project as ZIP', onclick: function () { UI.downloadZip(); } }), h('div.hr'),
      UI.row({ icon: 'trash', title: 'Clear this chat', sub: 'Files are kept', onclick: function () { UI.confirm('Clear the chat of this project?', 'Clear', true).then(function (y) { if (y) St.clearMsgs().then(function () { UI.toast('Cleared'); RC.bus.emit('project'); }); }); } }), h('div.hr'),
      UI.row({ icon: 'refresh', title: 'Reset all settings', onclick: function () { UI.confirm('Reset every setting to default? Models and projects stay.', 'Reset', true).then(function (y) { if (y) { RC.settings = JSON.parse(JSON.stringify(RC.defaults)); RC.saveSettings(); UI.applyTheme(); paint(); } }); } })));
    body.appendChild(UI.sec('About'));
    body.appendChild(UI.card(UI.row({ icon: 'info', title: 'Diagnostics', sub: 'Version, device, last crash', onclick: diag, right: h('span', { html: RC.i('chevR', 16) }) }),
      h('div.t2', { style: { marginTop: '10px' } }, 'ReCode has no server and no account. Models, projects and keys stay on this phone. The internet is used only for web research, downloads and the optional online API.')));
    body.scrollTop = k;
  }
  RC.bus.on('project', function () { if (root.classList.contains('on')) paint(); });
  UI.mods.set = { show: paint };
})();
