/* ReCode - RAG on the phone: documents -> chunks -> BM25 keyword ranking -> best passages for an agent.
   (No neural embeddings: the llama.cpp Android library has no embedding API, so ranking is lexical and 100% offline.) */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var U = RC.u;
  var STOP = {};
  ('a an and are as at be but by for from has have he her his i if in into is it its of on or our she so that the their them then there these they this to was we were what when which who will with you your not no do does did can could should would about how why also than too very just').split(' ').forEach(function (w) { STOP[w] = 1; });

  function tokens(s) {
    s = String(s || '').replace(/([a-z0-9])([A-Z])/g, '$1 $2').toLowerCase();
    var m = s.match(/[\p{L}\p{N}]+/gu) || [], out = [];
    for (var i = 0; i < m.length; i++) if (m[i].length > 1 && !STOP[m[i]]) out.push(m[i]);
    return out;
  }

  /** ~600 character passages that break on blank lines, with a two line overlap */
  function chunk(text, name) {
    var lines = String(text || '').replace(/\r/g, '').split('\n'), out = [], cur = [], len = 0, start = 0;
    function flush() {
      var t = cur.join('\n').trim();
      if (t.length > 20) out.push({ name: name, text: t, line: start + 1 });
      cur = cur.slice(-2); len = cur.join('\n').length; start = start + Math.max(0, cur.length ? 0 : 0);
    }
    for (var i = 0; i < lines.length; i++) {
      if (!cur.length) start = i;
      cur.push(lines[i]); len += lines[i].length + 1;
      if (len >= 600 || (len >= 300 && !lines[i].trim())) { flush(); start = i - cur.length + 1; }
    }
    if (cur.join('').trim()) { var t = cur.join('\n').trim(); if (t.length > 20) out.push({ name: name, text: t, line: start + 1 }); }
    out.forEach(function (c) {
      var tk = tokens(c.name + ' ' + c.text), tf = {};
      tk.forEach(function (w) { tf[w] = (tf[w] || 0) + 1; });
      c.tf = tf; c.n = tk.length || 1;
    });
    return out;
  }

  var cache = {};
  function chunksOf(key, name, text) {
    var k = key + '|' + text.length + '|' + text.slice(0, 24) + text.slice(-24);
    if (!cache[key] || cache[key].k !== k) cache[key] = { k: k, c: chunk(text, name) };
    return cache[key].c;
  }

  var R = RC.rag = {
    tokens: tokens, chunk: chunk,
    /** every passage the current project may use: knowledge documents + (optionally) the project's own files */
    corpus: function () {
      var all = [];
      RC.store.kbFor().forEach(function (d) { all = all.concat(chunksOf('kb:' + d.id, d.name, d.text || '')); });
      if (RC.settings.ragFiles) {
        var pid = RC.store.cur ? RC.store.cur.id : '';
        Object.keys(RC.store.files).forEach(function (p) { all = all.concat(chunksOf('f:' + pid + ':' + p, p, RC.store.files[p] || '')); });
      }
      return all;
    },
    stats: function () {
      var d = RC.store.kbFor(), c = 0;
      d.forEach(function (x) { c += chunksOf('kb:' + x.id, x.name, x.text || '').length; });
      return { docs: d.length, chunks: c };
    },
    /** BM25 over the corpus. opts: {k, exclude: [names], extra: [{name,text}]} */
    search: function (query, opts) {
      opts = opts || {};
      var corpus = R.corpus();
      if (opts.extra) opts.extra.forEach(function (e, i) { corpus = corpus.concat(chunksOf('x:' + i + ':' + e.name, e.name, e.text)); });
      if (opts.exclude) corpus = corpus.filter(function (c) { return opts.exclude.indexOf(c.name) < 0; });
      var q = tokens(query);
      if (!q.length || !corpus.length) return [];
      var N = corpus.length, avg = 0, df = {};
      corpus.forEach(function (c) { avg += c.n; q.forEach(function (w) { if (c.tf[w]) df[w] = (df[w] || 0) + 1; }); });
      avg /= N;
      var k1 = 1.5, b = 0.75, seen = {}, uq = q.filter(function (w) { if (seen[w]) return false; seen[w] = 1; return true; });
      var scored = corpus.map(function (c) {
        var sc = 0;
        uq.forEach(function (w) {
          var f = c.tf[w]; if (!f) return;
          var idf = Math.log(1 + (N - df[w] + 0.5) / (df[w] + 0.5));
          sc += idf * (f * (k1 + 1)) / (f + k1 * (1 - b + b * c.n / avg));
        });
        return { name: c.name, text: c.text, line: c.line, score: sc };
      }).filter(function (x) { return x.score > 0; });
      scored.sort(function (a, b2) { return b2.score - a.score; });
      return scored.slice(0, opts.k || RC.settings.ragK || 3);
    },
    format: function (hits, maxChars) {
      var out = '', budget = maxChars || 1800;
      hits.forEach(function (h, i) {
        var t = '[K' + (i + 1) + '] ' + h.name + ' (line ' + h.line + ')\n' + U.clip(h.text, 700, ' ...') + '\n\n';
        if (out.length + t.length <= budget) out += t;
      });
      return out.trim();
    }
  };
})();
