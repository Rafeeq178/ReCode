/* ReCode V4 advanced services: task routing, self-review, hybrid retrieval, project intelligence,
   local snapshot branches, security/quality audits and optional MCP Streamable HTTP client.
   No unrestricted shell, eval-based workflow, or remote code execution is introduced. */
(function () {
  'use strict';
  var RC = window.RC, U = RC.u, St = RC.store, N = RC.native;
  var META = '.recode/';
  function safeId(s) { return String(s || '').toLowerCase().replace(/[^a-z0-9_-]/g, '_').slice(0, 42); }
  function readJSON(k, d) { try { return JSON.parse(localStorage.getItem('rc.' + k) || 'null') || d; } catch (_) { return d; } }
  function saveJSON(k, v) { try { localStorage.setItem('rc.' + k, JSON.stringify(v)); } catch (_) {} }
  function files() { return St.files || {}; }
  function norm(p) { return String(p || '').replace(/\\/g, '/').replace(/^\.\//, ''); }
  function resolve(from, ref) {
    ref = norm(ref).split(/[?#]/)[0];
    if (!ref || /^(?:[a-z]+:|\/\/|#|data:)/i.test(ref)) return null;
    var parts = (from.indexOf('/') >= 0 ? from.slice(0, from.lastIndexOf('/') + 1) : '').split('/').filter(Boolean);
    ref.split('/').forEach(function (x) { if (!x || x === '.') return; if (x === '..') parts.pop(); else parts.push(x); });
    return parts.join('/');
  }
  function importsOf(path, content) {
    var out = [], re = /(?:from\s*|import\s*\(|require\s*\()\s*["']([^"']+)["']/g, m;
    while ((m = re.exec(content))) { if (m[1].charAt(0) === '.') out.push(m[1]); }
    if (/\.html?$/i.test(path)) {
      var htmlRe = /(?:src|href)\s*=\s*["']([^"']+)["']/gi;
      while ((m = htmlRe.exec(content))) { if (m[1].charAt(0) === '.' || !/^(?:https?:|\/)/i.test(m[1])) out.push(m[1]); }
    }
    return Array.from(new Set(out));
  }
  var A = RC.advanced = {
    version: '4.0.0',
    status: function () { return { version: A.version, routing: RC.modelRouter.status(), rag: RC.rag ? RC.rag.stats() : null, files: St.fileList().length, mcpServers: MCP.list().length }; },
    graph: function () {
      var names = St.fileList().filter(function (p) { return !p.startsWith(META); }), nodes = {}, edges = [], missing = [];
      names.forEach(function (p) { nodes[p] = { path: p, extension: (p.split('.').pop() || '').toLowerCase(), imports: [] }; });
      names.forEach(function (p) { importsOf(p, String(files()[p] || '')).forEach(function (ref) {
        var target = resolve(p, ref), candidates = [target, target + '.js', target + '.mjs', target + '.ts', target + '.tsx', target + '.jsx', target + '.json', target + '/index.js', target + '/index.ts'];
        var found = candidates.find(function (x) { return Object.prototype.hasOwnProperty.call(files(), x); });
        if (found) { nodes[p].imports.push(found); edges.push({ from: p, to: found, type: 'local-import' }); }
        else if (target && !/^(?:https?:|\/)/i.test(ref)) missing.push({ from: p, reference: ref, resolved: target });
      }); });
      return { nodes: nodes, edges: edges, missing: missing, count: names.length };
    },
    hybridSearch: function (query, k) {
      var q = String(query || '').toLowerCase().match(/[a-z0-9_$-]{2,}/g) || [], hits = RC.rag ? RC.rag.search(query, { k: Math.max(8, (k || 5) * 2) }) : [];
      var graph = A.graph(), boost = {};
      graph.edges.forEach(function (e) { boost[e.from] = (boost[e.from] || 0) + 0.12; boost[e.to] = (boost[e.to] || 0) + 0.08; });
      var seen = {};
      hits.forEach(function (h) { h.hybridScore = h.score + (boost[h.name] || 0); seen[h.name + ':' + h.line] = 1; });
      St.fileList().forEach(function (p) {
        if (!/\.(js|mjs|cjs|ts|tsx|jsx|py|php|kt|java|html|css|json|md)$/i.test(p)) return;
        var c = String(files()[p] || ''), terms = q.filter(function (w) { return c.toLowerCase().indexOf(w) >= 0; });
        if (!terms.length) return;
        var key = p + ':1'; if (seen[key]) return;
        hits.push({ name: p, line: 1, text: U.clip(c, 700), score: terms.length / Math.max(1, q.length), hybridScore: terms.length / Math.max(1, q.length) + (boost[p] || 0) });
      });
      return hits.sort(function (a, b) { return b.hybridScore - a.hybridScore; }).slice(0, k || 5);
    },
    securityAudit: function () {
      var findings = [], rules = [
        { id: 'dynamic-code', re: /\beval\s*\(|new\s+Function\s*\(/g, severity: 'high', msg: 'Dynamic code execution can run untrusted input.' },
        { id: 'unsafe-html', re: /\.innerHTML\s*=/g, severity: 'medium', msg: 'Review HTML insertion for untrusted data; prefer textContent or safe DOM APIs.' },
        { id: 'embedded-secret', re: /(?:api[_-]?key|secret|password|token)\s*[:=]\s*["'][A-Za-z0-9_\-./+=]{16,}["']/gi, severity: 'high', msg: 'Possible hard-coded credential. Move secrets to secure configuration.' },
        { id: 'http-url', re: /https?:\/\//g, severity: 'info', msg: 'Review network endpoint and transport security.' },
        { id: 'weak-random', re: /Math\.random\s*\(/g, severity: 'low', msg: 'Math.random is not suitable for security-sensitive tokens.' },
        { id: 'sql-concat', re: /(?:SELECT|INSERT|UPDATE|DELETE)[^\n]*\+\s*[A-Za-z_$]/gi, severity: 'high', msg: 'Possible SQL string concatenation; use parameterized queries.' }
      ];
      St.fileList().forEach(function (p) { var c = String(files()[p] || ''); rules.forEach(function (r) { r.re.lastIndex = 0; var m; while ((m = r.re.exec(c))) { var line = c.slice(0, m.index).split('\n').length; findings.push({ rule: r.id, severity: r.severity, file: p, line: line, message: r.msg }); if (findings.length >= 250) return; } }); });
      var rank = { high: 0, medium: 1, low: 2, info: 3 }; findings.sort(function (a, b) { return rank[a.severity] - rank[b.severity]; });
      return { findings: findings, summary: { high: findings.filter(function (x) { return x.severity === 'high'; }).length, medium: findings.filter(function (x) { return x.severity === 'medium'; }).length, total: findings.length }, note: 'Static heuristics only; this is not a penetration test.' };
    },
    responsiveAudit: function () {
      var names = St.fileList(), html = names.filter(function (p) { return /\.html?$/i.test(p); }), css = names.filter(function (p) { return /\.css$/i.test(p); }), findings = [];
      if (html.length && !html.some(function (p) { return /<meta[^>]+name=[\"']viewport[\"']/i.test(files()[p]); })) findings.push({ severity: 'high', message: 'No viewport meta tag found in HTML entry pages.' });
      if (css.length && !css.some(function (p) { return /@media/.test(files()[p]); })) findings.push({ severity: 'medium', message: 'No CSS media query found; verify mobile and tablet layouts.' });
      css.forEach(function (p) { var c = String(files()[p] || ''); if (/width\s*:\s*\d{3,}px/.test(c) && !/@media/.test(c)) findings.push({ severity: 'medium', file: p, message: 'Fixed large pixel width may overflow on phones.' }); if (/100vw/.test(c) && /padding|margin/.test(c)) findings.push({ severity: 'low', file: p, message: 'Check 100vw combined with spacing for horizontal overflow.' }); });
      return { findings: findings, note: 'Static responsive heuristics; confirm with the live preview on multiple devices.' };
    },
    responsiveCheck: async function () {
      var staticResult = A.responsiveAudit();
      var live = RC.run && RC.run.responsiveCheck ? await RC.run.responsiveCheck(St.files) : { skipped: true, note: 'Preview runner unavailable' };
      return { static: staticResult, live: live };
    },
    datasetAudit: function (path) {
      path = norm(path); var raw = String(files()[path] || ''), lines = raw.split(/\r?\n/).filter(function (x) { return x.trim(); }), errors = [], roles = {}, examples = 0;
      if (!/\.jsonl$/i.test(path)) return { ok: false, error: 'Select a .jsonl dataset file.' };
      lines.forEach(function (line, i) { try { var row = JSON.parse(line), msgs = row.messages || row.conversations || null; examples++; if (msgs) { if (!Array.isArray(msgs) || !msgs.length) errors.push({ line: i + 1, error: 'messages must be a non-empty array' }); else { var hasAssistant = false; msgs.forEach(function (m) { var role = m.role || m.from || 'unknown'; roles[role] = (roles[role] || 0) + 1; if (role === 'assistant' || role === 'gpt') hasAssistant = true; if (!m.content && !m.value) errors.push({ line: i + 1, error: 'message has no content' }); }); if (!hasAssistant) errors.push({ line: i + 1, error: 'No assistant response found' }); } } else if (!(typeof row.prompt === 'string' && typeof row.completion === 'string')) errors.push({ line: i + 1, error: 'Expected messages[] or prompt/completion strings' }); } catch (e) { errors.push({ line: i + 1, error: 'Invalid JSON: ' + e.message }); } });
      return { path: path, examples: examples, roles: roles, errors: errors.slice(0, 100), valid: errors.length === 0, splitSuggestion: { train: 90, validation: 10 }, note: 'Dataset validation only. ReCode does not train or fine-tune model weights on Android.' };
    },
    qualityAudit: function () {
      var findings = [];
      St.fileList().forEach(function (p) { var c = String(files()[p] || ''), lines = c.split('\n');
        if (c.length > 120000) findings.push({ file: p, line: 1, type: 'large-file', message: 'Large file; consider splitting into focused modules.' });
        lines.forEach(function (line, i) { if (line.length > 260) findings.push({ file: p, line: i + 1, type: 'long-line', message: 'Line exceeds 260 characters.' }); if (/\b(TODO|FIXME|XXX)\b/.test(line)) findings.push({ file: p, line: i + 1, type: 'todo', message: line.trim().slice(0, 180) }); });
      });
      var graph = A.graph(); graph.missing.forEach(function (x) { findings.push({ file: x.from, line: 0, type: 'unresolved-import', message: 'Cannot resolve ' + x.reference }); });
      return { findings: findings.slice(0, 300), count: findings.length, dependencies: { files: graph.count, edges: graph.edges.length, unresolved: graph.missing.length } };
    }
  };

  // Snapshot branches: durable, project-local checkpoints with named labels. This is not Git.
  var VCS = A.history = {
    list: function () { return RC.agentRuntime.checkpoints.list(); },
    save: async function (label, branch) { var cp = await RC.agentRuntime.checkpoints.create((branch ? '[' + branch + '] ' : '') + (label || 'Snapshot')); var b = readJSON('vcsBranches.' + (St.cur && St.cur.id), {}); var key = branch || 'main'; (b[key] = b[key] || []).push(cp.id); saveJSON('vcsBranches.' + (St.cur && St.cur.id), b); return cp; },
    branches: function () { return readJSON('vcsBranches.' + (St.cur && St.cur.id), { main: [] }); },
    restore: function (id) { return RC.agentRuntime.checkpoints.restore(id); },
    diff: function (id) { return RC.agentRuntime.checkpoints.diff(id); }
  };

  // MCP Streamable HTTP (JSON response or SSE data frames). STDIO transport is not available in Android WebView.
  var MCP = A.mcp = {
    connectedIds: {},
    list: function () { return readJSON('mcpServers', []).map(function (x) { x.connected = !!MCP.connectedIds[x.id]; return x; }); },
    save: function (server) {
      if (!server || !server.name || !/^https:\/\//i.test(server.url || '')) throw new Error('Enter a server name and valid HTTPS endpoint.');
      server.id = server.id || safeId(server.name); var all = MCP.list().filter(function (x) { return x.id !== server.id; }); server.enabled = server.enabled !== false; all.push(server); saveJSON('mcpServers', all); return server;
    },
    remove: function (id) { saveJSON('mcpServers', MCP.list().filter(function (x) { return x.id !== id; })); MCP.disconnect(id); },
    updateServer: function (server) { var all = readJSON('mcpServers', []).map(function (x) { if (x.id !== server.id) return x; var copy=Object.assign({},server); delete copy.connected; return copy; }); saveJSON('mcpServers', all); },
    parse: function (body) { var s = String(body || '').trim(); if (!s) return {}; try { return JSON.parse(s); } catch (_) {} var lines = s.split(/\r?\n/).filter(function (x) { return x.indexOf('data:') === 0; }).map(function (x) { return x.slice(5).trim(); }); for (var i = lines.length - 1; i >= 0; i--) { try { return JSON.parse(lines[i]); } catch (_) {} } throw new Error('MCP server returned an unsupported response.'); },
    request: async function (server, method, params) {
      var id = 'rcmcp_' + Date.now() + '_' + Math.floor(Math.random() * 100000), headers = Object.assign({ 'Content-Type': 'application/json', 'Accept': 'application/json, text/event-stream', 'MCP-Protocol-Version': server.protocolVersion || '2025-03-26' }, server.headers || {});
      if (server.sessionId) headers['Mcp-Session-Id'] = server.sessionId;
      var body = JSON.stringify({ jsonrpc: '2.0', id: id, method: method, params: params || {} });
      var response = await N.mcpRequest('POST', server.url, headers, body);
      if (response.status < 200 || response.status >= 300) throw new Error('MCP HTTP ' + response.status + ': ' + String(response.body).slice(0, 500));
      var session = response.sessionId || null; if (session) { server.sessionId = session; MCP.updateServer(server); }
      var data = MCP.parse(response.body); if (data.error) throw new Error(data.error.message || 'MCP protocol error'); return data.result || data;
    },
    notify: async function (server, method, params) {
      var headers = Object.assign({ 'Content-Type': 'application/json', 'Accept': 'application/json, text/event-stream', 'MCP-Protocol-Version': server.protocolVersion || '2025-03-26' }, server.headers || {});
      if (server.sessionId) headers['Mcp-Session-Id'] = server.sessionId;
      var response = await N.mcpRequest('POST', server.url, headers, JSON.stringify({ jsonrpc: '2.0', method: method, params: params || {} }));
      if (response.status < 200 || response.status >= 300) throw new Error('MCP notification HTTP ' + response.status);
      return true;
    },
    connect: async function (id) {
      var s = MCP.list().filter(function (x) { return x.id === id && x.enabled; })[0]; if (!s) throw new Error('MCP server is missing or disabled.'); s.sessionId = null;
      var init;
      try { s.protocolVersion = '2025-03-26'; init = await MCP.request(s, 'initialize', { protocolVersion: s.protocolVersion, capabilities: {}, clientInfo: { name: 'ReCode', version: A.version } }); }
      catch (firstError) { s.sessionId = null; s.protocolVersion = '2024-11-05'; init = await MCP.request(s, 'initialize', { protocolVersion: s.protocolVersion, capabilities: {}, clientInfo: { name: 'ReCode', version: A.version } }); }
      s.protocolVersion = init.protocolVersion || s.protocolVersion;
      await MCP.notify(s, 'notifications/initialized', {} ).catch(function () {});
      var tools = [], cursor = null, pages = 0, result;
      do { result = await MCP.request(s, 'tools/list', cursor ? { cursor: cursor } : {}); tools = tools.concat(result.tools || []); cursor = result.nextCursor || null; pages++; } while (cursor && pages < 10);
      if (cursor) throw new Error('MCP tool discovery exceeded 10 pages; server result was truncated.');
      MCP.disconnect(id);
      tools.forEach(function (remote) {
        var toolName = 'mcp_' + safeId(id) + '_' + safeId(remote.name), props = remote.inputSchema && remote.inputSchema.properties || {}, schema = {};
        (remote.inputSchema && remote.inputSchema.required || []).forEach(function (k) { if (props[k]) schema[k] = ['array','number','integer','boolean','object'].indexOf(props[k].type) >= 0 ? (props[k].type === 'integer' ? 'number' : props[k].type) : 'string'; });
        var description = '[MCP ' + s.name + '] ' + String(remote.description || remote.name).slice(0, 500);
        RC.agentRuntime.register(toolName, description, schema, 'mcp_call', async function (args) {
          var res = await MCP.request(s, 'tools/call', { name: remote.name, arguments: args });
          if (res.isError) throw new Error('Remote MCP tool reported an error: ' + JSON.stringify(res.content || res));
          return res.content || res.structuredContent || res;
        });
        if (RC.agentRuntime.registry[toolName]) RC.agentRuntime.registry[toolName].remoteSchema = remote.inputSchema || { type: 'object', properties: {}, additionalProperties: true };
        MCP.registered[id] = MCP.registered[id] || []; MCP.registered[id].push(toolName);
      });
      s.connected = true; s.serverInfo = init.serverInfo || {}; MCP.connectedIds[id] = true; MCP.updateServer(s); return { server: s.name, tools: tools.length, names: tools.map(function (x) { return x.name; }) };
    },
    registered: {},
    disconnect: function (id) { (MCP.registered[id] || []).forEach(function (name) { delete RC.agentRuntime.registry[name]; }); delete MCP.registered[id]; delete MCP.connectedIds[id]; }
  };

  // Register auditable project-analysis tools through the same permission and hook path.
  var rt = RC.agentRuntime;
  rt.register('analyze_dependencies', 'Build local import/dependency graph and report unresolved local imports', {}, 'read_file', async function () { return A.graph(); });
  rt.register('security_audit', 'Run static security heuristics over project files', {}, 'read_file', async function () { return A.securityAudit(); });
  rt.register('quality_audit', 'Inspect project maintainability and unresolved references', {}, 'read_file', async function () { return A.qualityAudit(); });
  rt.register('responsive_audit', 'Run static and sandboxed phone/tablet/desktop overflow checks', {}, 'read_file', async function () { return A.responsiveCheck(); });
  rt.register('dataset_audit', 'Validate a JSONL chat fine-tuning dataset without training model weights', { path: 'string' }, 'read_file', async function (a) { return A.datasetAudit(a.path); });
  rt.register('hybrid_search', 'Search project and knowledge using BM25 plus dependency-aware file ranking', { query: 'string' }, 'read_file', async function (a) { return A.hybridSearch(a.query, 6); });
  rt.register('save_snapshot', 'Save a named project snapshot on a local history branch', { label: 'string', branch: 'string' }, 'edit_file', async function (a) { var cp = await VCS.save(a.label, a.branch); return { id: cp.id, label: cp.label, time: cp.time }; });
  rt.register('compare_models', 'Compare responses from configured local and online models', { query: 'string' }, 'model_compare', async function (a) { return A.compareModels(a.query); });
  rt.register('mcp_list_servers', 'List configured optional MCP HTTP servers', {}, 'read_file', async function () { return MCP.list().map(function (s) { return { id: s.id, name: s.name, url: s.url, enabled: s.enabled }; }); });
  rt.register('mcp_connect', 'Connect to a configured MCP Streamable HTTP server and discover tools', { id: 'string' }, 'mcp_call', async function (a) { return MCP.connect(a.id); });

  // Final self-review is opt-in, bounded to one additional model call and never hides verification gaps.
  A.reviewFinal = async function (request, answer, signal) {
    if (RC.settings.selfReview !== true || !answer || !RC.llm.ready()) return answer;
    try {
      var provider = RC.settings.provider;
      var critique = await RC.llm.run({ agent: 'reviewer', provider: provider, maxTokens: 420, signal: signal,
        system: 'Review the proposed coding-agent final response for factual overclaims, missing verification, unreported limitations, and whether it satisfies the user request. If it is already accurate, return exactly KEEP. Otherwise return a concise corrected final response. Do not claim tests passed without evidence.',
        prompt: 'Original request:\n' + U.clip(request, 2500) + '\n\nProposed response:\n' + U.clip(answer, 3000) });
      return /^\s*KEEP\s*$/i.test(critique) ? answer : critique.trim();
    } catch (_) { return answer; }
  };

  // Simple model comparison helper for diagnostics; outputs are not merged automatically.
  A.compareModels = async function (prompt, signal) {
    var out = {}, s = RC.settings;
    if (s.model && N.models().some(function (m) { return m.name === s.model; })) {
      try { out.local = await RC.llm.run({ agent: 'comparison', provider: 'local', system: 'Answer the coding question accurately and concisely.', prompt: prompt, maxTokens: 500, signal: signal }); } catch (e) { out.localError = e.message; }
    }
    if (N.online() && s.api && s.api.model) {
      try { out.online = await RC.llm.run({ agent: 'comparison', provider: 'api', system: 'Answer the coding question accurately and concisely.', prompt: prompt, maxTokens: 500, signal: signal }); } catch (e) { out.onlineError = e.message; }
    }
    return out;
  };
})();
