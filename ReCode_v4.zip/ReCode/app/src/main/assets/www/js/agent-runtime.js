/* ReCode Agent Runtime v2: permission-gated tools, model-directed loop, hooks, agents, skills, memory, todos and snapshots. */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {}, U = RC.u, St = RC.store;
  var META = '.recode/', MAX_ITER = 24, MAX_FILE = 300000;
  function err(s) { throw new Error(s); }
  function path(p) {
    p = String(p || '').replace(/\\/g, '/'); if(/^\//.test(p)||/^[A-Za-z]:/.test(p)||p.indexOf('\0')>=0)err('Absolute or invalid project path blocked');
    var a = [];
    p.split('/').forEach(function (x) { if (!x || x === '.') return; if (x === '..') err('Path traversal blocked'); a.push(x); });
    p = a.join('/'); if (!p || p.length > 180 || p.charAt(0) === '/') err('Invalid project path'); return p;
  }
  function clone(x) { return JSON.parse(JSON.stringify(x)); }
  function meta(k, d) { try { return JSON.parse(localStorage.getItem('rc.' + k) || 'null') || d; } catch (_) { return d; } }
  function save(k, v) { try { localStorage.setItem('rc.' + k, JSON.stringify(v)); } catch (_) {} }
  var agentDefs = {
    planner:['Plans tasks and selects specialists.','Break complex work into verifiable tasks. Do not modify files.'], explorer:['Explores project structure and code.','Inspect files and report architecture, dependencies and related files.'], researcher:['Researches APIs and technical facts.','Use supplied sources only; distinguish facts from assumptions.'], architect:['Designs system architecture.','Define interfaces, data shapes, boundaries and migration strategy.'], frontend:['Builds HTML, CSS and client interfaces.','Follow existing design and accessibility conventions.'], backend:['Builds application logic and APIs.','Validate inputs and handle errors securely.'], database:['Designs data models and migrations.','Preserve data integrity and document schema decisions.'], coder:['Implements requested code changes.','Inspect before editing. Make minimal, maintainable changes.'], debugger:['Investigates failures.','Reproduce, isolate root cause and report evidence.'], fixer:['Repairs identified defects.','Make focused fixes and avoid unrelated changes.'], tester:['Creates and runs tests.','Test expected behavior and regressions; report limitations.'], reviewer:['Reviews code quality.','Prioritize correctness, regressions and maintainability.'], security:['Reviews security risks.','Look for injection, data exposure, unsafe paths and privilege issues.'], optimizer:['Improves performance.','Measure or identify bottlenecks before changing behavior.'], documentation:['Maintains project documentation.','Document setup, architecture, decisions and verified behavior.']
  };
  var agentTools={
    planner:'read_file,list_files,search_text,select_agents,todo_add,todo_update',
    explorer:'read_file,list_files,search_files,search_text,get_file_info,get_project_info,search_dependencies,rag_search',
    researcher:'read_file,list_files,search_text,rag_search',
    architect:'read_file,list_files,search_text,get_project_info,todo_add,todo_update',
    frontend:'read_file,list_files,search_text,write_file,edit_file,check_syntax,run_tests',
    backend:'read_file,list_files,search_text,write_file,edit_file,check_syntax,run_tests',
    database:'read_file,list_files,search_text,write_file,edit_file,check_syntax',
    coder:'read_file,list_files,search_text,write_file,edit_file,create_directory,check_syntax,run_tests',
    debugger:'read_file,list_files,search_text,check_syntax,run_tests',
    fixer:'read_file,write_file,edit_file,search_text,check_syntax,run_tests',
    tester:'read_file,list_files,search_text,check_syntax,run_tests',
    reviewer:'read_file,list_files,search_text,check_syntax,run_tests',
    security:'read_file,list_files,search_text,get_file_info,check_syntax',
    optimizer:'read_file,list_files,search_text,get_file_info,run_tests',
    documentation:'read_file,list_files,search_text,write_file,edit_file,check_syntax'
  };
  var skills = {
    'html-game':'Build small offline HTML5 games with canvas or DOM; use requestAnimationFrame and keyboard/touch controls.',
    'python-cli':'Build portable Python CLI tools with argparse, clear errors and tests.',
    'php-development':'Use modern PHP, PDO prepared statements, validation and session security.',
    firebase:'Use Firebase modular SDK, explicit security rules, auth-aware data access and offline persistence where supported.',
    'responsive-design':'Mobile-first layouts, semantic HTML, accessible controls and responsive CSS.',
    'database-design':'Normalize entities, define constraints/indexes and plan safe migrations.',
    'android-development':'Respect Android lifecycle, permissions, offline behavior and platform APIs.',
    debugging:'Reproduce first, isolate the smallest failing unit, fix root cause and run regression checks.'
  };
  var hooks = [], history = meta('permissionHistory', []);
  var permissions = meta('permissions', {global:{read_file:'ALLOW',list_files:'ALLOW',search_files:'ALLOW',search_text:'ALLOW',get_file_info:'ALLOW',write_file:'ASK',edit_file:'ASK',create_directory:'ASK',rename_file:'ASK',move_file:'ASK',delete_file:'DENY',run_command:'DENY',check_syntax:'ALLOW',run_tests:'ASK',delegate_agent:'ASK',checkpoint_restore:'ASK'}, projects:{}});
  var modes = { PLAN:'plan', ASK:'ask', AUTO:'auto' };
  var currentMode = meta('agentMode', 'ASK');
  function projectRules() { var id = St.cur && St.cur.id; return id && permissions.projects[id] || {}; }
  function decision(tool, target) {
    var p = projectRules(), values = [permissions.global[tool] || 'ASK'];
    if (p[tool]) values.push(p[tool]);
    var rules = p.paths || {};
    Object.keys(rules).forEach(function (prefix) { if (target && target.indexOf(prefix) === 0 && rules[prefix][tool]) values.push(rules[prefix][tool]); });
    if (values.indexOf('DENY') >= 0 || tool === 'run_command') return 'DENY';
    if (values.indexOf('ASK') >= 0) return 'ASK';
    return 'ALLOW';
  }
  async function authorize(tool, args) {
    var targets=args?[args.path,args.from,args.to].filter(Boolean):[],target=targets.join(' → ')||(args&&args.command)||'';
    var decisions=targets.length?targets.map(function(t){return decision(tool,t);}):[decision(tool,target)];
    var d=decisions.indexOf('DENY')>=0?'DENY':decisions.indexOf('ASK')>=0?'ASK':'ALLOW';
    if (d === 'DENY') err('Permission denied: ' + tool + (target?' ('+target+')':''));
    var planReadOnly=['read_file','list_files','search_files','search_text','get_file_info','check_syntax','get_project_info','search_dependencies','rag_search','select_agents','list_agents','list_skills','load_skill','delegate_agent','delegate_agents','todo_list','checkpoint_list','checkpoint_diff','analyze_dependencies','security_audit','quality_audit','hybrid_search','mcp_list_servers','responsive_audit','dataset_audit','analyze_dependencies','security_audit','quality_audit','hybrid_search'];
    if (currentMode === 'PLAN' && planReadOnly.indexOf(tool)<0) err('Plan mode is read-only.');
    if (currentMode==='PLAN'&&planReadOnly.indexOf(tool)>=0) d='ALLOW';
    if (d === 'ASK' || currentMode === 'ASK' && d !== 'ALLOW') {
      if (!RC.ui || !RC.ui.confirm) err('Approval required for ' + tool);
      var yes = await RC.ui.confirm('Allow ' + tool + (target ? ' on ' + target : '') + '?', 'Approve', true);
      if (!yes) err('User rejected ' + tool);
    }
    history.push({t:Date.now(),tool:tool,target:target,decision:d,mode:currentMode}); save('permissionHistory', history.slice(-300));
  }
  async function before(name, args) { for (var i=0;i<hooks.length;i++) { if (hooks[i].event !== 'PreToolUse') continue; var r=await hooks[i].fn('PreToolUse', {name:name,args:args}); if (r === false || r && r.block) err(r.reason || 'Blocked by hook'); } }
  async function after(name, args, result) { for (var i=0;i<hooks.length;i++) { if (hooks[i].event !== 'PostToolUse') continue; try { await hooks[i].fn('PostToolUse',{name:name,args:args,result:result}); } catch(e) { console.warn('Hook failed',e); } } }
  function registerHook(event, fn, id) { if(HOOK_EVENTS&&HOOK_EVENTS.indexOf(event)<0)err('Unsupported hook event: '+event);if(typeof fn!=='function')err('Hook must be a function');hooks.push({event:event,fn:fn,id:id||U.uid('hook')}); return function(){hooks=hooks.filter(function(h){return h.fn!==fn;});}; }
  var registry = {};
  function validateSyntax(p,c){try{if(/\.(js|mjs|cjs)$/i.test(p)&&!/^\s*(?:import|export)\s/m.test(c))new Function(c);if(/\.json$/i.test(p))JSON.parse(c);if(/\.css$/i.test(p)){var o=(c.match(/{/g)||[]).length,cl=(c.match(/}/g)||[]).length;if(o!==cl)throw new Error('Unbalanced CSS braces');}if(/\.html?$/i.test(p)&&typeof DOMParser!=='undefined'){var d=new DOMParser().parseFromString(c,'text/html');var pe=d.querySelector('parsererror');if(pe)throw new Error(pe.textContent||'HTML parse error');}}catch(e){err('Syntax validation failed for '+p+': '+e.message);}}
  function register(name, description, schema, permission, execute) { registry[name]={name:name,description:description,parameters:schema||{},permission:permission,execute:execute}; }
  function file(p) { p=path(p); if (!Object.prototype.hasOwnProperty.call(St.files,p)) err('File not found: '+p); return St.files[p]; }
  register('list_files','List project files',{},'read_file',async function(){return St.fileList();});
  register('read_file','Read a project file',{path:'string'},'read_file',async function(a){return file(a.path);});
  register('write_file','Create a new project file; asks before overwriting',{path:'string',content:'string'},'write_file',async function(a){var p=path(a.path); if(typeof a.content!=='string'||a.content.length>MAX_FILE)err('Invalid or oversized content'); if(St.files[p]!==undefined){var yes=await RC.ui.confirm('Overwrite existing file '+p+'? A checkpoint will be created first.','Overwrite',true);if(!yes)err('Overwrite rejected');} validateSyntax(p,a.content); await St.putFile(p,a.content); return 'Saved '+p;});
  register('edit_file','Replace project file content after confirmation',{path:'string',content:'string'},'edit_file',async function(a){var p=path(a.path);file(p);if(typeof a.content!=='string'||a.content.length>MAX_FILE)err('Invalid content');if(!RC.ui||!await RC.ui.confirm('Replace '+p+' with the new content? A checkpoint is saved first.','Overwrite',true))err('Edit rejected');validateSyntax(p,a.content);await St.putFile(p,a.content);return 'Updated '+p;});
  register('delete_file','Delete a project file after confirmation',{path:'string'},'delete_file',async function(a){var p=path(a.path);file(p);var yes=await RC.ui.confirm('Permanently delete '+p+'? A checkpoint will be created first.','Delete',true);if(!yes)err('Delete rejected');await St.delFile(p);return 'Deleted '+p;});
  register('search_files','Find files by name substring',{query:'string'},'search_files',async function(a){var q=String(a.query||'').toLowerCase();return St.fileList().filter(function(p){return p.toLowerCase().indexOf(q)>=0;});});
  register('search_text','Search text in project files',{query:'string'},'search_text',async function(a){var q=String(a.query||'').toLowerCase(),out=[];St.fileList().forEach(function(p){var lines=St.files[p].split('\n');lines.forEach(function(l,i){if(l.toLowerCase().indexOf(q)>=0&&out.length<100)out.push({path:p,line:i+1,text:U.clip(l,300)});});});return out;});
  register('create_directory','Create directory marker (workspace folders are implicit)',{path:'string'},'create_directory',async function(a){var p=path(a.path).replace(/\/$/,'')+'/.keep';if(St.files[p]===undefined)await St.putFile(p,'');return 'Directory ready';});
  register('rename_file','Rename a project file',{from:'string',to:'string'},'rename_file',async function(a){await St.renameFile(path(a.from),path(a.to));return 'Renamed';});
  register('move_file','Move a project file',{from:'string',to:'string'},'move_file',async function(a){await St.renameFile(path(a.from),path(a.to));return 'Moved';});
  register('get_file_info','Get file metadata',{path:'string'},'get_file_info',async function(a){var c=file(a.path);return {path:path(a.path),bytes:new Blob([c]).size,lines:c.split('\n').length,extension:U.ext(a.path)};});
  register('run_command','Run a terminal command (unavailable in Android WebView)',{command:'string'},'run_command',async function(){err('Terminal execution is not available in this Android build.');});
  register('check_syntax','Run available static syntax checks',{},'check_syntax',async function(a){var p=a.path?path(a.path):null,out=[];(p?[p]:St.fileList()).forEach(function(n){var c=St.files[n];try{validateSyntax(n,c);}catch(e){out.push({path:n,error:e.message});}});return {ok:!out.length,issues:out};});
  register('run_tests','Run ReCode preview checks',{},'run_tests',async function(){if(!RC.run||!RC.run.check)err('Test runner unavailable');return RC.run.check();});
  register('load_skill','Load full instructions for a relevant skill',{name:'string'},'read_file',async function(a){return Skills.load(a.name);});
  register('delegate_agent','Ask one specialist agent for an independent analysis',{agent:'string',task:'string'},'delegate_agent',async function(a){var id=String(a.agent||'').toLowerCase();var result=await specialist(id,a.task||'',null);return {agent:id,result:result};});
  register('update_memory','Save durable project memory',{level:'string',content:'string'},'edit_file',async function(a){await Memory.update(a.level,a.content);return 'Updated '+a.level+' memory';});
  register('todo_add','Add a project task',{title:'string'},'edit_file',async function(a){return Tasks.add(a.title);});
  register('todo_update','Change task status',{id:'string',status:'string'},'edit_file',async function(a){if(!['PENDING','IN_PROGRESS','COMPLETED','BLOCKED','FAILED'].includes(a.status))err('Invalid task status');return Tasks.update(a.id,a.status);});
  register('checkpoint_create','Save a snapshot of project files',{label:'string'},'edit_file',async function(a){return Checkpoints.create(a.label);});
  register('checkpoint_restore','Restore a previous project snapshot',{id:'string'},'checkpoint_restore',async function(a){return Checkpoints.restore(a.id);});
  async function execute(name,args) { var t=registry[name];if(!t)err('Unknown tool: '+name);args=args||{};Object.keys(t.parameters||{}).forEach(function(k){var type=t.parameters[k],v=args[k];if(v===undefined||v===null)err('Missing tool argument: '+k);if(type==='string'&&typeof v!=='string')err('Tool argument '+k+' must be a string');if(type==='array'&&!Array.isArray(v))err('Tool argument '+k+' must be an array');if(type==='number'&&typeof v!=='number')err('Tool argument '+k+' must be a number');if(type==='boolean'&&typeof v!=='boolean')err('Tool argument '+k+' must be a boolean');if(type==='object'&&(!v||typeof v!=='object'||Array.isArray(v)))err('Tool argument '+k+' must be an object');});await authorize(name,args);await before(name,args);if((name==='write_file'||name==='edit_file'||name==='delete_file'||name==='rename_file'||name==='move_file'||name==='checkpoint_restore')&&Checkpoints)await Checkpoints.create('Before '+name);var result=await t.execute(args);await after(name,args,result);return result; }
  function parseTool(text) {
    text=String(text||''); var m=/```(?:tool|json)?\s*([\s\S]*?)```/i.exec(text), raw=m?m[1]:text;
    var j=/\{\s*"(?:tool|name)"\s*:\s*"([\w]+)"[\s\S]*?\}/.exec(raw);
    if(j){try{var o=JSON.parse(j[0]);return {name:o.tool||o.name,args:o.arguments||o.args||{}};}catch(_){}}
    var lines=raw.split('\n');for(var i=0;i<lines.length;i++){var x=/^\s*TOOL:\s*([\w]+)(?:\s*\|\s*(.*))?\s*$/i.exec(lines[i]);if(x){var rest=x[2]||'',args={};try{if(rest.charAt(0)==='{')args=JSON.parse(rest);else if(rest){var bits=rest.split('|');if(x[1]==='read_file'||x[1]==='delete_file'||x[1]==='get_file_info')args.path=bits[0].trim();else if(x[1]==='write_file'||x[1]==='edit_file'){args.path=bits.shift().trim();args.content=bits.join('|');}else if(x[1]==='search_files'||x[1]==='search_text')args.query=rest;else if(x[1]==='run_command')args.command=rest;}}catch(e){return {invalid:e.message};}return {name:x[1],args:args};}}
    return null;
  }
  function toolManifest(names) { return Object.keys(registry).filter(function(n){return !names||names.indexOf(n)>=0;}).map(function(n){var t=registry[n];return t.name+': '+t.description+'; params='+JSON.stringify(t.parameters)+(t.remoteSchema?'; inputSchema='+JSON.stringify(t.remoteSchema):'');}).join('\n'); }
  function toolSchemas(){return Object.keys(registry).filter(function(n){return n!=='run_command';}).map(function(n){var t=registry[n],props={},required=[];Object.keys(t.parameters||{}).forEach(function(k){props[k]=t.parameters[k]==='array'?{type:'array',items:{type:'string'}}:{type:t.parameters[k]||'string'};required.push(k);});return {type:'function',function:{name:t.name,description:t.description,parameters:t.remoteSchema||{type:'object',properties:props,required:required,additionalProperties:false}}};});}
  // The only active orchestrator is the model-directed completeAgentLoop defined below.
  var Memory={load:async function(){var keys=['global','user','project','local'];var chunks=[];for(var i=0;i<keys.length;i++){var p=META+'memory/'+keys[i]+'.md';if(St.files[p])chunks.push('# '+keys[i]+' memory\n'+St.files[p]);}if(St.files['RECODE.md'])chunks.unshift(St.files['RECODE.md']);return chunks.join('\n\n');},update:async function(level,text){if(!['global','user','project','local'].includes(level))err('Invalid memory level');await St.putFile(META+'memory/'+level+'.md',String(text||''));},bootstrap:async function(){if(!St.files['RECODE.md'])await St.putFile('RECODE.md','# ReCode Project Guide\n\nDescribe project purpose, languages, architecture, conventions, setup and tests here.');var levels={global:'Durable cross-project guidance. Do not store secrets.',user:'User-approved durable coding preferences. Do not store sensitive details.',project:'Project architecture, stack, conventions, dependencies, tests and decisions.',local:'Workspace-specific setup notes. Do not store credentials.'};for(var k of Object.keys(levels)){var mp=META+'memory/'+k+'.md';if(!St.files[mp])await St.putFile(mp,'# '+k+' memory\n\n'+levels[k]);}for(var id of Object.keys(agentDefs)){var ap=META+'agents/'+id+'.md';if(!St.files[ap])await St.putFile(ap,'---\nname: '+id+'\ndescription: '+agentDefs[id][0]+'\ntools: '+(agentTools[id]||'read_file, search_text')+'\n---\n\n'+agentDefs[id][1]);}for(var sn of Object.keys(skills)){var sp=META+'skills/'+sn+'/SKILL.md';if(!St.files[sp])await St.putFile(sp,'---\nname: '+sn+'\ndescription: '+skills[sn]+'\n---\n\n'+skills[sn]);}}};
  var Tasks={get:function(){return meta('todos.'+(St.cur&&St.cur.id),[]);},save:function(a){save('todos.'+(St.cur&&St.cur.id),a);RC.bus.emit('todos',a);return a;},add:function(title,parent){var a=Tasks.get();a.push({id:U.uid('task'),title:title,parent:parent||null,status:'PENDING',updated:Date.now()});return Tasks.save(a);},update:function(id,status){var a=Tasks.get();var t=a.filter(function(x){return x.id===id;})[0];if(!t)err('Task not found');t.status=status;t.updated=Date.now();return Tasks.save(a);}};
  var Checkpoints={list:function(){return meta('checkpoints.'+(St.cur&&St.cur.id),[]);},create:function(label){var a=Checkpoints.list();a.push({id:U.uid('cp'),label:label||'Checkpoint',time:Date.now(),files:clone(St.files)});save('checkpoints.'+(St.cur&&St.cur.id),a);return a[a.length-1];},restore:async function(id){var cp=Checkpoints.list().filter(function(x){return x.id===id;})[0];if(!cp)err('Checkpoint not found');var current=St.fileList();for(var i=0;i<current.length;i++)await St.delFile(current[i]);var names=Object.keys(cp.files);for(var j=0;j<names.length;j++)await St.putFile(names[j],cp.files[names[j]]);return 'Restored '+cp.label;}};
  var Agents={list:function(){return Object.keys(agentDefs).map(function(k){return {id:k,name:k,description:agentDefs[k][0],instructions:agentDefs[k][1],enabled:true};});},select:function(task){var t=String(task).toLowerCase(),map={frontend:/html|css|ui|frontend|design/,backend:/api|server|backend|php/,database:/database|sql|schema|firebase/,security:/security|auth|permission|secret/,debugger:/bug|error|debug|fix/,tester:/test|verify|check/,documentation:/docs|readme/};return Object.keys(map).filter(function(k){return map[k].test(t);});}};
  var Skills={list:function(){return Object.keys(skills).map(function(k){return {name:k,description:skills[k].slice(0,110)};});},load:function(name){if(!skills[name])err('Skill not found');return skills[name];},add:function(name,text){skills[name]=String(text);save('customSkills',skills);},remove:function(name){delete skills[name];save('customSkills',skills);}};
  Object.assign(skills,meta('customSkills',{}));
  // --- Production hardening and the single, model-directed runtime -----------------
  var agentFiles = {};
  Object.keys(agentDefs).forEach(function(id){
    var raw=St.files[META+'agents/'+id+'.md'];
    if(raw){agentFiles[id]=raw;var body=raw.replace(/^---[\s\S]*?---\s*/,'').trim();if(body)agentDefs[id][1]=body;}
  });
  function frontmatter(raw){var m=/^---\s*\n([\s\S]*?)\n---\s*\n?([\s\S]*)$/.exec(String(raw||''));var meta={};if(!m)return {meta:meta,instructions:String(raw||'')};m[1].split(/\r?\n/).forEach(function(l){var x=/^([\w-]+):\s*(.*)$/.exec(l);if(x)meta[x[1]]=x[2].replace(/^['"]|['"]$/g,'');});return {meta:meta,instructions:m[2]||''};}
  function compact(text,budget){text=String(text||'');budget=Math.max(500,budget||5000);if(text.length<=budget)return text;var head=Math.floor(budget*.62),tail=Math.floor(budget*.28);return text.slice(0,head)+'\n\n[... compacted '+(text.length-budget)+' characters ...]\n\n'+text.slice(-tail);}
  function event(eventName,payload){hooks.slice().forEach(function(h){if(h.event===eventName){try{var r=h.fn(eventName,payload||{});if(r&&typeof r.then==='function')r.catch(function(e){console.warn('Hook',eventName,e);});}catch(e){console.warn('Hook',eventName,e);}}});}
  async function runHooks(eventName,payload,blocking){for(var i=0;i<hooks.length;i++){var h=hooks[i];if(h.event!==eventName)continue;try{var r=await h.fn(eventName,payload||{});if(blocking&&(r===false||r&&r.block))err(r.reason||('Blocked by '+eventName+' hook'));}catch(e){if(blocking)throw e;console.warn('Hook failed',eventName,e);}}}
  // Every tool goes through the same permission and hook boundary.
  // execute() already enforces PreToolUse/PostToolUse hooks and permission checks.
  // Structured JSON and lightweight text calls are both accepted, including nested arguments.
  parseTool=function(input){
    var text=String(input||'').trim(),candidates=[text],fm=/```(?:tool|json)\s*([\s\S]*?)```/ig,m;
    while((m=fm.exec(text)))candidates.unshift(m[1].trim());
    for(var z=0;z<candidates.length;z++){
      var raw=candidates[z],start=raw.indexOf('{');
      if(start>=0&&/^\s*\{\s*"(?:tool|name|function)"/.test(raw.slice(start))){
        var depth=0,str=false,esc=false,end=-1;
        for(var i=start;i<raw.length;i++){var ch=raw[i];if(str){if(esc)esc=false;else if(ch==='\\')esc=true;else if(ch==='"')str=false;}else{if(ch==='"')str=true;else if(ch==='{')depth++;else if(ch==='}'&&--depth===0){end=i+1;break;}}}
        if(end>start){try{var o=JSON.parse(raw.slice(start,end)),nm=o.tool||o.name||o.function&&o.function.name,ar=o.arguments||o.args||o.function&&o.function.arguments||{};if(typeof ar==='string')ar=JSON.parse(ar);if(nm)return {name:nm,args:ar};}catch(e){return {invalid:'Invalid structured tool JSON: '+e.message};}}
      }
      var lines=raw.split(/\r?\n/);
      for(var j=0;j<lines.length;j++){
        var x=/^\s*TOOL:\s*([\w-]+)(?:\s*\|\s*(.*))?\s*$/i.exec(lines[j]);if(!x)continue;
        var rest=x[2]||'',args={},n=x[1];
        try{
          if(rest.trim().charAt(0)==='{')args=JSON.parse(rest);
          else if(rest){var bits=rest.split('|');
            if(['read_file','delete_file','get_file_info','check_syntax'].indexOf(n)>=0)args.path=bits[0].trim();
            else if(['write_file','edit_file'].indexOf(n)>=0){args.path=bits.shift().trim();args.content=bits.length?bits.join('|'):lines.slice(j+1).join('\n');args.content=String(args.content||'').replace(/^```[a-z0-9_-]*\s*/i,'').replace(/\s*```\s*$/,'');}
            else if(['search_files','search_text'].indexOf(n)>=0)args.query=rest;
            else if(n==='run_command')args.command=rest;
            else if(n==='load_skill')args.name=rest;
          }
        }catch(e){return {invalid:e.message};}
        return {name:n,args:args};
      }
    }
    return null;
  };
  async function specialist(id,task,signal,readOnly){
    var profile=Agents.list().filter(function(x){return x.id===id&&x.enabled;})[0];if(!profile)err('Unknown or disabled specialist agent: '+id);if(signal&&signal.aborted)throw RC.llm.AbortErr();
    var cfg=frontmatter(St.files[META+'agents/'+id+'.md']||''),saved=(RC.settings.agents||{})[id]||{},system=saved.prompt||cfg.instructions||profile.instructions;
    var safeRead=['list_files','read_file','search_files','search_text','get_file_info','check_syntax','get_project_info','rag_search','search_dependencies'];
    var allAllowed=Object.keys(registry).filter(function(x){return !['run_command','delegate_agent','delegate_agents'].includes(x);});
    var configured=(profile.tools==='*'?safeRead:String(profile.tools).split(',').map(function(x){return x.trim();}).filter(function(x){return allAllowed.indexOf(x)>=0;}));if(readOnly)configured=configured.filter(function(x){return safeRead.indexOf(x)>=0;});
    var transcript=[],ctx='SPECIALIST TASK\n'+task+'\n\nPROJECT FILES\n'+St.fileList().join('\n')+'\n\nPROJECT MEMORY\n'+compact(await Memory.load(),900)+'\n\nYou are an independent specialist with a separate context. You may use only these tools: '+configured.join(', ')+'\n'+toolManifest(configured)+'\nEvery call passes through the central permission manager. Never bypass DENY. Use TOOL: name | JSON or return FINAL: findings. Do not modify files unless your configured tool list explicitly permits the requested modification.';
    for(var i=0;i<5;i++){if(signal&&signal.aborted)throw RC.llm.AbortErr();var out=await (RC.modelRouter?RC.modelRouter.run:RC.llm.run)({agent:id,system:'You are ReCode '+id+' specialist. '+system,prompt:compact(ctx,Math.max(1800,(+RC.settings.ctxChars||7000)-1000)),maxTokens:650,signal:signal});var call=parseTool(out);if(!call)return String(out||'').replace(/^\s*FINAL:\s*/i,'').trim();if(call.invalid){ctx='Invalid tool call: '+call.invalid+'. Correct it or return FINAL.';continue;}if(configured.indexOf(call.name)<0){ctx='Tool '+call.name+' is not allowed for this specialist. Allowed: '+configured.join(', ')+'. Return another tool call or FINAL.';continue;}try{var result=await execute(call.name,call.args);transcript.push({tool:call.name,args:call.args,result:result});ctx='Tool result '+call.name+': '+compact(JSON.stringify(result),1400)+'\n\nSpecialist task: '+task+'\nContinue investigation or return FINAL.';}catch(e){ctx='Tool error '+call.name+': '+e.message+'\nChoose another read-only tool or return FINAL.';}}
    return 'Specialist iteration limit reached. Findings collected: '+transcript.length+' read-only tool calls. '+compact(JSON.stringify(transcript),900);
  }
  register('delegate_agents','Run independent specialist analyses in parallel',{agents:'array',task:'string'},'delegate_agent',async function(a){var available=Agents.list().filter(function(x){return x.enabled;}).map(function(x){return x.id;});var ids=(a.agents||[]).filter(function(x){return available.indexOf(x)>=0;}).slice(0,4);if(!ids.length)err('Choose at least one valid specialist');var out=await Promise.all(ids.map(async function(id){try{return {agent:id,result:await specialist(id,a.task||'',null,true)};}catch(e){return {agent:id,error:e.message};}}));return out;});
  register('select_agents','Select relevant specialists for a task',{task:'string'},'read_file',async function(a){return Agents.select(a.task||'');});
  register('list_skills','List skill names and short descriptions',{},'read_file',async function(){return Skills.list();});
  register('list_agents','List available specialist agents',{},'read_file',async function(){return Agents.list();});
  register('checkpoint_list','List project checkpoints',{},'read_file',async function(){return Checkpoints.list().map(function(x){return {id:x.id,label:x.label,time:x.time,files:Object.keys(x.files||{}).length};});});
  register('todo_list','List project tasks',{},'read_file',async function(){return Tasks.get();});
  register('search_text','Search text in project files',{query:'string'},'search_text',async function(a){var q=String(a.query||'').toLowerCase(),out=[];St.fileList().forEach(function(p){var lines=String(St.files[p]||'').split('\n');lines.forEach(function(l,i){if(l.toLowerCase().indexOf(q)>=0&&out.length<100)out.push({path:p,line:i+1,text:U.clip(l,260)});});});return out;});
  // Project memory and skills are persisted in the workspace, not only in volatile UI state.
  Memory.load=async function(){var keys=['project','local'],chunks=[];['global','user'].forEach(function(k){var v=meta('memory.'+k,'');if(v)chunks.push('# '+k+' memory\n'+v);});if(St.files['RECODE.md'])chunks.push('# RECODE.md\n'+St.files['RECODE.md']);for(var i=0;i<keys.length;i++){var p=META+'memory/'+keys[i]+'.md';if(St.files[p])chunks.push('# '+keys[i]+' memory\n'+St.files[p]);}return compact(chunks.join('\n\n'),3600);};
  Memory.update=async function(level,text){if(!['global','user','project','local'].includes(level))err('Invalid memory level');if(level==='global'||level==='user')save('memory.'+level,String(text||''));else await St.putFile(META+'memory/'+level+'.md',String(text||''));return true;};
  Skills.list=function(){var all={};Object.keys(skills).forEach(function(k){all[k]=skills[k];});St.fileList().forEach(function(p){var m=/^\.recode\/skills\/([^/]+)\/SKILL\.md$/i.exec(p);if(m)all[m[1]]=String(St.files[p]).replace(/^---[\s\S]*?---\s*/,'').slice(0,500);});return Object.keys(all).map(function(k){return {name:k,description:all[k].slice(0,140),content:all[k]};});};
  Skills.load=async function(name){var p=META+'skills/'+name+'/SKILL.md';if(St.files[p])return St.files[p];if(!skills[name])err('Skill not found: '+name);return '# '+name+'\n'+skills[name];};
  Skills.add=async function(name,text){if(!/^[a-z0-9-]{2,50}$/i.test(name))err('Invalid skill name');await St.putFile(META+'skills/'+name+'/SKILL.md',String(text||''));skills[name]=String(text||'').slice(0,500);return name;};
  Skills.remove=async function(name){var p=META+'skills/'+name+'/SKILL.md';if(St.files[p]!==undefined)await St.delFile(p);delete skills[name];return true;};
  Agents.list=function(){return Object.keys(agentDefs).map(function(k){var f=frontmatter(St.files[META+'agents/'+k+'.md']||''),d=agentDefs[k];return {id:k,name:f.meta.name||k,description:f.meta.description||d[0],instructions:f.instructions||d[1],tools:f.meta.tools||'*',custom:customAgentIds.indexOf(k)>=0,enabled:meta('disabledAgents',[]).indexOf(k)<0&&(!RC.settings.agents||!RC.settings.agents[k]||RC.settings.agents[k].on!==false)};});};
  Agents.select=function(task){var t=String(task||'').toLowerCase(),rules={planner:/plan|complex|project|build|create|develop|implement/,explorer:/analy[sz]e|inspect|understand|explore|existing|project/,researcher:/latest|research|documentation|api|library|version/,architect:/architect|design|structure|refactor|migrat/,frontend:/html|css|ui|frontend|design|responsive/,backend:/api|server|backend|php|endpoint/,database:/database|sql|schema|firebase|storage/,debugger:/bug|error|debug|crash|fail/,fixer:/fix|repair|resolve|broken/,tester:/test|verify|check|validate/,reviewer:/review|quality|audit/,security:/security|auth|permission|secret|vulnerab/,optimizer:/performance|optimi[sz]e|speed/,documentation:/docs|readme|document/};return Object.keys(rules).filter(function(k){return rules[k].test(t)&&meta('disabledAgents',[]).indexOf(k)<0&&(!RC.settings.agents||!RC.settings.agents[k]||RC.settings.agents[k].on!==false);});};
  Tasks.add=function(title,parent){var a=Tasks.get();var item={id:U.uid('task'),title:String(title||'Untitled task'),parent:parent||null,status:'PENDING',updated:Date.now()};a.push(item);return Tasks.save(a);};
  Tasks.subtask=function(parent,title){var a=Tasks.get();if(!a.some(function(x){return x.id===parent;}))err('Parent task not found');return Tasks.add(title,parent);};
  Tasks.update=function(id,status){var a=Tasks.get(),t=a.filter(function(x){return x.id===id;})[0];if(!t)err('Task not found');if(!['PENDING','IN_PROGRESS','COMPLETED','BLOCKED','FAILED'].includes(status))err('Invalid task status');t.status=status;t.updated=Date.now();return Tasks.save(a);};
  Checkpoints.diff=function(id){var cp=Checkpoints.list().filter(function(x){return x.id===id;})[0];if(!cp)err('Checkpoint not found');var a=cp.files||{},b={};Object.keys(St.files).forEach(function(k){if(k.indexOf(META+'checkpoints/')!==0)b[k]=St.files[k];});var all={};Object.keys(a).concat(Object.keys(b)).forEach(function(k){if(a[k]!==b[k])all[k]={before:a[k]===undefined?null:a[k],after:b[k]===undefined?null:b[k]};});return all;};
  // Context compaction keeps user intent and durable state while trimming noisy tool output.
  var Context={budget:function(){return Math.max(1800,(+RC.settings.ctxChars||7000));},compact:compact,summary:function(request,transcript){var rows=transcript.slice(-8).map(function(x){return x.tool+'('+JSON.stringify(x.args)+') => '+compact(JSON.stringify(x.result),260);});return compact('Original request: '+request+'\nCurrent files: '+St.fileList().join(', ')+'\nRecent tool history:\n'+rows.join('\n'),this.budget()-700);}};
  // The previous fixed-sequence orchestration has been removed.
  var agentLoop;
  // Complete the single-agentic architecture: specialist lifecycle, structured tools,
  // persistent controls, event hooks and bounded context recovery.
  var HOOK_EVENTS=['SessionStart','SessionEnd','UserPromptSubmit','PreToolUse','PostToolUse','Stop','PreCompact'];
  var skillEnabled=meta('disabledSkills',[]);
  // Global/user memory survives project switches; project/local memory stays with the workspace.
  Memory.load=async function(){var chunks=[],g=meta('memory.global',''),u=meta('memory.user','');if(!g&&St.files[META+'memory/global.md']){g=St.files[META+'memory/global.md'];save('memory.global',g);}if(!u&&St.files[META+'memory/user.md']){u=St.files[META+'memory/user.md'];save('memory.user',u);}if(St.files['RECODE.md'])chunks.push('# Project guide\n'+St.files['RECODE.md']);if(g)chunks.push('# Global managed memory\n'+g);if(u)chunks.push('# User memory\n'+u);['project','local'].forEach(function(k){var p=META+'memory/'+k+'.md';if(St.files[p])chunks.push('# '+k+' memory\n'+St.files[p]);});return compact(chunks.join('\n\n'),3600);};
  Memory.update=async function(level,text){text=String(text||'');if(level==='global'||level==='user'){save('memory.'+level,text);return true;}if(level==='project'||level==='local'){await St.putFile(META+'memory/'+level+'.md',text);return true;}err('Invalid memory level');};
  Agents.enable=function(id,on){var a=meta('disabledAgents',[]).filter(function(x){return x!==id;});if(!on)a.push(id);save('disabledAgents',a);return on;};
  Skills.enable=function(name,on){var a=meta('disabledSkills',[]).filter(function(x){return x!==name;});if(!on)a.push(name);save('disabledSkills',a);skillEnabled=a;return on;};
  Skills.export=function(name){return St.files[META+'skills/'+name+'/SKILL.md']||null;};
  Skills.import=async function(name,raw){return Skills.add(name,raw);};
  var originalSkillList=Skills.list;
  Skills.list=function(){return originalSkillList().map(function(x){x.enabled=skillEnabled.indexOf(x.name)<0;return x;});};
  var originalSkillLoad=Skills.load;
  Skills.load=async function(name){if(skillEnabled.indexOf(name)>=0)err('Skill is disabled: '+name);return originalSkillLoad(name);};
  Tasks.clear=function(){Tasks.save([]);return true;};
  Checkpoints.list=function(){var out=[];St.fileList().forEach(function(p){if(!/^\.recode\/checkpoints\/[^/]+\.json$/.test(p))return;try{var cp=JSON.parse(St.files[p]);cp.storagePath=p;out.push(cp);}catch(e){console.warn('Invalid checkpoint',p,e);}});if(!out.length)out=meta('checkpoints.'+(St.cur&&St.cur.id),[]);return out.sort(function(a,b){return a.time-b.time;});};
  Checkpoints.create=async function(label){var id=U.uid('cp'),files={};Object.keys(St.files).forEach(function(p){if(p.indexOf('.recode/checkpoints/')!==0)files[p]=St.files[p];});var cp={id:id,label:label||'Checkpoint',time:Date.now(),files:files};var p=META+'checkpoints/'+id+'.json';await St.putFile(p,JSON.stringify(cp));var all=Checkpoints.list();if(all.length>10){for(var i=0;i<all.length-10;i++)if(all[i].storagePath)await St.delFile(all[i].storagePath);}return cp;};
  Checkpoints.restore=async function(id){var cp=Checkpoints.list().filter(function(x){return x.id===id;})[0];if(!cp)err('Checkpoint not found');if(currentMode==='PLAN')err('Restore is unavailable in Plan mode');if(!RC.ui||!RC.ui.confirm||!await RC.ui.confirm('Restore checkpoint "'+cp.label+'"? Current project files will be replaced.','Restore',true))err('Checkpoint restore cancelled');await Checkpoints.create('Before restore');var current=St.fileList().filter(function(p){return p.indexOf('.recode/checkpoints/')!==0;});for(var i=0;i<current.length;i++)await St.delFile(current[i]);var names=Object.keys(cp.files||{});for(var j=0;j<names.length;j++)await St.putFile(names[j],cp.files[names[j]]);return 'Restored '+cp.label;};
  Context.layers=function(request,transcript,extra){
    var raw=String(extra||''),budget=this.budget(),requestBlock='ORIGINAL USER REQUEST (preserve exactly):\n'+String(request||'');
    var snippets=(transcript||[]).slice(-5).map(function(x){return x.tool+': '+compact(JSON.stringify(x.result||x.error),180);}).join('\n');
    var durable='PERSISTED SESSION SUMMARY:\n'+compact(St.files[META+'memory/session.md']||'',520)+'\n\nPROJECT FILES:\n'+St.fileList().slice(0,140).join('\n')+'\n\nPROJECT GUIDE:\n'+compact(St.files['RECODE.md']||'',520)+'\n\nPROJECT MEMORY:\n'+compact(St.files[META+'memory/project.md']||'',360)+'\n\nRECENT TOOL RESULTS:\n'+snippets;
    var requestLimit=Math.min(requestBlock.length,Math.floor(budget*.48));if(requestBlock.length>requestLimit)requestBlock=compact(requestBlock,requestLimit);
    var remaining=Math.max(500,budget-requestBlock.length-80);durable=compact(durable,Math.floor(remaining*.55));raw=compact(raw,Math.floor(remaining*.42));
    var result=requestBlock+'\n\n'+durable+'\n\nCURRENT STATE:\n'+raw;
    if(result.length>budget)result=requestBlock+'\n\n'+compact(durable+'\n'+raw,Math.max(300,budget-requestBlock.length-60));
    return result;
  };
  Context.persist=async function(request,transcript,progress){var summary='## Session '+new Date().toISOString()+'\n\nOriginal request: '+request+'\n\nProgress: '+(progress||'')+'\n\nCurrent project files: '+St.fileList().filter(function(p){return p.indexOf(META+'checkpoints/')!==0;}).join(', ')+'\n\nPending tasks: '+JSON.stringify(Tasks.get())+'\n\nRecent tool calls:\n'+(transcript||[]).slice(-12).map(function(x){return '- '+x.tool+' '+JSON.stringify(x.args)+' => '+compact(JSON.stringify(x.result||x.error),180);}).join('\n');await St.putFile(META+'memory/session.md',compact(summary,5000));return true;};
  Context.load=async function(){return St.files[META+'memory/session.md']||'';};
  Context.aiSummarize=async function(request,transcript,signal){
    var raw='Original request (preserve): '+request+'\n\nCurrent files: '+St.fileList().filter(function(p){return p.indexOf(META+'checkpoints/')!==0;}).join(', ')+'\n\nTodo state: '+JSON.stringify(Tasks.get())+'\n\nTool history: '+(transcript||[]).slice(-14).map(function(x){return x.tool+' '+JSON.stringify(x.args)+' => '+compact(JSON.stringify(x.result||x.error),220);}).join('\n');
    try{var summary=await (RC.modelRouter?RC.modelRouter.run:RC.llm.run)({agent:'context',system:'Compress coding-session state for a small-context model. Preserve the exact user objective, constraints, architecture, decisions, modified files, verified results, errors, pending work and next action. Never invent facts. Output compact Markdown.',prompt:compact(raw,Math.max(1600,Context.budget())),maxTokens:420,signal:signal});await St.putFile(META+'memory/session.md',compact(summary,4200));return summary;}catch(e){await Context.persist(request,transcript,'AI summary unavailable: '+e.message);return Context.load();}
  };
  // Hooks are deterministic and fail closed for blocking pre-tool events.
  var hookOff=[];
  registerHook('PreToolUse',function(_,p){if(p.name==='run_command')return {block:true,reason:'Terminal execution is disabled in the Android sandbox.'};if(p.args){try{['path','from','to'].forEach(function(k){if(p.args[k])path(p.args[k]);});}catch(e){return {block:true,reason:e.message};}}return true;},'builtin-safety');
  async function emitHook(name,payload,blocking){if(HOOK_EVENTS.indexOf(name)<0)return;await runHooks(name,payload,!!blocking);}
  // Extra tools complete the project explorer and recovery surface.
  register('search_dependencies','Search likely dependency/import references',{query:'string'},'search_text',async function(a){var q=String(a.query||'').toLowerCase(),out=[];St.fileList().forEach(function(n){if(!/\.(js|mjs|cjs|ts|tsx|jsx|py|php|kt|java|html|json)$/.test(n))return;var lines=String(St.files[n]||'').split('\n');lines.forEach(function(l,i){if((l.toLowerCase().indexOf('import')>=0||l.toLowerCase().indexOf('require')>=0||l.toLowerCase().indexOf('include')>=0||l.toLowerCase().indexOf('from')>=0)&&l.toLowerCase().indexOf(q)>=0&&out.length<100)out.push({path:n,line:i+1,text:U.clip(l,260)});});});return out;});
  register('get_project_info','Summarize project files and likely technology stack',{},'read_file',async function(){var fs=St.fileList(),ext={};fs.forEach(function(n){var m=/\.([^.\/]+)$/.exec(n);if(m)ext[m[1].toLowerCase()]=(ext[m[1].toLowerCase()]||0)+1;});return {project:St.cur&&St.cur.name||'Project',fileCount:fs.length,extensions:ext,rootFiles:fs.filter(function(n){return n.indexOf('/')<0;}).slice(0,80)};});
  register('checkpoint_diff','Compare a checkpoint with current files',{id:'string'},'read_file',async function(a){return Checkpoints.diff(a.id);});
  register('todo_subtask','Add a child task',{parent:'string',title:'string'},'edit_file',async function(a){return Tasks.subtask(a.parent,a.title);});
  register('rag_search','Retrieve relevant project/documentation passages',{query:'string'},'read_file',async function(a){if(!RC.rag||!RC.rag.search)err('RAG search is unavailable');return RC.rag.search(a.query,{k:RC.settings.ragK||3});});
  // Rebuild tool manifests dynamically, with schemas suitable for text-only and structured models.
  function structuredManifest(){return Object.keys(registry).map(function(n){var t=registry[n];return {type:'function',function:{name:n,description:t.description,parameters:t.remoteSchema||{type:'object',properties:Object.keys(t.parameters||{}).reduce(function(o,k){o[k]={type:(t.parameters[k]||'string')};return o;},{}),additionalProperties:false}}};});}
  function eventHooks(run,request){return Promise.all([emitHook('SessionStart',{run:run},false),emitHook('UserPromptSubmit',{request:request,project:St.cur},false)]);}
  // Replace the loop with a resumable model-directed loop; only one source of orchestration exists.
  async function completeAgentLoop(run,request,opts){
    opts=opts||{};var max=Math.min(MAX_ITER,Math.max(1,+opts.maxIterations||20)),transcript=[],memory=await Memory.load(),agentMeta=Agents.list(),skillMeta=Skills.list(),todo=Tasks.get();
    run.todo=todo;run.context=run.context||{};run.context.request=request;run.context.transcript=transcript;run.context.started=Date.now();
    await St.putFile(META+'memory/session.md','## Active session\nStarted: '+new Date().toISOString()+'\n\nOriginal user request (verbatim):\n'+request+'\n\nStatus: in progress.');
    await eventHooks(run,request);var system=(opts.system||'You are ReCode, an offline-first autonomous software engineering agent. You alone decide the next tool or specialist. Inspect before editing. Plan first for complex work. Use tools, delegate specialists when useful, load only relevant skills, verify all changes, and report limitations honestly. Never claim tests passed without test evidence.')+'\n\nTOOL FORMAT: TOOL: tool_name | {"key":"value"}\nSTRUCTURED FORMAT: {"tool":"tool_name","arguments":{...}}\nFINAL FORMAT: FINAL: answer\nOne tool call per response. Continue until genuinely complete. DENY always overrides all permissions.\n\nTOOLS:\n'+toolManifest(opts.tools)+'\n\nAGENTS:\n'+agentMeta.filter(function(x){return x.enabled;}).map(function(x){return x.id+': '+x.description+' [tools '+x.tools+']';}).join('\n')+'\n\nSKILLS (metadata only; call load_skill when relevant):\n'+skillMeta.filter(function(x){return x.enabled;}).map(function(x){return x.name+': '+x.description;}).join('\n');
    var context='ORIGINAL USER REQUEST:\n'+request+'\n\nPROJECT FILES:\n'+St.fileList().join('\n')+'\n\nPROJECT MEMORY:\n'+compact(memory,1600)+'\n\nSESSION MEMORY:\n'+compact(await Context.load(),700)+'\n\nTASKS:\n'+JSON.stringify(todo)+'\n\nStart by deciding whether to plan, inspect, delegate, or act.';
    try{
      for(var i=0;i<max;i++){
        if(run.ctl.signal.aborted)throw RC.llm.AbortErr();
        var step={id:U.uid('step'),agent:'main',title:'Agent iteration '+(i+1),kind:'agent',status:'running',t0:Date.now(),log:[]};run.steps.push(step);RC.bus.emit('run',run);
        var prompt=Context.layers(request,transcript,context)+'\n\nCURRENT AVAILABLE TOOLS (refresh after MCP discovery):\n'+toolManifest(opts.tools);
        var callOptions={agent:'main',system:system,prompt:prompt,maxTokens:Math.min(1600,+opts.maxTokens||1150),signal:run.ctl.signal,onPhase:function(v){step.phase=v;RC.bus.emit('run',run);}};
        var chosenRoute=RC.modelRouter?RC.modelRouter.choose(callOptions):{provider:RC.settings.provider};callOptions.provider=chosenRoute.provider;step.route=chosenRoute;
        if(chosenRoute.provider==='api'&&RC.settings.api.toolCalling!==false)callOptions.tools=toolSchemas();
        var out;try{out=await (RC.modelRouter?RC.modelRouter.run:RC.llm.run)(callOptions);}catch(modelError){if(callOptions.tools&&/tool|function|400|unsupported|invalid/i.test(modelError.message||'')){RC.settings.api.toolCalling=false;RC.saveSettings();delete callOptions.tools;out=await (RC.modelRouter?RC.modelRouter.run:RC.llm.run)(callOptions);}else throw modelError;}
        step.out=out;step.status='done';step.t1=Date.now();var call=parseTool(out);
        if(!call){run.final=String(out||'').replace(/^\s*FINAL:\s*/i,'').trim()||'The model returned an empty response.';if(RC.advanced&&RC.advanced.reviewFinal)run.final=await RC.advanced.reviewFinal(request,run.final,run.ctl.signal);await Context.persist(request,transcript,run.final);await emitHook('Stop',{run:run,final:run.final},false);await emitHook('SessionEnd',{run:run},false);return run.final;}
        if(call.invalid){step.status='error';step.note=call.invalid;context='INVALID TOOL CALL: '+call.invalid+'\nCorrect the arguments and try again.';continue;}
        step.kind='tool';step.title='Tool: '+call.name;var started=Date.now();
        try{var result=await execute(call.name,call.args);var rec={tool:call.name,args:call.args,result:result,duration:Date.now()-started};transcript.push(rec);run.context.transcript=transcript;step.log.push('Result: '+compact(JSON.stringify(result),1200));run.files=St.fileList().filter(function(n){return n.indexOf('.recode/')!==0;});context='TOOL RESULT\n'+call.name+'('+JSON.stringify(call.args)+')\n'+compact(JSON.stringify(result),1800)+'\n\nOriginal request: '+request+'\nProgress: '+transcript.length+' tool calls completed. Choose the next action or FINAL.';
        }catch(e){step.status='error';step.note=e.message;step.log.push('Error: '+e.message);transcript.push({tool:call.name,args:call.args,error:e.message});context='TOOL ERROR\n'+call.name+': '+e.message+'\nDo not repeat blindly. Choose a safe alternative or explain the blocker.';}
        if(i%4===3){await emitHook('PreCompact',{request:request,transcript:transcript},false);await Context.aiSummarize(request,transcript,run.ctl.signal);}
        RC.bus.emit('run',run);
      }
      run.final='Stopped at the configured iteration limit ('+max+'). '+transcript.length+' tool calls were attempted; remaining work is not verified.';await Context.persist(request,transcript,run.final);await emitHook('Stop',{run:run,final:run.final},false);await emitHook('SessionEnd',{run:run},false);return run.final;
    }catch(e){if(e&&e.name==='AbortError')await emitHook('Stop',{run:run,reason:'cancelled'},false);await emitHook('SessionEnd',{run:run,error:e.message},false);throw e;}
  }
  agentLoop=completeAgentLoop;
  // Persist and expose permission controls without allowing a project rule to override DENY.
  function setPermission(tool,value,project,prefix){if(!registry[tool]||!['ALLOW','ASK','DENY'].includes(value))err('Invalid tool permission');if(project){permissions.projects[project]=permissions.projects[project]||{};if(prefix){permissions.projects[project].paths=permissions.projects[project].paths||{};var normalized=path(prefix),key=String(prefix).replace(/\\/g,'/').endsWith('/')?normalized+'/':normalized;permissions.projects[project].paths[key]=permissions.projects[project].paths[key]||{};permissions.projects[project].paths[key][tool]=value;}else permissions.projects[project][tool]=value;}else permissions.global[tool]=value;save('permissions',permissions);return value;}
  function permissionHistory(){return history.slice();}
  function clearProjectPermission(tool,project){if(!project||!permissions.projects[project])return false;delete permissions.projects[project][tool];if(permissions.projects[project].paths)Object.keys(permissions.projects[project].paths).forEach(function(k){delete permissions.projects[project].paths[k][tool];});save('permissions',permissions);return true;}
  function agentToolAllow(id,tool){var a=Agents.list().filter(function(x){return x.id===id;})[0];if(!a)return false;return a.tools==='*'||String(a.tools).split(',').map(function(x){return x.trim();}).indexOf(tool)>=0;}
  // Native UI compatibility: all execution now enters this agent loop; no legacy pipeline.
  var customAgentIds=meta('customAgents',[]);
  // Discover persisted custom agent Markdown files when a project is reopened.
  St.fileList().forEach(function(filePath){var match=/^\.recode\/agents\/([a-z0-9_-]+)\.md$/i.exec(filePath);if(match&&!agentDefs[match[1]]){var fm=frontmatter(St.files[filePath]);agentDefs[match[1]]=[fm.meta.description||'Custom specialist',fm.instructions||'Follow project instructions and report evidence.'];if(customAgentIds.indexOf(match[1])<0)customAgentIds.push(match[1]);}});
  save('customAgents',customAgentIds);
  RC.agents={def:{},order:Object.keys(agentDefs),fit:function(b,parts){return compact(parts.filter(function(x){return x&&x.t;}).map(function(x){return x.t;}).join('\n\n'),b);},stripThink:function(t){return String(t||'').replace(/<think>[\s\S]*?(<\/think>|$)/gi,'').trim();},extractCode:function(t){var m=/```[\w-]*\s*([\s\S]*?)```/.exec(String(t||''));return {code:m?m[1]:String(t||''),weak:!m};}};
  Object.keys(agentDefs).forEach(function(id){RC.agents.def[id]={name:id.charAt(0).toUpperCase()+id.slice(1),icon:'spark',desc:agentDefs[id][0],system:agentDefs[id][1],on:true,locked:false,custom:customAgentIds.indexOf(id)>=0};});
  RC.agentCfg=function(id){var a=(RC.settings.agents||{})[id]||{};return {on:a.on!==false&&meta('disabledAgents',[]).indexOf(id)<0,max:a.max||1100,prompt:a.prompt||agentDefs[id]&&agentDefs[id][1]||''};};
  Agents.list=function(){St.fileList().forEach(function(fp){var m=/^\.recode\/agents\/([a-z0-9_-]+)\.md$/i.exec(fp);if(m&&!agentDefs[m[1]]){var fm=frontmatter(St.files[fp]);agentDefs[m[1]]=[fm.meta.description||'Custom specialist',fm.instructions||'Follow project instructions and report evidence.'];if(customAgentIds.indexOf(m[1])<0)customAgentIds.push(m[1]);if(RC.agents&&RC.agents.def&&!RC.agents.def[m[1]]){RC.agents.order.push(m[1]);RC.agents.def[m[1]]={name:fm.meta.name||m[1],icon:'spark',desc:agentDefs[m[1]][0],system:agentDefs[m[1]][1],on:true,locked:false,custom:true};}}});save('customAgents',customAgentIds);return Object.keys(agentDefs).map(function(id){var f=frontmatter(St.files[META+'agents/'+id+'.md']||''),d=agentDefs[id];if(f.instructions){d[1]=f.instructions;if(RC.agents&&RC.agents.def&&RC.agents.def[id])RC.agents.def[id].system=f.instructions;}return {id:id,name:f.meta.name||id,description:f.meta.description||d[0],instructions:f.instructions||d[1],tools:f.meta.tools||agentTools[id]||'*',custom:customAgentIds.indexOf(id)>=0,enabled:meta('disabledAgents',[]).indexOf(id)<0&&(!RC.settings.agents||!RC.settings.agents[id]||RC.settings.agents[id].on!==false)};});};
  Agents.select=function(task){var words=String(task||'').toLowerCase().match(/[a-z0-9]+/g)||[],stop={the:1,and:1,'for':1,with:1,from:1,that:1,this:1,into:1,make:1,build:1,create:1,please:1};var ranked=Agents.list().filter(function(a){return a.enabled;}).map(function(a){var text=(a.id+' '+a.name+' '+a.description+' '+a.instructions).toLowerCase(),score=0;words.forEach(function(w){if(w.length>2&&!stop[w]&&text.indexOf(w)>=0)score+=w.length>6?2:1;});return {id:a.id,score:score};}).filter(function(x){return x.score>0;}).sort(function(a,b){return b.score-a.score;});if(/\b(plan|complex|project|implement|develop|build)\b/i.test(task||'')){var planner=ranked.filter(function(x){return x.id==='planner';});if(planner.length)ranked=planner.concat(ranked.filter(function(x){return x.id!=='planner';}));}return ranked.slice(0,6).map(function(x){return x.id;});};
  Agents.add=async function(id,raw){id=String(id||'').toLowerCase();if(!/^[a-z][a-z0-9-]{1,35}$/.test(id))err('Invalid agent id');if(agentDefs[id])err('Agent already exists');var f=frontmatter(raw);if(!f.meta.name||!f.meta.description)err('Agent Markdown needs name and description frontmatter');agentDefs[id]=[f.meta.description,f.instructions||'Follow project rules, inspect before editing and verify results.'];if(customAgentIds.indexOf(id)<0)customAgentIds.push(id);save('customAgents',customAgentIds);await St.putFile(META+'agents/'+id+'.md',String(raw));if(RC.agents){RC.agents.order.push(id);RC.agents.def[id]={name:f.meta.name,icon:'spark',desc:f.meta.description,system:f.instructions||'',on:true,locked:false,custom:true};}return id;};
  Agents.edit=async function(id,raw){if(!agentDefs[id])err('Unknown agent');var f=frontmatter(raw);if(!f.meta.name||!f.meta.description)err('Agent Markdown needs name and description frontmatter');agentDefs[id]=[f.meta.description,f.instructions||''];await St.putFile(META+'agents/'+id+'.md',String(raw));if(RC.agents&&RC.agents.def[id]){RC.agents.def[id].name=f.meta.name;RC.agents.def[id].desc=f.meta.description;RC.agents.def[id].system=f.instructions||'';}return id;};
  Agents.remove=async function(id){if(customAgentIds.indexOf(id)<0)err('Built-in agents cannot be deleted');delete agentDefs[id];customAgentIds=customAgentIds.filter(function(x){return x!==id;});save('customAgents',customAgentIds);if(RC.agents){RC.agents.order=RC.agents.order.filter(function(x){return x!==id;});delete RC.agents.def[id];}var p=META+'agents/'+id+'.md';if(St.files[p]!==undefined)await St.delFile(p);return true;};
  Agents.export=function(id){return St.files[META+'agents/'+id+'.md']||null;};
  Agents.import=async function(raw){var data;try{data=JSON.parse(raw);}catch(_){data=null;}if(data&&typeof data==='object'&&!data.name&&!data.description){var out=[];for(var key of Object.keys(data)){var md=data[key];var f2=frontmatter(md);if(!f2.meta.name){md='---\nname: '+key+'\ndescription: Imported specialist\n---\n\n'+String(md); }out.push(await Agents.import(md));}return out;}var f=frontmatter(raw),id=String(f.meta.id||f.meta.name||'').toLowerCase().replace(/[^a-z0-9-]/g,'-');if(!id)err('Agent id/name missing');if(agentDefs[id])return Agents.edit(id,raw);return Agents.add(id,raw);};
  Skills.export=function(name){return St.files[META+'skills/'+name+'/SKILL.md']||null;};
  Skills.import=async function(name,raw){return Skills.add(name,raw);};
  var Pipe={current:null,lastWasBuild:true,start:function(text,mode){var run={id:U.uid('run'),mode:mode||'auto',status:'running',title:U.clip(text.replace(/\s+/g,' '),70,'…'),t0:Date.now(),t1:0,steps:[],files:[],sources:[],final:'',zip:null,ctl:new AbortController()};Pipe.current=run;run.done=(async function(){try{await Memory.bootstrap();run.final=await agentLoop(run,text,{maxIterations:20});run.status='done';}catch(e){run.status=e&&e.name==='AbortError'?'stopped':'error';run.error=e.message;run.final=run.final||(run.status==='stopped'?'Stopped.':'Agent failed: '+e.message);}run.t1=Date.now();Pipe.current=null;RC.bus.emit('run',run);if(currentMode==='PLAN'&&run.status==='done'&&RC.ui&&RC.ui.sheet){var planEdit=U.h('textarea.in',{style:{width:'100%',minHeight:'260px',maxHeight:'55vh'},value:run.final});planEdit.value=run.final;var box=U.h('div',U.h('div.t2','Read-only plan. No project files have been changed. Edit the plan before approval if needed.'),planEdit,U.h('div.row',RC.ui.btn('Approve & execute','check','',function(){var approved=planEdit.value.trim();if(!approved)return RC.ui.toast('Plan is empty');RC.ui.closeSheet(true);currentMode='ASK';save('agentMode',currentMode);Pipe.start('Execute this user-approved plan. Original request: '+text+'\nApproved plan:\n'+approved,'auto');}),RC.ui.btn('Reject plan','close','ghost',function(){RC.ui.closeSheet(true);})));RC.ui.sheet({title:'Plan preview',body:box});}return run;})();RC.bus.emit('run',run);return run;},stop:function(){if(Pipe.current)Pipe.current.ctl.abort();},zipBytes:function(){return U.zip(St.fileList().map(function(p){return {name:p,data:St.files[p]};}));},zipName:function(){return U.slug(St.cur?St.cur.name:'project')+'.zip';}};
  RC.pipe=Pipe;
  registerHook('PostToolUse',function(_,p){if((p.name==='write_file'||p.name==='edit_file')&&p.args&&p.args.path)validateSyntax(p.args.path,p.args.content||'');return true;},'builtin-post-write-validation');
  registerHook('PreCompact',function(_,p){return Context.persist(p.request||'',p.transcript||[],'Context compaction checkpoint');},'builtin-context-checkpoint');
  registerHook('SessionStart',function(){return Memory.bootstrap();},'builtin-memory-bootstrap');
  RC.agentRuntime={registry:registry,register:register,execute:execute,parseTool:parseTool,agentLoop:agentLoop,toolManifest:toolManifest,toolSchemas:toolSchemas,permissions:permissions,setPermission:setPermission,clearProjectPermission:clearProjectPermission,permissionHistory:permissionHistory,registerHook:registerHook,hooks:hooks,hookEvents:HOOK_EVENTS,mode:function(v){if(v){if(!modes[v])err('Invalid mode');currentMode=v;save('agentMode',v);RC.bus.emit('settings');}return currentMode;},agents:Agents,skills:Skills,memory:Memory,tasks:Tasks,checkpoints:Checkpoints,context:Context,selectAgents:Agents.select,parseAgentConfig:frontmatter,specialist:specialist,structuredManifest:structuredManifest,exportAgent:function(id){return Agents.export(id);},exportSkill:function(id){return Skills.export(id);}};
  RC.bus.on('project',function(){Memory.bootstrap().catch(function(){});});
  // Runtime is the only orchestrator; legacy pipeline has been removed.
})();
