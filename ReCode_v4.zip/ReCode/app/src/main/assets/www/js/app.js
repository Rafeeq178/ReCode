/* ReCode - boot */
(function () {
  'use strict';
  var RC = window.RC, U = RC.u;
  function hideBoot() {
    var b = U.$('#boot'); b.classList.add('off');
    RC.native.call('ready');
    setTimeout(function () { b.remove(); }, 500);
  }
  U.$('#boot').innerHTML = RC.logo(96);
  RC.ui.applyTheme();
  RC.store.init().then(function () {
    RC.ui.init();
    // models picked/finished while the UI was not open
    var info = RC.native.models();
    if (!RC.settings.model && info.length) RC.set('model', info[0].name);
    setTimeout(hideBoot, 250);
  }).catch(function (e) {
    console.error(e);
    document.body.appendChild(U.h('pre', { style: { position: 'fixed', inset: 0, zIndex: 100, background: '#fff', color: '#900', padding: '20px', whiteSpace: 'pre-wrap' } }, 'ReCode failed to start:\n' + (e && e.stack || e)));
    RC.native.call('ready');
  });
  if (window.matchMedia) matchMedia('(prefers-color-scheme: dark)').addEventListener && matchMedia('(prefers-color-scheme: dark)').addEventListener('change', function () { if (RC.settings.theme === 'system') RC.ui.applyTheme(); });
})();
