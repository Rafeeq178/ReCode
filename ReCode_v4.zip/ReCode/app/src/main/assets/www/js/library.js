/* ReCode - Library tab: models (on-device GGUF / online API) and the knowledge base (RAG). */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var U = RC.u, h = U.h, UI = RC.ui, St = RC.store, N = RC.native;
  var root = U.$('#v-lib'), tab = 'models', body = h('div.scroll'), head = h('div', { style: { padding: '0 16px 6px' } });
  root.appendChild(head); root.appendChild(body);

  var HF = 'https://huggingface.co/';
  var CATALOG = [
    ['Qwen2.5 Coder 0.5B', 'Fastest coder · weak on big files', '~400 MB', HF + 'Qwen/Qwen2.5-Coder-0.5B-Instruct-GGUF/resolve/main/qwen2.5-coder-0.5b-instruct-q4_k_m.gguf', 400],
    ['Qwen2.5 Coder 1.5B', 'Best balance for phones', '~1.1 GB', HF + 'Qwen/Qwen2.5-Coder-1.5B-Instruct-GGUF/resolve/main/qwen2.5-coder-1.5b-instruct-q4_k_m.gguf', 1100],
    ['Qwen2.5 Coder 3B', 'Smarter code · needs 8 GB RAM', '~2.1 GB', HF + 'Qwen/Qwen2.5-Coder-3B-Instruct-GGUF/resolve/main/qwen2.5-coder-3b-instruct-q4_k_m.gguf', 2100],
    ['Qwen2.5 1.5B', 'General chat · multilingual', '~1.1 GB', HF + 'Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf', 1100],
    ['Llama 3.2 1B', 'Small general model', '~800 MB', HF + 'bartowski/Llama-3.2-1B-Instruct-GGUF/resolve/main/Llama-3.2-1B-Instruct-Q4_K_M.gguf', 800]
  ];
  var PRESETS = {
    openai: ['OpenAI', 'https://api.openai.com/v1', 'gpt-4o-mini'],
    openrouter: ['OpenRouter', 'https://openrouter.ai/api/v1', 'qwen/qwen-2.5-coder-32b-instruct'],
    groq: ['Groq', 'https://api.groq.com/openai/v1', 'llama-3.3-70b-versatile'],
    gemini: ['Gemini', 'https://generativelanguage.googleapis.com/v1beta/openai', 'gemini-2.0-flash'],
    deepseek: ['DeepSeek', 'https://api.deepseek.com/v1', 'deepseek-chat'],
    custom: ['Custom', '', '']
  };
  var info = {};

  function paintHead() {
    U.clear(head);
    head.appendChild(UI.seg([['models', 'Models'], ['kb', 'Knowledge']], tab, function (t) { tab = t; paint(); }));
  }

  // ------------------------------------------------------------------ models
  function models() {
    var S = RC.settings;
    info = N.info() || {};
    body.appendChild(UI.sec('Where the AI runs'));
    body.appendChild(UI.card(UI.seg([['local', 'On this phone'], ['api', 'Online API']], S.provider, function (v) { RC.set('provider', v); paint(); }),
      h('div.t2', { style: { marginTop: '10px' } }, S.provider === 'local' ? 'Fully offline. Each agent step reloads the GGUF model so it starts with a clean memory.' : 'Uses an OpenAI-compatible server over the internet. Your key stays on this device.')));
    if (S.provider === 'local') local(); else api();
  }
  function local() {
    var S = RC.settings, list = N.models(), dl = N.dl || [];
    if (info.ramMB) body.appendChild(h('div.t2', { style: { margin: '10px 4px 0' } }, 'Device: ' + (info.device || '') + ' · RAM ' + Math.round(info.ramMB / 102.4) / 10 + ' GB · free storage ' + Math.round((info.freeMB || 0) / 102.4) / 10 + ' GB · ' + (info.cores || '?') + ' cores'));
    body.appendChild(UI.sec('On this device'));
    if (!list.length) body.appendChild(h('div.card.empty', 'No model yet. Download a coder model or import a .gguf file.'));
    list.forEach(function (m) {
      var active = S.model === m.name, warn = info.ramMB && m.size / 1048576 > info.ramMB * 0.55;
      body.appendChild(h('div.card' + (active ? '' : ''), { style: active ? { borderColor: 'var(--brand)', borderWidth: '1.5px' } : {} },
        h('div.row', h('div.ico' + (active ? '.fill' : ''), { html: RC.i(active ? 'check' : 'cpu', 20) }),
          h('div.grow', h('div.t1.ell', m.name.replace(/\.gguf$/i, '')), h('div.t2', U.bytes(m.size) + (active ? ' · active' : ''))),
          active ? h('span.badge', 'Active') : null),
        warn ? h('div.t2', { style: { color: 'var(--danger)', margin: '8px 0 0' } }, 'Large for this phone\'s RAM - it may crash while loading.') : null,
        h('div.row', { style: { marginTop: '10px' } }, active ? null : UI.btn('Use', 'check', 'sm', function () { RC.set('model', m.name); paint(); UI.toast('Using ' + m.name); }),
          UI.btn('Delete', 'trash', 'sm danger', function () { UI.confirm('Delete ' + m.name + ' from this phone?', 'Delete', true).then(function (y) { if (y) { N.call('deleteModel', m.name); if (S.model === m.name) RC.set('model', ''); paint(); } }); }))));
    });
    dl.filter(function (d) { return d.state !== 2; }).forEach(function (d) {
      var pct = d.total > 0 ? Math.round(d.done * 100 / d.total) : 0;
      body.appendChild(h('div.card', h('div.row', h('div.ico', { html: RC.i('download', 20) }),
        h('div.grow', h('div.t1.ell', d.name), h('div.t2', d.state === 1 ? (d.err || 'Paused') + ' · ' + U.bytes(d.done) : U.bytes(d.done) + (d.total > 0 ? ' / ' + U.bytes(d.total) + ' · ' + pct + '%' : ''))),
        d.state === 0 ? UI.rbtn('pause', function () { N.call('pauseDownload', d.name); }, 'Pause', 'sm') : UI.rbtn('play', function () { N.call('resumeDownload', d.name, S.hfToken || ''); }, 'Resume', 'sm'),
        UI.rbtn('x', function () { N.call('cancelDownload', d.name); }, 'Cancel', 'sm')),
        h('div', { style: { height: '6px', background: 'var(--track)', borderRadius: '3px', marginTop: '10px', overflow: 'hidden' } }, h('div', { style: { height: '100%', width: pct + '%', background: 'var(--brand)' } }))));
    });
    body.appendChild(h('div.row', { style: { marginTop: '14px' } }, UI.btn('Hugging Face', 'download', '', catalog), UI.btn('From phone', 'plus', 'ghost', function () { if (!N.has) return UI.toast('Needs the ReCode app'); N.call('pickModel'); })));
  }
  function catalog() {
    var S = RC.settings, box = h('div');
    CATALOG.forEach(function (c) {
      var fname = c[3].split('/').pop(), have = N.models().some(function (m) { return m.name === fname; });
      var big = info.ramMB && c[4] > info.ramMB * 0.55;
      box.appendChild(h('div.row', { style: { padding: '8px 0' } }, h('div.ico', { html: RC.i('cpu', 19) }),
        h('div.grow', h('div.t1', c[0]), h('div.t2', c[1] + ' · ' + c[2] + (big ? ' · may not fit' : ''))),
        have ? h('span.badge', 'Installed') : UI.btn('Get', 'download', 'sm', function () { if (!N.has) return UI.toast('Needs the ReCode app'); N.call('downloadModel', c[3], fname, S.hfToken || ''); UI.closeSheet(true); UI.toast('Download started'); })));
    });
    var url = h('input', { type: 'url', placeholder: 'https://huggingface.co/.../model-Q4_K_M.gguf' });
    var tok = h('input', { type: 'password', placeholder: 'hf_… (only for private/gated models)', value: S.hfToken || '' });
    box.appendChild(h('div.hr'));
    box.appendChild(UI.field('Any .gguf link', url));
    box.appendChild(UI.field('Hugging Face token (optional)', tok));
    box.appendChild(UI.btn('Download link', 'download', '', function () {
      if (!url.value.trim()) return UI.toast('Paste a link first');
      RC.set('hfToken', tok.value.trim()); N.call('downloadModel', url.value.trim(), '', tok.value.trim()); UI.closeSheet(true);
    }));
    UI.sheet({ title: 'Download a model', body: box });
  }
  function tempSlider(A) {
    var b = h('b', String(A.temp)), i = h('input', { type: 'range', min: 0, max: 1, step: 0.1, value: A.temp, oninput: function () { A.temp = +i.value; b.textContent = i.value; }, onchange: function () { RC.saveSettings(); } });
    return h('div.setrow', h('div.grow', h('div.t1', 'Creativity'), h('div.t2', 'Lower = more exact code')), h('div.slider', i, b));
  }
  function api() {
    var S = RC.settings, A = S.api;
    var preset = h('select', { onchange: function () { var p = PRESETS[preset.value]; A.preset = preset.value; if (preset.value !== 'custom') { A.base = p[1]; A.model = p[2]; } RC.saveSettings(); paint(); } },
      Object.keys(PRESETS).map(function (k) { return h('option', { value: k, selected: A.preset === k }, PRESETS[k][0]); }));
    function inp(key, label, type, ph) {
      var i = h('input', { type: type || 'text', value: A[key] || '', placeholder: ph || '', onchange: function () { A[key] = i.value.trim(); RC.saveSettings(); } });
      return UI.field(label, i);
    }
    body.appendChild(UI.sec('Online API (OpenAI compatible)'));
    body.appendChild(UI.card(UI.field('Provider', preset), inp('base', 'Address', 'url', 'https://…/v1'), inp('key', 'API key', 'password', 'sk-…'), inp('model', 'Model name', 'text', 'model id'),
      tempSlider(A),
      h('div.row', { style: { marginTop: '8px' } }, UI.btn('Test connection', 'bolt', 'sm', function () {
        var b = this; UI.toast('Testing…');
        RC.llm.run({ system: 'Reply with the single word OK.', prompt: 'ping', maxTokens: 16 }).then(function (t) { UI.toast('Connected: ' + U.clip(t.trim(), 40, '')); }, function (e) { UI.toast(e.message); });
      }))));
    body.appendChild(h('div.t2', { style: { margin: '10px 4px' } }, 'Needs internet. Pick "On this phone" to work fully offline.'));
  }

  // ------------------------------------------------------------------ knowledge
  function kb() {
    var st = RC.rag.stats(), docs = St.kbFor();
    body.appendChild(UI.sec('Knowledge base (RAG)'));
    body.appendChild(UI.card(h('div.t2', 'Add documents, notes or code. When ReCode plans or writes, it searches them (keyword ranking, fully offline) and gives the best passages to the agent. Currently ' + st.docs + ' document(s), ' + st.chunks + ' passage(s).'),
      h('div.row', { style: { marginTop: '12px', flexWrap: 'wrap' } }, UI.btn('Add files', 'upload', 'sm', addFiles), UI.btn('Paste text', 'edit', 'sm ghost', addText), UI.btn('Web page', 'globe', 'sm ghost', addUrl))));
    body.appendChild(UI.sec('Documents'));
    if (!docs.length) body.appendChild(h('div.card.empty', 'Nothing yet.'));
    docs.forEach(function (d) {
      body.appendChild(h('div.card', h('div.row', h('div.ico', { html: RC.i('book', 19) }),
        h('div.grow', h('div.t1.ell', d.name), h('div.t2', U.bytes(d.text.length) + ' · ' + (d.pid === '*' ? 'all projects' : 'this project'))),
        UI.rbtn('trash', function () { St.delKb(d.id); }, 'Delete', 'sm'))));
    });
  }
  function scopeAsk(save) {
    var box = h('div', h('p', 'Use this knowledge in:'),
      h('div.row', UI.btn('This project', null, '', function () { UI.closeSheet(); save(St.cur.id); }), UI.btn('All projects', null, 'ghost', function () { UI.closeSheet(); save('*'); })));
    UI.sheet({ title: 'Scope', body: box });
  }
  function addFiles() {
    N.pickDocs().then(function (docs) {
      docs.filter(function (d) { return d.error; }).forEach(function (d) { UI.toast(d.name + ': ' + d.error); });
      var ok = docs.filter(function (d) { return d.text; }); if (!ok.length) return;
      scopeAsk(function (pid) { Promise.all(ok.map(function (d) { return St.addKb({ pid: pid, name: d.name, text: d.text }); })).then(function () { UI.toast(ok.length + ' added'); }); });
    }, function (e) { UI.toast(e.message); });
  }
  function addText() {
    UI.prompt('Paste text or notes', '', 'Paste here', true).then(function (t) {
      if (!t || !t.trim()) return;
      scopeAsk(function (pid) { St.addKb({ pid: pid, name: 'Note ' + new Date().toLocaleDateString() + ' ' + U.clip(t.trim().replace(/\s+/g, ' '), 18, ''), text: t }); });
    });
  }
  function addUrl() {
    UI.prompt('Web page address', '', 'https://…').then(function (u) {
      if (!u || !/^https?:\/\//i.test(u.trim())) return u && UI.toast('Enter a full https:// address');
      UI.toast('Reading page…');
      N.read(u.trim(), 12000).then(function (d) { scopeAsk(function (pid) { St.addKb({ pid: pid, name: d.title || u, text: d.text }); }); }, function (e) { UI.toast(e.message); });
    });
  }

  function paint() { var k = body.scrollTop; U.clear(body); paintHead(); if (tab === 'models') models(); else kb(); body.scrollTop = k; }
  RC.bus.on('dl', function (list) {
    if (root.classList.contains('on') && tab === 'models' && !UI.sheetStack.length) paint();
    list.forEach(function (d) { if (d.state === 2 && !d.seen) { d.seen = true; var m = N.models(); if (!RC.settings.model && m.length) { RC.set('model', m[0].name); } UI.toast('Model ready: ' + d.name); N.call('clearDownload', d.name); } });
  });
  RC.bus.on('kb', function () { if (root.classList.contains('on')) paint(); });
  RC.bus.on('project', function () { if (root.classList.contains('on')) paint(); });
  UI.mods.lib = { show: paint };
  paintHead();
})();
