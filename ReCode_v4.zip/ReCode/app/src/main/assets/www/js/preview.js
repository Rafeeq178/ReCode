/* ReCode - Run tab: offline runner for the project (HTML/CSS/JS) in a sandboxed frame + console. */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var U = RC.u, h = U.h, UI = RC.ui, St = RC.store, N = RC.native, Run = RC.run;
  var root = U.$('#v-run');
  var sid = U.uid('pv'), frame = null, temp = null, device = 'auto', showCon = false, consoleLines = [], errCount = 0, stale = true;
  var box = h('div#pvbox'), con = h('div#console'), banner = h('div'), bar = h('div.toolbar'), wrapEl = h('div#pvwrap', banner, box, con);
  root.appendChild(bar); root.appendChild(wrapEl);

  function files() { return temp || St.files; }
  function paintBar() {
    U.clear(bar);
    bar.appendChild(UI.btn('Reload', 'refresh', 'sm', function () { load(true); }));
    var d = h('button.chip', { onclick: function () { device = device === 'auto' ? 'phone' : device === 'phone' ? 'tablet' : 'auto'; box.className = device === 'auto' ? '' : device; paintBar(); } }, h('span', { html: RC.i('cpu', 14) }), device === 'auto' ? 'Fit' : device === 'phone' ? 'Phone' : 'Tablet');
    bar.appendChild(d);
    bar.appendChild(h('button.chip' + (showCon ? '.on' : ''), { onclick: function () { showCon = !showCon; paintCon(); paintBar(); } }, h('span', { html: RC.i('terminal', 14) }), 'Console' + (errCount ? ' (' + errCount + ')' : '')));
    bar.appendChild(h('button.chip', { onclick: exportHtml }, h('span', { html: RC.i('download', 14) }), '.html'));
  }
  function paintCon() {
    con.style.display = showCon ? 'block' : 'none';
    U.clear(con);
    if (!consoleLines.length) con.appendChild(h('div', { style: { color: 'var(--codeMuted)' } }, 'Console is empty.'));
    consoleLines.slice(-200).forEach(function (l) { con.appendChild(h('div.' + l[0], l[1])); });
    con.scrollTop = con.scrollHeight;
  }
  function exportHtml() {
    var b = Run.bundle(files()); if (!b) return UI.toast('Nothing to export');
    N.save(U.slug(St.cur.name) + '.html', b.html, 'text/html').then(function () { UI.toast('Saved'); }, function (e) { if (e.message !== 'cancelled') UI.toast(e.message); });
  }
  function onMsg(ev) {
    var d = ev.data;
    if (!frame || ev.source !== frame.contentWindow || !d || d.rc !== 1 || d.sid !== sid) return;
    if (d.k === 'console') { consoleLines.push([d.lvl, d.text]); if (d.lvl === 'error') errCount++; }
    else if (d.k === 'error') { consoleLines.push(['error', d.msg + (d.line ? ' (line ' + d.line + ')' : '')]); errCount++; }
    else if (d.k === 'ls') { if (!temp) St.setLS(d.data); }
    else return;
    paintCon(); paintBar();
    if (d.k === 'error' && !showCon) UI.toast('The page has an error - open Console');
  }
  window.addEventListener('message', onMsg);

  function load(force) {
    stale = false;
    U.clear(box); consoleLines = []; errCount = 0;
    U.clear(banner);
    if (temp) banner.appendChild(h('div.card', { style: { marginBottom: '8px', display: 'flex', gap: '10px', alignItems: 'center' } }, h('div.grow.t2', 'Snippet preview - not part of the project.'),
      UI.btn('Save to project', null, 'sm', function () { var f = temp; temp = null; Object.keys(f).forEach(function (p) { St.putFile(p === 'index.html' && St.files['index.html'] ? 'snippet.html' : p, f[p]); }); UI.toast('Saved'); load(true); }),
      UI.btn('Close', null, 'sm ghost', function () { temp = null; load(true); })));
    sid = U.uid('pv');
    var b = Run.frame(files(), sid);
    if (!b) { box.appendChild(h('div.empty', { style: { alignSelf: 'center' } }, 'Nothing to run yet. Build something first - HTML, CSS and JS files run here, fully offline.')); frame = null; paintBar(); paintCon(); return; }
    frame = h('iframe', { sandbox: Run.SANDBOX, title: 'preview' });
    frame.srcdoc = b.srcdoc;
    box.appendChild(frame);
    paintBar(); paintCon();
  }
  UI.runSnippet = function (code, lang) {
    lang = (lang || '').toLowerCase(); var f = {};
    if (/^(js|javascript)$/.test(lang)) f['index.html'] = '<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head><body><script>\n' + code + '\n<\/script></body></html>';
    else if (lang === 'svg') f['index.html'] = '<!DOCTYPE html><html><body style="margin:0">' + code + '</body></html>';
    else f['index.html'] = code;
    temp = f; UI.go('run'); load(true);
  };
  var refresh = U.debounce(function () { if (RC.settings.autoPreview && !temp && root.classList.contains('on')) load(); else stale = true; }, 500);
  RC.bus.on('files', refresh);
  RC.bus.on('project', function () { temp = null; stale = true; if (root.classList.contains('on')) load(); });
  RC.bus.on('settings', function () { if (root.classList.contains('on') && frame) { /* netPreview change applies on reload */ } });
  UI.mods.run = { show: function () { if (stale || !frame || temp) load(); else { paintBar(); paintCon(); } }, back: function () { if (temp) { temp = null; load(true); return true; } return false; } };
  paintBar(); paintCon();
})();
