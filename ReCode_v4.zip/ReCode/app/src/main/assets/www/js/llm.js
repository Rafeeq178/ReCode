/* ReCode - one entry point for every model call, local (GGUF) or online (OpenAI compatible API).
   Every call is an isolated "agent turn": its own system prompt, no memory of earlier calls. */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var U = RC.u, N = RC.native;
  var chain = Promise.resolve();
  var curId = null;

  function AbortErr() { var e = new Error('Stopped'); e.name = 'AbortError'; return e; }

  var L = RC.llm = {
    AbortErr: AbortErr,
    /** {ok, why} - is a model available right now? */
    ready: function (provider) {
      var s = RC.settings, selected = provider || s.provider;
      if (!N.has) return { ok: false, why: 'Open ReCode on your phone to run a model.' };
      if (selected === 'api') {
        if (!s.api.base || !s.api.model) return { ok: false, why: 'Fill the online API address and model in Library.' };
        if (!N.online()) return { ok: false, why: 'The online API needs internet.' };
        return { ok: true };
      }
      if (!s.model) return { ok: false, why: 'Choose or download a model in Library first.' };
      var list = N.models();
      if (!list.some(function (m) { return m.name === s.model; })) return { ok: false, why: 'The selected model file is missing. Pick one in Library.' };
      return { ok: true };
    },
    label: function () {
      var s = RC.settings;
      return s.provider === 'api' ? (s.api.model + ' (online)') : (s.model ? s.model.replace(/\.gguf$/i, '') : 'No model');
    },
    /**
     * run({agent, system, prompt, maxTokens, signal, onPhase(p), onToken(text)}) -> Promise<string>
     * Calls are queued, so only one model call runs at a time.
     */
    run: function (o) {
      var p = chain.then(function () { return one(o); });
      chain = p.catch(function () { });
      return p;
    },
    stop: function () { N.call('llmStop'); }
  };

  // Task-aware routing never changes the user's saved provider. A provider is attached
  // to each serialized request, so concurrent agent calls cannot race settings.
  RC.modelRouter = {
    choose: function (o) {
      o = o || {}; var s = RC.settings, prompt = String(o.prompt || ''), task = String(o.agent || '') + ' ' + prompt;
      var online = N.online() && !!(s.api && s.api.base && s.api.model);
      var local = !!(s.model && N.models().some(function (m) { return m.name === s.model; }));
      if (s.autoModelRouting === false) return { provider: s.provider, reason: 'Automatic routing disabled' };
      if (!online) return { provider: local ? 'local' : s.provider, reason: 'Offline or no online API configured' };
      var complexity = Math.min(10, (prompt.length > 5000 ? 3 : prompt.length > 1800 ? 2 : 0) + (/architect|security|debug|review|refactor|complex|multi-file|migration|reason/i.test(task) ? 3 : 0) + (/main|planner|architect|reviewer|security/i.test(o.agent || '') ? 2 : 0));
      if (complexity >= (+s.apiRouteThreshold || 5)) return { provider: 'api', reason: 'Online model selected for a high-complexity task', complexity: complexity };
      return { provider: local ? 'local' : 'api', reason: local ? 'Local model is sufficient for this task' : 'No local model is available', complexity: complexity };
    },
    run: function (o) { var route = RC.modelRouter.choose(o); var next = Object.assign({}, o, { provider: route.provider, route: route }); if (o.onRoute) o.onRoute(route); return L.run(next); },
    status: function () { return { savedProvider: RC.settings.provider, localModel: RC.settings.model || null, onlineModel: RC.settings.api && RC.settings.api.model || null, online: N.online(), auto: RC.settings.autoModelRouting !== false }; }
  };

  function one(o) {
    return new Promise(function (resolve, reject) {
      if (o.signal && o.signal.aborted) return reject(AbortErr());
      var rdy = L.ready(o.provider);
      if (!rdy.ok) return reject(new Error(rdy.why));
      var id = U.uid('l'), text = '', settled = false, s = RC.settings, off, killT;
      curId = id;
      function done(err) {
        if (settled) return; settled = true;
        clearTimeout(killT); off && off();
        if (o.signal) o.signal.removeEventListener('abort', onAbort);
        curId = null;
        err ? reject(err) : resolve(text);
      }
      function onAbort() {
        L.stop();
        killT = setTimeout(function () { done(AbortErr()); }, 2500); // never hang if the phone does not answer
      }
      if (o.signal) o.signal.addEventListener('abort', onAbort);
      off = N.onLlm(id, function (ev) {
        if (ev.k === 'loading') o.onPhase && o.onPhase('loading');
        else if (ev.k === 'loaded') o.onPhase && o.onPhase('thinking');
        else if (ev.k === 'tok') {
          if (!text) o.onPhase && o.onPhase('writing');
          text += ev.v; o.onToken && o.onToken(text);
        }
        else if (ev.k === 'done') done();
        else if (ev.k === 'stopped') done(AbortErr());
        else if (ev.k === 'err') done(new Error(ev.v || 'The model failed'));
      });
      var max = Math.max(32, Math.min(o.maxTokens || 800, 8192));
      var provider = o.provider || s.provider;
      var ready = L.ready(provider);
      if (!ready.ok) return done(new Error(ready.why));
      try {
        if (provider === 'api') N.call('apiRun', id, s.api.base, s.api.key || '', s.api.model, o.system || '', o.prompt || '', max, +s.api.temp || 0.3, (o.tools && o.tools.length ? JSON.stringify(o.tools) : ''));
        else N.call('llmRun', id, s.model, o.system || '', o.prompt || '', max);
      } catch (e) { done(e); }
    });
  }
})();
