/* ReCode - Activity: the live "Summary" timeline of what every agent does (steps, what each agent knew, its output). */
(function () {
  'use strict';
  var RC = window.RC = window.RC || {};
  var U = RC.u, h = U.h, UI = RC.ui, St = RC.store;
  var TL = UI.timeline = {};
  var state = { run: null, detail: null };

  function agentName(id) { return (RC.agents.def[id] || { name: id }).name; }
  function agentIcon(id) { return (RC.agents.def[id] || { icon: 'spark' }).icon; }
  var PH = { loading: 'Loading model', thinking: 'Thinking', writing: 'Writing' };

  TL.lastRun = function () {
    if (RC.pipe.current) return RC.pipe.current;
    for (var i = St.msgs.length - 1; i >= 0; i--) if (St.msgs[i].run) return St.msgs[i].run;
    return null;
  };
  TL.slim = function (run) {
    return {
      id: run.id, mode: run.mode, status: run.status, title: run.title, t0: run.t0, t1: run.t1, files: run.files.slice(), sources: run.sources, zip: run.zip, error: run.error,
      steps: run.steps.map(function (s) {
        return { id: s.id, agent: s.agent, title: s.title, kind: s.kind, status: s.status, t0: s.t0, t1: s.t1, note: s.note, log: s.log.slice(0, 40),
          ctx: s.ctx ? { system: U.clip(s.ctx.system, 2500), prompt: U.clip(s.ctx.prompt, 7000) } : null, out: U.clip(s.out, 7000) };
      })
    };
  };
  function statusIcon(s) {
    if (s.status === 'running') return h('div.spin');
    if (s.status === 'done') return h('div.dotok', { html: RC.i('check', 12) });
    if (s.status === 'error') return h('div.dotok.doterr', { html: RC.i('x', 12) });
    return h('span.t2', s.status === 'skipped' ? 'skipped' : 'stopped');
  }
  TL.stepWord = function (s) {
    if (s.kind === 'tool') return 'Running command';
    return PH[s.phase] || 'Thinking';
  };

  function list(host, run) {
    var secs = Math.round(((run.t1 || Date.now()) - run.t0) / 1000);
    host.appendChild(h('div.sumhead', h('div.ico.fill', { html: RC.i('layers', 20) }), h('div.grow', h('div', run.title || 'Activity'),
      h('div.t2', { style: { fontWeight: 500, fontSize: '13px', marginTop: '3px' } }, run.steps.length + ' steps · ' + U.dur((run.t1 || Date.now()) - run.t0) + ' · ' + (run.status === 'running' ? 'working…' : run.status)))));
    var tl = h('div.tl'); host.appendChild(tl);
    if (!run.steps.length) tl.appendChild(h('div.empty', 'No steps yet.'));
    run.steps.forEach(function (s) {
      var live = s.status === 'running';
      tl.appendChild(h('div.st.' + s.status, h('button.l', { onclick: function () { state.detail = s.id; TL.paint(); } },
        h('span.ag', { html: RC.i(agentIcon(s.agent), 16) }),
        h('span.n' + (live ? '.pulse' : ''), s.title),
        statusIcon(s)),
        live ? h('div.sub', h('span.ph', TL.stepWord(s)), ' · ' + agentName(s.agent)) : (s.note ? h('div.sub', s.note) : h('div.sub', agentName(s.agent) + (s.t1 ? ' · ' + U.dur(s.t1 - s.t0) : '')))));
    });
    if (run.final && run.status !== 'running') host.appendChild(h('div.card', { style: { marginTop: '14px' } }, h('div.ai', { html: U.md(U.clip(run.final, 1500, '…')) })));
  }

  function detail(host, run, s) {
    host.appendChild(h('div.row', { style: { marginBottom: '6px' } }, UI.rbtn('chevL', function () { state.detail = null; TL.paint(); }, 'Back', 'sm'),
      h('div.grow', h('div.t1.ell', s.title), h('div.t2', agentName(s.agent)))));
    var d = h('div.detail');
    d.appendChild(h('div.kv', h('span', s.status), h('span', U.dur((s.t1 || Date.now()) - s.t0)), h('span', s.kind === 'tool' ? 'tool step' : 'model step'),
      s.status === 'running' && s.kind !== 'tool' ? h('span', TL.stepWord(s)) : null, s.note ? h('span', s.note) : null));
    if (s.kind !== 'tool' && s.ctx) {
      d.appendChild(h('details.d', h('summary', 'What this agent knew (isolated memory)'),
        h('div.t2', { style: { margin: '6px 0' } }, 'The model was reloaded for this step. It saw only this:'),
        h('pre', 'SYSTEM\n' + s.ctx.system + '\n\nHAND-OVER\n' + s.ctx.prompt)));
    }
    if (s.log && s.log.length) d.appendChild(h('details.d', { open: true }, h('summary', 'Log'), h('pre', s.log.join('\n'))));
    if (s.kind !== 'tool') {
      d.appendChild(h('div.sec', { style: { margin: '14px 2px 6px' } }, s.status === 'running' ? 'Live output' : 'Output'));
      var ex = RC.agents.extractCode(s.out || ''), isCode = /```/.test(s.out || '') && !ex.weak;
      var pre = h('pre.code', { html: s.out ? (isCode ? U.hl(ex.code, ex.lang || U.ext(s.title.split(' ').pop())) : U.esc(s.out)) : '<span class="tk-c">waiting for the model…</span>' });
      d.appendChild(pre);
      if (s.status === 'running') setTimeout(function () { pre.scrollTop = pre.scrollHeight; }, 0);
    }
    host.appendChild(d);
  }

  var hosts = [];
  /** draw the timeline for the chosen run into every visible host */
  TL.paint = function () {
    var run = state.run || TL.lastRun();
    hosts.forEach(function (x) {
      if (!x.el.isConnected || !x.visible()) return;
      var keep = x.scroller && x.scroller();
      var top = keep ? keep.scrollTop : 0;
      U.clear(x.el);
      if (!run) { x.el.appendChild(h('div.empty', 'Nothing has run yet. Ask ReCode to build something and every agent step shows up here, live.')); return; }
      var s = state.detail && run.steps.filter(function (z) { return z.id === state.detail; })[0];
      if (s) detail(x.el, run, s); else list(x.el, run);
      if (keep && !s) keep.scrollTop = top;
    });
  };
  TL.show = function (run) { state.run = run && run !== RC.pipe.current ? run : null; state.detail = null; TL.paint(); };

  // wide layout: the #v-act panel
  var panel = h('div.scroll'); U.$('#v-act').appendChild(panel);
  hosts.push({ el: panel, visible: function () { return UI.wide && UI.view === 'build' && UI.wsTab === 'act'; }, scroller: function () { return panel; } });
  UI.mods.act = { show: TL.paint, back: function () { if (state.detail) { state.detail = null; TL.paint(); return true; } return false; } };

  // phone layout: a bottom sheet like the "Summary" screen
  UI.openActivity = function (run) {
    if (UI.wide) { UI.wsTab = 'act'; UI.paint(); TL.show(run); return; }
    var body = h('div');
    var o = { title: 'Summary', body: body, isActivity: true, back: null, onClose: function () { hosts = hosts.filter(function (x) { return x.el !== body; }); } };
    o.back = function () { if (state.detail) { state.detail = null; TL.paint(); } else UI.closeSheet(true); };
    UI.sheet(o);
    hosts.push({ el: body, visible: function () { return true; }, scroller: function () { return o.el; } });
    TL.show(run);
  };
  var q = U.raf(function () { if (hosts.some(function (x) { return x.el.isConnected; })) TL.paint(); });
  RC.bus.on('run', q);
})();
