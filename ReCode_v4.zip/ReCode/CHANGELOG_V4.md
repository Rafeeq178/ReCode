# ReCode 4.0.0 — Advanced Agent Runtime Upgrade

## Added
- Task-aware local/online model router. Provider is selected per request without mutating the saved provider.
- Optional bounded final-answer self-review.
- Dependency graph and unresolved local import detection.
- Hybrid retrieval combining existing BM25 results with dependency-aware file ranking.
- Static security, maintainability and responsive audits.
- Isolated responsive viewport probes at phone, tablet and desktop widths.
- JSONL fine-tuning dataset validator and training-preparation helper (no weight training).
- Named local snapshot branches and restore/diff support (not native Git).
- Optional MCP Streamable HTTP JSON-RPC client with tool discovery and permission-gated remote tools.
- 11 additional agent profiles (26 total) and 9 additional skills (17 total).
- Advanced settings panel for routing, self-review, MCP, audits, model comparison and snapshot history.

## Preserved
- Android/Kotlin application shell and local GGUF inference integration.
- OpenAI-compatible API client.
- Model-directed Agentic Loop; no fixed Planner → Architect → Coder → Fixer pipeline.
- Existing project store, RAG/BM25, sandboxed web preview, static checks, task manager, memory, hooks, permissions and checkpoint system.

## Deliberate limitations
- No unrestricted Android shell, Node.js or Python runtime is exposed. Existing HTML/CSS/JS sandbox preview remains the in-app execution environment.
- Snapshot branches are not a native Git repository implementation.
- MCP supports user-configured HTTPS Streamable HTTP JSON-RPC; STDIO, OAuth and SSE-only transports are not supported.
- Screenshot-to-code/visual similarity is not claimed: this app's current model bridge is text-only and has no image/vision input pipeline.
- JSONL dataset validation is supported; on-device model-weight fine-tuning is not.
- Native Gradle/APK build and real-device inference/MCP/API integration tests require Android SDK/device credentials and were not available in this build environment.
