RECODE - OFFLINE-FIRST AUTONOMOUS CODING ENVIRONMENT
Android app with local GGUF models and optional OpenAI-compatible online APIs.

BUILD
1. Put ReCode_v3.zip and the included .github/workflows/build.yml in a GitHub repository.
2. Push to the main branch.
3. Open Actions -> Build APK and download the generated ReCode-debug.apk artifact/release.
4. Install on Android 10+ (arm64-v8a). The debug signing key is included to keep update signatures stable.

ARCHITECTURE
- The WebView interface and agent runtime live in app/src/main/assets/www.
- Kotlin provides the Android bridge, llama.cpp local inference, online API streaming, file picker, downloads and web research.
- There is ONE orchestrator: agent-runtime.js. The old agents.js and pipeline.js execution pipeline have been removed.
- Every request enters the model-directed agent loop. The model chooses project tools and specialist delegation; tool results are fed back until FINAL or a safe iteration limit.
- Local models use compact text TOOL: calls or JSON tool-call text. Online OpenAI-compatible endpoints use streamed structured function calling when supported, with automatic text-call fallback if unsupported.
- Specialist definitions are stored in .recode/agents/*.md; skills are stored in .recode/skills/*/SKILL.md. User-defined files are stored in each project workspace.
- PLAN is read-only and presents an approval preview. ASK requests approval for protected operations. AUTO follows configured permissions. DENY always wins.
- Project files are isolated in the IndexedDB workspace. Tool paths are normalized and traversal is rejected. Terminal commands are disabled in the Android WebView sandbox.
- Project memory is stored in RECODE.md and .recode/memory/*.md. Session summaries, todos and checkpoints persist locally.
- The context manager uses budget reduction, output snipping, microcompaction, history collapse and model summarization for small-context models.
- RAG remains BM25-based over knowledge documents and project files.
- Preview checks run in a sandboxed iframe. Internet access in preview is off by default.

AGENT TOOLS
File tools: read/write/edit/delete/list/search, directories, move/rename, metadata.
Development tools: syntax checks, sandbox preview tests, dependency search, RAG search and project information.
Agent tools: dynamic selection, specialist delegation, parallel specialist analysis, skill loading, todo management, memory updates and checkpoint restore/diff.

SECURITY
- Every tool passes the permission manager and PreToolUse/PostToolUse hook boundary.
- Default permissions are conservative: reads allowed, writes/edits ask, deletes denied, terminal denied.
- File writes are size-limited, syntax-checked and checkpointed. Overwrite and delete actions require confirmation.
- Checkpoints are capped to a bounded history; restore requires confirmation.
- No model-generated JavaScript is executed as a workflow. The model can only call registered tools.

LIMITATIONS TO VERIFY BEFORE PRODUCTION
- MCP server transport is not enabled in this Android build; MCP remains optional and is not advertised as connected.
- Terminal command execution is intentionally disabled. Build/test support is through the in-app preview runner and static checks.
- Specialist agents run isolated contexts with Markdown-configured tool scopes. Parallel delegation is restricted to read-only analysis to avoid file-write races; every specialist tool call still passes through the central permission manager.
- Some external OpenAI-compatible APIs do not implement streamed function calling. ReCode detects common unsupported-tool errors and falls back to text tool calls.
- Context budgets are character-based approximations, not exact tokenizer counts. Small GGUF models may need shorter tasks and smaller files.
- Android Gradle build and on-device local-model/API regression tests must be run through GitHub Actions and on a real device. This environment has no Gradle/Android SDK, so no APK build is claimed.


RECODE V4 ADVANCED
- Task-aware local/online model routing (settings controlled).
- Optional final-answer self-review.
- Dependency graph, hybrid BM25 retrieval, static security/quality/responsive audits.
- Named local snapshot branches and restore (not native Git).
- Optional MCP Streamable HTTP client for JSON-RPC tools.
- 26 specialist profiles and expanded on-demand skills.
- Android shell/Node/Python execution remains disabled for platform and safety reasons.
See RECODE.md for support boundaries and verification notes.
- JSONL fine-tuning dataset validator (preparation only; no on-device weight training).

See CHANGELOG_V4.md for V4 additions, retained features, limitations and test boundaries.
