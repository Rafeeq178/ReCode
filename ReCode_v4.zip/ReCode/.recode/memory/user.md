# User Memory

Store only user-approved durable preferences relevant to coding assistance. Never store secrets or sensitive personal data.
