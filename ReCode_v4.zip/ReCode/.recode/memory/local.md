# Local Project Memory

Store machine- or workspace-specific setup notes that should not be treated as global project conventions. Keep credentials out.
