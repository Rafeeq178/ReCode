# Project Memory

Record project purpose, architecture, languages, frameworks, dependencies, important decisions, coding conventions, data models, test commands, known limitations and next actions.
