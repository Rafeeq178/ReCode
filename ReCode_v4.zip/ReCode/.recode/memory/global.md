# Global Managed Memory

Store durable cross-project ReCode behavior and development preferences here. Do not store API keys, passwords, tokens, private credentials or personal secrets.
