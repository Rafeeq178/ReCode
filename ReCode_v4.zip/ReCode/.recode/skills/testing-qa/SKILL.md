---
name: testing-qa
description: Derive tests from acceptance criteria. Include normal, edge, failure and regression cases. Run available checks and state cle
---

# Testing Qa

Derive tests from acceptance criteria. Include normal, edge, failure and regression cases. Run available checks and state clearly which tests could not run.
