---
name: database-design
description: Model entities and relationships, define constraints and indexes, plan migrations and preserve refer
---

# Database Design

Model entities and relationships, define constraints and indexes, plan migrations and preserve referential integrity.
