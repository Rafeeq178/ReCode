---
name: node-development
description: Build maintainable Node.js applications. Inspect package.json and lockfiles first. Validate versions, use async error handlin
---

# Node Development

Build maintainable Node.js applications. Inspect package.json and lockfiles first. Validate versions, use async error handling, avoid unnecessary dependencies and add tests.
