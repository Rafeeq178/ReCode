---
name: android-development
description: Respect Android lifecycle, permissions, storage scopes, background limits and offline behavior. Keep
---

# Android Development

Respect Android lifecycle, permissions, storage scopes, background limits and offline behavior. Keep native bridge contracts stable.
