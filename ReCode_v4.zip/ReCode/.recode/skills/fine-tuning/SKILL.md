---
name: fine-tuning
description: Prepares and validates instruction-tuning datasets and training plans.
---

# Fine-tuning preparation

Validate JSONL structure, role names, assistant responses, empty examples, duplicates and sensitive data. Keep a held-out validation split. Select training framework and quantization based on model architecture and available compute. ReCode on Android validates and prepares data only; actual weight training requires a compatible external training environment.
