---
name: api-integration
description: Read the API specification, define request/response schemas, handle auth securely, timeouts, retries, rate limits and error r
---

# Api Integration

Read the API specification, define request/response schemas, handle auth securely, timeouts, retries, rate limits and error responses. Never hard-code private credentials.
