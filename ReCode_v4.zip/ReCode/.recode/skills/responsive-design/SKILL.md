---
name: responsive-design
description: Use mobile-first CSS, semantic HTML, accessible contrast and focus states, flexible layouts and resp
---

# Responsive Design

Use mobile-first CSS, semantic HTML, accessible contrast and focus states, flexible layouts and responsive breakpoints.
