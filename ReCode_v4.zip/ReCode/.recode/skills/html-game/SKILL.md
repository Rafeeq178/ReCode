---
name: html-game
description: Build offline HTML5 games with canvas or DOM. Use requestAnimationFrame, responsive scaling, keyboar
---

# Html Game

Build offline HTML5 games with canvas or DOM. Use requestAnimationFrame, responsive scaling, keyboard and touch controls, and clear game state. Avoid external dependencies.
