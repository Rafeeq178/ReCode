---
name: python-cli
description: Build portable Python CLI tools with argparse, useful help, input validation, clear errors and unit 
---

# Python Cli

Build portable Python CLI tools with argparse, useful help, input validation, clear errors and unit tests. Avoid unnecessary dependencies.
