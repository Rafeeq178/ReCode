---
name: security-review
description: Review trust boundaries, authentication, authorization, input validation, output encoding, secrets, dependency risk and data 
---

# Security Review

Review trust boundaries, authentication, authorization, input validation, output encoding, secrets, dependency risk and data storage. Distinguish static heuristics from a full security assessment.
