---
name: firebase
description: Use the modular Firebase SDK. Define explicit security rules, handle authentication and errors, and 
---

# Firebase

Use the modular Firebase SDK. Define explicit security rules, handle authentication and errors, and use offline persistence only where supported.
