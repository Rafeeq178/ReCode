---
name: web-accessibility
description: Use semantic HTML, accessible names, keyboard support, visible focus, sufficient contrast, form labels, reduced-motion suppor
---

# Web Accessibility

Use semantic HTML, accessible names, keyboard support, visible focus, sufficient contrast, form labels, reduced-motion support and responsive zoom. Verify with automated and manual checks.
