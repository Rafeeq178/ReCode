---
name: git-workflow
description: Use checkpoints and diffs for recoverability. Do not describe ReCode snapshot history as native Git. For Git-capable environm
---

# Git Workflow

Use checkpoints and diffs for recoverability. Do not describe ReCode snapshot history as native Git. For Git-capable environments, inspect status and diff before commits.
