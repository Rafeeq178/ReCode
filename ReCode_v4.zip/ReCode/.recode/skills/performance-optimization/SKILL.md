---
name: performance-optimization
description: Profile first where possible. Optimize algorithmic complexity, repeated work, memory, network payloads and rendering. Preserv
---

# Performance Optimization

Profile first where possible. Optimize algorithmic complexity, repeated work, memory, network payloads and rendering. Preserve correctness and run regression tests.
