pluginManagement {
    repositories { google(); mavenCentral(); gradlePluginPortal() }
}
dependencyResolutionManagement {
    repositories { google(); mavenCentral() }
}
rootProject.name = "ReCode"
include(":app")
// llama.cpp's Android AI-chat library (cloned by CI / setup.sh)
include(":lib")
project(":lib").projectDir = file("llama.cpp/examples/llama.android/lib")
