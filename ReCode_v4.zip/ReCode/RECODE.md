# ReCode Project Guide

## Objective
ReCode is an offline-first Android coding assistant. It runs local GGUF models through the native llama.cpp bridge and optionally connects to OpenAI-compatible online APIs. The model-directed agent runtime is the only orchestration system.

## Architecture
- `app/src/main/assets/www/js/agent-runtime.js`: tool registry, parser, permissions, hooks, agent loop, subagents, skills, memory, todo, checkpoints and context management.
- `llm.js`: unified local/API inference entry point. Structured API tool calls are forwarded to the native bridge; local models use compact text calls.
- `store.js`: IndexedDB-backed project/file/message storage.
- `rag.js`: BM25 retrieval over knowledge and project files.
- `runner.js`: static checks and sandboxed preview/runtime probe.
- `settings.js`: agent, skill, permission and workflow-monitor controls.
- Kotlin `Bridge.kt` and `ApiClient.kt`: Android model/network/file bridge.
- The former `agents.js` and `pipeline.js` orchestrator have been removed. Do not reintroduce the fixed Planner -> Architect -> Coder -> Fixer sequence.

## Runtime Rules
1. All user requests enter `RC.agentRuntime.agentLoop` through `RC.pipe.start`.
2. The model decides which registered tool or specialist is needed next.
3. Tool execution must pass schema validation, permission checks and hooks.
4. Never bypass DENY. PLAN is read-only; ASK prompts for protected actions; AUTO follows saved permissions.
5. Subagents have isolated prompts and per-agent tool allowlists; every tool still passes through central permissions. Parallel specialist dispatch is read-only, while a single specialist can use its configured tools. Native model inference is serialized through the shared Android bridge.
6. Never execute model-generated JavaScript. Workflows are sequences of validated registered tool calls.
7. Preserve the original user request, project memory, decisions, errors and pending work during compaction.
8. Do not claim success without syntax checks or sandbox test evidence appropriate to the task.

## Agent and Skill Configuration
- Built-in and custom agent Markdown: `.recode/agents/<id>.md`.
- Agent files use YAML frontmatter: `name`, `description`, and `tools`.
- Skill instructions: `.recode/skills/<skill-name>/SKILL.md`.
- Load full skill content only when selected as relevant.
- Global and user memory persist in app-level local storage across project switches; project and local memory live in `.recode/memory/project.md` and `.recode/memory/local.md`. Project guide: `RECODE.md`.

## Permissions
- Default read/search permissions: ALLOW.
- File creation/editing: ASK.
- Delete and terminal: DENY.
- DENY > ASK > ALLOW. Project-specific rules cannot override global DENY.
- File paths are relative to the active project and traversal is rejected.
- Snapshot before modifications; overwrite/delete and restore require confirmation.

## Context and Persistence
- Target small local contexts (~4K tokens); configured character budget is only an approximation.
- Compact tool outputs, retain recent results, collapse older history and persist session summaries.
- Todos use PENDING, IN_PROGRESS, COMPLETED, BLOCKED and FAILED.
- Checkpoints preserve project file snapshots and can be diffed/restored with confirmation.

## Verification
- Run JavaScript syntax checks, JSON parsing, static project checks and sandbox preview tests where relevant.
- Local and online model behavior must be tested separately.
- MCP is optional and currently not connected in the Android build. Terminal execution is intentionally unavailable.


## ReCode V4 Advanced Systems

- Task-aware model routing selects the configured local GGUF model or configured online API per request. Routing never silently changes the saved provider. Online routing can transmit prompt/context to the configured provider; disable Auto Model Routing for predictable local-only operation.
- Optional final-answer self-review performs one bounded review call and is disabled by default.
- Project intelligence tools: dependency graph, BM25 + dependency-aware hybrid search, static security heuristics, code-quality checks and responsive-design heuristics. These are advisory checks, not full build, penetration or visual tests.
- Snapshot history supports named branches and restore using project-local snapshots. This is Git-like history, not a native Git implementation.
- Optional MCP Streamable HTTP client supports JSON-RPC initialize, tools/list and tools/call with user-configured endpoints. STDIO, OAuth, SSE-only transports and persistent session negotiation are not supported. Treat connected servers as trusted and keep remote tool permissions restricted.
- Additional specialist profiles: API Integration, DevOps, Git/History, Performance, UI/UX, Accessibility, Migration, Deployment, QA Automation and Build Engineer.
- The existing sandboxed HTML/CSS/JS preview and test probe remain the in-app web runtime. Android shell/Node/Python execution is intentionally not enabled; no unrestricted command execution is exposed.

### V4 verification boundaries

JavaScript syntax and static project checks can run in the app. Native Gradle/APK builds, device-specific GGUF inference, real API credentials, third-party MCP servers, and visual screenshot fidelity require external/device testing. Do not report these as verified unless actually tested.

- Fine-tuning assistant validates JSONL chat datasets and produces preparation guidance; it does not train model weights.
