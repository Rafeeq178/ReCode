package com.aicompany.app.terminal

import android.content.Context
import com.aicompany.app.tools.WorkspaceProvider
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Builds proot command lines that run inside the Alpine rootfs.
 * proot and its loader ship as native libs (jniLibs), so they can execute on Android 10+
 * with targetSdk 28 and useLegacyPackaging enabled.
 */
@Singleton
class ShellLauncher @Inject constructor(
    @ApplicationContext context: Context,
    private val installer: RootfsInstaller,
    private val workspace: WorkspaceProvider,
) {
    private val nativeDir = File(context.applicationInfo.nativeLibraryDir)
    private val prootBin = File(nativeDir, "libproot.so")
    private val loaderBin = File(nativeDir, "libproot-loader.so")
    private val prootTmp = File(context.filesDir, "proot-tmp").apply { mkdirs() }

    /** Null when the terminal can run, otherwise the reason it cannot. */
    fun notReadyReason(): String? = when {
        !prootBin.canExecute() -> "proot binary is missing from this APK"
        !loaderBin.canExecute() -> "proot loader is missing from this APK"
        !installer.isInstalled() -> "Alpine rootfs is not installed yet"
        else -> null
    }

    /**
     * Minimal proot options. Used after a normal start was killed with signal 9 (some phones kill
     * proot when it fakes root or touches /sys). Set automatically by the terminal screen.
     */
    @Volatile var safeMode: Boolean = false

    fun argv(shellArgs: List<String>): List<String> {
        val ws = workspace.sandbox.root.absolutePath
        return buildList {
            add(prootBin.absolutePath)
            add("--link2symlink")
            if (!safeMode) add("-0")
            add("-r"); add(installer.rootfsDir.absolutePath)
            add("-b"); add("/dev")
            add("-b"); add("/proc")
            if (!safeMode) { add("-b"); add("/sys") }
            add("-b"); add("$ws:/workspace")
            add("-w"); add("/workspace")
            addAll(shellArgs)
        }
    }

    /** Interactive login shell for the embedded terminal. */
    fun interactiveArgv(): List<String> = argv(listOf("/bin/sh", "-l"))

    /** Non-interactive shell for tools. The command runs inside the Alpine rootfs only. */
    fun commandArgv(command: String): List<String> {
        require(command.isNotBlank()) { "Command is empty" }
        require(command.length <= MAX_COMMAND_CHARS) { "Command is too long" }
        require(!command.contains('\u0000')) { "Invalid command" }
        return argv(listOf("/bin/sh", "-c", command))
    }

    /** Host folder used as the process working directory (must exist on the host). */
    fun hostCwd(): String = workspace.sandbox.root.absolutePath

    fun environment(): Map<String, String> = mapOf(
        "PROOT_TMP_DIR" to prootTmp.absolutePath,
        "PROOT_LOADER" to loaderBin.absolutePath,
        // Android's own seccomp filter makes proot's seccomp acceleration crash/kill the shell (exit -9)
        // on several phones. Plain ptrace mode is slightly slower but starts reliably.
        "PROOT_NO_SECCOMP" to "1",
        "HOME" to "/root",
        "PATH" to "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
        "TERM" to "xterm-256color",
        "LANG" to "C.UTF-8",
    )

    companion object {
        const val MAX_COMMAND_CHARS = 4000
    }
}
