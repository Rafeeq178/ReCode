VETHOS v13 - simple offline assistant with tools and skills (Kotlin, llama.cpp v1.0.0, LiquidAI LFM2.5)

Build: put Vethos_v12.zip in the GitHub repo (the workflow builds the highest Vethos_vN.zip). Android 10+, arm64.
llama.cpp: LLAMA_REF = v1.0.0 in .github/workflows/build-apk.yml (falls back to master if the tag is missing).

MODEL
  - Library has LFM2.5 1.2B (about 700 MB, recommended) and LFM2.5 350M, plus the older models.
  - The model is loaded ONCE and stays loaded: a new chat only sends a new system prompt (no reload of the file).
    "Load" button in the Library loads it by hand. "Keep model loaded" (Settings) loads it when the app opens.
    A quiet notification with a Stop button keeps it alive in the background.
  - The system prompt is short: only 7 core tools are listed with arguments, the rest are found with tool_search
    (like Claude's deferred tools). Skills show only name + description; read_skill loads the full text on demand.
  - Reasoning text between <think> tags is hidden.

TOOLS (drawer -> Phone tools, groups open when tapped)
  Internet : web_search, web_fetch, image_search, weather, sports, places
  Time     : alarm, timer, calendar_add, calendar_list, location, time, compose (email / sms draft)
  Files    : create_file, view_file, edit_file, list_files, present_file, make_pdf, make_docx, make_xlsx, chart, page (html), shell
  Phone    : flashlight, volume, wifi, battery, open_app, call, sms, whatsapp, navigate, camera, notify, clipboard, speak
  Helpers  : calc, random, encode, qr_make, qr_scan, read_file, write_file, read_skill, save_skill, tool_search
  Files made by the assistant are saved to Downloads/Vethos and shown as a tap-to-open link; nothing opens until you tap.
  Own tools: + button. Kinds: call a web address (GET/POST with {argument} placeholders), open a link / app,
  or saved instructions for the model. Hold your own tool to edit or delete.
  Sensitive tools (call, sms, location, shell, save_skill ...) ask "Allow?" first.

SKILLS (drawer -> Skills): skills/<name>/SKILL.md, add / edit / delete / import / export / on-off. Examples are created
  on first start (Research, Word document, PDF document, Excel sheet, Chart, Web page or app, Presentation, Make a skill).

ONE ASSISTANT: no personalities, no planner / coder modes. Home = greeting + model + message box (Claude-like look).

NOT in the phone app (they belong to Claude's own servers): connectors / MCP, US election results, Claude Docs,
published artifacts, real .pptx files (use the Presentation skill = HTML slides), end_conversation.

v13 changes
  - One assistant only (personalities, Planner, Coder and General Assistant removed).
  - New simple look: Home with asterisk logo, "Hey there", model chip and a message box; dark round send button.
  - Steps are shown as one quiet line ("✔ Web search ›"); tap it to see what was sent and received.
  - Answers appear as soon as the model writes them (the slow typing effect is gone); no endless animations.
  - The model AND the system prompt are prepared when the app opens, so a new chat answers without waiting.
