package com.vethos.app.ui

import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.vethos.app.data.Engine
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.content.res.ColorStateList
import android.os.Bundle
import android.transition.TransitionManager
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import com.vethos.app.R
import com.vethos.app.data.ChatRepo
import com.vethos.app.data.Store
import com.vethos.app.databinding.ActivityMainBinding
import com.vethos.app.databinding.ItemDrawerBinding
import com.vethos.app.databinding.ItemNavBinding
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private val navItems = mutableListOf<ItemNavBinding>()
    private val drawerItems = mutableListOf<ItemDrawerBinding>()
    private var current = -1

    private val askNotif = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private class Tab(val label: String, val icon: Int, val make: () -> Fragment)
    private val tabs = listOf(
        Tab("Home", R.drawable.ic_home) { HomeFragment() },
        Tab("Library", R.drawable.ic_lib) { LibraryFragment() },
        Tab("Settings", R.drawable.ic_set) { SettingsFragment() },
    )

    /** tab index, or -1 for "My Offline Chatbots" which opens its own screen */
    private class MenuItem(val label: String, val icon: Int, val tab: Int)
    private val menu = listOf(
        MenuItem("Home", R.drawable.ic_home, 0),
        MenuItem("Library", R.drawable.ic_lib, 1),
        MenuItem("Phone tools", R.drawable.ic_chip, -2),
        MenuItem("Skills", R.drawable.ic_book, -6),
        MenuItem("Settings", R.drawable.ic_set, 2),
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        if (CrashActivity.pending(this)) {
            super.onCreate(savedInstanceState)
            startActivity(Intent(this, CrashActivity::class.java))
            finish()
            return
        }
        installSplashScreen()
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        tabs.forEachIndexed { i, t ->
            val n = ItemNavBinding.inflate(layoutInflater, b.nav, false)
            n.icon.setImageResource(t.icon)
            n.label.text = t.label
            n.root.setOnClickListener { select(i) }
            b.nav.addView(n.root)
            navItems.add(n)
        }

        menu.forEach { m ->
            val d = ItemDrawerBinding.inflate(layoutInflater, b.menu, false)
            d.icon.setImageResource(m.icon)
            d.label.text = m.label
            d.root.setOnClickListener {
                b.drawer.closeDrawer(GravityCompat.START)
                when {
                    m.tab >= 0 -> select(m.tab)
                    m.tab == -2 -> startActivity(Intent(this, ToolsActivity::class.java))
                    m.tab == -6 -> startActivity(Intent(this, SkillsActivity::class.java))
                }
            }
            b.menu.addView(d.root)
            drawerItems.add(d)
        }
        b.btnNewChat.setOnClickListener {
            b.drawer.closeDrawer(GravityCompat.START)
            startActivity(Intent(this, ChatActivity::class.java))
        }
        b.btnAllHistory.setOnClickListener {
            b.drawer.closeDrawer(GravityCompat.START)
            startActivity(Intent(this, HistoryActivity::class.java))
        }

        val back = object : OnBackPressedCallback(false) {
            override fun handleOnBackPressed() { b.drawer.closeDrawer(GravityCompat.START) }
        }
        onBackPressedDispatcher.addCallback(this, back)
        b.drawer.addDrawerListener(object : DrawerLayout.SimpleDrawerListener() {
            override fun onDrawerOpened(drawerView: View) { back.isEnabled = true }
            override fun onDrawerClosed(drawerView: View) { back.isEnabled = false }
        })

        select(intent.getIntExtra("tab", savedInstanceState?.getInt("tab") ?: 0))
        warmModel()
        askPermissions()
    }

    /** Android 13+: notification permission (download progress). Asked once, with a short reason first. */
    private fun askPermissions() {
        if (Build.VERSION.SDK_INT < 33 || Store.askedNotif) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return
        Store.askedNotif = true
        confirm(
            "Allow notifications?",
            "Vethos shows the progress of model downloads in the notification bar and tells you when a model is ready. Downloads also keep running when you leave the app.",
            "Allow"
        ) { askNotif.launch(Manifest.permission.POST_NOTIFICATIONS) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        select(intent.getIntExtra("tab", 0))
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", current)
    }

    fun openDrawer() {
        refreshRecents()
        b.drawer.openDrawer(GravityCompat.START)
    }

    private fun refreshRecents() {
        b.recent.removeAllViews()
        val chats = ChatRepo.sorted().filter { it.msgs.isNotEmpty() }.take(6)
        if (chats.isEmpty()) {
            b.recent.addView(TextView(this).apply {
                text = "No chats yet"
                setTextColor(getColor(R.color.v_muted))
                textSize = 15f
                setPadding(dp(20), dp(12), dp(20), 0)
            })
        }
        chats.forEach { c ->
            b.recent.addView(TextView(this).apply {
                text = c.title
                setTextColor(getColor(R.color.v_text))
                textSize = 16f
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                setPadding(dp(20), dp(14), dp(16), dp(14))
                setOnClickListener {
                    b.drawer.closeDrawer(GravityCompat.START)
                    startActivity(Intent(this@MainActivity, ChatActivity::class.java).putExtra("id", c.id))
                }
            }, LinearLayout.LayoutParams(-1, -2))
        }
    }

    fun select(i: Int) {
        if (i == current && supportFragmentManager.findFragmentById(R.id.container) != null) return
        current = i
        supportFragmentManager.beginTransaction().setReorderingAllowed(true)
            .replace(R.id.container, tabs[i].make()).commit()

        TransitionManager.beginDelayedTransition(b.nav)
        navItems.forEachIndexed { idx, n ->
            val on = idx == i
            val lp = n.root.layoutParams as LinearLayout.LayoutParams
            lp.weight = if (on) 1.9f else 1f
            n.root.layoutParams = lp
            n.root.setBackgroundResource(if (on) R.drawable.bg_nav_on else 0)
            n.label.visibility = if (on) View.VISIBLE else View.GONE
            val c = getColor(if (on) R.color.white else R.color.v_nav_off)
            n.icon.imageTintList = ColorStateList.valueOf(c)
            n.label.setTextColor(c)
        }
        drawerItems.forEachIndexed { idx, d ->
            val on = menu[idx].tab == i
            d.root.setBackgroundResource(if (on) R.drawable.bg_nav_sel else 0)
            val c = getColor(if (on) R.color.v_blue else R.color.v_text)
            d.icon.imageTintList = ColorStateList.valueOf(c)
            d.label.setTextColor(c)
        }
    }

    /** "Keep model loaded": loads the model once when the app opens, so chats start at once. */
    private fun warmModel() {
        if (warmed || !Store.preload) return
        val f = Store.lastModel?.let { File(Store.modelsDir, it) } ?: return
        if (!f.exists()) return
        warmed = true
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.Default) {
                    Engine.preload(this@MainActivity, f.absolutePath)
                    Engine.load(this@MainActivity, f.absolutePath, "prepared", com.vethos.app.data.SystemPrompt.build(emptyList()))
                }
            } catch (_: Throwable) { }
        }
    }

    companion object { private var warmed = false }
}
