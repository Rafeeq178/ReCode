package com.vethos.app.tools

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import com.vethos.app.R
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Files the assistant makes, like Claude does: a private workspace folder, plus real documents
 * (pdf, docx, xlsx), charts and web pages. present_file / the document tools copy the result to
 * Downloads/Vethos and put a tap-to-open link in the chat.
 */
object FileTools {
    private fun ok(t: String, d: String? = null) = ToolResult(true, t, d)
    private fun bad(t: String) = ToolResult(false, t)

    fun workspace(ctx: Context): File = File(ctx.filesDir, "workspace").apply { mkdirs() }

    private fun safe(name: String, defExt: String): String {
        var n = name.substringAfterLast('/').substringAfterLast('\\').trim().replace(Regex("[^A-Za-z0-9._ -]"), "_")
        if (n.isEmpty() || n == "." || n == "..") n = "file"
        if (!n.contains('.')) n += "." + defExt
        return n.take(80)
    }

    /** Copies a workspace file to Downloads/Vethos and returns "📄 [name](content-uri)". */
    fun publish(ctx: Context, f: File): String? {
        val ext = f.extension.lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        val cv = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, f.name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/Vethos")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return null
        ctx.contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } } ?: return null
        val icon = when (ext) { "pdf" -> "📕"; "docx" -> "📘"; "xlsx" -> "📗"; "png", "jpg" -> "🖼"; "html" -> "🌐"; else -> "📄" }
        return icon + " [" + f.name.replace("[", "(").replace("]", ")") + " (tap to open)](" + uri.toString() + ")"
    }

    private fun shown(c: ToolCtx, f: File, what: String): ToolResult {
        val link = publish(c.ctx, f) ?: return ok(what + " saved in the workspace, but could not copy it to Downloads.")
        return ok(what + " is ready in Downloads/Vethos:\n" + link, "The file was created and shown to the user as a tappable link. Just tell the user it is ready.")
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    fun build(): List<ToolDef> = listOf(
        ToolDef(
            id = "create_file", title = "Create file", icon = R.drawable.ic_code, sensitive = false,
            desc = "Creates a text or code file (txt, md, csv, json, html, py, ...) in the workspace",
            params = listOf(ToolParam("name", "File name"), ToolParam("content", "Content")),
            usage = "{\"name\":\"notes.md\",\"content\":\"...\"} creates a file",
            run = { c, a, done ->
                val f = File(workspace(c.ctx), safe(a.optString("name"), "txt"))
                f.writeText(a.optString("content"))
                done(ok("Created " + f.name + " (" + f.length() + " bytes)", "File created: " + f.name))
            },
            headless = true,
        ),
        ToolDef(
            id = "view_file", title = "View file", icon = R.drawable.ic_code, sensitive = false,
            desc = "Reads a file from the workspace",
            params = listOf(ToolParam("name", "File name")),
            usage = "{\"name\":\"notes.md\"} shows the file text",
            run = { c, a, done ->
                val f = File(workspace(c.ctx), safe(a.optString("name"), "txt"))
                if (!f.isFile) done(bad("No such file: " + f.name))
                else done(ok("Read " + f.name, f.readText().take(3000)))
            },
            headless = true,
        ),
        ToolDef(
            id = "edit_file", title = "Edit file", icon = R.drawable.ic_edit, sensitive = false,
            desc = "Replaces one piece of text inside a workspace file",
            params = listOf(ToolParam("name", "File name"), ToolParam("old", "Text to replace"), ToolParam("new", "New text")),
            usage = "{\"name\":\"a.py\",\"old\":\"x=1\",\"new\":\"x=2\"} replaces text once",
            run = { c, a, done ->
                val f = File(workspace(c.ctx), safe(a.optString("name"), "txt"))
                val old = a.optString("old")
                if (!f.isFile) done(bad("No such file: " + f.name))
                else {
                    val t = f.readText()
                    val n = if (old.isEmpty()) 0 else t.split(old).size - 1
                    if (n != 1) done(bad(if (n == 0) "That text was not found" else "That text appears " + n + " times; give a longer piece"))
                    else { f.writeText(t.replace(old, a.optString("new"))); done(ok("Edited " + f.name)) }
                }
            },
            headless = true,
        ),
        ToolDef(
            id = "list_files", title = "List files", icon = R.drawable.ic_code, sensitive = false,
            desc = "Lists the files in the workspace",
            params = emptyList(),
            usage = "{} lists workspace files",
            run = { c, _, done ->
                val l = (workspace(c.ctx).listFiles() ?: emptyArray()).sortedBy { it.name }
                val s = if (l.isEmpty()) "The workspace is empty" else l.joinToString("\n") { it.name + " (" + it.length() + " bytes)" }
                done(ok(s, s))
            },
            headless = true,
        ),
        ToolDef(
            id = "present_file", title = "Share file", icon = R.drawable.ic_share, sensitive = false,
            desc = "Copies a workspace file to Downloads and shows a tap-to-open link",
            params = listOf(ToolParam("name", "File name")),
            usage = "{\"name\":\"notes.md\"} gives the user the file",
            run = { c, a, done ->
                val f = File(workspace(c.ctx), safe(a.optString("name"), "txt"))
                done(if (f.isFile) shown(c, f, f.name) else bad("No such file: " + f.name))
            },
            headless = true,
        ),
        ToolDef(
            id = "make_pdf", title = "Make PDF", icon = R.drawable.ic_code, sensitive = false,
            desc = "Makes a PDF document from text",
            params = listOf(ToolParam("name", "File name"), ToolParam("title", "Title", optional = true), ToolParam("content", "Text")),
            usage = "{\"name\":\"report.pdf\",\"title\":\"...\",\"content\":\"text, blank line = new paragraph\"} makes a PDF",
            run = { c, a, done ->
                val f = File(workspace(c.ctx), safe(a.optString("name"), "pdf"))
                makePdf(f, a.optString("title"), a.optString("content"))
                done(shown(c, f, f.name))
            },
            headless = true,
        ),
        ToolDef(
            id = "make_docx", title = "Make Word file", icon = R.drawable.ic_code, sensitive = false,
            desc = "Makes a Word (.docx) document from text",
            params = listOf(ToolParam("name", "File name"), ToolParam("title", "Title", optional = true), ToolParam("content", "Text")),
            usage = "{\"name\":\"letter.docx\",\"title\":\"...\",\"content\":\"text, one paragraph per line\"} makes a Word file",
            run = { c, a, done ->
                val f = File(workspace(c.ctx), safe(a.optString("name"), "docx"))
                makeDocx(f, a.optString("title"), a.optString("content"))
                done(shown(c, f, f.name))
            },
            headless = true,
        ),
        ToolDef(
            id = "make_xlsx", title = "Make Excel file", icon = R.drawable.ic_code, sensitive = false,
            desc = "Makes an Excel (.xlsx) sheet from CSV text",
            params = listOf(ToolParam("name", "File name"), ToolParam("csv", "Rows, comma separated")),
            usage = "{\"name\":\"data.xlsx\",\"csv\":\"Name,Qty\\nTea,2\"} makes an Excel file",
            run = { c, a, done ->
                val f = File(workspace(c.ctx), safe(a.optString("name"), "xlsx"))
                makeXlsx(f, a.optString("csv").ifBlank { a.optString("content") })
                done(shown(c, f, f.name))
            },
            headless = true,
        ),
        ToolDef(
            id = "chart", title = "Make chart", icon = R.drawable.ic_ins, sensitive = false,
            desc = "Draws a bar, line or pie chart as a picture",
            params = listOf(ToolParam("type", "bar, line or pie"), ToolParam("title", "Title"),
                ToolParam("labels", "Labels", "a,b,c"), ToolParam("values", "Numbers", "1,2,3")),
            usage = "{\"type\":\"bar\",\"title\":\"Sales\",\"labels\":\"Jan,Feb\",\"values\":\"10,20\"} draws a chart",
            run = { c, a, done ->
                val labels = a.optString("labels").split(",").map { it.trim() }.filter { it.isNotEmpty() }
                val vals = a.optString("values").split(",").mapNotNull { it.trim().toDoubleOrNull() }
                if (vals.isEmpty()) done(bad("Need numbers in values"))
                else {
                    val f = File(workspace(c.ctx), safe("chart-" + System.currentTimeMillis(), "png"))
                    drawChart(f, a.optString("type").lowercase(), a.optString("title"), labels, vals)
                    done(shown(c, f, "Chart"))
                }
            },
            headless = true,
        ),
        ToolDef(
            id = "page", title = "Make web page", icon = R.drawable.ic_code, sensitive = false,
            desc = "Saves an HTML page (app, card, report). It opens only when you tap it",
            params = listOf(ToolParam("name", "File name"), ToolParam("html", "Full HTML")),
            usage = "{\"name\":\"card.html\",\"html\":\"<html>...</html>\"} saves a page",
            run = { c, a, done ->
                val f = File(workspace(c.ctx), safe(a.optString("name"), "html"))
                f.writeText(a.optString("html"))
                done(shown(c, f, f.name))
            },
            headless = true,
        ),
        ToolDef(
            id = "shell", title = "Run command", icon = R.drawable.ic_code, sensitive = true,
            desc = "Runs a shell command inside the app (limited Android shell)",
            params = listOf(ToolParam("command", "Command")),
            usage = "{\"command\":\"ls -la\"} runs a command (asks first)",
            run = { c, a, done ->
                val cmd = a.optString("command").trim()
                if (cmd.isEmpty()) done(bad("Need a command"))
                else NetTools.bg(c, done) {
                    val p = ProcessBuilder("sh", "-c", cmd).directory(workspace(c.ctx)).redirectErrorStream(true).start()
                    val out = StringBuilder()
                    val t = Thread { try { p.inputStream.bufferedReader().forEachLine { if (out.length < 4000) out.append(it).append('\n') } } catch (_: Exception) { } }
                    t.start()
                    val finished = p.waitFor(15, java.util.concurrent.TimeUnit.SECONDS)
                    if (!finished) p.destroyForcibly()
                    t.join(500)
                    val s = out.toString().trim().ifEmpty { "(no output)" }
                    ToolResult(true, if (finished) "Command finished" else "Stopped after 15 seconds", s.take(2000))
                }
            },
            headless = true,
        ),
    )

    // ------------------------------------------------------------------ PDF
    private fun makePdf(f: File, title: String, content: String) {
        val w = 595; val h = 842; val m = 48f
        val doc = PdfDocument()
        val body = Paint().apply { textSize = 12f; isAntiAlias = true; color = Color.BLACK }
        val head = Paint().apply { textSize = 20f; isAntiAlias = true; typeface = Typeface.DEFAULT_BOLD; color = Color.BLACK }
        var pageNo = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, pageNo).create())
        var cv = page.canvas
        var y = m + 14f
        fun newPage() {
            doc.finishPage(page); pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, pageNo).create())
            cv = page.canvas; y = m + 14f
        }
        fun line(text: String, p: Paint, gap: Float) {
            if (y > h - m) newPage()
            cv.drawText(text, m, y, p); y += gap
        }
        fun wrap(text: String, p: Paint, gap: Float) {
            var cur = ""
            for (word in text.split(" ")) {
                val t = if (cur.isEmpty()) word else "$cur $word"
                if (p.measureText(t) > w - 2 * m && cur.isNotEmpty()) { line(cur, p, gap); cur = word } else cur = t
            }
            line(cur, p, gap)
        }
        if (title.isNotBlank()) { wrap(title, head, 28f); y += 6f }
        for (para in content.replace("\r", "").split("\n")) {
            if (para.isBlank()) y += 10f else wrap(para.trim(), body, 17f)
        }
        doc.finishPage(page)
        FileOutputStream(f).use { doc.writeTo(it) }
        doc.close()
    }

    // ------------------------------------------------------------------ DOCX
    private fun zip(f: File, files: List<Pair<String, String>>) {
        ZipOutputStream(FileOutputStream(f)).use { z ->
            for ((n, t) in files) { z.putNextEntry(ZipEntry(n)); z.write(t.toByteArray(Charsets.UTF_8)); z.closeEntry() }
        }
    }

    private fun makeDocx(f: File, title: String, content: String) {
        val sb = StringBuilder()
        fun para(t: String, bold: Boolean, size: Int) {
            sb.append("<w:p><w:r><w:rPr>").append(if (bold) "<w:b/>" else "").append("<w:sz w:val=\"").append(size).append("\"/></w:rPr><w:t xml:space=\"preserve\">")
                .append(esc(t)).append("</w:t></w:r></w:p>")
        }
        if (title.isNotBlank()) para(title, true, 40)
        for (ln in content.replace("\r", "").split("\n")) {
            if (ln.startsWith("#")) para(ln.trimStart('#', ' '), true, 30) else para(ln, false, 24)
        }
        val ns = "http://schemas.openxmlformats.org/"
        zip(f, listOf(
            "[Content_Types].xml" to "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"" + ns + "package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>",
            "_rels/.rels" to "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"" + ns + "package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"" + ns + "officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>",
            "word/document.xml" to "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><w:document xmlns:w=\"" + ns + "wordprocessingml/2006/main\"><w:body>" + sb + "</w:body></w:document>",
        ))
    }

    // ------------------------------------------------------------------ XLSX
    private fun csvRow(line: String): List<String> {
        val out = ArrayList<String>(); val cur = StringBuilder(); var q = false
        for (ch in line) {
            if (ch == '"') q = !q else if (ch == ',' && !q) { out.add(cur.toString()); cur.setLength(0) } else cur.append(ch)
        }
        out.add(cur.toString()); return out
    }

    private fun colName(i: Int): String {
        var n = i; val s = StringBuilder()
        do { s.insert(0, ('A' + n % 26)); n = n / 26 - 1 } while (n >= 0)
        return s.toString()
    }

    private fun makeXlsx(f: File, csv: String) {
        val rows = StringBuilder()
        csv.replace("\r", "").split("\n").filter { it.isNotBlank() }.forEachIndexed { r, line ->
            rows.append("<row r=\"").append(r + 1).append("\">")
            csvRow(line).forEachIndexed { cIdx, v ->
                val ref = colName(cIdx) + (r + 1)
                val num = v.trim().toDoubleOrNull()
                if (num != null) rows.append("<c r=\"").append(ref).append("\"><v>").append(v.trim()).append("</v></c>")
                else rows.append("<c r=\"").append(ref).append("\" t=\"inlineStr\"><is><t xml:space=\"preserve\">").append(esc(v)).append("</t></is></c>")
            }
            rows.append("</row>")
        }
        val ns = "http://schemas.openxmlformats.org/"
        zip(f, listOf(
            "[Content_Types].xml" to "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"" + ns + "package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>",
            "_rels/.rels" to "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"" + ns + "package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"" + ns + "officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>",
            "xl/workbook.xml" to "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><workbook xmlns=\"" + ns + "spreadsheetml/2006/main\" xmlns:r=\"" + ns + "officeDocument/2006/relationships\"><sheets><sheet name=\"Sheet1\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>",
            "xl/_rels/workbook.xml.rels" to "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"" + ns + "package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"" + ns + "officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>",
            "xl/worksheets/sheet1.xml" to "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"" + ns + "spreadsheetml/2006/main\"><sheetData>" + rows + "</sheetData></worksheet>",
        ))
    }

    // ------------------------------------------------------------------ chart
    private fun drawChart(f: File, type: String, title: String, labels: List<String>, vals: List<Double>) {
        val w = 900; val h = 560
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        cv.drawColor(Color.WHITE)
        val ink = Paint().apply { color = Color.rgb(31, 26, 23); isAntiAlias = true; textSize = 26f }
        val orange = Paint().apply { color = Color.rgb(201, 98, 63); isAntiAlias = true; strokeWidth = 5f; style = Paint.Style.FILL }
        ink.typeface = Typeface.DEFAULT_BOLD
        cv.drawText(title.take(40), 40f, 50f, ink)
        ink.typeface = Typeface.DEFAULT; ink.textSize = 20f
        val maxV = (vals.maxOrNull() ?: 1.0).let { if (it <= 0) 1.0 else it }
        val left = 70f; val right = w - 40f; val top = 90f; val bottom = h - 90f
        val n = vals.size
        if (type == "pie") {
            val total = vals.sum().let { if (it <= 0) 1.0 else it }
            val rect = android.graphics.RectF(60f, 90f, 60f + 380f, 90f + 380f)
            var start = -90f
            vals.forEachIndexed { i, v ->
                orange.color = Color.HSVToColor(floatArrayOf((i * 47f) % 360f, 0.55f, 0.88f))
                val sweep = (v / total * 360.0).toFloat()
                cv.drawArc(rect, start, sweep, true, orange); start += sweep
                cv.drawRect(500f, 110f + i * 34f, 524f, 134f + i * 34f, orange)
                cv.drawText((labels.getOrNull(i) ?: ("#" + (i + 1))).take(18) + "  " + v, 536f, 130f + i * 34f, ink)
            }
        } else {
            cv.drawLine(left, bottom, right, bottom, ink); cv.drawLine(left, top, left, bottom, ink)
            val slot = (right - left) / n
            val path = Path()
            vals.forEachIndexed { i, v ->
                val x = left + slot * i + slot / 2
                val y = bottom - ((v / maxV) * (bottom - top)).toFloat()
                if (type == "line") {
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    cv.drawCircle(x, y, 7f, orange)
                } else {
                    cv.drawRect(x - slot * 0.32f, y, x + slot * 0.32f, bottom, orange)
                }
                ink.textAlign = Paint.Align.CENTER
                cv.drawText(v.toString().removeSuffix(".0"), x, y - 10f, ink)
                cv.drawText((labels.getOrNull(i) ?: "").take(10), x, bottom + 30f, ink)
                ink.textAlign = Paint.Align.LEFT
            }
            if (type == "line") { val lp = Paint(orange).apply { style = Paint.Style.STROKE }; cv.drawPath(path, lp) }
        }
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }
}
