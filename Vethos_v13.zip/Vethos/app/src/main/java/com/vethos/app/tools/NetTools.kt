package com.vethos.app.tools

import com.vethos.app.R
import org.json.JSONArray
import org.json.JSONObject
import kotlin.concurrent.thread

/** Internet tools: web_search, web_fetch, image_search, weather, sports, places. They need a connection; the rest of the app stays offline. */
object NetTools {
    /** Runs [work] on a background thread and delivers its result on the main thread. */
    fun bg(c: ToolCtx, done: (ToolResult) -> Unit, work: () -> ToolResult) {
        val h = android.os.Handler(android.os.Looper.getMainLooper())
        thread {
            val r = try { work() } catch (e: Throwable) {
                ToolResult(false, "Internet request failed: " + (e.message ?: e.javaClass.simpleName))
            }
            h.post { done(r) }
        }
    }

    private fun ok(text: String, data: String? = null) = ToolResult(true, text, data)
    private fun bad(text: String) = ToolResult(false, text)

    fun build(): List<ToolDef> = listOf(
        ToolDef(
            id = "web_search", title = "Web search", icon = R.drawable.ic_search, sensitive = false,
            desc = "Searches the internet and returns the top results",
            params = listOf(ToolParam("query", "Search words")),
            usage = "{\"query\":\"words\"} searches the web",
            run = { c, a, done ->
                val q = a.optString("query").ifBlank { a.optString("q") }.trim()
                if (q.isEmpty()) done(bad("Need a search query")) else bg(c, done) { webSearch(q) }
            },
            headless = true,
        ),
        ToolDef(
            id = "web_fetch", title = "Open web page", icon = R.drawable.ic_search, sensitive = false,
            desc = "Reads the text of a web page",
            params = listOf(ToolParam("url", "Page address")),
            usage = "{\"url\":\"https://...\"} reads a page",
            run = { c, a, done ->
                val u = a.optString("url").trim()
                if (!u.startsWith("http")) done(bad("Need a full web address (https://...)")) else bg(c, done) {
                    val text = Http.htmlToText(Http.get(u))
                    if (text.isBlank()) bad("The page had no readable text") else ok("Read " + u, text.take(3000))
                }
            },
            headless = true,
        ),
        ToolDef(
            id = "image_search", title = "Image search", icon = R.drawable.ic_search, sensitive = false,
            desc = "Finds pictures (Wikimedia Commons). Tap a result to open it",
            params = listOf(ToolParam("query", "What to look for")),
            usage = "{\"query\":\"words\"} finds pictures",
            run = { c, a, done ->
                val q = a.optString("query").trim()
                if (q.isEmpty()) done(bad("Need a search query")) else bg(c, done) { imageSearch(q) }
            },
            headless = true,
        ),
        ToolDef(
            id = "weather", title = "Weather", icon = R.drawable.ic_search, sensitive = false,
            desc = "Current weather and a 3-day forecast for a city",
            params = listOf(ToolParam("city", "City name")),
            usage = "{\"city\":\"Karachi\"} weather now + 3 days",
            run = { c, a, done ->
                val city = a.optString("city").ifBlank { a.optString("location") }.trim()
                if (city.isEmpty()) done(bad("Need a city")) else bg(c, done) { weather(city) }
            },
            headless = true,
        ),
        ToolDef(
            id = "sports", title = "Sports scores", icon = R.drawable.ic_search, sensitive = false,
            desc = "Latest scores: epl, la_liga, serie_a, bundesliga, ligue_1, mls, champions_league, nba, nfl, mlb, nhl",
            params = listOf(ToolParam("league", "League", "e.g. epl or nba"), ToolParam("team", "Team", optional = true)),
            usage = "{\"league\":\"epl\",\"team\":\"optional\"} recent scores",
            run = { c, a, done ->
                val lg = a.optString("league").trim().lowercase()
                if (lg.isEmpty()) done(bad("Need a league")) else bg(c, done) { sports(lg, a.optString("team").trim()) }
            },
            headless = true,
        ),
        ToolDef(
            id = "places", title = "Find places", icon = R.drawable.ic_search, sensitive = false,
            desc = "Finds places on the map (OpenStreetMap). Tap a result to open the map",
            params = listOf(ToolParam("query", "What and where", "e.g. pharmacy Gulshan Karachi")),
            usage = "{\"query\":\"pharmacy in Karachi\"} finds places",
            run = { c, a, done ->
                val q = a.optString("query").trim()
                if (q.isEmpty()) done(bad("Need a query")) else bg(c, done) { places(q) }
            },
            headless = true,
        ),
    )

    // ---------------------------------------------------------------- web_search
    private fun webSearch(q: String): ToolResult {
        val lines = ArrayList<String>()
        try {
            val html = Http.get("https://html.duckduckgo.com/html/?q=" + Http.enc(q), 400_000)
            val link = Regex("(?s)<a[^>]*class=\"result__a\"[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a>")
            val snip = Regex("(?s)<a[^>]*class=\"result__snippet\"[^>]*>(.*?)</a>")
            val links = link.findAll(html).toList()
            val snips = snip.findAll(html).toList()
            for ((i, m) in links.take(5).withIndex()) {
                var u = m.groupValues[1].replace("&amp;", "&")
                val k = u.indexOf("uddg=")
                if (k >= 0) u = Http.dec(u.substring(k + 5).substringBefore('&'))
                if (u.startsWith("//")) u = "https:" + u
                val title = Http.htmlToText(m.groupValues[2])
                val s = snips.getOrNull(i)?.let { Http.htmlToText(it.groupValues[1]) } ?: ""
                lines.add((i + 1).toString() + ". " + title + "\n" + u + "\n" + s)
            }
        } catch (_: Throwable) { }
        if (lines.isEmpty()) {
            val j = JSONObject(Http.get("https://en.wikipedia.org/w/api.php?action=query&list=search&format=json&srlimit=5&srsearch=" + Http.enc(q)))
            val arr = j.optJSONObject("query")?.optJSONArray("search") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val t = o.optString("title")
                lines.add((i + 1).toString() + ". " + t + "\nhttps://en.wikipedia.org/wiki/" + Http.enc(t.replace(' ', '_')) + "\n" + Http.htmlToText(o.optString("snippet")))
            }
        }
        if (lines.isEmpty()) return bad("No results for \"" + q + "\"")
        val body = lines.joinToString("\n\n")
        return ok("Searched the web for \"" + q + "\" (" + lines.size + " results)",
            "Search results for \"" + q + "\":\n" + body + "\n\nTo read a page in full use web_fetch with its address.")
    }

    // ---------------------------------------------------------------- image_search
    private fun imageSearch(q: String): ToolResult {
        val url = "https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrnamespace=6&gsrlimit=4&prop=imageinfo&iiprop=url&iiurlwidth=800&format=json&gsrsearch=" + Http.enc(q)
        val pages = JSONObject(Http.get(url)).optJSONObject("query")?.optJSONObject("pages") ?: return bad("No pictures found")
        val sb = StringBuilder()
        pages.keys().forEach { k ->
            val p = pages.getJSONObject(k)
            val info = p.optJSONArray("imageinfo")?.optJSONObject(0)
            val img = info?.optString("thumburl")?.ifBlank { info.optString("url") } ?: ""
            if (img.isNotEmpty()) {
                val title = p.optString("title").removePrefix("File:").substringBeforeLast('.').replace('_', ' ')
                sb.append("🖼 [").append(title.take(60)).append("](").append(img).append(")\n")
            }
        }
        if (sb.isEmpty()) return bad("No pictures found for \"" + q + "\"")
        return ok("Pictures for \"" + q + "\" (tap one to open):\n" + sb.toString().trim(),
            "Pictures were shown to the user as tappable links. Just say they are above.")
    }

    // ---------------------------------------------------------------- weather
    private val wcode = mapOf(0 to "clear", 1 to "mostly clear", 2 to "partly cloudy", 3 to "overcast", 45 to "fog", 48 to "fog",
        51 to "light drizzle", 53 to "drizzle", 55 to "heavy drizzle", 61 to "light rain", 63 to "rain", 65 to "heavy rain",
        71 to "light snow", 73 to "snow", 75 to "heavy snow", 80 to "showers", 81 to "showers", 82 to "heavy showers",
        95 to "thunderstorm", 96 to "thunderstorm with hail", 99 to "thunderstorm with hail")

    private fun weather(city: String): ToolResult {
        val g = JSONObject(Http.get("https://geocoding-api.open-meteo.com/v1/search?count=1&name=" + Http.enc(city)))
        val r = g.optJSONArray("results")?.optJSONObject(0) ?: return bad("City \"" + city + "\" not found")
        val lat = r.getDouble("latitude")
        val lon = r.getDouble("longitude")
        val name = r.optString("name") + ", " + r.optString("country")
        val w = JSONObject(Http.get("https://api.open-meteo.com/v1/forecast?latitude=" + lat + "&longitude=" + lon +
            "&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,weather_code&timezone=auto&forecast_days=3"))
        val cur = w.getJSONObject("current")
        val sb = StringBuilder()
        sb.append(name).append(" now: ").append(cur.optDouble("temperature_2m")).append("°C, ")
            .append(wcode[cur.optInt("weather_code")] ?: "").append(", humidity ").append(cur.optInt("relative_humidity_2m"))
            .append("%, wind ").append(cur.optDouble("wind_speed_10m")).append(" km/h")
        val d = w.getJSONObject("daily")
        val days = d.getJSONArray("time")
        for (i in 0 until days.length()) {
            sb.append("\n").append(days.getString(i)).append(": ")
                .append(d.getJSONArray("temperature_2m_min").optDouble(i)).append("–").append(d.getJSONArray("temperature_2m_max").optDouble(i)).append("°C, ")
                .append(wcode[d.getJSONArray("weather_code").optInt(i)] ?: "").append(", rain chance ")
                .append(d.getJSONArray("precipitation_probability_max").optInt(i)).append("%")
        }
        return ok(sb.toString(), sb.toString())
    }

    // ---------------------------------------------------------------- sports (ESPN public scoreboard)
    private val leagues = mapOf(
        "epl" to "soccer/eng.1", "premier_league" to "soccer/eng.1", "la_liga" to "soccer/esp.1", "serie_a" to "soccer/ita.1",
        "bundesliga" to "soccer/ger.1", "ligue_1" to "soccer/fra.1", "mls" to "soccer/usa.1", "champions_league" to "soccer/uefa.champions",
        "nba" to "basketball/nba", "nfl" to "football/nfl", "mlb" to "baseball/mlb", "nhl" to "hockey/nhl",
    )

    private fun sports(league: String, team: String): ToolResult {
        val path = leagues[league.replace(' ', '_')] ?: return bad("League not supported. Use: " + leagues.keys.joinToString(", ") + ". For cricket use web_search.")
        val j = JSONObject(Http.get("https://site.api.espn.com/apis/site/v2/sports/" + path + "/scoreboard"))
        val ev = j.optJSONArray("events") ?: JSONArray()
        val lines = ArrayList<String>()
        for (i in 0 until ev.length()) {
            val e = ev.getJSONObject(i)
            val comp = e.optJSONArray("competitions")?.optJSONObject(0) ?: continue
            val cs = comp.optJSONArray("competitors") ?: continue
            val parts = ArrayList<String>()
            for (k in 0 until cs.length()) {
                val t = cs.getJSONObject(k)
                parts.add(t.optJSONObject("team")?.optString("displayName").orEmpty() + " " + t.optString("score"))
            }
            val st = e.optJSONObject("status")?.optJSONObject("type")?.optString("shortDetail").orEmpty()
            val line = parts.joinToString(" - ") + " (" + st + ")"
            if (team.isEmpty() || line.lowercase().contains(team.lowercase())) lines.add(line)
        }
        if (lines.isEmpty()) return bad("No games found")
        val t = lines.take(10).joinToString("\n")
        return ok(t, t)
    }

    // ---------------------------------------------------------------- places (OpenStreetMap Nominatim)
    private fun places(q: String): ToolResult {
        val arr = JSONArray(Http.get("https://nominatim.openstreetmap.org/search?format=json&limit=5&q=" + Http.enc(q)))
        if (arr.length() == 0) return bad("No places found for \"" + q + "\"")
        val sb = StringBuilder()
        val data = StringBuilder()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val name = o.optString("display_name").split(",").take(3).joinToString(",").trim()
            val geo = "geo:" + o.optString("lat") + "," + o.optString("lon") + "?q=" + o.optString("lat") + "," + o.optString("lon") + "(" + Http.enc(name.take(40)) + ")"
            sb.append("📍 [").append(name.replace("[", "(").replace("]", ")")).append("](").append(geo).append(")\n")
            data.append(name).append(" (").append(o.optString("lat")).append(", ").append(o.optString("lon")).append(")\n")
        }
        return ok("Places for \"" + q + "\" (tap to open the map):\n" + sb.toString().trim(), data.toString())
    }
}
