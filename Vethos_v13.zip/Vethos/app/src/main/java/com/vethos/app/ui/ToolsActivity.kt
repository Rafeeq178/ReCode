package com.vethos.app.ui

import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.vethos.app.R
import com.vethos.app.databinding.ActivityToolsBinding
import com.vethos.app.databinding.ItemToolBinding
import com.vethos.app.tools.CustomTool
import com.vethos.app.tools.CustomTools
import com.vethos.app.tools.Launchers
import com.vethos.app.tools.PermHelper
import com.vethos.app.tools.ToolCtx
import com.vethos.app.tools.ToolDef
import com.vethos.app.tools.ToolRunner
import com.vethos.app.tools.Tools
import org.json.JSONObject

/** Every tool, in groups that open when tapped. Your own tools live in "My tools". */
class ToolsActivity : AppCompatActivity() {
    private lateinit var b: ActivityToolsBinding
    private val perms = PermHelper(this)
    private val launchers = Launchers(this)
    private val open = HashSet<String>()

    private val groups = linkedMapOf(
        "Phone" to setOf("flashlight", "volume", "wifi", "battery", "open_app", "call", "sms", "whatsapp", "navigate", "camera", "notify", "clipboard", "speak"),
        "Internet" to setOf("web_search", "web_fetch", "image_search", "weather", "sports", "places"),
        "Time, calendar, location" to setOf("alarm", "timer", "calendar_add", "calendar_list", "location", "time", "compose"),
        "Files and documents" to setOf("create_file", "view_file", "edit_file", "list_files", "present_file", "make_pdf", "make_docx", "make_xlsx", "chart", "page", "read_file", "write_file", "shell"),
        "Helpers" to setOf("calc", "random", "encode", "qr_make", "qr_scan", "read_skill", "tool_search"),
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityToolsBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnBack.setOnClickListener { finish() }
        b.btnAdd.setOnClickListener { pickKind() }
        render()
    }

    private fun render() {
        b.list.removeAllViews()
        val all = Tools.all
        val used = HashSet<String>()
        for ((name, ids) in groups) {
            val tools = all.filter { it.id in ids }
            used.addAll(tools.map { it.id })
            section(name, tools)
        }
        val mine = all.filter { it.id !in used }
        section("My tools", mine, emptyHint = "No tool of your own yet. Tap + to make one.")
    }

    private fun section(name: String, tools: List<ToolDef>, emptyHint: String? = null) {
        val isOpen = name in open
        b.list.addView(TextView(this).apply {
            text = (if (isOpen) "▾  " else "▸  ") + name + "  (" + tools.size + ")"
            textSize = 17f
            setTextColor(getColor(R.color.v_text))
            setPadding(dp(6), dp(14), dp(6), dp(10))
            setOnClickListener { if (!open.add(name)) open.remove(name); render() }
        })
        if (!isOpen) return
        if (tools.isEmpty() && emptyHint != null) {
            b.list.addView(TextView(this).apply {
                text = emptyHint; setTextColor(getColor(R.color.v_muted)); setPadding(dp(12), 0, dp(6), dp(10))
            })
        }
        tools.forEach { d ->
            val r = ItemToolBinding.inflate(layoutInflater, b.list, false)
            r.icon.setImageResource(d.icon)
            r.title.text = d.title + if (d.sensitive) "  (asks first)" else ""
            r.sub.text = d.desc
            r.sw.isChecked = Tools.enabled(d.id)
            r.sw.setOnCheckedChangeListener { _, on -> Tools.setEnabled(d.id, on) }
            r.root.setOnClickListener { tryTool(d) }
            val mine = CustomTools.list().firstOrNull { it.id == d.id }
            if (mine != null) r.root.setOnLongClickListener { more(mine); true }
            b.list.addView(r.root)
        }
    }

    // ------------------------------------------------------------------ try a tool by hand
    private fun tryTool(d: ToolDef) {
        val ctx = ToolCtx(this, perms, launchers)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), 0)
        }
        val fields = d.params.map { p ->
            EditText(this).apply {
                hint = p.label + if (p.optional) " (optional)" else ""
                if (p.hint.isNotEmpty()) hint = hint.toString() + " – " + p.hint
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            }.also { box.addView(it, LinearLayout.LayoutParams(-1, -2)) }
        }
        fun go() {
            val args = JSONObject()
            d.params.forEachIndexed { i, p ->
                val v = fields[i].text.toString().trim()
                if (v.isNotEmpty()) args.put(p.key, v)
            }
            ToolRunner.run(ctx, d, args, true) { r ->
                if (r.text.length > 70 || r.text.contains('\n'))
                    MaterialAlertDialogBuilder(this).setTitle(d.title).setMessage(r.text).setPositiveButton("OK", null).show()
                else toast(r.text)
            }
        }
        if (d.params.isEmpty()) { go(); return }
        MaterialAlertDialogBuilder(this).setTitle(d.title).setView(ScrollView(this).apply { addView(box) })
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Run") { _, _ -> go() }
            .show()
    }

    // ------------------------------------------------------------------ my own tools
    private fun pickKind() {
        MaterialAlertDialogBuilder(this).setTitle("New tool")
            .setItems(arrayOf("Call a web address (API)", "Open a link or app", "Saved instructions for the model")) { _, which ->
                editCustom(null, arrayOf("http", "open", "prompt")[which])
            }.show()
    }

    private fun more(t: CustomTool) {
        showSheet(t.title, listOf(
            SheetRow(R.drawable.ic_edit, "Edit") { editCustom(t, t.kind) },
            SheetRow(R.drawable.ic_trash, "Delete") {
                confirm("Delete tool?", "“" + t.title + "” will be removed.", "Delete") { CustomTools.delete(t.id); render() }
            },
        ))
    }

    private fun editCustom(old: CustomTool?, kind: String) {
        fun field(hint: String, text: String, lines: Int = 1) = EditText(this).apply {
            setHint(hint); setText(text)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            if (lines > 1) { minLines = lines; maxLines = lines + 5; gravity = Gravity.TOP }
        }
        val name = field("Name (e.g. Petrol price)", old?.title ?: "")
        val desc = field("What it does (the model reads this)", old?.desc ?: "")
        val params = field("Arguments, comma separated (e.g. city,fuel)", old?.params ?: "")
        val url = field(if (kind == "open") "Link, use {city} for arguments" else "Web address, use {city} for arguments", old?.url ?: "")
        val method = field("Method: GET or POST", old?.method ?: "GET")
        val body = field(if (kind == "prompt") "Instructions, use {city} for arguments" else "Body for POST, use {city}", old?.body ?: "", if (kind == "prompt") 6 else 3)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), 0)
            addView(name); addView(desc); addView(params)
            if (kind != "prompt") addView(url)
            if (kind == "http") addView(method)
            if (kind != "open") addView(body)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(if (old == null) "New tool" else "Edit tool")
            .setView(ScrollView(this).apply { addView(box) })
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val n = name.text.toString().trim()
                if (n.isEmpty()) { toast("Name is needed"); return@setPositiveButton }
                CustomTools.save(old?.id, CustomTool("", n, desc.text.toString().trim(), kind, url.text.toString().trim(),
                    method.text.toString().trim().ifEmpty { "GET" }, body.text.toString(), params.text.toString().trim()))
                open.add("My tools")
                render()
            }
            .show()
    }
}
