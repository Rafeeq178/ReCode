package com.vethos.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.MimeTypeMap
import android.widget.Toast

/**
 * Cards in a chat are plain markdown links. Nothing opens until the user taps one:
 *   vethos-ask://text   -> sends "text" as the next message (answer buttons)
 *   content://, file:// -> opens a saved file (PDF, DOCX, chart, page...)
 *   https://, geo:      -> browser / maps
 */
object Links {
    private val steps = HashMap<String, String>()
    private var stepNo = 0

    fun addStep(details: String): String {
        val id = "s" + (++stepNo)
        steps[id] = details
        return id
    }

    fun open(ctx: Context, url: String) {
        try {
            if (url.startsWith("vethos-ask://")) {
                val text = Uri.decode(url.removePrefix("vethos-ask://"))
                var c: Context? = ctx
                while (c is android.content.ContextWrapper && c !is ChatActivity) c = c.baseContext
                (c as? ChatActivity)?.askFromLink(text)
                return
            }
            if (url.startsWith("vethos-step://")) {
                val d = steps[url.removePrefix("vethos-step://")] ?: "Details are not available any more."
                var c: Context? = ctx
                while (c is android.content.ContextWrapper && c !is android.app.Activity) c = c.baseContext
                com.google.android.material.dialog.MaterialAlertDialogBuilder(c ?: ctx)
                    .setTitle("Summary").setMessage(d).setPositiveButton("OK", null).show()
                return
            }
            val uri = Uri.parse(url)
            val i = Intent(Intent.ACTION_VIEW)
            if (url.startsWith("content://") || url.startsWith("file://")) {
                var type = ctx.contentResolver.getType(uri)
                if (type == null) {
                    val ext = MimeTypeMap.getFileExtensionFromUrl(url)
                    type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.lowercase())
                }
                i.setDataAndType(uri, type ?: "*/*")
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } else {
                i.data = uri
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(ctx, "No app can open this", Toast.LENGTH_SHORT).show()
        }
    }
}
