package com.vethos.app.data

import android.graphics.Color
import com.vethos.app.R
import com.vethos.app.tools.Tools
import org.json.JSONArray

/**
 * temp = creativity in tenths (0..10); tone / lang = "" means automatic;
 * tools = "" none, "*" all, or comma separated tool ids.
 */
data class Persona(
    val id: String, var name: String, var desc: String, var prompt: String, var ico: Int,
    var temp: Int = 5, var tone: String = "", var lang: String = "", var tools: String = "",
) {
    /** Tool ids this personality may use right now (also switched on in the Phone tools screen). */
    fun allowedTools(): Set<String> {
        val ids = if (tools == "*") Tools.all.map { it.id } else tools.split(',').map { it.trim() }.filter { it.isNotEmpty() }
        val base = ids.filter { Tools.get(it) != null && Tools.enabled(it) }.toSet()
        // every personality can load skills as soon as one skill is switched on
        return if (Tools.enabled("read_skill") && Skills.hasEnabled()) base + "read_skill" else base
    }
}

class PIcon(val res: Int, val tint: Int)

/** Vethos has ONE assistant. No personalities to choose from. */
object Personas {
    val icons = listOf(PIcon(R.drawable.ic_asterisk, Color.parseColor("#C9623F")))

    private val one by lazy { Persona("assistant", "Vethos", "", "", 0, 5, "", "", "*") }

    fun all(): List<Persona> = listOf(one)
    fun get(id: String?): Persona? = one
    fun current(): Persona = one
    var selectedId: String
        get() = one.id
        set(@Suppress("UNUSED_PARAMETER") v) { }
}
