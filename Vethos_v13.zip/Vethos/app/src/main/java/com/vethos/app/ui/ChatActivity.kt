package com.vethos.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.speech.RecognizerIntent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.vethos.app.R
import com.vethos.app.data.Chat
import com.vethos.app.data.ChatRepo
import com.vethos.app.data.Engine
import com.vethos.app.data.Msg
import com.vethos.app.data.Persona
import com.vethos.app.data.Personas
import com.vethos.app.data.Store
import com.vethos.app.databinding.ActivityChatBinding
import com.vethos.app.tools.PhoneTools
import com.vethos.app.lang.Speaker
import com.vethos.app.tools.Launchers
import com.vethos.app.tools.PermHelper
import com.vethos.app.tools.ToolCtx
import com.vethos.app.tools.ToolRunner
import com.vethos.app.tools.Tools
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class ChatActivity : AppCompatActivity() {
    private lateinit var b: ActivityChatBinding
    private lateinit var chat: Chat
    private lateinit var persona: Persona
    private lateinit var adapter: ChatAdapter
    private var gen: Job? = null
    private var typer: Job? = null
    private var ready = false
    private var pendingSend: String? = null
    private var attached: Attach.Picked? = null
    private val perms = PermHelper(this)
    private val launchers = Launchers(this)
    private var busyWeb = false    // true while /research is searching and reading pages
    private var preparing = false  // true while the message is being translated to English
    private var toolDepth = 0   // how many tool results were already handed back to the model (agent loop)
    private val MAX_TOOL_DEPTH = 3

    // live typing state
    private val target = StringBuilder()
    private var shown = 0
    private var generating = false
    private var autoFollow = true

    private val speech = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == RESULT_OK && !t.isNullOrBlank()) {
            b.input.setText(t); b.input.setSelection(t.length)
        }
    }

    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) attachFile(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityChatBinding.inflate(layoutInflater)
        setContentView(b.root)

        val existing = ChatRepo.get(intent.getStringExtra("id"))
        chat = existing ?: Chat(UUID.randomUUID().toString(), "New chat", System.currentTimeMillis(), mutableListOf())
        persona = if (existing != null) {
            Personas.get(existing.persona) ?: Personas.current()
        } else {
            Personas.get(intent.getStringExtra("persona")) ?: Personas.current()
        }
        chat.persona = persona.id
        if (existing == null) Personas.selectedId = persona.id

        adapter = ChatAdapter(chat.msgs, ::copy, ::feedback, ::share, ::speakMsg) { regenerate() }
        val lm = LinearLayoutManager(this)
        b.rv.layoutManager = lm
        b.rv.adapter = adapter
        b.rv.itemAnimator = null
        b.rv.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(rv: RecyclerView, state: Int) {
                if (state == RecyclerView.SCROLL_STATE_DRAGGING) autoFollow = false
                else if (state == RecyclerView.SCROLL_STATE_IDLE && !rv.canScrollVertically(1)) autoFollow = true
            }
        })
        applyPersona()
        Blocks.onSave = { lang, code -> saveCode(lang, code) }

        b.btnBack.setOnClickListener { finish() }
        b.btnHistory.setOnClickListener { startActivity(Intent(this, HistoryActivity::class.java)) }
        b.btnMore.setOnClickListener { showOptions() }
        b.btnAttach.setOnClickListener { pickFile.launch(arrayOf("*/*")) }
        b.attachClose.setOnClickListener { attached = null; b.attachBar.visibility = View.GONE }
        b.btnMic.setOnClickListener { listen() }
        b.send.setOnClickListener { if (gen?.isActive == true) gen?.cancel() else send(null) }

        val preset = intent.getStringExtra("preset")?.takeIf { it.isNotEmpty() }
        if (preset != null) {
            if (intent.getBooleanExtra("autosend", false)) pendingSend = preset
            else { b.input.setText(preset); b.input.setSelection(preset.length) }
        }

        listOf("Help me plan my day", "Explain inflation in simple words", "Give me 5 ideas for a small online business")
            .forEach { q ->
                b.sugs.addView(TextView(this).apply {
                    text = q
                    setBackgroundResource(R.drawable.bg_chip_sug)
                    setTextColor(getColor(R.color.v_text))
                    textSize = 15f
                    elevation = dp(1).toFloat()
                    setPadding(dp(18), dp(12), dp(18), dp(12))
                    setOnClickListener { send(q) }
                }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(12) })
            }

        refreshHero()
        scrollBottom()
        loadModel()
    }

    private fun applyPersona() {
        b.title.text = "Vethos"
        b.heroTitle.text = "Hey there"
        b.heroSub.text = "How can I help?"
        b.heroIcon.setImageResource(R.drawable.ic_asterisk)
    }

    private fun refreshHero() {
        val empty = chat.msgs.isEmpty() && !adapter.thinking
        b.hero.visibility = if (empty) View.VISIBLE else View.GONE
        b.rv.visibility = if (empty) View.INVISIBLE else View.VISIBLE
    }

    private fun scrollBottom() = b.rv.post {
        if (adapter.itemCount > 0) b.rv.scrollToPosition(adapter.itemCount - 1)
    }

    private fun showBanner(text: String, onClick: (() -> Unit)?) {
        b.banner.text = text
        b.banner.visibility = View.VISIBLE
        b.banner.setOnClickListener { onClick?.invoke() }
    }

    private fun modelFile(): File? = Store.lastModel?.let { File(Store.modelsDir, it) }?.takeIf { it.exists() }

    private fun loadModel(force: Boolean = false, history: List<Msg> = chat.msgs) {
        val f = modelFile()
        if (f == null) {
            b.sub.text = "No model"
            showBanner("No model yet. Tap here to open the Library.") {
                startActivity(
                    Intent(this, MainActivity::class.java).putExtra("tab", 1)
                        .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                )
                finish()
            }
            return
        }
        b.sub.text = f.name.removeSuffix(".gguf")
        b.banner.visibility = View.GONE
        b.loading.visibility = View.VISIBLE
        ready = false
        val system = buildSystem(history)
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.Default) { Engine.load(this@ChatActivity, f.absolutePath, chat.id, system, force) }
                ready = true
                pendingSend?.let { pendingSend = null; send(it) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                showBanner("Could not load this model: " + (e.message ?: "unknown error"), null)
            } finally {
                b.loading.visibility = View.GONE
            }
        }
    }

    private fun buildSystem(history: List<Msg>): String = com.vethos.app.data.SystemPrompt.build(history)

    private fun listen() {
        try {
            speech.launch(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Store.voiceLang)
            )
        } catch (e: Exception) {
            toast("Voice input isn't available on this phone")
        }
    }

    private fun attachFile(uri: android.net.Uri) {
        lifecycleScope.launch {
            try {
                val p = withContext(Dispatchers.IO) { Attach.read(this@ChatActivity, uri) }
                attached = p
                b.attachName.text = p.name + if (p.truncated) "  (first ${Attach.MAX_CHARS} characters used)" else ""
                b.attachBar.visibility = View.VISIBLE
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                toast(e.message ?: "Could not read this file")
            }
        }
    }

    /** Called when the user taps an answer button (vethos-ask:// link) inside a chat. */
    fun askFromLink(text: String) { send(text) }

    private fun send(preset: String?) {
        val q = (preset ?: b.input.text.toString()).trim()
        val file = attached
        if (q.isEmpty() && file == null) return
        if (!ready) {
            if (b.loading.visibility == View.VISIBLE) { pendingSend = q; b.input.setText("") }
            else toast("Select a model first")
            return
        }
        if (gen?.isActive == true || preparing || busyWeb) return
        toolDepth = 0
        b.input.setText("")
        attached = null
        b.attachBar.visibility = View.GONE
        val shownText = if (file != null) Attach.wrap(file, q) else q
        val m = Msg("user", shownText)
        chat.msgs.add(m)
        if (chat.title == "New chat") chat.title = (if (q.isNotEmpty()) q else "File: " + file?.name).take(40)
        adapter.notifyItemInserted(chat.msgs.lastIndex)
        refreshHero(); scrollBottom()
        generate(shownText)
    }

    /** An answer made by the app itself (translation, help), not by the model. */
    private fun replyLocal(text: String) {
        chat.msgs.add(Msg("ai", text))
        adapter.notifyItemInserted(chat.msgs.lastIndex)
        refreshHero(); scrollBottom()
        if (Store.keepHistory) ChatRepo.save(chat)
    }

    private fun clipboardText(): String {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val c = cm.primaryClip
        return if (c != null && c.itemCount > 0) c.getItemAt(0).coerceToText(this).toString().trim() else ""
    }

    private fun speakMsg(m: Msg) = Speaker.toggle(this, m.text)

    private fun generate(prompt: String) {
        adapter.thinking = true
        adapter.notifyItemInserted(chat.msgs.size)
        refreshHero(); scrollBottom(); setBusy(true)
        autoFollow = true
        target.setLength(0); shown = 0; generating = true
        val t0 = SystemClock.uptimeMillis()
        gen = lifecycleScope.launch {
            var ai: Msg? = null
            var tFirst = 0L
            var cancelled = false
            try {
                Engine.send(this@ChatActivity, prompt, Store.maxTokens).collect { tok ->
                    if (ai == null) {
                        tFirst = SystemClock.uptimeMillis()
                        Store.lastFirst = (tFirst - t0) / 1000f
                        val m = Msg("ai", "")
                        ai = m
                        adapter.thinking = false
                        adapter.streaming = true
                        chat.msgs.add(m)
                        adapter.notifyDataSetChanged()
                        startTyper()
                    }
                    target.append(tok)
                    ai!!.text = target.toString()
                }
                generating = false
                typer?.join() // let the typing animation finish
            } catch (e: CancellationException) {
                cancelled = true
                throw e
            } catch (e: Throwable) {
                toast("Error: " + (e.message ?: "generation failed"))
            } finally {
                generating = false
                typer?.cancel()
                ai?.text = target.toString()
                if (!cancelled && ai != null && tFirst > 0) {
                    val secs = (SystemClock.uptimeMillis() - tFirst) / 1000f
                    if (secs > 0.3f) Store.lastTps = (target.length / 4f) / secs
                }
                adapter.thinking = false
                adapter.streaming = false
                adapter.endLive()
                adapter.notifyDataSetChanged()
                setBusy(false)
                refreshHero()
                if (Store.keepHistory) ChatRepo.save(chat)
                scrollBottom()
                val done = ai
                if (!cancelled && done != null) toolStep(done)
            }
        }
    }

    /** If the answer is a tool request (<tool>{...}</tool>), run the tool and show its result in the chat. */
    private fun saveCode(lang: String, code: String) {
        val ext = com.vethos.app.data.HtmlRun.extFor(lang)
        launchers.saveText("vethos_code_" + (System.currentTimeMillis() / 1000) + "." + ext, code) { ok, msg ->
            toast(if (ok) "Saved $msg" else msg)
        }
    }

    private fun toolStep(m: Msg) {
        val call = Tools.parse(Think.strip(m.text), persona.allowedTools()) ?: return
        val def = Tools.get(call.name) ?: return
        val clean = listOf(call.before, call.after).filter { it.isNotBlank() }.joinToString("\n\n")
        fun show(status: String) {
            m.text = (if (clean.isEmpty()) "" else clean + "\n\n") + status
            adapter.notifyDataSetChanged()
            if (Store.keepHistory) ChatRepo.save(chat)
            scrollBottom()
        }
        show("⚙ " + def.title + "…")
        ToolRunner.run(ToolCtx(this, perms, launchers), def, call.args, false) { r ->
            // one quiet line per step (tap it to see what was sent and received), like Claude's step list
            val id = Links.addStep("Tool: " + def.title + "\nInput: " + call.args + "\n\nResult:\n" + (r.data ?: r.text).take(1500))
            val line = "[" + (if (r.ok) "✔ " else "✖ ") + def.title + " ›](vethos-step://" + id + ")"
            val extra = if (!r.ok || r.data == null || r.text.contains("](")) "\n\n" + r.text else ""
            show(line + extra)
            // read-type tools (file, clipboard, QR): hand the content back to the model once so it can answer
            val data = r.data
            if (r.ok && data != null && toolDepth < MAX_TOOL_DEPTH) {
                toolDepth++
                val last = toolDepth >= MAX_TOOL_DEPTH
                b.root.post {
                    if (ready && gen?.isActive != true) {
                        generate("Result of the " + def.title + " tool:\n" + data +
                            "\n\nNow answer the user's request using this result. " +
                            (if (last) "Do not call a tool again." else "If you still need another tool, call it; otherwise just answer."))
                    }
                }
            }
        }
    }

    /** Reveals the received text a few characters per frame, with a blinking dot at the end. */
    private fun startTyper() {
        typer?.cancel()
        typer = lifecycleScope.launch {
            var lastShown = -1
            var lastOn = true
            while (true) {
                delay(22)
                val backlog = target.length - shown
                if (backlog > 0) shown = target.length
                if (!generating && shown >= target.length) break
                val on = shown < target.length || (SystemClock.uptimeMillis() / 450) % 2 == 0L
                if (shown != lastShown || on != lastOn) {
                    lastShown = shown; lastOn = on
                    adapter.updateLive(b.rv, Tools.hideLive(target.substring(0, shown)), on)
                    if (autoFollow && b.rv.canScrollVertically(1)) b.rv.scrollBy(0, 400)
                }
            }
        }
    }

    private fun setBusy(busy: Boolean) {
        b.send.setImageResource(if (busy) R.drawable.ic_stop else R.drawable.ic_send)
    }

    private fun copy(m: Msg) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("Vethos", m.text))
        toast("Copied")
    }

    private fun share(m: Msg) = shareText(m.text)

    private fun shareText(text: String) {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Share"))
    }

    private fun feedback(pos: Int, v: Int) {
        val m = chat.msgs.getOrNull(pos) ?: return
        m.fb = if (m.fb == v) 0 else v
        if (m.fb != 0) {
            val q = chat.msgs.take(pos).lastOrNull { it.role == "user" }?.text ?: ""
            Store.addSteer(if (v > 0) "best" else "bad", "Q: " + q.take(200) + "\nA: " + m.text.take(300))
            toast(if (v > 0) "Saved as a good answer" else "Saved as a bad answer")
        }
        adapter.notifyItemChanged(pos)
        if (Store.keepHistory) ChatRepo.save(chat)
    }

    private fun regenerate() {
        if (gen?.isActive == true || !ready) return
        toolDepth = 0
        val lastAi = chat.msgs.lastOrNull() ?: return
        if (lastAi.role != "ai") return
        val userIdx = chat.msgs.indexOfLast { it.role == "user" }
        if (userIdx < 0) return
        val um = chat.msgs[userIdx]
        val prompt = um.en ?: um.text
        chat.msgs.removeAt(chat.msgs.lastIndex)
        adapter.notifyDataSetChanged()
        // The engine remembers the old answer, so reload it with the history before the last question.
        val history = chat.msgs.take(userIdx)
        val f = modelFile() ?: return
        b.loading.visibility = View.VISIBLE
        ready = false
        val system = buildSystem(history)
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.Default) { Engine.load(this@ChatActivity, f.absolutePath, chat.id, system, true) }
                ready = true
                b.loading.visibility = View.GONE
                generate(prompt)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                b.loading.visibility = View.GONE
                showBanner("Could not load this model: " + (e.message ?: "unknown error"), null)
            }
        }
    }

    private fun showOptions() {
        showSheet("Options", listOf(
            SheetRow(R.drawable.ic_plus, "New chat") {
                gen?.cancel()
                startActivity(Intent(this, ChatActivity::class.java))
                finish()
            },
            SheetRow(R.drawable.ic_share, "Export chat as text") { exportChat() },
            SheetRow(R.drawable.ic_trash, "Clear conversation") {
                confirm("Clear conversation?", "All messages in this chat will be removed.", "Clear") { clearChat() }
            },
        ))
    }

    private fun exportChat() {
        if (chat.msgs.isEmpty()) { toast("Nothing to export yet"); return }
        shareText(chat.msgs.joinToString("\n\n") { (if (it.role == "user") "You: " else persona.name + ": ") + Attach.display(it.text) })
    }

    private fun clearChat() {
        gen?.cancel()
        chat.msgs.clear()
        chat.title = "New chat"
        adapter.notifyDataSetChanged()
        ChatRepo.delete(chat.id)
        refreshHero()
        loadModel(force = true, history = emptyList())
    }

    override fun onDestroy() {
        super.onDestroy()
        Speaker.stop()
        Blocks.onSave = null
    }

    override fun onStop() {
        super.onStop()
        if (chat.msgs.isNotEmpty() && Store.keepHistory) ChatRepo.save(chat)
    }
}
