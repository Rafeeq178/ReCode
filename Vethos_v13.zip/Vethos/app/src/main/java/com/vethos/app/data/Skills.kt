package com.vethos.app.data

import java.io.File

/** One skill = a folder skills/<id>/SKILL.md (same layout as Claude's skills). */
class Skill(val id: String, val name: String, val desc: String, val body: String, val enabled: Boolean)

object Skills {
    private val root: File get() = File(Store.app.filesDir, "skills").apply { mkdirs() }
    private val prefs get() = Store.app.getSharedPreferences("vethos", 0)

    fun slug(s: String): String {
        val t = s.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-')
        return t.take(40).ifEmpty { "skill" }
    }

    fun enabled(id: String): Boolean = !prefs.getBoolean("skill_off_" + id, false)
    fun setEnabled(id: String, on: Boolean) = prefs.edit().putBoolean("skill_off_" + id, !on).apply()

    fun all(): List<Skill> {
        seed()
        val dirs = root.listFiles { f -> f.isDirectory } ?: return emptyList()
        return dirs.sortedBy { it.name }.mapNotNull { d ->
            val f = File(d, "SKILL.md")
            if (!f.isFile) null
            else {
                val p = parse(f.readText(), d.name)
                Skill(d.name, p.first, p.second, p.third, enabled(d.name))
            }
        }
    }

    fun hasEnabled(): Boolean = all().any { it.enabled }

    fun find(q: String): Skill? {
        val k = q.trim().lowercase()
        if (k.isEmpty()) return null
        val list = all().filter { it.enabled }
        return list.firstOrNull { it.id == k || it.name.lowercase() == k || it.id == slug(q) }
            ?: list.firstOrNull { it.name.lowercase().contains(k) || k.contains(it.name.lowercase()) }
    }

    /** name, description, body. Reads the "---" header (name: / description:) if there is one. */
    fun parse(text: String, fallback: String): Triple<String, String, String> {
        val t = text.replace("\r\n", "\n").trim()
        var name = fallback
        var desc = ""
        var body = t
        if (t.startsWith("---")) {
            val end = t.indexOf("\n---", 3)
            if (end > 0) {
                val head = t.substring(3, end)
                body = t.substring(end + 4).trim()
                var key = ""
                val kv = Regex("^([A-Za-z_-]+):\\s*(.*)$")
                for (ln in head.lines()) {
                    val m = kv.find(ln)
                    if (m != null) {
                        key = m.groupValues[1].lowercase()
                        val v = unq(m.groupValues[2])
                        if (key == "name" && v.isNotBlank()) name = v
                        if (key == "description") desc = if (v in listOf(">", "|", ">-", "|-")) "" else v
                    } else if (key == "description" && ln.isNotBlank()) {
                        desc = (desc + " " + ln.trim()).trim()
                    }
                }
            }
        }
        return Triple(name, desc, body)
    }

    private fun unq(s: String): String {
        val t = s.trim()
        return if (t.length >= 2 && (t.startsWith("\"") && t.endsWith("\"") || t.startsWith("'") && t.endsWith("'")))
            t.substring(1, t.length - 1) else t
    }

    fun render(name: String, desc: String, body: String): String =
        "---\nname: " + name.replace('\n', ' ') + "\ndescription: " + desc.replace('\n', ' ') + "\n---\n\n" + body.trim() + "\n"

    private fun uniqueId(base: String, keep: String?): String {
        var c = base
        var i = 1
        while (File(root, c).exists() && c != keep) { i++; c = base + "-" + i }
        return c
    }

    /** Creates a skill (oldId == null) or edits/renames one. Returns the skill id. */
    fun save(oldId: String?, name: String, desc: String, body: String): String {
        val base = slug(name)
        val id = if (oldId != null && (oldId == base || oldId.startsWith(base + "-"))) oldId else uniqueId(base, oldId)
        val dir = File(root, id).apply { mkdirs() }
        File(dir, "SKILL.md").writeText(render(name.trim(), desc.trim(), body))
        if (oldId != null && oldId != id) {
            val was = enabled(oldId)
            File(root, oldId).deleteRecursively()
            prefs.edit().remove("skill_off_" + oldId).apply()
            setEnabled(id, was)
        }
        return id
    }

    fun delete(id: String) {
        File(root, id).deleteRecursively()
        prefs.edit().remove("skill_off_" + id).apply()
    }

    fun duplicate(id: String) {
        val s = all().firstOrNull { it.id == id } ?: return
        save(null, s.name + " copy", s.desc, s.body)
    }

    /** Short block for the system prompt: only names + descriptions, the full text is loaded on demand. */
    fun prompt(): String {
        val list = all().filter { it.enabled }.take(12)
        if (list.isEmpty()) return ""
        val sb = StringBuilder()
        sb.append("You have skills: saved instructions for special tasks. When the user's request matches a skill, FIRST reply with ONLY ")
        sb.append("<tool>{\"name\":\"read_skill\",\"args\":{\"name\":\"SKILL NAME\"}}</tool> and then follow the instructions you get back.\nSkills:\n")
        list.forEach { sb.append("- ").append(it.name).append(": ").append(it.desc.take(90)).append('\n') }
        return sb.toString().trimEnd()
    }

    private fun seed() {
        if (!prefs.getBoolean("skills_seeded", false)) {
            prefs.edit().putBoolean("skills_seeded", true).apply()
            save(null, "Email writer", "Use when the user wants an email or formal message written.",
                "1. Use what the user gave; do not ask extra questions.\n2. Write a subject line, a greeting, a short body (3-5 sentences) and a polite closing.\n3. Keep the tone the user asked for (formal by default).\n4. Then call the compose tool with kind email so the draft opens, or just show the email.")
            save(null, "Explain simply", "Use when the user says explain, samjhao, or asks how something works.",
                "1. Start with a one-sentence answer.\n2. Then explain in 3-5 short steps with a simple everyday example.\n3. Avoid jargon; if you must use a term, define it in a few words.")
        }
        if (!prefs.getBoolean("skills_seeded_v12", false)) {
            prefs.edit().putBoolean("skills_seeded_v12", true).apply()
            save(null, "Research", "Use for news, prices, rates, facts that change, or when the user says search or check online.",
                "1. Call web_search with 2-5 short words (add the year if it matters).\n2. If the snippets do not hold the answer, call web_fetch on the best result.\n3. Answer in a few lines with the number or fact first, then the source name.\n4. If nothing was found, say so. Never invent prices or numbers.")
            save(null, "Word document", "Use when the user wants a Word / .docx file, letter, report or CV.",
                "1. Write the full text first: a title, then short paragraphs. A line starting with # becomes a heading.\n2. Call make_docx with name, title and content.\n3. Tell the user the file is in Downloads/Vethos and can be opened by tapping the link.")
            save(null, "PDF document", "Use when the user wants a PDF file, report, notes or certificate.",
                "1. Write the full text, one paragraph per line, blank line between sections.\n2. Call make_pdf with name, title and content.\n3. Tell the user to tap the link to open it.")
            save(null, "Excel sheet", "Use when the user wants a spreadsheet, table, budget or .xlsx file.",
                "1. Build the table as CSV text: first row = column names, then one row per line, commas between cells, numbers without symbols.\n2. Call make_xlsx with name and csv.\n3. Mention what each column means.")
            save(null, "Chart", "Use when the user wants a graph, chart or visual comparison of numbers.",
                "1. Pick bar for comparing, line for change over time, pie for shares.\n2. Call chart with type, title, labels (comma separated) and values (comma separated numbers).\n3. Say in one sentence what the chart shows.")
            save(null, "Web page or app", "Use when the user wants a web page, mini app, calculator, card or invitation.",
                "1. Write ONE complete HTML file: all CSS in <style>, all JavaScript in <script>, no external links or images.\n2. Make it work on a phone: viewport meta tag, large buttons, readable text.\n3. Call page with name (ending .html) and html. It opens only when the user taps the link.")
            save(null, "Presentation", "Use when the user wants slides or a presentation.",
                "1. Plan 5-8 slides: title, key points (max 4 short bullets each), closing.\n2. Build ONE HTML file where each slide is a full-screen section and Next / Back buttons switch slides.\n3. Call page with name deck.html. (A .pptx file cannot be made on the phone.)")
            save(null, "Make a skill", "Use when the user wants to create or save a new skill.",
                "1. Ask what the skill should do only if it is unclear.\n2. Write a name, a one-line description that says WHEN to use it, and 3-6 numbered instruction lines.\n3. Call save_skill with name, description and instructions. The user is asked to allow it.")
        }
    }
}
