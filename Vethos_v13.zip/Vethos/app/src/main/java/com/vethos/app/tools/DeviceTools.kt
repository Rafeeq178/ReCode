package com.vethos.app.tools

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.CalendarContract
import com.vethos.app.R
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** alarm, timer, calendar, location, time, message compose. */
object DeviceTools {
    private fun ok(t: String, d: String? = null) = ToolResult(true, t, d)
    private fun bad(t: String) = ToolResult(false, t)

    private fun launch(c: ToolCtx, i: Intent): Boolean = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.ctx.startActivity(i); true
    } catch (_: Exception) { false }

    /** accepts 7, 7:30, 19:45, "7:30 pm" */
    private fun parseTime(s: String): Pair<Int, Int>? {
        val m = Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?", RegexOption.IGNORE_CASE).find(s.trim()) ?: return null
        var h = m.groupValues[1].toInt()
        val min = m.groupValues[2].ifEmpty { "0" }.toInt()
        val ap = m.groupValues[3].lowercase()
        if (ap == "pm" && h < 12) h += 12
        if (ap == "am" && h == 12) h = 0
        return if (h in 0..23 && min in 0..59) Pair(h, min) else null
    }

    fun build(): List<ToolDef> = listOf(
        ToolDef(
            id = "alarm", title = "Set alarm", icon = R.drawable.ic_pin, sensitive = false,
            desc = "Sets an alarm in the clock app",
            params = listOf(ToolParam("time", "Time", "7:30 or 19:45 or 7 pm"), ToolParam("label", "Label", optional = true)),
            usage = "{\"time\":\"7:30 am\",\"label\":\"optional\"} sets an alarm",
            run = { c, a, done ->
                val t = parseTime(a.optString("time"))
                if (t == null) done(bad("I could not read the time"))
                else {
                    val i = Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, t.first).putExtra(AlarmClock.EXTRA_MINUTES, t.second)
                        .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label").ifBlank { "Vethos" })
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    val hh = String.format(Locale.US, "%02d:%02d", t.first, t.second)
                    done(if (launch(c, i)) ok("Alarm set for " + hh) else bad("No clock app found"))
                }
            },
        ),
        ToolDef(
            id = "timer", title = "Set timer", icon = R.drawable.ic_pin, sensitive = false,
            desc = "Starts a countdown timer",
            params = listOf(ToolParam("minutes", "Minutes", "e.g. 10"), ToolParam("seconds", "Seconds", optional = true), ToolParam("label", "Label", optional = true)),
            usage = "{\"minutes\":10,\"seconds\":0} starts a timer",
            run = { c, a, done ->
                val total = a.optDouble("minutes", 0.0) * 60 + a.optDouble("seconds", 0.0)
                if (total < 1) done(bad("Need minutes or seconds"))
                else {
                    val i = Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, total.toInt())
                        .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label").ifBlank { "Vethos" })
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    done(if (launch(c, i)) ok("Timer started: " + total.toInt() + " seconds") else bad("No clock app found"))
                }
            },
        ),
        ToolDef(
            id = "calendar_add", title = "Add calendar event", icon = R.drawable.ic_pin, sensitive = false,
            desc = "Opens a new calendar event ready to save",
            params = listOf(ToolParam("title", "Title"), ToolParam("date", "Date", "YYYY-MM-DD"), ToolParam("time", "Time", "19:30", optional = true),
                ToolParam("minutes", "Length in minutes", optional = true), ToolParam("place", "Place", optional = true)),
            usage = "{\"title\":\"Dentist\",\"date\":\"2026-11-20\",\"time\":\"15:00\",\"minutes\":60} new event",
            run = { c, a, done ->
                val cal = Calendar.getInstance()
                try {
                    val d = a.optString("date").trim()
                    if (d.isNotEmpty()) {
                        val p = d.split("-")
                        cal.set(p[0].toInt(), p[1].toInt() - 1, p[2].toInt())
                    }
                    val t = parseTime(a.optString("time").ifBlank { "9:00" }) ?: Pair(9, 0)
                    cal.set(Calendar.HOUR_OF_DAY, t.first); cal.set(Calendar.MINUTE, t.second); cal.set(Calendar.SECOND, 0)
                } catch (_: Exception) { }
                val len = a.optInt("minutes", 60).coerceAtLeast(5)
                val i = Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                    .putExtra(CalendarContract.Events.TITLE, a.optString("title").ifBlank { "Event" })
                    .putExtra(CalendarContract.Events.EVENT_LOCATION, a.optString("place"))
                    .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, cal.timeInMillis)
                    .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, cal.timeInMillis + len * 60_000L)
                done(if (launch(c, i)) ok("Calendar event opened. Tap Save there.") else bad("No calendar app found"))
            },
        ),
        ToolDef(
            id = "calendar_list", title = "Upcoming events", icon = R.drawable.ic_pin, sensitive = false,
            desc = "Lists calendar events of the next days",
            params = listOf(ToolParam("days", "Days ahead", "default 7", optional = true)),
            usage = "{\"days\":7} lists upcoming events",
            run = { c, a, done ->
                c.perms.ensure(Manifest.permission.READ_CALENDAR) { granted ->
                    if (!granted) done(bad("Calendar permission was not given"))
                    else {
                        try {
                            val days = a.optInt("days", 7).coerceIn(1, 60)
                            val now = System.currentTimeMillis()
                            val uri = CalendarContract.Instances.CONTENT_URI.buildUpon().also {
                                android.content.ContentUris.appendId(it, now)
                                android.content.ContentUris.appendId(it, now + days * 86_400_000L)
                            }.build()
                            val cur = c.ctx.contentResolver.query(uri,
                                arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.EVENT_LOCATION),
                                null, null, CalendarContract.Instances.BEGIN + " ASC")
                            val f = SimpleDateFormat("EEE d MMM HH:mm", Locale.getDefault())
                            val sb = StringBuilder()
                            cur?.use {
                                var n = 0
                                while (it.moveToNext() && n < 15) {
                                    sb.append(f.format(Date(it.getLong(1)))).append(" - ").append(it.getString(0).orEmpty())
                                    val loc = it.getString(2).orEmpty()
                                    if (loc.isNotBlank()) sb.append(" (").append(loc).append(")")
                                    sb.append('\n'); n++
                                }
                            }
                            done(if (sb.isEmpty()) ok("No events in the next " + days + " days") else ok(sb.toString().trim(), sb.toString().trim()))
                        } catch (e: Exception) { done(bad("Could not read the calendar")) }
                    }
                }
            },
        ),
        ToolDef(
            id = "location", title = "My location", icon = R.drawable.ic_pin, sensitive = true,
            desc = "Reads the phone's last known location",
            params = emptyList(),
            usage = "{} gives latitude and longitude",
            run = { c, _, done ->
                c.perms.ensure(Manifest.permission.ACCESS_COARSE_LOCATION) { granted ->
                    if (!granted) done(bad("Location permission was not given"))
                    else {
                        try {
                            val lm = c.ctx.getSystemService(android.content.Context.LOCATION_SERVICE) as android.location.LocationManager
                            var best: android.location.Location? = null
                            for (p in lm.getProviders(true)) {
                                val l = lm.getLastKnownLocation(p) ?: continue
                                if (best == null || l.time > best!!.time) best = l
                            }
                            val b = best
                            if (b == null) done(bad("No location yet. Turn on location and open a maps app once."))
                            else {
                                val s = "Latitude " + b.latitude + ", longitude " + b.longitude
                                done(ok(s, s))
                            }
                        } catch (e: SecurityException) { done(bad("Location permission was not given")) }
                    }
                }
            },
        ),
        ToolDef(
            id = "time", title = "Date and time", icon = R.drawable.ic_pin, sensitive = false,
            desc = "Today's date, the time and the time zone",
            params = emptyList(),
            usage = "{} gives the current date and time",
            run = { _, _, done ->
                val f = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm (zzzz)", Locale.ENGLISH)
                val s = f.format(Date())
                done(ok(s, s))
            },
            headless = true,
        ),
        ToolDef(
            id = "compose", title = "Write email / text", icon = R.drawable.ic_send, sensitive = false,
            desc = "Opens a draft email or text message for you to send",
            params = listOf(ToolParam("kind", "email or sms"), ToolParam("to", "Address or number", optional = true),
                ToolParam("subject", "Subject", optional = true), ToolParam("body", "Message")),
            usage = "{\"kind\":\"email\",\"to\":\"a@b.com\",\"subject\":\"...\",\"body\":\"...\"} opens a draft",
            run = { c, a, done ->
                val to = a.optString("to")
                val body = a.optString("body")
                val i = if (a.optString("kind").lowercase().startsWith("s")) {
                    Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(to))).putExtra("sms_body", body)
                } else {
                    Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + Uri.encode(to)))
                        .putExtra(Intent.EXTRA_SUBJECT, a.optString("subject")).putExtra(Intent.EXTRA_TEXT, body)
                }
                done(if (launch(c, i)) ok("Draft opened. Check it and tap send.") else bad("No app found for this"))
            },
        ),
    )
}
