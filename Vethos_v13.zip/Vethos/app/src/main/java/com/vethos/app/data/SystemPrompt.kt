package com.vethos.app.data

import com.vethos.app.tools.Tools
import com.vethos.app.ui.Attach

/** The system prompt of every chat. It is the same for every new chat, so the app can prepare it before you type. */
object SystemPrompt {
    fun build(history: List<Msg>): String {
        val persona = Personas.current()
        val sb = StringBuilder(persona.prompt.ifBlank { Store.systemPrompt })
        val allowed = persona.allowedTools()
        val toolPrompt = Tools.prompt(allowed)
        if (toolPrompt.isNotEmpty()) sb.append("\n\n").append(toolPrompt)
        if ("read_skill" in allowed) {
            val sk = Skills.prompt()
            if (sk.isNotEmpty()) sb.append("\n\n").append(sk)
        }
        val best = Store.steer("best")
        if (best.isNotEmpty()) sb.append("\n\nExamples of answers the user liked:\n").append(best.joinToString("\n---\n"))
        val bad = Store.steer("bad")
        if (bad.isNotEmpty()) sb.append("\n\nAvoid answers like these (the user disliked them):\n").append(bad.joinToString("\n---\n"))
        val mem = Store.memory
        if (history.isNotEmpty() && mem > 0) {
            sb.append("\n\nEarlier in this conversation:\n")
            history.takeLast(mem).forEach {
                sb.append(if (it.role == "user") "User: " else "Assistant: ").append(Attach.display(it.en ?: it.text).take(400)).append('\n')
            }
        }
        return sb.toString()
    }
}
