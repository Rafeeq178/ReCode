package com.vethos.app.tools

import com.vethos.app.R
import com.vethos.app.data.Skills

/** The "read_skill" tool: the model asks for a skill by name and gets its full instructions back. */
object SkillTools {
    fun build(): List<ToolDef> = listOf(
        ToolDef(
            id = "read_skill", title = "Read skill", icon = R.drawable.ic_book, sensitive = false,
            desc = "Loads the instructions of a saved skill so the assistant can follow them",
            params = listOf(ToolParam("name", "Skill name")),
            usage = "{\"name\":\"skill name\"} loads the full instructions of a skill",
            run = { _, a, done ->
                val q = a.optString("name")
                val s = Skills.find(q)
                if (s == null) {
                    val names = Skills.all().filter { it.enabled }.joinToString(", ") { it.name }
                    done(ToolResult(false, "No skill called \"" + q + "\". Available: " + names))
                } else {
                    done(ToolResult(true, "Skill: " + s.name, "Follow these instructions (skill \"" + s.name + "\"):\n" + s.body.take(3000)))
                }
            },
            headless = true,
        ),
        ToolDef(
            id = "save_skill", title = "Save skill", icon = R.drawable.ic_book, sensitive = true,
            desc = "Creates or updates a skill (saved instructions)",
            params = listOf(ToolParam("name", "Skill name"), ToolParam("description", "When to use it"), ToolParam("instructions", "Instructions")),
            usage = "{\"name\":\"...\",\"description\":\"when to use\",\"instructions\":\"1. ...\"} saves a skill (asks first)",
            run = { _, a, done ->
                val n = a.optString("name").trim()
                if (n.isEmpty() || a.optString("instructions").isBlank()) done(ToolResult(false, "A skill needs a name and instructions"))
                else {
                    val existing = Skills.all().firstOrNull { it.name.equals(n, true) }
                    Skills.save(existing?.id, n, a.optString("description"), a.optString("instructions"))
                    done(ToolResult(true, "Skill \"" + n + "\" saved. It works in new chats."))
                }
            },
            headless = true,
        )
    )
}
