package com.vethos.app.data

import android.content.Context
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Thin wrapper over llama.cpp's Android AI-chat library (com.arm.aichat).
 * The model stays loaded for the whole life of the app (and while ModelService runs):
 * a new chat only sends a new system prompt, it never reloads the model file.
 * If the upstream API changes, this is the only file that needs editing.
 */
object Engine {
    private var engine: InferenceEngine? = null
    private val lock = Mutex()
    var loadedPath: String? = null
        private set
    var chatId: String? = null
        private set
    private var systemPrompt: String? = null
    /** true = the system prompt is loaded and nothing was said yet, so any new chat with the same prompt can start at once */
    private var pristine = false

    private fun get(ctx: Context): InferenceEngine =
        engine ?: AiChat.getInferenceEngine(ctx.applicationContext).also { engine = it }

    private suspend fun fullLoad(e: InferenceEngine, path: String) {
        try { e.cleanUp() } catch (_: Throwable) { }
        loadedPath = null; chatId = null; systemPrompt = null; pristine = false
        e.loadModel(path)
        loadedPath = path
    }

    /** Loads only the model file (no chat yet). Used at app start and by the Library "Load" button. */
    suspend fun preload(ctx: Context, path: String) = lock.withLock {
        if (loadedPath == path) return@withLock
        fullLoad(get(ctx), path)
        com.vethos.app.data.ModelService.start(ctx.applicationContext)
    }

    /**
     * Makes the model ready for a chat. The model file is loaded only when it is not loaded yet.
     * [force] = start the conversation again (edit / regenerate / clear) with a fresh system prompt.
     */
    suspend fun load(ctx: Context, path: String, chat: String, system: String, force: Boolean = false) = lock.withLock {
        val e = get(ctx)
        if (!force && loadedPath == path && systemPrompt == system && (chatId == chat || pristine)) {
            chatId = chat
            return@withLock
        }
        if (loadedPath != path) fullLoad(e, path)
        try {
            e.setSystemPrompt(system)
        } catch (t: kotlinx.coroutines.CancellationException) {
            throw t
        } catch (t: Throwable) {
            // the library was in a bad state: load the model once more, then try again
            fullLoad(e, path)
            e.setSystemPrompt(system)
        }
        chatId = chat
        systemPrompt = system
        pristine = true
        com.vethos.app.data.ModelService.start(ctx.applicationContext)
    }

    fun send(ctx: Context, prompt: String, maxTokens: Int): Flow<String> {
        pristine = false
        return get(ctx).sendUserPrompt(prompt, maxTokens)
    }

    /** Forget the loaded model (user pressed Unload, deleted it or switched model). */
    fun unload() {
        try { engine?.cleanUp() } catch (_: Throwable) { }
        loadedPath = null; chatId = null; systemPrompt = null; pristine = false
        try { com.vethos.app.data.ModelService.stop(Store.app) } catch (_: Throwable) { }
    }
}
