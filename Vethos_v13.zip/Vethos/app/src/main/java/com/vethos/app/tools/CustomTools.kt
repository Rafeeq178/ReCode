package com.vethos.app.tools

import android.content.Intent
import android.net.Uri
import com.vethos.app.R
import com.vethos.app.data.Store
import org.json.JSONArray
import org.json.JSONObject

/** A tool the user made. kind: "http" (calls a web address), "open" (opens a link / app), "prompt" (hands saved instructions to the model). */
class CustomTool(val id: String, val title: String, val desc: String, val kind: String, val url: String, val method: String, val body: String, val params: String)

object CustomTools {
    private val prefs get() = Store.app.getSharedPreferences("vethos", 0)

    fun slug(s: String): String = s.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_').take(30).ifEmpty { "tool" }

    fun list(): List<CustomTool> {
        val arr = try { JSONArray(prefs.getString("custom_tools", "[]")) } catch (_: Exception) { JSONArray() }
        return (0 until arr.length()).map { arr.getJSONObject(it) }.map {
            CustomTool(it.optString("id"), it.optString("title"), it.optString("desc"), it.optString("kind", "http"),
                it.optString("url"), it.optString("method", "GET"), it.optString("body"), it.optString("params"))
        }
    }

    private fun saveAll(l: List<CustomTool>) {
        val arr = JSONArray()
        l.forEach {
            arr.put(JSONObject().put("id", it.id).put("title", it.title).put("desc", it.desc).put("kind", it.kind)
                .put("url", it.url).put("method", it.method).put("body", it.body).put("params", it.params))
        }
        prefs.edit().putString("custom_tools", arr.toString()).apply()
    }

    /** Adds or replaces a tool. Returns its id (never clashes with a built-in tool). */
    fun save(oldId: String?, t: CustomTool): String {
        val l = list().toMutableList()
        val builtin = Tools.builtinIds()
        var id = slug(t.title)
        if (id in builtin || (l.any { it.id == id } && id != oldId)) id = "my_" + id
        var n = 1
        val base = id
        while ((id in builtin || l.any { it.id == id }) && id != oldId) { n++; id = base + "_" + n }
        l.removeAll { it.id == oldId }
        l.add(CustomTool(id, t.title, t.desc, t.kind, t.url, t.method, t.body, t.params))
        saveAll(l)
        return id
    }

    fun delete(id: String) { saveAll(list().filter { it.id != id }) }

    private fun fill(tpl: String, a: JSONObject, urlEncode: Boolean): String {
        var s = tpl
        a.keys().forEach { k ->
            val v = a.opt(k)?.toString().orEmpty()
            s = s.replace("{" + k + "}", if (urlEncode) Http.enc(v) else v)
        }
        return s
    }

    fun build(): List<ToolDef> = list().map { t ->
        val keys = t.params.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        val example = "{" + keys.joinToString(",") { "\"" + it + "\":\"...\"" } + "}"
        ToolDef(
            id = t.id, title = t.title, icon = R.drawable.ic_flask,
            sensitive = t.kind == "http" && !t.method.equals("GET", true),
            desc = t.desc.ifBlank { "Custom tool" },
            params = keys.map { ToolParam(it, it) },
            usage = example + " " + t.desc.take(80),
            run = { c, a, done ->
                when (t.kind) {
                    "open" -> {
                        try {
                            c.ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(fill(t.url, a, true))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            done(ToolResult(true, "Opened " + t.title))
                        } catch (e: Exception) { done(ToolResult(false, "Nothing can open this link")) }
                    }
                    "prompt" -> {
                        val text = fill(t.body, a, false)
                        done(ToolResult(true, "Ran " + t.title, "Follow these instructions now:\n" + text))
                    }
                    else -> NetTools.bg(c, done) {
                        val raw = Http.request(t.method.uppercase(), fill(t.url, a, true), if (t.method.equals("GET", true)) null else fill(t.body, a, false), 200_000)
                        val txt = if (raw.trimStart().startsWith("<")) Http.htmlToText(raw) else raw
                        ToolResult(true, "Called " + t.title, txt.take(3000))
                    }
                }
            },
            headless = t.kind != "open",
        )
    }
}
