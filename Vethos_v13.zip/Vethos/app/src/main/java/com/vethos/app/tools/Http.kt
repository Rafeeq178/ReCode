package com.vethos.app.tools

import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder

/** Small helpers shared by the internet tools. Always call from a background thread. */
object Http {
    const val UA = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36 Vethos/12"

    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
    fun dec(s: String): String = try { URLDecoder.decode(s, "UTF-8") } catch (_: Exception) { s }

    fun get(url: String, maxBytes: Int = 600_000, headers: Map<String, String> = emptyMap()): String =
        request("GET", url, null, maxBytes, headers)

    fun request(method: String, url: String, body: String?, maxBytes: Int = 600_000, headers: Map<String, String> = emptyMap()): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 12_000
            c.readTimeout = 15_000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Accept-Language", "en,ur;q=0.8")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            if (body != null) {
                c.doOutput = true
                if (!headers.containsKey("Content-Type")) c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toByteArray()) }
            }
            val code = c.responseCode
            val stream = if (code in 200..399) c.inputStream else (c.errorStream ?: c.inputStream)
            val buf = java.io.ByteArrayOutputStream()
            val tmp = ByteArray(8192)
            stream.use { st ->
                while (buf.size() < maxBytes) {
                    val n = st.read(tmp)
                    if (n < 0) break
                    buf.write(tmp, 0, n)
                }
            }
            val text = buf.toString("UTF-8")
            if (code >= 400) throw RuntimeException("HTTP " + code)
            return text
        } finally {
            c.disconnect()
        }
    }

    /** Readable text of an HTML page. */
    fun htmlToText(html: String): String {
        var t = html
        t = t.replace(Regex("(?is)<(script|style|noscript|svg|head)[^>]*>.*?</\\1>"), " ")
        t = t.replace(Regex("(?i)<br\\s*/?>|</p>|</div>|</li>|</h[1-6]>|</tr>"), "\n")
        t = t.replace(Regex("<[^>]+>"), " ")
        t = t.replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
            .replace("&quot;", "\"").replace("&#39;", "'").replace("&#x27;", "'")
        t = t.replace(Regex("[ \\t\\u00A0]+"), " ").replace(Regex("\\s*\\n\\s*"), "\n").replace(Regex("\\n{3,}"), "\n\n")
        return t.trim()
    }
}
