package com.vethos.app.data

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.ServiceCompat
import com.vethos.app.ui.MainActivity

/** Keeps the app (and so the loaded model) alive in the background. Shows one quiet notification with a Stop button. */
class ModelService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Engine.unload()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Model running", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 1, Intent(this, ModelService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val name = Engine.loadedPath?.substringAfterLast('/')?.removeSuffix(".gguf") ?: "model"
        val n = Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle("Vethos model is loaded")
            .setContentText(name + " · new chats start instantly")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(0, "Stop model", stop).build())
            .build()
        // 0x40000000 = FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        ServiceCompat.startForeground(this, ID, n, 0x40000000)
        return START_NOT_STICKY
    }

    companion object {
        private const val CH = "model_running"
        private const val ID = 77
        const val ACTION_STOP = "com.vethos.app.STOP_MODEL"

        fun start(ctx: Context) {
            try { ctx.startForegroundService(Intent(ctx, ModelService::class.java)) } catch (_: Throwable) { }
        }

        fun stop(ctx: Context) {
            try { ctx.stopService(Intent(ctx, ModelService::class.java)) } catch (_: Throwable) { }
        }
    }
}
