package com.vethos.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.Fragment
import com.vethos.app.data.Store
import com.vethos.app.databinding.FragmentHomeBinding
import java.io.File

/** Home: a greeting, the active model, and a message box. Nothing else. */
class HomeFragment : Fragment() {
    private var _b: FragmentHomeBinding? = null
    private val b get() = _b!!

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        FragmentHomeBinding.inflate(i, c, false).also { _b = it }.root

    override fun onViewCreated(v: View, s: Bundle?) {
        wireMenu(b.btnMenu)
        b.modelCard.setOnClickListener { (activity as MainActivity).select(1) }
        b.homeSend.setOnClickListener { sendFromHome() }
        b.homeInput.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_SEND) { sendFromHome(); true } else false
        }
    }

    private fun sendFromHome() {
        val t = b.homeInput.text.toString().trim()
        val i = Intent(requireContext(), ChatActivity::class.java)
        if (t.isNotEmpty()) i.putExtra("preset", t).putExtra("autosend", true)
        b.homeInput.setText("")
        startActivity(i)
    }

    override fun onResume() {
        super.onResume()
        val f = Store.lastModel?.let { File(Store.modelsDir, it) }
        b.modelName.text = if (f != null && f.exists()) f.name.removeSuffix(".gguf") else "No model yet · tap to add one"
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
