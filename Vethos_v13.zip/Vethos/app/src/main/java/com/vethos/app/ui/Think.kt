package com.vethos.app.ui

/** Reasoning models write their thoughts between <think> tags. The chat never shows them. */
object Think {
    fun strip(s: String): String {
        if (!s.contains("<think>") && !s.contains("</think>")) return s
        var t = s.replace(Regex("(?s)<think>.*?</think>"), "")
        val open = t.indexOf("<think>")
        if (open >= 0) t = t.substring(0, open) + "…"      // still thinking
        return t.replace("</think>", "").trimStart()
    }
}
